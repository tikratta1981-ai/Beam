# โครงสร้างโปรเจกต์ (Phase 1: จัดไฟล์ใหม่ตามผัง)

ย้ายไฟล์ 90 ไฟล์เข้าโฟลเดอร์ตามหมวด และแก้ import ให้อัตโนมัติ (ไม่แก้ตรรกะ)

- components/{hud,dock,panels,farm/{controls,tools,harvest,build,plots},modals/<หมวด>,3d/models/{animals,buildings,props}}
- security/{anti-cheat,storage,runtime,log}  (index.ts ยังเป็น API เดียว)
- utils/{audio,ai,generators,three}  (utils/audio/index.ts = audio.ts เดิม จึง import เดิมยังใช้ได้)
- types/index.ts รวม type ทั้งหมด (types.ts เดิม -> types/viseme.ts)
- docs/ เก็บเอกสารและไฟล์ที่ไม่ใช่โค้ด

## Phase 2 (ยังไม่ทำ ต้องมี npm install + tsc ทดสอบทีละก้อน)
App.tsx 2113 บรรทัด -> hooks/ ; FarmWorld.tsx 1477 ; FarmCharacters3D 1477 ; FishingDockModal 1235 ;
Goat3D 1130 ; Chicken3D 1046 ; data/initialData.ts 606 -> data/{crops,animals,recipes,...}
