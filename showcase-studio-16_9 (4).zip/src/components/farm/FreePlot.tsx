import React from 'react';

interface FreePlotProps {
  width: number;
  height: number;
  isReady: boolean;
}

/**
 * แปลงปลูกแบบอิสระ (เบาและไม่ใช้ WebGL) — วางได้หลายแปลง ย่อ/ขยายได้
 * แสดงร่องดินเอียงสไตล์ไอโซเมตริก พร้อมต้นอ่อน/ต้นโตตามสถานะ
 */
export const FreePlot: React.FC<FreePlotProps> = ({ width, height, isReady }) => {
  const rows = Math.max(2, Math.floor(height / 28));
  const cols = Math.max(2, Math.floor(width / 36));

  return (
    <div
      className="relative w-full h-full overflow-hidden pointer-events-none select-none"
      style={{ borderRadius: 12 }}
    >
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(135deg,#8a6a3f 0%,#6e522d 100%)',
          border: '3px solid #4f6b2a',
          borderRadius: 12,
          boxShadow: 'inset 0 0 14px rgba(0,0,0,.35), 0 4px 8px rgba(20,35,12,.3)',
        }}
      />
      <div className="absolute inset-[6px] flex flex-col justify-around">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="relative" style={{ height: 8 }}>
            <div
              className="absolute inset-x-0 top-0 h-full"
              style={{ background: '#3b2a1a', borderRadius: 6, boxShadow: '0 2px 3px rgba(0,0,0,.4)' }}
            />
            <div className="absolute inset-x-2 -top-3 flex justify-around">
              {Array.from({ length: cols }).map((__, c) => (
                <span key={c} style={{ fontSize: isReady ? 15 : 11, lineHeight: 1, opacity: isReady ? 1 : 0.85 }}>
                  {isReady ? '🌽' : '🌱'}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
