// src/components/farm/IsometricPlot3D.tsx

import React from 'react';
import { Plot } from '../../types/game';
import { CROPS } from '../../data/initialData';
import { AnimatedCrop3D } from '../3d/AnimatedCrop3D';
import { Sparkles, Zap } from 'lucide-react';

interface IsometricPlot3DProps {
  plot: Plot;
  onClick: (e: React.MouseEvent) => void;
  width?: number;
  height?: number;
  isSelected?: boolean;
  yieldCount?: number;
}

// พิกัดปักพืช 10 ต้นบนร่องดิน Isometric (แถวบน 3 ต้น + แถวกลาง 4 ต้น + แถวล่าง 3 ต้น = 10 ต้นพอดี)
const TEN_PLANTS_GRID = [
  // แถวบน (3 ต้น)
  { x: 44, y: 31, scale: 0.7, zIndex: 1, rot: -4 },
  { x: 60, y: 26, scale: 0.74, zIndex: 2, rot: 2 },
  { x: 76, y: 31, scale: 0.7, zIndex: 1, rot: 4 },

  // แถวกลาง (4 ต้น)
  { x: 30, y: 43, scale: 0.82, zIndex: 3, rot: -6 },
  { x: 50, y: 38, scale: 0.86, zIndex: 4, rot: 1 },
  { x: 70, y: 38, scale: 0.86, zIndex: 4, rot: -2 },
  { x: 90, y: 43, scale: 0.82, zIndex: 3, rot: 5 },

  // แถวล่าง (3 ต้น)
  { x: 42, y: 55, scale: 0.95, zIndex: 5, rot: -3 },
  { x: 60, y: 51, scale: 1.0, zIndex: 6, rot: 0 },
  { x: 78, y: 55, scale: 0.95, zIndex: 5, rot: 3 },
];

export const IsometricPlot3D: React.FC<IsometricPlot3DProps> = ({
  plot,
  onClick,
  width = 120,
  height = 92,
  isSelected = false,
  yieldCount = 10,
}) => {
  const cropKey = plot.cropId || (plot as any).cropType;
  const cropInfo = cropKey ? CROPS[cropKey] : null;

  return (
    <div
      data-plot-id={plot.id}
      onClick={onClick}
      style={{ width: `${width}px`, height: `${height}px` }}
      className={`relative select-none cursor-pointer group transition-all duration-150 ${
        isSelected
          ? 'ring-4 ring-amber-400 rounded-3xl scale-105'
          : plot.isReady
          ? 'hover:scale-105 active:scale-95'
          : 'hover:scale-[1.02] active:scale-95'
      }`}
    >
      {/* 1. กระบะไม้ดินยกสูง 3 มิติ */}
      <svg viewBox="0 0 120 92" className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
        <defs>
          <linearGradient id={`woodTop_${plot.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#965a25" />
            <stop offset="100%" stopColor="#784218" />
          </linearGradient>
          <linearGradient id={`woodLeft_${plot.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#5a3111" />
            <stop offset="100%" stopColor="#3d1f08" />
          </linearGradient>
          <linearGradient id={`woodRight_${plot.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#4c270d" />
            <stop offset="100%" stopColor="#2c1404" />
          </linearGradient>
          <linearGradient id={`soilBed_${plot.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={plot.watered ? '#221206' : '#3d220e'} />
            <stop offset="100%" stopColor={plot.watered ? '#351c0b' : '#522e13'} />
          </linearGradient>
        </defs>

        {/* เงาตกกระทบพื้นหญ้า */}
        <ellipse cx="60" cy="62" rx="56" ry="24" fill="rgba(18, 32, 10, 0.45)" filter="blur(4px)" />

        {/* สันกระบะไม้ด้านล่างเพื่อมิติความสูง */}
        <polygon points="10,46 60,74 60,86 10,58" fill={`url(#woodLeft_${plot.id})`} stroke="#241003" strokeWidth="0.8" />
        <polygon points="60,74 110,46 110,58 60,86" fill={`url(#woodRight_${plot.id})`} stroke="#1b0c02" strokeWidth="0.8" />

        {/* ขอบไม้กระบะบน */}
        <polygon points="60,18 110,46 60,74 10,46" fill={`url(#woodTop_${plot.id})`} stroke="#aa6930" strokeWidth="1" />

        {/* ผืนดินร่องแปลงเกษตร */}
        <polygon
          points="60,23 104,46 60,70 16,46"
          fill={`url(#soilBed_${plot.id})`}
          stroke="#1b0b03"
          strokeWidth="0.8"
        />

        {/* ร่องดินไถพรวน (Furrow Ridges) */}
        <g stroke={plot.watered ? '#150903' : '#281408'} strokeWidth="2.2" strokeLinecap="round" opacity="0.85">
          <line x1="38" y1="34" x2="82" y2="58" />
          <line x1="49" y1="28" x2="93" y2="52" />
          <line x1="27" y1="40" x2="71" y2="64" />
        </g>
        <g stroke="#6e3c1b" strokeWidth="1" strokeLinecap="round" opacity="0.45">
          <line x1="38" y1="33" x2="82" y2="57" />
          <line x1="49" y1="27" x2="93" y2="51" />
          <line x1="27" y1="39" x2="71" y2="63" />
        </g>

        {/* เสาไม้ 4 มุมแปลงเกษตร */}
        <rect x="57" y="11" width="6" height="15" rx="1.5" fill="#884d1e" stroke="#3d200b" strokeWidth="0.8" />
        <rect x="7" y="38" width="6.5" height="17" rx="1.5" fill="#754117" stroke="#321908" strokeWidth="0.8" />
        <rect x="106.5" y="38" width="6.5" height="17" rx="1.5" fill="#633612" stroke="#261205" strokeWidth="0.8" />

        {/* คานรั้วไม้ */}
        <polygon points="10,42 60,70 60,74 10,46" fill="#a8662e" stroke="#522a0f" strokeWidth="0.7" />
        <polygon points="60,70 110,42 110,46 60,74" fill="#8f5221" stroke="#45220a" strokeWidth="0.7" />

        {/* เสามุมหน้าสุด */}
        <rect x="56.5" y="66" width="7" height="19" rx="1.5" fill="#9e5d28" stroke="#3d1f0a" strokeWidth="0.8" />
        <polygon points="56.5,66 60,62 63.5,66" fill="#c47938" />
      </svg>

      {/* 2. Badge ป้ายบอกจำนวน 10 ต้น (มุมบนขวา) */}
      {cropKey && (
        <div className="absolute top-0.5 right-1 z-30 pointer-events-none">
          <div
            className={`flex items-center gap-0.5 px-2 py-0.5 rounded-full font-black text-[10px] shadow-lg border ${
              plot.isReady
                ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-stone-950 border-white animate-bounce'
                : 'bg-stone-950/90 text-emerald-300 border-emerald-500/70'
            }`}
          >
            <span>10 ต้น</span>
            <span className="font-extrabold text-[11px] text-yellow-300">(x{yieldCount})</span>
          </div>
        </div>
      )}

      {/* 3. การแสดงผลพืช 10 ต้นแน่นเต็มแปลงจริงๆ */}
      <div className="absolute inset-0 pointer-events-none overflow-visible">
        {/* กรณีแปลงว่าง */}
        {!cropKey && (
          <div className="absolute inset-0 flex flex-col items-center justify-center -translate-y-2 group-hover:scale-110 transition-transform">
            <div className="w-7 h-7 rounded-full bg-amber-950/85 border border-amber-400 shadow-md flex items-center justify-center text-amber-200 text-xs font-black">
              🌱
            </div>
            <span className="text-[10px] font-kanit font-bold text-amber-200 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] mt-0.5">
              ปลูก (10 ต้น)
            </span>
          </div>
        )}

        {/* กรณีมีพืช: ปักพืชทั้ง 10 ต้นเรียง 3 แถวเต็มกระบะดิน */}
        {cropKey && (
          <div className="relative w-full h-full">
            {TEN_PLANTS_GRID.map((pos, index) => {
              const cropSize = plot.isReady ? 48 : 34;
              const scaleModifier = plot.isReady ? pos.scale : pos.scale * 0.72;

              return (
                <div
                  key={index}
                  style={{
                    left: `${pos.x}px`,
                    top: `${pos.y}px`,
                    transform: `translate(-50%, -85%) scale(${scaleModifier}) rotate(${pos.rot}deg)`,
                    zIndex: pos.zIndex,
                  }}
                  className={`absolute origin-bottom transition-all ${
                    plot.isReady ? 'hover:scale-110' : 'opacity-90'
                  }`}
                >
                  <AnimatedCrop3D cropId={cropKey} size={cropSize} />
                </div>
              );
            })}

            {/* ป้ายบอกสถานะด้านล่าง */}
            <div className="absolute bottom-1 left-1/2 -translate-x-1/2 z-40 flex flex-col items-center">
              {/* ช่วงกำลังเติบโต */}
              {!plot.isReady && (
                <div className="bg-stone-950/90 text-amber-300 text-[9px] font-bold px-2 py-0.5 rounded-full border border-amber-400/60 flex items-center gap-1 shadow-md whitespace-nowrap">
                  <span>{cropInfo?.thaiName || 'กำลังโต'}</span>
                  <span className="text-emerald-400 font-extrabold bg-stone-900 px-1 rounded-sm">10 ต้น</span>
                  <Zap className="w-2.5 h-2.5 text-cyan-300" />
                </div>
              )}

              {/* ช่วงสุกพร้อมเก็บเกี่ยว */}
              {plot.isReady && (
                <div className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 text-stone-950 font-black text-[10px] px-2.5 py-0.5 rounded-full border-2 border-white shadow-xl flex items-center gap-1 whitespace-nowrap animate-bounce">
                  <Sparkles className="w-2.5 h-2.5 text-amber-800" />
                  <span>เกี่ยว 10 ต้น!</span>
                  <span className="bg-amber-950 text-yellow-300 px-1.5 py-0.2 rounded-full text-[9px] font-black border border-amber-300">
                    +{yieldCount}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ออร่าสีทองหนาแน่นเมื่อสุกเต็มที่ทั้ง 10 ต้น */}
      {plot.isReady && (
        <div className="absolute inset-x-2 bottom-3 h-11 bg-yellow-400/30 rounded-full blur-md pointer-events-none animate-pulse" />
      )}
    </div>
  );
};