import React from 'react';
import { RotateCw, Trash2, FlipHorizontal, Check } from 'lucide-react';

interface EntityToolbarProps {
  onRotate?: () => void;
  onFlip?: () => void;
  onDelete: () => void;
  onConfirm: () => void;
}

export const EntityToolbar: React.FC<EntityToolbarProps> = ({
  onRotate,
  onFlip,
  onDelete,
  onConfirm,
}) => {
  return (
    <>
      {onRotate && (
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            onRotate();
          }}
          className="absolute -top-3.5 -left-3.5 z-50 w-8 h-8 bg-amber-600 hover:bg-amber-500 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform hover:scale-110 active:scale-95 cursor-pointer"
          title="หมุน 90 องศา"
        >
          <RotateCw className="w-4 h-4" />
        </button>
      )}

      <button
        type="button"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
        className="absolute -top-3.5 -right-3.5 z-50 w-8 h-8 bg-red-600 hover:bg-red-500 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform hover:scale-110 active:scale-95 cursor-pointer"
        title="ลบสิ่งนี้"
      >
        <Trash2 className="w-4 h-4" />
      </button>

      {onFlip && (
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            onFlip();
          }}
          className="absolute -bottom-3.5 -left-3.5 z-50 w-8 h-8 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform hover:scale-110 active:scale-95 cursor-pointer"
          title="พลิกด้านซ้าย-ขวา"
        >
          <FlipHorizontal className="w-4 h-4" />
        </button>
      )}

      <button
        type="button"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => {
          e.stopPropagation();
          onConfirm();
        }}
        className="absolute -bottom-3.5 -right-3.5 z-50 w-8 h-8 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform hover:scale-110 active:scale-95 cursor-pointer"
        title="ยืนยันตำแหน่งนี้"
      >
        <Check className="w-[18px] h-[18px]" />
      </button>
    </>
  );
};
