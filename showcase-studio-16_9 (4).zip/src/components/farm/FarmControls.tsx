import React, { useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Users,
  Grid,
  Layers,
  Check,
  Move,
  Wand2,
  Menu,
  X,
  Sprout,
} from 'lucide-react';

interface FarmControlsProps {
  isEditMode: boolean;
  onToggleEditMode: () => void;
  snapToGrid: boolean;
  onToggleSnapToGrid: () => void;
  onAutoArrange: () => void;
  onOpenCatalog: () => void;
  onAddFreePlot: () => void;
  showCharacters3D: boolean;
  onToggleCharacters3D: () => void;
  timeOfDay?: 'day' | 'twilight' | 'night';
  onToggleTimeOfDay?: () => void;
  userZoom: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetView: () => void;
}

export const FarmControls: React.FC<FarmControlsProps> = ({
  isEditMode,
  onToggleEditMode,
  snapToGrid,
  onToggleSnapToGrid,
  onAutoArrange,
  onOpenCatalog,
  onAddFreePlot,
  showCharacters3D,
  onToggleCharacters3D,
  timeOfDay = 'day',
  onToggleTimeOfDay,
  userZoom,
  onZoomIn,
  onZoomOut,
  onResetView,
}) => {
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  return (
    <>
      {/* เมนูฟาร์มแบบพับเก็บได้ (ซ้ายกลางจอ) */}
      <div
        onPointerDown={(e) => e.stopPropagation()}
        className="farm-toolbar-top interactive-target absolute top-1/2 left-4 -translate-y-[18px] z-[90] flex flex-col items-start gap-2 pointer-events-auto"
      >
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setMenuOpen((v) => !v);
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl shadow-2xl font-black text-xs transition-transform active:scale-95 border-2 cursor-pointer ${
            isEditMode
              ? 'bg-emerald-500 text-white border-white animate-pulse'
              : 'bg-stone-900/85 text-amber-200 border-amber-400/80 hover:bg-stone-800'
          }`}
          title={menuOpen ? 'ซ่อนเมนู' : 'เปิดเมนูฟาร์ม'}
        >
          {menuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>{menuOpen ? 'ซ่อนเมนู' : isEditMode ? 'กำลังจัดฟาร์ม' : 'เมนูฟาร์ม'}</span>
        </button>

        {menuOpen && (
          <div className="flex flex-col gap-2 p-2 rounded-2xl bg-stone-900/85 border-2 border-amber-400/60 shadow-2xl backdrop-blur-sm min-w-[170px]">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenCatalog();
                setMenuOpen(false);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-black text-xs transition-transform active:scale-95 border-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-900 border-white hover:brightness-110 cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>🏗️ สิ่งก่อสร้าง</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onAddFreePlot();
                setMenuOpen(false);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-black text-xs transition-transform active:scale-95 border-2 bg-gradient-to-r from-lime-500 to-green-600 text-white border-lime-200 hover:brightness-110 cursor-pointer"
              title="เพิ่มแปลงปลูกแบบอิสระ วางตรงไหนก็ได้ ย่อ/ขยายได้"
            >
              <Sprout className="w-4 h-4" />
              <span>เพิ่มแปลงปลูกอิสระ</span>
            </button>

            {isEditMode && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAutoArrange();
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-black text-xs transition-transform active:scale-95 border-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-300 hover:brightness-110 cursor-pointer"
                  title="จัดของทั้งหมดเข้าตำแหน่งผังมาตรฐานอัตโนมัติ"
                >
                  <Wand2 className="w-4 h-4" />
                  <span className="tb-label">จัดผังอัตโนมัติ</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSnapToGrid();
                  }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl font-black text-xs transition-transform active:scale-95 border-2 cursor-pointer ${
                    snapToGrid
                      ? 'bg-cyan-600 text-white border-cyan-300'
                      : 'bg-stone-800 text-stone-300 border-stone-600 hover:bg-stone-700'
                  }`}
                  title="จัดแนวเข้าช่องกริด 32px"
                >
                  <Grid className="w-4 h-4" />
                  <span className="tb-label">{snapToGrid ? 'Snap: เปิด' : 'Snap: ปิด'}</span>
                </button>
              </>
            )}

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleEditMode();
                if (isEditMode) setMenuOpen(false);
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-black text-xs transition-transform active:scale-95 border-2 cursor-pointer ${
                isEditMode
                  ? 'bg-emerald-500 text-white border-white'
                  : 'bg-stone-800 text-amber-200 border-amber-400/80 hover:bg-stone-700'
              }`}
            >
              {isEditMode ? <Check className="w-4 h-4" /> : <Move className="w-4 h-4 text-amber-300" />}
              <span>{isEditMode ? 'บันทึกตำแหน่ง' : 'จัดวางฟาร์ม'}</span>
            </button>
          </div>
        )}
      </div>

      {isEditMode && (
        <div className="farm-edit-hint absolute top-20 left-1/2 -translate-x-1/2 z-[85] bg-stone-900/90 text-yellow-300 border-2 border-yellow-400 px-4 py-1.5 rounded-full text-xs font-bold shadow-2xl pointer-events-none flex items-center gap-2">
          <span>✨ ลากเตาอบ 3D และแปลงข้าวโพด 3D ไปวางที่ไหนก็ได้ | 🔄 หมุน 90°</span>
        </div>
      )}

      {/* แถบปุ่มซูมและควบคุมมุมมอง (ล่างขวา) */}
      <div
        onPointerDown={(e) => e.stopPropagation()}
        className="farm-zoom-col interactive-target absolute right-4 bottom-24 z-[80] flex flex-col gap-2 pointer-events-auto"
      >
        <button
          type="button"
          onClick={onToggleCharacters3D}
          className={`w-9 h-9 rounded-full border flex items-center justify-center shadow-lg active:scale-95 transition-all cursor-pointer ${
            showCharacters3D
              ? 'bg-amber-500/90 border-amber-300 text-stone-900 font-bold'
              : 'bg-stone-900/80 border-stone-600 text-stone-400 hover:text-white'
          }`}
          title={showCharacters3D ? 'ซ่อนตัวละคร 3D' : 'แสดงตัวละคร 3D'}
        >
          <Users className="w-4 h-4" />
        </button>
        {onToggleTimeOfDay && (
          <button
            type="button"
            onClick={onToggleTimeOfDay}
            className="w-9 h-9 rounded-full bg-stone-900/80 border border-amber-400/70 flex items-center justify-center text-sm shadow-lg active:scale-95 transition-all cursor-pointer"
            title={
              timeOfDay === 'day'
                ? 'ช่วงเวลา: กลางวัน ☀️ (คลิกเพื่อเปลี่ยนเป็นยามเย็น)'
                : timeOfDay === 'twilight'
                ? 'ช่วงเวลา: ยามเย็น 🌅 (คลิกเพื่อเปลี่ยนเป็นกลางคืน)'
                : 'ช่วงเวลา: กลางคืน 🌙 (คลิกเพื่อเปลี่ยนเป็นกลางวัน)'
            }
          >
            <span>{timeOfDay === 'day' ? '☀️' : timeOfDay === 'twilight' ? '🌅' : '🌙'}</span>
          </button>
        )}
        <button
          type="button"
          onClick={onZoomIn}
          className="w-9 h-9 rounded-full bg-stone-900/80 border border-amber-400/70 flex items-center justify-center text-amber-200 hover:text-white shadow-lg active:scale-95 transition-all cursor-pointer"
          title="ซูมเข้า"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          type="button"
          onClick={onZoomOut}
          className="w-9 h-9 rounded-full bg-stone-900/80 border border-amber-400/70 flex items-center justify-center text-amber-200 hover:text-white shadow-lg active:scale-95 transition-all cursor-pointer"
          title="ซูมออก"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          type="button"
          onClick={onResetView}
          className="w-9 h-9 rounded-full bg-stone-900/80 border border-amber-400/70 flex items-center justify-center text-amber-200 hover:text-white shadow-lg active:scale-95 transition-all cursor-pointer"
          title="รีเซ็ตมุมกล้อง"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
        <div className="text-[10px] text-center font-bold bg-stone-900/80 text-amber-300 px-1 py-0.5 rounded border border-amber-400/40">
          {Math.round(userZoom * 100)}%
        </div>
      </div>
    </>
  );
};
