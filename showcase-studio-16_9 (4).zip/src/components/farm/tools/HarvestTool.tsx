// src/components/farm/HarvestTool.tsx

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { sound } from '../../../utils/audio/index';

interface HarvestToolProps {
  isActive?: boolean;
  onToggleTool?: (active: boolean) => void;
  readyCount?: number;
  onHarvestAll?: () => void;
}

type SwingPhase = 'idle' | 'windup' | 'accel' | 'follow' | 'recovery';

const SWING_POSES: Record<SwingPhase, { body: number; sickle: number; ms: number }> = {
  idle: { body: 0, sickle: 0, ms: 100 },
  windup: { body: -15, sickle: -55, ms: 60 },
  accel: { body: 10, sickle: -10, ms: 70 },
  follow: { body: 32, sickle: 85, ms: 80 },
  recovery: { body: 0, sickle: 0, ms: 60 },
};

const HIT_FRAME_MS = 130;
const SWING_TOTAL_MS = 270;

export const HarvestTool: React.FC<HarvestToolProps> = ({
  isActive = false,
  onToggleTool,
  readyCount = 0,
  onHarvestAll,
}) => {
  const [pointerPos, setPointerPos] = useState<{ x: number; y: number } | null>(null);
  const [mounted, setMounted] = useState(false);
  const [phase, setPhase] = useState<SwingPhase>('idle');
  const [hitFlash, setHitFlash] = useState<boolean>(false);

  const swingStartRef = useRef<number | null>(null);
  const swingTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  const clearSwingTimers = useCallback(() => {
    swingTimersRef.current.forEach(clearTimeout);
    swingTimersRef.current = [];
  }, []);

  const triggerSwingAnimation = useCallback(() => {
    const now = performance.now();
    if (swingStartRef.current !== null && now - swingStartRef.current < HIT_FRAME_MS) return;

    clearSwingTimers();
    swingStartRef.current = now;
    setPhase('windup');
    const at = (ms: number, fn: () => void) => swingTimersRef.current.push(setTimeout(fn, ms));
    at(60, () => setPhase('accel'));
    at(HIT_FRAME_MS, () => {
      setPhase('follow');
      setHitFlash(true);
    });
    at(HIT_FRAME_MS + 60, () => setHitFlash(false));
    at(210, () => setPhase('recovery'));
    at(SWING_TOTAL_MS, () => {
      setPhase('idle');
      swingStartRef.current = null;
    });
  }, [clearSwingTimers]);

  useEffect(() => clearSwingTimers, [clearSwingTimers]);
  useEffect(() => {
    setMounted(true);
  }, []);

  // ติดตามพิกัดของเมาส์/นิ้วเพื่อขยับตัวละครถือเคียว
  useEffect(() => {
    if (!isActive) {
      setPointerPos(null);
      clearSwingTimers();
      setPhase('idle');
      return;
    }

    const handlePointerMove = (e: PointerEvent) => {
      setPointerPos({ x: e.clientX, y: e.clientY });
    };

    const handlePointerDown = (e: PointerEvent) => {
      setPointerPos({ x: e.clientX, y: e.clientY });
      triggerSwingAnimation();
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerdown', handlePointerDown);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerdown', handlePointerDown);
    };
  }, [isActive, triggerSwingAnimation, clearSwingTimers]);

  const handleToggle = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    try {
      sound.playClick();
    } catch {}
    const next = !isActive;
    if (next) {
      const rect = e.currentTarget.getBoundingClientRect();
      setPointerPos({ x: rect.left + rect.width / 2, y: Math.max(60, rect.top + rect.height / 2) });
    }
    onToggleTool?.(next);
  };

  const pose = SWING_POSES[phase];

  return (
    <>
      <div className="flex flex-col items-end gap-2">
        <div className="relative">
          <button
            type="button"
            data-harvest-btn="true"
            onClick={handleToggle}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full shadow-lg border-2 transition-all active:scale-95 touch-manipulation cursor-pointer select-none ${
              isActive
                ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-white text-stone-900 ring-4 ring-yellow-300/70 scale-105'
                : 'bg-stone-900/90 border-amber-500/80 text-amber-200 hover:bg-stone-800'
            }`}
            title="โหมดเคียวเก็บเกี่ยว (กดแล้วปัดฟันแปลงพืช)"
          >
            <span className="text-xl pointer-events-none">🌾</span>
            <span className="text-xs font-black tracking-wide pointer-events-none">
              {isActive ? 'กำลังถือเคียว' : 'เลือกเคียว'}
            </span>
          </button>
          {readyCount > 0 && (
            <span
              className="absolute -top-2 -right-2 min-w-[22px] h-[22px] px-1 rounded-full bg-red-600 border-2 border-white text-white text-[11px] font-black flex items-center justify-center shadow-lg pointer-events-none"
              aria-label={`พร้อมเกี่ยว ${readyCount} แปลง`}
            >
              {readyCount > 99 ? '99+' : readyCount}
            </span>
          )}
        </div>

        {isActive && onHarvestAll && readyCount > 0 && (
          <button
            type="button"
            data-harvest-btn="true"
            onClick={(e) => {
              e.stopPropagation();
              onHarvestAll();
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full shadow-lg border-2 border-white bg-gradient-to-r from-red-600 to-orange-500 text-white active:scale-95 touch-manipulation cursor-pointer select-none"
            title="เกี่ยวทุกแปลงที่สุกแบบคอมโบต่อเนื่อง"
          >
            <span className="text-lg pointer-events-none">⚡</span>
            <span className="text-xs font-black tracking-wide pointer-events-none">เกี่ยวยกแปลง</span>
          </button>
        )}
      </div>

      {mounted && isActive && pointerPos && createPortal(
        <div
          className="fixed pointer-events-none select-none z-[999999]"
          style={{
            left: `${pointerPos.x}px`,
            top: `${pointerPos.y}px`,
            transform: 'translate(-50%, -70%)',
          }}
        >
          <div
            className="relative"
            style={{
              transform: `rotate(${pose.body}deg)`,
              transformOrigin: '50% 100%',
              transition: `transform ${pose.ms}ms ${phase === 'accel' ? 'ease-in' : 'ease-out'}`,
              willChange: 'transform',
            }}
          >
            <span className="block text-5xl leading-none drop-shadow-[0_8px_12px_rgba(0,0,0,0.55)]">🧑‍🌾</span>

            <svg
              viewBox="0 0 48 48"
              width="44"
              height="44"
              className="absolute"
              style={{
                left: '70%',
                top: '10%',
                transform: `rotate(${pose.sickle}deg) scale(${hitFlash ? 1.15 : 1})`,
                transformOrigin: '15% 90%',
                transition: `transform ${pose.ms}ms ${phase === 'accel' ? 'ease-in' : 'ease-out'}`,
                willChange: 'transform',
                filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.5))',
              }}
            >
              <line x1="8" y1="42" x2="24" y2="24" stroke="#8b5a2b" strokeWidth="5" strokeLinecap="round" />
              <path
                d="M22 26 C 22 8, 40 6, 45 14 C 36 12, 30 18, 28 31 Z"
                fill="#e2e8f0"
                stroke="#475569"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
            </svg>

            {(phase === 'accel' || phase === 'follow') && (
              <div className="absolute left-[55%] top-[20%] w-16 h-1.5 bg-gradient-to-r from-transparent via-yellow-200 to-white rounded-full blur-[1px] rotate-45" />
            )}

            {phase === 'windup' && (
              <div className="absolute top-0 right-0 w-3.5 h-3.5 bg-yellow-300 rounded-full blur-[1px] animate-ping" />
            )}
          </div>
        </div>,
        document.body
      )}
    </>
  );
};