import React from 'react';
import { Sparkles, X } from 'lucide-react';
import { CatalogItem, UNIQUE_FACILITY_TYPES, PlacedEntity } from '../../data/farmWorldData';

interface BuildableCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  placedItems: PlacedEntity[];
  failedImages: Record<string, boolean>;
  onImageError: (key: string) => void;
  catalog: CatalogItem[];
  onSpawnItem: (item: CatalogItem, e: React.MouseEvent) => void;
}

export const BuildableCatalogModal: React.FC<BuildableCatalogModalProps> = ({
  isOpen,
  onClose,
  placedItems,
  failedImages,
  onImageError,
  catalog,
  onSpawnItem,
}) => {
  if (!isOpen) return null;

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      onClick={onClose}
      className="interactive-target absolute inset-0 z-[100] flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 pointer-events-auto"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-4xl bg-stone-900 border-4 border-amber-500 rounded-3xl p-5 shadow-2xl text-white"
      >
        <div className="flex items-center justify-between border-b border-amber-500/30 pb-3 mb-4">
          <div className="flex items-center gap-2 text-amber-300 font-black text-base sm:text-lg">
            <Sparkles className="w-6 h-6 text-yellow-400" />
            <span>เลือกสิ่งก่อสร้าง สัตว์ และของตกแต่งฟาร์ม</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-stone-800 hover:bg-red-600 text-stone-300 hover:text-white flex items-center justify-center border border-stone-600 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-4 pt-1 px-1">
          {catalog.map((item) => {
            const isUniqueAndPlaced =
              UNIQUE_FACILITY_TYPES.has(item.type) &&
              placedItems.some((p) => p.type === item.type);

            return (
              <div
                key={item.type}
                onClick={(e) => !isUniqueAndPlaced && onSpawnItem(item, e)}
                className={`flex-shrink-0 w-32 p-3 rounded-2xl flex flex-col items-center justify-between transition-all shadow-lg border-2 ${
                  isUniqueAndPlaced
                    ? 'bg-stone-800/40 border-stone-700 opacity-50 cursor-not-allowed'
                    : 'bg-stone-800/90 hover:bg-stone-700 border-amber-500/40 hover:border-amber-400 cursor-pointer group hover:scale-105 active:scale-95'
                }`}
              >
                <div className="w-20 h-20 rounded-xl bg-black/40 flex items-center justify-center mb-2 overflow-hidden relative">
                  {item.imgSrc && !failedImages[`catalog_${item.type}`] ? (
                    <img
                      src={item.imgSrc}
                      alt={item.name}
                      onError={() => onImageError(`catalog_${item.type}`)}
                      className="w-full h-full object-contain drop-shadow"
                    />
                  ) : (
                    <span className="text-4xl group-hover:scale-110 transition-transform">
                      {item.icon}
                    </span>
                  )}
                </div>
                <span className="text-xs font-bold text-amber-200 text-center leading-tight mb-2">
                  {item.name}
                </span>
                <span
                  className={`text-[10px] font-bold px-3 py-1 rounded-full border shadow ${
                    isUniqueAndPlaced
                      ? 'bg-stone-700 text-stone-400 border-stone-600'
                      : 'text-stone-900 bg-amber-400 group-hover:bg-yellow-300 border-amber-300'
                  }`}
                >
                  {isUniqueAndPlaced ? 'สร้างแล้ว' : '+ วางลงฟาร์ม'}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
