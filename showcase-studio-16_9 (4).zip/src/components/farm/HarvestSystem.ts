// src/components/farm/HarvestSystem.ts

import { Plot } from '../../types/game';
import { sound } from '../../utils/audio';

export interface HarvestHitResult {
  plotId: number;
  x: number;
  y: number;
  cropType: string;
  combo?: number;
}

export class HarvestSystem {
  private harvestedThisSwipe: Set<number> = new Set();
  private pendingPlots: Set<number> = new Set();
  private isSwiping: boolean = false;
  private comboCount: number = 0;
  private comboTimer: ReturnType<typeof setTimeout> | null = null;

  // Debounce Save: เซฟหลังปล่อยนิ้ว 1.5 วินาที (ไม่เซฟกลางการปัด)
  private dirty: boolean = false;
  private idleTimer: ReturnType<typeof setTimeout> | null = null;
  private onIdle: (() => void) | null = null;

  // Hit Frame: Windup 60ms + Swing Accel 70ms = 130ms
  public static readonly HIT_FRAME_MS = 130;
  public static readonly COMBO_RESET_MS = 1500;
  public static readonly SAVE_DEBOUNCE_MS = 1500;

  public getComboCount(): number {
    return this.comboCount;
  }

  public static comboLabel(combo: number): string | null {
    if (combo >= 5) return '🔥 คมกริบ x5! เซียนเคียว';
    if (combo === 4) return 'เกี่ยวต่อเนื่อง x4!';
    if (combo === 3) return 'ฟันเร็ว x3!';
    if (combo === 2) return 'สับคม x2';
    return null;
  }

  /** ลงทะเบียน callback ที่จะถูกเรียก 1.5 วินาทีหลังปล่อยนิ้ว (ถ้ามีการเก็บเกี่ยวเกิดขึ้น) */
  public setOnIdle(cb: (() => void) | null): void {
    this.onIdle = cb;
  }

  /** true ระหว่างปัดเคียว / รอ Hit Frame / รอ debounce — ใช้ให้ระบบเซฟเว้นช่วงนี้ */
  public isBusy(): boolean {
    return this.isSwiping || this.pendingPlots.size > 0 || this.idleTimer !== null;
  }

  // เริ่มต้นการปัดเคียว
  public startSwipe(): void {
    this.isSwiping = true;
    this.harvestedThisSwipe.clear();
    if (this.idleTimer) {
      clearTimeout(this.idleTimer);
      this.idleTimer = null;
    }
  }

  // ปล่อยนิ้ว / จบการปัด
  public endSwipe(): void {
    this.isSwiping = false;
    this.harvestedThisSwipe.clear();
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => {
      this.idleTimer = null;
      if (this.pendingPlots.size > 0) {
        this.endSwipe(); // ยังมี Hit Frame ค้าง รอรอบถัดไป
        return;
      }
      if (this.dirty) {
        this.dirty = false;
        try {
          this.onIdle?.();
        } catch {}
      }
    }, HarvestSystem.SAVE_DEBOUNCE_MS);
  }

  public getIsSwiping(): boolean {
    return this.isSwiping;
  }

  /**
   * ตรวจสอบว่าแปลงพร้อมเก็บหรือไม่ และตัดผลผลิตตามลำดับ Hit Frame
   */
  public checkAndHarvest(
    plotId: number,
    plot: Plot,
    onHarvest: (plotId: number) => void,
    onSuccess?: (res: HarvestHitResult) => void
  ): boolean {
    // รองรับทั้ง cropId และ cropType
    const cropType = (plot as any).cropType || plot.cropId || 'wheat';

    if (!plot.isReady || this.harvestedThisSwipe.has(plotId) || this.pendingPlots.has(plotId)) {
      return false;
    }

    this.harvestedThisSwipe.add(plotId);
    this.pendingPlots.add(plotId);

    // นับคอมโบ (รีเซ็ตถ้าหยุดเกี่ยวเกิน 1.5 วินาที)
    this.comboCount += 1;
    const combo = this.comboCount;
    if (this.comboTimer) clearTimeout(this.comboTimer);
    this.comboTimer = setTimeout(() => {
      this.comboCount = 0;
    }, HarvestSystem.COMBO_RESET_MS);

    // ตัดผลผลิตจริงที่ Hit Frame (130ms) เท่านั้น ไม่หักล่วงหน้า
    setTimeout(() => {
      try {
        sound.playSickleSlice();
        sound.playComboSound(combo);
      } catch {}
      try {
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(15);
      } catch {}

      onHarvest(plotId);
      this.dirty = true;

      if (onSuccess) {
        onSuccess({ plotId, x: 0, y: 0, cropType, combo });
      }

      setTimeout(() => this.pendingPlots.delete(plotId), 120);
    }, HarvestSystem.HIT_FRAME_MS);

    return true;
  }
}

export const harvestSystem = new HarvestSystem();