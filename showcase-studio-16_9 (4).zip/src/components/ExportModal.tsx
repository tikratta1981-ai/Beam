import React, { useState } from 'react';
import { globalVideoExporter } from '../export/video-exporter';
import { generateFacebookShareUrl, DEFAULT_SHARE_META, capturePosterFrame } from '../export/fb-share';
import { Video, Download, Share2, X, CheckCircle, AlertCircle, Play, Film } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  recordedBlob: { blob: Blob; url: string; mimeType: string } | null;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  recordedBlob,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const fileSizeMB = recordedBlob ? (recordedBlob.blob.size / (1024 * 1024)).toFixed(2) : '0';

  const handleDownload = () => {
    if (!recordedBlob) return;
    const ext = recordedBlob.mimeType.includes('mp4') ? 'mp4' : 'webm';
    globalVideoExporter.downloadVideo(recordedBlob.url, `showcase-studio-16-9-${Date.now()}.${ext}`);
  };

  const handleFacebookShare = () => {
    const url = generateFacebookShareUrl(window.location.href, DEFAULT_SHARE_META.title);
    window.open(url, '_blank', 'width=620,height=520');
  };

  const handleCopyShareText = () => {
    const text = `${DEFAULT_SHARE_META.title}\n${DEFAULT_SHARE_META.description}\n\n${DEFAULT_SHARE_META.hashtags.join(' ')}\n${window.location.href}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <Film className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-base text-neutral-100">
              16:9 VIDEO EXPORT & SOCIAL SHARE
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col gap-5 max-h-[80dvh] overflow-y-auto">
          {recordedBlob ? (
            <>
              {/* Video Player */}
              <div className="w-full aspect-video bg-black rounded-xl overflow-hidden border border-neutral-800 relative">
                <video
                  src={recordedBlob.url}
                  controls
                  autoPlay
                  loop
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Validation Status */}
              <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800 flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle className="w-4 h-4" />
                  <span>EXPORT VALIDATED (MP4/H.264 Fast-Start)</span>
                </div>
                <div className="flex items-center gap-4 text-neutral-400">
                  <span>MIME: <strong className="text-neutral-200">{recordedBlob.mimeType}</strong></span>
                  <span>SIZE: <strong className="text-neutral-200">{fileSizeMB} MB</strong></span>
                  <span>ASPECT: <strong className="text-cyan-400">16:9</strong></span>
                </div>
              </div>

              {/* Actions: Download & Facebook */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  id="btn-download-video"
                  onClick={handleDownload}
                  className="py-3 px-4 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-cyan-900/30 transition"
                >
                  <Download className="w-4 h-4" /> ดาวน์โหลดไฟล์วิดีโอ (Download MP4)
                </button>

                <button
                  id="btn-facebook-share"
                  onClick={handleFacebookShare}
                  className="py-3 px-4 bg-[#1877F2] hover:bg-[#166fe5] text-white font-semibold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-blue-900/30 transition"
                >
                  <Share2 className="w-4 h-4" /> แชร์ไปยัง Facebook
                </button>
              </div>

              {/* Social Metadata Card */}
              <div className="bg-neutral-950/80 p-4 rounded-xl border border-neutral-800/80 flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-300">
                    SOCIAL MEDIA PREVIEW & HASHTAGS
                  </span>
                  <button
                    onClick={handleCopyShareText}
                    className="text-xs text-cyan-400 hover:text-cyan-300 transition"
                  >
                    {copied ? '✓ คัดลอกแล้ว!' : 'คัดลอกข้อความแชร์'}
                  </button>
                </div>
                <div className="text-xs text-neutral-400 bg-neutral-900/80 p-3 rounded-lg border border-neutral-800 font-sans leading-relaxed">
                  <div className="font-semibold text-neutral-200 mb-1">{DEFAULT_SHARE_META.title}</div>
                  <div className="text-[11px] mb-2">{DEFAULT_SHARE_META.description}</div>
                  <div className="text-[10px] text-cyan-400 font-mono">{DEFAULT_SHARE_META.hashtags.join(' ')}</div>
                </div>
              </div>
            </>
          ) : (
            <div className="py-12 flex flex-col items-center justify-center text-center gap-3 text-neutral-500">
              <AlertCircle className="w-10 h-10 text-neutral-600" />
              <p className="text-sm">ยังไม่มีคลิปวิดีโอที่บันทึก กรุณากดปุ่ม <strong>REC</strong> บนแถบควบคุมเพื่อบันทึกวิดีโอ 16:9</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
