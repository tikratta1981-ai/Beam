import React from 'react';

export interface ToastData {
  message: string;
  type: 'info' | 'error' | 'success';
}

interface ToastProps {
  toast: ToastData | null;
}

export const Toast: React.FC<ToastProps> = ({ toast }) => {
  if (!toast) return null;

  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 pointer-events-none transition-all duration-300">
      <div
        className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl shadow-2xl border-2 text-xs sm:text-sm font-black ${
          toast.type === 'error'
            ? 'bg-red-950/95 text-red-200 border-red-500 shadow-red-900/50'
            : toast.type === 'success'
            ? 'bg-emerald-950/95 text-emerald-200 border-emerald-400 shadow-emerald-900/50'
            : 'game-wood-board text-amber-200 border-amber-400 shadow-amber-900/50'
        }`}
      >
        <span className="text-base">
          {toast.type === 'error' ? '⚠️' : toast.type === 'success' ? '✨' : '📢'}
        </span>
        <span>{toast.message}</span>
      </div>
    </div>
  );
};
