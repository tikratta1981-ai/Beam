import React, { useState, useRef } from 'react';
import { Camera, Settings } from 'lucide-react';
import { sound } from '../utils/audio';

export interface PlayerHeaderProps {
  farmName?: string;
  level?: number;
  xp?: number;
  maxXp?: number;
  onOpenSettings?: () => void;
}

export const PlayerHeader: React.FC<PlayerHeaderProps> = ({
  farmName = 'My Cozy Farm',
  level = 1,
  xp = 0,
  maxXp = 100,
  onOpenSettings,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // ดึงรูปโปรไฟล์ที่บันทึกไว้ใน LocalStorage หากไม่มีให้ใช้รูปชาวไร่เริ่มต้น
  const [avatarSrc, setAvatarSrc] = useState<string>(() => {
    try {
      const savedAvatar = localStorage.getItem('beam_farm_player_avatar');
      if (savedAvatar) return savedAvatar;
    } catch {}
    return '/avatar.png'; // 👈 รูปเริ่มต้นในโฟลเดอร์ public/
  });

  // คลิกที่วงกลมรูปเพื่อเปิดหน้าต่างเลือกไฟล์
  const handleAvatarClick = () => {
    try { sound.playClick(); } catch {}
    fileInputRef.current?.click();
  };

  // จัดการเมื่อผู้ใช้เลือกไฟล์รูปภาพใหม่
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('กรุณาเลือกไฟล์รูปภาพเท่านั้นครับ (PNG, JPG, WebP)');
      return;
    }

    // จำกัดขนาดรูปไม่เกิน 5MB
    if (file.size > 5 * 1024 * 1024) {
      alert('ไฟล์รูปภาพมีขนาดใหญ่เกินไป (ไม่ควรเกิน 5MB)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Data = event.target?.result as string;
      if (base64Data) {
        setAvatarSrc(base64Data);
        try {
          localStorage.setItem('beam_farm_player_avatar', base64Data);
          try { sound.playSuccessChime(); } catch {}
        } catch (err) {
          console.warn('LocalStorage เต็มหรือไม่สามารถบันทึกได้:', err);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // คำนวณเปอร์เซ็นต์หลอด EXP
  const xpPercentage = Math.min(100, Math.max(0, (xp / maxXp) * 100));

  return (
    <div className="relative inline-flex items-center select-none filter drop-shadow-lg">
      {/* Input File ที่ซ่อนไว้ สำหรับเลือกรูป */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* แถบกล่องไม้สีน้ำตาลหลัก */}
      <div className="flex items-center bg-[#543318] border-[3px] border-[#381d09] rounded-2xl pl-16 pr-3 py-1.5 min-w-[260px] max-w-[340px] shadow-2xl">
        <div className="flex flex-col flex-1 mr-2">
          {/* ชื่อฟาร์ม */}
          <span className="text-white font-black text-sm tracking-wide drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)] truncate">
            {farmName}
          </span>

          {/* แถบหลอด XP สีดำเข้ม */}
          <div className="relative w-full h-4 bg-[#231206] rounded-full overflow-hidden border border-[#3e1f0a] flex items-center justify-center mt-0.5">
            {/* สีหลอดความคืบหน้า EXP (เกรเดียนท์เหลืองส้ม) */}
            <div
              className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-300"
              style={{ width: `${xpPercentage}%` }}
            />
            {/* ตัวเลข XP เช่น 0 / 100 XP */}
            <span className="relative z-10 text-[10px] font-black text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] tracking-wider">
              {xp} / {maxXp} XP
            </span>
          </div>
        </div>

        {/* ปุ่มไอคอนฟันเฟืองตั้งค่า ⚙️ */}
        <button
          type="button"
          onClick={() => {
            try { sound.playClick(); } catch {}
            onOpenSettings?.();
          }}
          className="text-[#ecd0a4] hover:text-white p-1 rounded-lg hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
          title="ตั้งค่าเกม"
        >
          <Settings className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>

      {/* วงกลมรูปโปรไฟล์ (ยื่นซ้อนออกมาทางซ้าย) */}
      <div
        onClick={handleAvatarClick}
        className="group absolute -left-2 top-1/2 -translate-y-1/2 w-14 h-14 rounded-full border-[3px] border-[#ffb612] bg-[#2d180a] shadow-xl cursor-pointer transition-transform hover:scale-105 active:scale-95 z-20"
        title="คลิกเพื่ออัปโหลดรูปโปรไฟล์ตัวเอง"
      >
        {/* คอนเทนเนอร์รูปภาพ */}
        <div className="w-full h-full rounded-full overflow-hidden relative">
          <img
            src={avatarSrc}
            alt="Farmer Avatar"
            className="w-full h-full object-cover select-none pointer-events-none"
            onError={(e) => {
              // หากรูปโหลดไม่ติด ให้ใช้ภาพสำรอง
              (e.target as HTMLImageElement).src = '/buildings/farmhouse.png';
            }}
          />

          {/* โอเวอร์เลย์ไอคอนกล้อง 📷 เมื่อเอาเมาส์ชี้ */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white">
            <Camera className="w-4 h-4 drop-shadow" />
            <span className="text-[7px] font-black mt-0.5 tracking-tighter">เปลี่ยนรูป</span>
          </div>
        </div>

        {/* ป้ายแสดงเลเวล (Lv. 1) สีเหลืองขอบเข้ม */}
        <div className="absolute -bottom-1 -left-1 bg-gradient-to-b from-[#ffcf25] to-[#f39c12] text-stone-950 border-[2px] border-[#381d09] text-[10px] font-black px-1.5 py-0.2 rounded-full shadow-md leading-tight">
          Lv. {level}
        </div>
      </div>
    </div>
  );
};

export default PlayerHeader;