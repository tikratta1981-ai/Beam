import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../utils/audio';
import { setupRealisticLighting, getWoodPBRTexture } from '../../utils/threeTextures';

export interface Tree3DProps {
  fruitReady: boolean;
  onPick?: () => void;
  seamless?: boolean;
  className?: string;
}

export const Tree3D: React.FC<Tree3DProps> = ({
  fruitReady,
  onPick,
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);
  const applesRef = useRef<THREE.Mesh[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 140;
    const height = container.clientHeight || 160;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.5, 6.2);
    camera.lookAt(0, 1.2, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    const ambientLight = new THREE.AmbientLight(0xf0fdf4, 1.3);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffae6, 1.8);
    sunLight.position.set(5, 10, 5);
    sunLight.castShadow = true;
    scene.add(sunLight);

    // ลำต้นไม้ 3D (Tree Trunk)
    const trunkMat = track(new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 }));
    const trunk = new THREE.Mesh(track(new THREE.CylinderGeometry(0.18, 0.28, 1.4, 8)), trunkMat);
    trunk.position.y = 0.7;
    trunk.castShadow = true;
    scene.add(trunk);

    // พุ่มใบไม้ทรงกลมเหลี่ยม 3 ชั้น (Low-poly Foliage Canopy)
    const leavesMat1 = track(new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.8 }));
    const leavesMat2 = track(new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.8 }));
    const leavesMat3 = track(new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8 }));

    const canopyGroup = new THREE.Group();
    canopyGroup.position.y = 1.6;

    const c1 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.9, 0)), leavesMat2);
    c1.position.set(0, 0.1, 0);
    c1.castShadow = true;
    canopyGroup.add(c1);

    const c2 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.65, 0)), leavesMat1);
    c2.position.set(0.35, 0.45, 0.2);
    canopyGroup.add(c2);

    const c3 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.65, 0)), leavesMat3);
    c3.position.set(-0.35, 0.35, -0.2);
    canopyGroup.add(c3);

    scene.add(canopyGroup);

    // ผลแอปเปิ้ลสีแดงสด 3D (3D Red Apples)
    const appleMat = track(new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.3 }));
    const appleGeo = track(new THREE.SphereGeometry(0.1, 8, 8));
    const apples: THREE.Mesh[] = [];

    const appleOffsets = [
      { x: 0.4, y: 1.4, z: 0.6 },
      { x: -0.45, y: 1.5, z: 0.45 },
      { x: 0.1, y: 1.8, z: 0.75 },
      { x: -0.2, y: 1.25, z: 0.65 },
      { x: 0.5, y: 1.65, z: -0.3 },
    ];

    appleOffsets.forEach((pos) => {
      const apple = new THREE.Mesh(appleGeo, appleMat);
      apple.position.set(pos.x, pos.y, pos.z);
      apple.castShadow = true;
      apple.visible = fruitReady;
      scene.add(apple);
      apples.push(apple);
    });
    applesRef.current = apples;

    let animId: number;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);

      // ใบไม้พริ้วไหวตามลม
      canopyGroup.rotation.z = Math.sin(time * 0.002) * 0.04;
      canopyGroup.rotation.x = Math.cos(time * 0.002) * 0.03;

      if (fruitReady) {
        apples.forEach((a, idx) => {
          a.rotation.y += 0.02;
          a.scale.setScalar(1.0 + Math.sin(time * 0.005 + idx) * 0.08);
        });
      }

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, [fruitReady]);

  const handleClick = () => {
    if (fruitReady && onPick) {
      sound.playHarvest();
      onPick();
      setActiveSpeech('เก็บแอปเปิ้ลสดแล้ว! 🍎✨');
    } else {
      sound.playClick();
      setActiveSpeech('ต้นแอปเปิลผลดก 🍎 กำลังเติบโต');
    }
    setTimeout(() => setActiveSpeech(null), 2000);
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      className={`relative w-full h-full select-none cursor-pointer ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />

      {activeSpeech && (
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-stone-900/90 text-red-200 text-[10px] font-bold rounded-full border border-red-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}
    </div>
  );
};
