import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export interface House3DProps {
  type?: 'farmhouse' | 'barn_silo';
  level?: 1 | 2 | 3 | 4;
  seamless?: boolean;
  autoRotate?: boolean; // เพิ่ม prop เสริมสำหรับหมุนช้าๆ ให้ดูมีมิติ
  className?: string;
}

export const House3D: React.FC<House3DProps> = ({
  type = 'farmhouse',
  level = 1,
  seamless = false,
  autoRotate = true,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    let disposed = false;
    let animationId = 0;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    camera.position.set(5.2, 4.2, 7.5);
    camera.lookAt(0, 1.1, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    const geometries: THREE.BufferGeometry[] = [];
    const materials: THREE.Material[] = [];

    const geometry = <T extends THREE.BufferGeometry>(g: T): T => {
      geometries.push(g);
      return g;
    };

    const material = <T extends THREE.Material>(m: T): T => {
      materials.push(m);
      return m;
    };

    const mat = (color: number, roughness = 0.8) =>
      material(
        new THREE.MeshStandardMaterial({
          color,
          roughness,
        }),
      );

    const wood = mat(0x87502f);
    const wall = mat(type === 'barn_silo' ? 0xa8322d : 0xc39a68);
    const roofMat = mat(0x46352c);
    const trim = mat(0xf0e4ca);
    const glass = material(
      new THREE.MeshStandardMaterial({
        color: 0x8fc5d9,
        roughness: 0.25,
        metalness: 0.05,
      }),
    );
    const stone = mat(0x77736c);
    const dark = mat(0x493328);
    const groundMat = material(
      new THREE.MeshStandardMaterial({
        color: 0x6f9258,
        roughness: 1,
      }),
    );

    scene.add(new THREE.HemisphereLight(0xfff1d6, 0x65765a, 2));

    const sun = new THREE.DirectionalLight(0xfff0d5, 3);
    sun.position.set(5, 9, 6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -5;
    sun.shadow.camera.right = 5;
    sun.shadow.camera.top = 6;
    sun.shadow.camera.bottom = -4;
    sun.shadow.bias = -0.0005;
    scene.add(sun);

    const fill = new THREE.DirectionalLight(0xffffff, 0.7);
    fill.position.set(-5, 4, -4);
    scene.add(fill);

    const building = new THREE.Group();
    scene.add(building);

    const addBox = (
      w: number,
      h: number,
      d: number,
      x: number,
      y: number,
      z: number,
      m: THREE.Material,
      castShadow = true,
    ) => {
      const mesh = new THREE.Mesh(geometry(new THREE.BoxGeometry(w, h, d)), m);
      mesh.position.set(x, y, z);
      mesh.castShadow = castShadow;
      mesh.receiveShadow = true;
      building.add(mesh);
      return mesh;
    };

    const addCylinder = (
      radiusTop: number,
      radiusBottom: number,
      height: number,
      x: number,
      y: number,
      z: number,
      m: THREE.Material,
      segments = 16,
    ) => {
      const mesh = new THREE.Mesh(
        geometry(
          new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments),
        ),
        m,
      );
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      building.add(mesh);
      return mesh;
    };

    // พื้นดินและฐานอาคาร
    const ground = new THREE.Mesh(
      geometry(new THREE.CircleGeometry(5, 48)),
      groundMat,
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.13;
    ground.receiveShadow = true;
    scene.add(ground);

    const foundationMat = mat(0x82786b);
    addBox(2.35, 0.18, 2.05, 0, 0, 0, foundationMat);

    if (type === 'barn_silo') {
      // โรงนา
      addBox(1.8, 1.5, 1.7, -0.35, 0.84, 0, wall);

      // หลังคาจั่วโรงนา
      const roofRun = 1.1;
      const roofRise = 0.72;
      const roofLength = 2.0;
      const slopeLength = Math.hypot(roofRun, roofRise);
      const slopeAngle = Math.atan2(roofRise, roofRun);

      for (const side of [-1, 1]) {
        const panel = addBox(
          slopeLength,
          0.12,
          roofLength,
          -0.35 + (side * roofRun) / 2,
          1.59 + roofRise / 2,
          0,
          roofMat,
        );
        // FIX: แก้ไขมุมหมุนหลังคาให้เอียงลงเป็นทรงจั่ว
        panel.rotation.z = -side * slopeAngle;
      }

      // ผนังหน้าจั่วด้านหน้าและด้านหลัง
      for (const z of [-0.86, 0.86]) {
        const positions = new Float32Array([
          -1.25, 1.58, z,
          0.55, 1.58, z,
          -0.35, 2.3, z,
        ]);
        const g = geometry(new THREE.BufferGeometry());
        g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        g.computeVertexNormals();

        const gable = new THREE.Mesh(
          g,
          material(
            new THREE.MeshStandardMaterial({
              color: 0xa8322d,
              side: THREE.DoubleSide,
              roughness: 0.8,
            }),
          ),
        );
        gable.castShadow = true;
        building.add(gable);
      }

      // ประตูโรงนา
      addBox(0.75, 0.95, 0.06, -0.35, 0.53, 0.89, dark);
      addBox(0.035, 0.95, 0.025, -0.72, 0.53, 0.93, trim, false);
      addBox(0.035, 0.95, 0.025, 0.02, 0.53, 0.93, trim, false);
      addBox(0.8, 0.045, 0.025, -0.35, 1.02, 0.93, trim, false);

      // ไซโลทรงกระบอกและหลังคากรวย
      addCylinder(0.37, 0.37, 1.75, 1.02, 0.875, 0, mat(0xaeb9c1));
      const siloRoof = new THREE.Mesh(
        geometry(new THREE.ConeGeometry(0.4, 0.38, 24)),
        roofMat,
      );
      siloRoof.position.set(1.02, 1.94, 0);
      siloRoof.castShadow = true;
      building.add(siloRoof);

      // ขอบฐานไซโล
      addCylinder(0.39, 0.39, 0.08, 1.02, 0.08, 0, stone);
    } else {
      const twoStorey = level >= 3;
      const houseWidth = level >= 4 ? 2.05 : 1.8;
      const houseDepth = 1.65;
      const groundFloorHeight = 1.25;
      const upperFloorHeight = twoStorey ? 1.0 : 0;
      const wallHeight = groundFloorHeight + upperFloorHeight;
      const wallBottom = 0.1;
      const wallTop = wallBottom + wallHeight;

      // ตัวบ้าน
      addBox(
        houseWidth,
        wallHeight,
        houseDepth,
        0,
        wallBottom + wallHeight / 2,
        0,
        wall,
      );

      // ฐานรองผนัง
      addBox(
        houseWidth + 0.12,
        0.12,
        houseDepth + 0.12,
        0,
        wallBottom + 0.04,
        0,
        foundationMat,
      );

      // ประตูหน้าบ้าน
      const doorWidth = 0.34;
      const doorHeight = 0.78;
      const frontZ = houseDepth / 2 + 0.015;

      addBox(
        doorWidth,
        doorHeight,
        0.055,
        0,
        wallBottom + doorHeight / 2,
        frontZ,
        dark,
      );

      // กรอบประตู
      const frame = 0.045;
      addBox(
        frame,
        doorHeight + frame,
        0.07,
        -doorWidth / 2 - frame / 2,
        wallBottom + doorHeight / 2,
        frontZ + 0.015,
        trim,
        false,
      );
      addBox(
        frame,
        doorHeight + frame,
        0.07,
        doorWidth / 2 + frame / 2,
        wallBottom + doorHeight / 2,
        frontZ + 0.015,
        trim,
        false,
      );
      addBox(
        doorWidth + frame * 2,
        frame,
        0.07,
        0,
        wallBottom + doorHeight + frame / 2,
        frontZ + 0.015,
        trim,
        false,
      );

      // ลูกบิดประตู
      addCylinder(0.025, 0.025, 0.02, 0.09, 0.48, frontZ + 0.055, trim, 12)
        .rotation.x = Math.PI / 2;

      // หน้าต่างพร้อมกรอบ
      const addWindow = (x: number, y: number, z: number) => {
        const ww = 0.36;
        const wh = 0.34;
        const border = 0.045;

        addBox(ww, wh, 0.045, x, y, z, glass, false);

        addBox(
          ww + border * 2,
          border,
          0.07,
          x,
          y + wh / 2 + border / 2,
          z + 0.015,
          trim,
          false,
        );
        addBox(
          ww + border * 2,
          border,
          0.07,
          x,
          y - wh / 2 - border / 2,
          z + 0.015,
          trim,
          false,
        );
        addBox(
          border,
          wh,
          0.07,
          x - ww / 2 - border / 2,
          y,
          z + 0.015,
          trim,
          false,
        );
        addBox(
          border,
          wh,
          0.07,
          x + ww / 2 + border / 2,
          y,
          z + 0.015,
          trim,
          false,
        );

        addBox(0.025, wh, 0.075, x, y, z + 0.025, trim, false);
        addBox(ww, 0.025, 0.075, x, y, z + 0.025, trim, false);
      };

      addWindow(-0.56, 0.75, frontZ);
      addWindow(0.56, 0.75, frontZ);

      // บ้านสองชั้น
      if (twoStorey) {
        addBox(
          houseWidth + 0.08,
          0.12,
          houseDepth + 0.08,
          0,
          wallBottom + groundFloorHeight,
          0,
          wood,
        );

        addWindow(-0.5, wallBottom + groundFloorHeight + 0.55, frontZ);
        addWindow(0.5, wallBottom + groundFloorHeight + 0.55, frontZ);

        for (const x of [-houseWidth / 2 + 0.06, houseWidth / 2 - 0.06]) {
          for (const z of [-houseDepth / 2 + 0.06, houseDepth / 2 - 0.06]) {
            addBox(0.09, wallHeight, 0.09, x, wallBottom + wallHeight / 2, z, wood);
          }
        }
      }

      // หลังคาจั่วบ้านพัก
      const roofRun = houseWidth / 2 + 0.18;
      const roofRise = level >= 4 ? 0.95 : 0.78;
      const roofLength = houseDepth + 0.38;
      const slopeLength = Math.hypot(roofRun, roofRise);
      const slopeAngle = Math.atan2(roofRise, roofRun);
      const ridgeY = wallTop + roofRise;

      for (const side of [-1, 1]) {
        const panel = addBox(
          slopeLength,
          0.13,
          roofLength,
          (side * roofRun) / 2,
          wallTop + roofRise / 2,
          0,
          roofMat,
        );
        // FIX: แก้ไขมุมหมุนหลังคาให้เอียงลงเป็นทรงจั่ว
        panel.rotation.z = -side * slopeAngle;
      }

      // หน้าจั่วสามเหลี่ยม
      const addGable = (z: number) => {
        const positions = new Float32Array([
          -houseWidth / 2, wallTop, z,
          houseWidth / 2, wallTop, z,
          0, ridgeY, z,
        ]);

        const g = geometry(new THREE.BufferGeometry());
        g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        g.computeVertexNormals();

        const mesh = new THREE.Mesh(
          g,
          material(
            new THREE.MeshStandardMaterial({
              color: level >= 4 ? 0xe2c7a0 : 0xc39a68,
              side: THREE.DoubleSide,
              roughness: 0.85,
            }),
          ),
        );
        mesh.castShadow = true;
        building.add(mesh);
      };

      addGable(houseDepth / 2);
      addGable(-houseDepth / 2);

      // ระเบียงหน้าบ้าน
      if (level >= 2) {
        const porchDepth = 0.62;
        const porchZ = houseDepth / 2 + porchDepth / 2 + 0.04;
        const porchY = 0.18;

        addBox(2.05, 0.12, porchDepth, 0, porchY, porchZ, wood);

        const postHeight = 1.05;
        for (const x of [-0.82, 0.82]) {
          addBox(
            0.085,
            postHeight,
            0.085,
            x,
            porchY + postHeight / 2,
            porchZ + porchDepth / 2 - 0.08,
            trim,
          );
        }

        // ราวระเบียง
        addBox(
          1.65,
          0.07,
          0.07,
          0,
          porchY + 0.68,
          porchZ + porchDepth / 2 - 0.08,
          trim,
        );

        // บันได
        for (let i = 0; i < 3; i++) {
          const stepHeight = 0.06;
          addBox(
            0.72,
            stepHeight,
            0.16,
            0,
            0.13 - i * stepHeight,
            porchZ + porchDepth / 2 + 0.08 + i * 0.15,
            wood,
          );
        }
      }

      // ปล่องไฟ
      if (level >= 3) {
        addBox(
          0.22,
          1.0,
          0.22,
          -houseWidth * 0.28,
          wallTop + 0.45,
          -0.35,
          stone,
        );
        addBox(
          0.3,
          0.08,
          0.3,
          -houseWidth * 0.28,
          wallTop + 0.95,
          -0.35,
          dark,
        );
      }

      // ห้องใต้หลังคา
      if (level >= 4) {
        addBox(
          0.65,
          0.32,
          0.08,
          0,
          ridgeY - 0.45,
          houseDepth / 2 + 0.03,
          trim,
        );
        addBox(
          0.75,
          0.07,
          roofLength + 0.1,
          0,
          wallTop + 0.03,
          0,
          wood,
        );
      }
    }

    const resize = () => {
      if (disposed) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (width <= 0 || height <= 0) return;

      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
      if (!autoRotate) {
        renderer.render(scene, camera);
      }
    };

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);
    resize();

    // Render loop พร้อม auto-rotation แบบนุ่มนวล
    const animate = () => {
      if (disposed) return;
      animationId = requestAnimationFrame(animate);

      if (autoRotate) {
        building.rotation.y += 0.004;
      }

      renderer.render(scene, camera);
    };

    if (autoRotate) {
      animate();
    } else {
      renderer.render(scene, camera);
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(animationId);
      resizeObserver.disconnect();

      geometries.forEach((g) => g.dispose());
      materials.forEach((m) => m.dispose());
      renderer.dispose();
    };
  }, [type, level, autoRotate]);

  return (
    <div
      ref={containerRef}
      className={`relative h-full w-full select-none ${
        seamless
          ? 'overflow-visible bg-transparent'
          : 'overflow-hidden rounded-2xl'
      } ${className}`}
    >
      <canvas
        ref={canvasRef}
        className="h-full w-full touch-none"
        aria-label={`3D ${type === 'farmhouse' ? 'บ้านพัก' : 'โรงนาและไซโล'} ระดับ ${level}`}
      />
    </div>
  );
};