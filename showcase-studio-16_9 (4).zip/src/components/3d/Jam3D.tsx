import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../utils/audio';
import { setupRealisticLighting, getWoodPBRTexture } from '../../utils/threeTextures';

export interface Jam3DProps {
  isProducing: boolean;
  productName?: string;
  onClick?: () => void;
  seamless?: boolean;
  className?: string;
}

export const Jam3D: React.FC<Jam3DProps> = ({
  isProducing,
  productName,
  onClick,
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 160;
    const height = container.clientHeight || 160;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 5.8);
    camera.lookAt(0, 0.6, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    setupRealisticLighting(scene, renderer);

    const woodMat = track(new THREE.MeshStandardMaterial({ map: getWoodPBRTexture(), color: 0x78350f, roughness: 0.8 }));
    const roofMat = track(new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.6 }));
    const copperMat = track(new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.8, roughness: 0.3 }));
    const jamMat = track(new THREE.MeshStandardMaterial({ color: 0x9f1239, roughness: 0.2 }));

    // พื้นไม้
    const floor = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 0.15, 1.5)), woodMat);
    floor.position.y = 0.08;
    floor.receiveShadow = true;
    scene.add(floor);

    // กระท่อมไม้ส่วนหลัง
    const hut = new THREE.Mesh(track(new THREE.BoxGeometry(1.3, 0.85, 0.8)), woodMat);
    hut.position.set(0, 0.55, -0.25);
    hut.castShadow = true;
    scene.add(hut);

    // หลังคาสีแดงเชอร์รี่
    const roof = new THREE.Mesh(track(new THREE.ConeGeometry(1.15, 0.5, 4)), roofMat);
    roof.position.set(0, 1.22, -0.25);
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    scene.add(roof);

    // หม้อต้มแยมทองแดงใบใหญ่ (Boiling Jam Cauldron)
    const pot = new THREE.Mesh(track(new THREE.CylinderGeometry(0.38, 0.28, 0.45, 12)), copperMat);
    pot.position.set(-0.35, 0.38, 0.35);
    pot.castShadow = true;
    scene.add(pot);

    // ผิวแยมเดือด (Bubbling Jam Surface)
    const jamSurface = new THREE.Mesh(track(new THREE.CircleGeometry(0.35, 12)), jamMat);
    jamSurface.rotation.x = -Math.PI / 2;
    jamSurface.position.set(-0.35, 0.56, 0.35);
    scene.add(jamSurface);

    // ฟองแยมปุดๆ
    const bubble1 = new THREE.Mesh(track(new THREE.SphereGeometry(0.06, 6, 6)), jamMat);
    bubble1.position.set(-0.35, 0.6, 0.35);
    scene.add(bubble1);

    // โหลแยมบนลังไม้ (Jam Jars on Crate)
    const crate = new THREE.Mesh(track(new THREE.BoxGeometry(0.55, 0.3, 0.4)), woodMat);
    crate.position.set(0.42, 0.25, 0.35);
    crate.castShadow = true;
    scene.add(crate);

    const jarGeo = track(new THREE.CylinderGeometry(0.08, 0.08, 0.16, 8));
    const jar1 = new THREE.Mesh(jarGeo, jamMat);
    jar1.position.set(0.35, 0.48, 0.35);
    scene.add(jar1);

    const jar2 = new THREE.Mesh(jarGeo, track(new THREE.MeshStandardMaterial({ color: 0x581c87, roughness: 0.2 })));
    jar2.position.set(0.52, 0.48, 0.35);
    scene.add(jar2);

    let animId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      if (isProducing) {
        bubble1.position.y = 0.58 + Math.abs(Math.sin(time * 0.008)) * 0.08;
        bubble1.scale.setScalar(0.8 + Math.sin(time * 0.01) * 0.4);
      }

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, [isProducing]);

  const handleClick = () => {
    sound.playClick();
    if (onClick) onClick();
    setActiveSpeech(isProducing ? `กำลังกวน: ${productName || 'แยมผลไม้'} 🍯🍓` : 'โรงงานแยมผลไม้ 🍯✨');
    setTimeout(() => setActiveSpeech(null), 2000);
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      className={`relative w-full h-full select-none cursor-pointer ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />

      {activeSpeech && (
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-stone-900/90 text-rose-200 text-[10px] font-bold rounded-full border border-rose-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}
    </div>
  );
};
