import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export interface Truck3DProps {
  seamless?: boolean;
  className?: string;
}

export const Truck3D: React.FC<Truck3DProps> = ({
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 112;
    const height = container.clientHeight || 80;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 3.8, 5.2);
    camera.lookAt(0, 0.5, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    const ambientLight = new THREE.AmbientLight(0xfff7ed, 1.3);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffae6, 1.8);
    sunLight.position.set(5, 8, 5);
    sunLight.castShadow = true;
    scene.add(sunLight);

    const blueMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.4 }));
    const glassMat = track(new THREE.MeshStandardMaterial({ color: 0x93c5fd, roughness: 0.1, metalness: 0.5 }));
    const tireMat = track(new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 }));
    const rimMat = track(new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.8, roughness: 0.2 }));
    const woodMat = track(new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.8 }));

    const truckGroup = new THREE.Group();
    truckGroup.rotation.y = Math.PI / 6;

    // ตัวถังส่วนหน้า/ห้องโดยสาร (Cabin)
    const cab = new THREE.Mesh(track(new THREE.BoxGeometry(0.8, 0.6, 0.7)), blueMat);
    cab.position.set(0, 0.55, 0.35);
    cab.castShadow = true;
    truckGroup.add(cab);

    // กระจกหน้า
    const win = new THREE.Mesh(track(new THREE.BoxGeometry(0.7, 0.35, 0.1)), glassMat);
    win.position.set(0, 0.65, 0.71);
    truckGroup.add(win);

    // ฝากระโปรงหน้า (Hood)
    const hood = new THREE.Mesh(track(new THREE.BoxGeometry(0.76, 0.35, 0.5)), blueMat);
    hood.position.set(0, 0.42, 0.85);
    hood.castShadow = true;
    truckGroup.add(hood);

    // กระบะบรรทุกท้าย (Truck Bed)
    const bed = new THREE.Mesh(track(new THREE.BoxGeometry(0.85, 0.35, 0.95)), blueMat);
    bed.position.set(0, 0.42, -0.45);
    bed.castShadow = true;
    truckGroup.add(bed);

    // ลังผักผลไม้บนกระบะ (Cargo Crates)
    const c1 = new THREE.Mesh(track(new THREE.BoxGeometry(0.35, 0.25, 0.35)), woodMat);
    c1.position.set(0.18, 0.68, -0.4);
    truckGroup.add(c1);

    const c2 = new THREE.Mesh(track(new THREE.BoxGeometry(0.32, 0.25, 0.32)), woodMat);
    c2.position.set(-0.18, 0.68, -0.45);
    truckGroup.add(c2);

    // ล้อ 4 ข้าง (4 Wheels)
    const wheelPositions = [
      { x: 0.42, z: 0.65 },
      { x: -0.42, z: 0.65 },
      { x: 0.42, z: -0.55 },
      { x: -0.42, z: -0.55 },
    ];

    wheelPositions.forEach((pos) => {
      const tire = new THREE.Mesh(track(new THREE.CylinderGeometry(0.18, 0.18, 0.1, 10)), tireMat);
      tire.rotation.z = Math.PI / 2;
      tire.position.set(pos.x, 0.18, pos.z);
      truckGroup.add(tire);

      const rim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.09, 0.09, 0.11, 8)), rimMat);
      rim.rotation.z = Math.PI / 2;
      rim.position.set(pos.x, 0.18, pos.z);
      truckGroup.add(rim);
    });

    scene.add(truckGroup);

    let animId: number;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      truckGroup.position.y = Math.sin(time * 0.004) * 0.015;
      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full select-none ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />
    </div>
  );
};
