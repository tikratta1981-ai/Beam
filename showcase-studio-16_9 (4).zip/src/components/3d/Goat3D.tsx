// src/components/3d/Goat3D.tsx
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { sound } from '../../utils/audio';
import {
  getWoodPBRTexture,
  getGalvanizedMetalTexture,
  getStrawTexture,
} from '../../utils/threeTextures';

export interface Goat3DProps {
  readyProduce: number;           // จำนวนผลผลิตที่พร้อมเก็บ (ยังใช้ callback เดิมของระบบ) (0 - 5)
  isFed: boolean;                 // สถานะว่ากินอิ่มอยู่หรือไม่
  onFeed?: () => void;            // Callback เมื่อกดให้หญ้าสด
  onCollectMilk?: () => void;     // Callback เมื่อกดเก็บนมแพะ
  onCollectEggs?: () => void;     // Fallback
  seamless?: boolean;             // กลืนกับฉากฟาร์ม
  compact?: boolean;              // ซ่อน Header Overlay
  className?: string;
}

type GoatRole = 'buck_alpha' | 'doe_milker' | 'doe_alpine' | 'doe_brown' | 'kid_playful' | 'kid_sleepy';

interface GoatInstance {
  id: string;
  name: string;
  role: GoatRole;
  group: THREE.Group;
  neckGroup: THREE.Group;
  headGroup: THREE.Group;
  jawMesh: THREE.Mesh;
  leftEar: THREE.Group;
  rightEar: THREE.Group;
  tailGroup: THREE.Group;
  beardMesh?: THREE.Mesh;
  udderMesh?: THREE.Mesh;
  legFL: THREE.Group;
  legFR: THREE.Group;
  legBL: THREE.Group;
  legBR: THREE.Group;
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  direction: number;
  targetDirection: number;
  speed: number;
  state: 'grazing' | 'walking' | 'idle' | 'prancing' | 'seeking_food' | 'standing_up' | 'resting';
  stateTimer: number;
  walkCycle: number;
  chewCycle: number;
  bipedalProgress: number; // 0 (4 ขา) -> 1 (ยืน 2 ขาชะเง้อ)
  earFlickTimer: number;
  scale: number;
}

interface GrassParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  rotVel: THREE.Vector3;
  groundY: number;
  settled: boolean;
  eaten: boolean;
  age: number;
}

interface MilkJetParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
}

export const Goat3D: React.FC<Goat3DProps> = ({
  readyProduce,
  isFed,
  onFeed,
  onCollectMilk,
  onCollectEggs,
  seamless = false,
  compact = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);
  const [feedEffect, setFeedEffect] = useState(false);

  const goatsRef = useRef<GoatInstance[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const milkGroupRef = useRef<THREE.Group | null>(null);
  const grassParticlesRef = useRef<GrassParticle[]>([]);
  const milkJetParticlesRef = useRef<MilkJetParticle[]>([]);
  const grassGeoRef = useRef<THREE.BufferGeometry | null>(null);
  const grassMatRef = useRef<THREE.Material | null>(null);

  const handleCollectAction = onCollectMilk || onCollectEggs;

  // 🥛 1. จัดการถังนมสเตนเลส 3 มิติ พร้อมฟองนมระยิบระยับ
  useEffect(() => {
    if (!milkGroupRef.current) return;
    const milkGroup = milkGroupRef.current;

    while (milkGroup.children.length > 0) {
      const child = milkGroup.children[0];
      milkGroup.remove(child);
      child.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const m = obj as THREE.Mesh;
          m.geometry?.dispose();
          if (Array.isArray(m.material)) m.material.forEach((mat) => mat.dispose());
          else m.material?.dispose();
        }
      });
    }

    const count = Math.min(readyProduce, 5);
    if (count <= 0) return;

    const metalTex = getGalvanizedMetalTexture();
    const bucketMat = new THREE.MeshStandardMaterial({
      map: metalTex,
      metalness: 0.85,
      roughness: 0.25,
      color: 0xeeeeee,
    });
    const rimMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.9,
      roughness: 0.2,
    });
    const milkMat = new THREE.MeshStandardMaterial({
      color: 0xfffff8,
      roughness: 0.15,
      metalness: 0.05,
    });

    const bucketGeo = new THREE.CylinderGeometry(0.15, 0.11, 0.28, 16);
    const rimGeo = new THREE.TorusGeometry(0.15, 0.012, 8, 16);
    const milkSurfaceGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.02, 16);

    for (let i = 0; i < count; i++) {
      const singleBucketGroup = new THREE.Group();
      
      const bucket = new THREE.Mesh(bucketGeo.clone(), bucketMat);
      bucket.position.y = 0.14;
      bucket.castShadow = true;
      singleBucketGroup.add(bucket);

      const rim = new THREE.Mesh(rimGeo.clone(), rimMat);
      rim.rotation.x = Math.PI / 2;
      rim.position.y = 0.28;
      singleBucketGroup.add(rim);

      const milkSurface = new THREE.Mesh(milkSurfaceGeo.clone(), milkMat);
      milkSurface.position.y = 0.25;
      singleBucketGroup.add(milkSurface);

      const spacing = 0.32;
      singleBucketGroup.position.set((i - (count - 1) / 2) * spacing, 0, 0);
      singleBucketGroup.rotation.y = (i * 0.4) - 0.6;
      milkGroup.add(singleBucketGroup);
    }

    bucketGeo.dispose();
    rimGeo.dispose();
    milkSurfaceGeo.dispose();
  }, [readyProduce]);

  // 🌿 2. โปรยใบโคลเวอร์และหญ้าเนเปียร์ 3D
  const spawnGrassScattering = useCallback((originX = 0, originZ = 0) => {
    if (!sceneRef.current || !grassGeoRef.current || !grassMatRef.current) return;
    const scene = sceneRef.current;
    const geo = grassGeoRef.current;
    const mat = grassMatRef.current;

    for (let i = 0; i < 36; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      const startX = originX + (Math.random() - 0.5) * 1.2;
      const startY = 1.8 + Math.random() * 0.5;
      const startZ = originZ + (Math.random() - 0.5) * 1.2;
      mesh.position.set(startX, startY, startZ);
      mesh.scale.set(
        0.8 + Math.random() * 0.6,
        0.8 + Math.random() * 0.4,
        0.8 + Math.random() * 0.8
      );
      mesh.castShadow = true;
      scene.add(mesh);

      const targetAngle = Math.random() * Math.PI * 2;
      const horizSpeed = 0.8 + Math.random() * 1.8;
      grassParticlesRef.current.push({
        mesh,
        vel: new THREE.Vector3(
          Math.cos(targetAngle) * horizSpeed,
          1.8 + Math.random() * 1.2,
          Math.sin(targetAngle) * horizSpeed
        ),
        rotVel: new THREE.Vector3(
          (Math.random() - 0.5) * 14,
          (Math.random() - 0.5) * 14,
          (Math.random() - 0.5) * 14
        ),
        groundY: 0.04 + Math.random() * 0.02,
        settled: false,
        eaten: false,
        age: 0,
      });
    }

    // กระตุ้นเร่งให้แพะทั้งหมดวิ่งกรูเข้าหาอาหาร
    goatsRef.current.forEach((g) => {
      g.state = 'seeking_food';
      g.stateTimer = 6 + Math.random() * 3;
      g.speed = (g.role.startsWith('kid') ? 2.4 : 1.8) * (0.95 + Math.random() * 0.2);
    });
  }, []);

  // 🥛 3. ละอองสายน้ำนมพุ่งตอนรีด (Milking Squirt FX)
  const spawnMilkSquirts = useCallback((originPos: THREE.Vector3) => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;
    const milkGeo = new THREE.SphereGeometry(0.02, 6, 6);
    const milkMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    for (let i = 0; i < 18; i++) {
      const mesh = new THREE.Mesh(milkGeo, milkMat);
      mesh.position.copy(originPos).add(new THREE.Vector3(
        (Math.random() - 0.5) * 0.1,
        0.1,
        (Math.random() - 0.5) * 0.1
      ));
      scene.add(mesh);

      milkJetParticlesRef.current.push({
        mesh,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 0.8 + 0.3,
          -1.2 - Math.random() * 0.8,
          (Math.random() - 0.5) * 0.8 - 0.5
        ),
        life: 0.6,
      });
    }
  }, []);

  // 🎬 4. Three.js Engine Lifecycle & Procedural Goat Builder
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 200;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    // A. Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 100);
    camera.position.set(0, 5.4, 7.6);
    camera.lookAt(0, 0.45, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // B. แสงและบรรยากาศ (Sunlight, Ambient, Rim Glow)
    const hemiLight = new THREE.HemisphereLight(0xfffbeb, 0x3f6212, 1.05);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffae0, 1.5);
    sunLight.position.set(5.5, 10, 5.5);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.bias = -0.0006;
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0xd9f99d, 0.45);
    rimLight.position.set(-5, 4.5, -4);
    scene.add(rimLight);

    // C. ผืนดินรับเงา
    const shadowGround = new THREE.Mesh(
      track(new THREE.PlaneGeometry(16, 12)),
      track(new THREE.ShadowMaterial({ opacity: 0.28 }))
    );
    shadowGround.rotation.x = -Math.PI / 2;
    shadowGround.position.y = 0.001;
    shadowGround.receiveShadow = true;
    scene.add(shadowGround);

    // D. ภูเขาหินปีนป่าย 3 ระดับ (Multi-tier Climbing Rock Steps)
    const rockMat = track(new THREE.MeshStandardMaterial({
      color: 0x71717a,
      roughness: 0.9,
      metalness: 0.05,
    }));

    const rockBase = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.55, 1)), rockMat);
    rockBase.scale.set(1.6, 0.6, 1.4);
    rockBase.position.set(-2.2, 0.16, 0.5);
    rockBase.castShadow = true;
    rockBase.receiveShadow = true;
    scene.add(rockBase);

    const rockStep1 = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.42, 1)), rockMat);
    rockStep1.scale.set(1.3, 0.7, 1.1);
    rockStep1.position.set(-2.3, 0.38, 0.3);
    rockStep1.castShadow = true;
    rockStep1.receiveShadow = true;
    scene.add(rockStep1);

    const rockPeak = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.32, 1)), rockMat);
    rockPeak.scale.set(1.0, 0.9, 0.9);
    rockPeak.position.set(-2.4, 0.65, 0.2);
    rockPeak.castShadow = true;
    rockPeak.receiveShadow = true;
    scene.add(rockPeak);

    // E. เพิงพักไม้คลาสสิก & รางหญ้า (Shelter & Hay Rack)
    const woodTex = getWoodPBRTexture();
    const woodMat = track(new THREE.MeshStandardMaterial({
      map: woodTex,
      roughness: 0.82,
    }));

    const shelterGroup = new THREE.Group();
    shelterGroup.position.set(-1.8, 0, -1.2);

    const backWall = new THREE.Mesh(track(new THREE.BoxGeometry(1.7, 1.3, 0.08)), woodMat);
    backWall.position.set(0, 0.65, -0.65);
    backWall.castShadow = true;
    shelterGroup.add(backWall);

    const roofMesh = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.9, 0.08, 1.5)),
      track(new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 }))
    );
    roofMesh.position.set(0, 1.35, 0);
    roofMesh.rotation.x = 0.18;
    roofMesh.castShadow = true;
    shelterGroup.add(roofMesh);
    scene.add(shelterGroup);

    // รางหญ้าไม้แห้ง (Hay Trough)
    const troughGroup = new THREE.Group();
    troughGroup.position.set(1.9, 0, 0.35);

    const hayTrough = new THREE.Mesh(track(new THREE.BoxGeometry(1.3, 0.32, 0.42)), woodMat);
    hayTrough.position.y = 0.16;
    hayTrough.castShadow = true;
    troughGroup.add(hayTrough);

    const strawTex = getStrawTexture();
    const hayInTrough = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.2, 0.16, 0.34)),
      track(new THREE.MeshStandardMaterial({ map: strawTex, roughness: 0.9 }))
    );
    hayInTrough.position.y = 0.26;
    troughGroup.add(hayInTrough);
    scene.add(troughGroup);

    // รางน้ำดื่มสัตว์ (Water Trough)
    const waterTrough = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.8, 0.24, 0.35)),
      track(new THREE.MeshStandardMaterial({ color: 0x57534e, roughness: 0.5 }))
    );
    waterTrough.position.set(0.2, 0.12, -1.3);
    waterTrough.castShadow = true;
    scene.add(waterTrough);

    const waterSurface = new THREE.Mesh(
      track(new THREE.PlaneGeometry(0.72, 0.28)),
      track(new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1, metalness: 0.8 }))
    );
    waterSurface.rotation.x = -Math.PI / 2;
    waterSurface.position.set(0.2, 0.21, -1.3);
    scene.add(waterSurface);

    // บริเวณถังนม
    const milkArea = new THREE.Group();
    milkArea.position.set(1.9, 0, -0.85);
    scene.add(milkArea);
    milkGroupRef.current = milkArea;

    // รั้วไม้ด้านหลัง
    const fenceGroup = new THREE.Group();
    for (let x = -2.8; x <= 2.8; x += 1.1) {
      const post = new THREE.Mesh(track(new THREE.CylinderGeometry(0.045, 0.05, 0.72, 6)), woodMat);
      post.position.set(x, 0.36, -1.8);
      post.castShadow = true;
      fenceGroup.add(post);
    }
    const railGeo = track(new THREE.BoxGeometry(5.8, 0.05, 0.04));
    const rail1 = new THREE.Mesh(railGeo, woodMat);
    rail1.position.set(0, 0.54, -1.8);
    const rail2 = new THREE.Mesh(railGeo, woodMat);
    rail2.position.set(0, 0.28, -1.8);
    fenceGroup.add(rail1, rail2);
    scene.add(fenceGroup);

    // F. ใบหญ้า Particle Asset
    grassGeoRef.current = track(new THREE.BoxGeometry(0.07, 0.02, 0.14));
    grassMatRef.current = track(new THREE.MeshStandardMaterial({
      color: 0x22c55e,
      roughness: 0.35,
    }));

    // G. สร้างโมเดลแกะแบบแยกชิ้นและข้อต่อ (Procedural Articulated Sheep)
    const hoofMat = track(new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4 }));
    const hornMat = track(new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.35 }));
    const udderMat = track(new THREE.MeshStandardMaterial({ color: 0xfbcfe8, roughness: 0.55 }));
    const woolMat = track(new THREE.MeshStandardMaterial({ color: 0xf5f0df, roughness: 0.96 }));
    const woolShadowMat = track(new THREE.MeshStandardMaterial({ color: 0xe2dac6, roughness: 1.0 }));
    const eyePupilMat = track(new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1 }));

    const createDetailedGoat = (
      id: string,
      name: string,
      role: GoatRole,
      colorHex: number,
      initPos: THREE.Vector3
    ): GoatInstance => {
      const group = new THREE.Group();
      group.position.copy(initPos);

      const isAlpha = role === 'buck_alpha';
      const isKid = role.startsWith('kid');
      const isDoe = role.startsWith('doe');
      const scale = isKid ? 0.44 : isAlpha ? 1.18 : 0.96;

      const coatMat = track(new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: 0.88,
        metalness: 0.02,
      }));

      // ลำตัวแกะ: ใช้ทรงรีแทนกล่อง เพื่อให้แนวอก-ท้อง-สะโพกต่อเนื่อง
      const body = new THREE.Mesh(track(new THREE.SphereGeometry(1, 20, 14)), coatMat);
      body.scale.set(0.31, 0.29, 0.55);
      body.position.set(0, 0.57, 0);
      body.castShadow = true;
      body.receiveShadow = true;
      group.add(body);

      // ขนแกะเป็นก้อนทรงรีซ้อนตามแนวลำตัว ไม่ใช้ผิวขนแบบแหลมแข็ง
      // จำกัดจำนวนก้อนและยึดตำแหน่งกับลำตัวเพื่อให้เป็น procedural mesh ที่เบา
      const woolGeo = track(new THREE.SphereGeometry(1, 10, 8));
      const woolTufts: Array<[number, number, number, number, number, number]> = [
        [-0.22, 0.68, -0.30, 0.13, 0.13, 0.16], [0, 0.77, -0.30, 0.14, 0.14, 0.16], [0.22, 0.68, -0.30, 0.13, 0.13, 0.16],
        [-0.27, 0.62, -0.08, 0.12, 0.14, 0.17], [0, 0.78, -0.08, 0.15, 0.13, 0.18], [0.27, 0.62, -0.08, 0.12, 0.14, 0.17],
        [-0.27, 0.62, 0.16, 0.12, 0.14, 0.17], [0, 0.78, 0.16, 0.15, 0.13, 0.18], [0.27, 0.62, 0.16, 0.12, 0.14, 0.17],
        [-0.20, 0.67, 0.35, 0.12, 0.13, 0.15], [0, 0.75, 0.35, 0.13, 0.13, 0.15], [0.20, 0.67, 0.35, 0.12, 0.13, 0.15],
      ];
      woolTufts.forEach(([x, y, z, sx, sy, sz], i) => {
        const tuft = new THREE.Mesh(woolGeo, i % 3 === 0 ? woolShadowMat : woolMat);
        tuft.position.set(x, y, z);
        tuft.scale.set(sx, sy, sz);
        tuft.castShadow = true;
        tuft.receiveShadow = true;
        group.add(tuft);
      });

      // เต้านม + หัวนม 2 ข้าง
      let udderMesh: THREE.Mesh | undefined;
      if (isDoe) {
        udderMesh = new THREE.Mesh(track(new THREE.SphereGeometry(0.13, 10, 10)), udderMat);
        udderMesh.scale.set(1.1, 0.75, 1.05);
        udderMesh.position.set(0, 0.31, -0.18);
        group.add(udderMesh);

        // หัวนม (Teats)
        const teatGeo = track(new THREE.ConeGeometry(0.025, 0.08, 6));
        const teatL = new THREE.Mesh(teatGeo, udderMat);
        teatL.position.set(0.06, 0.24, -0.19);
        teatL.rotation.z = -0.2;
        group.add(teatL);
        const teatR = new THREE.Mesh(teatGeo, udderMat);
        teatR.position.set(-0.06, 0.24, -0.19);
        teatR.rotation.z = 0.2;
        group.add(teatR);
      }

      // หางสั้นของแกะ: ติดกับส่วนท้ายของลำตัวและชี้ลงเล็กน้อย
      const tailGroup = new THREE.Group();
      tailGroup.position.set(0, 0.60, -0.49);
      const tailMesh = new THREE.Mesh(track(new THREE.SphereGeometry(1, 10, 8)), woolMat);
      tailMesh.scale.set(0.075, 0.10, 0.09);
      tailMesh.rotation.x = -0.25;
      tailMesh.castShadow = true;
      tailGroup.add(tailMesh);
      group.add(tailGroup);

      // คอและหัว: ใช้ทรงรีเรียวต่อจากอก ไม่ใช้กล่องแยกชิ้น
      const neckGroup = new THREE.Group();
      neckGroup.position.set(0, 0.63, 0.34);
      const neckMesh = new THREE.Mesh(track(new THREE.SphereGeometry(1, 16, 12)), coatMat);
      neckMesh.scale.set(0.18, 0.25, 0.25);
      neckMesh.position.set(0, 0.08, 0.08);
      neckMesh.rotation.x = 0.42;
      neckMesh.castShadow = true;
      neckGroup.add(neckMesh);

      const headGroup = new THREE.Group();
      headGroup.position.set(0, 0.27, 0.20);

      const skull = new THREE.Mesh(track(new THREE.SphereGeometry(1, 16, 12)), coatMat);
      skull.scale.set(0.17, 0.17, 0.19);
      skull.position.set(0, 0.015, 0.015);
      skull.castShadow = true;
      headGroup.add(skull);

      // ปากและจมูกเป็นทรงรีเล็กลงทางปลายจมูก
      const snout = new THREE.Mesh(track(new THREE.SphereGeometry(1, 14, 10)), coatMat);
      snout.scale.set(0.115, 0.095, 0.16);
      snout.position.set(0, -0.045, 0.17);
      snout.castShadow = true;
      headGroup.add(snout);

      const noseMat = track(new THREE.MeshStandardMaterial({ color: 0x4b3a32, roughness: 0.75 }));
      const nose = new THREE.Mesh(track(new THREE.SphereGeometry(1, 10, 8)), noseMat);
      nose.scale.set(0.065, 0.045, 0.035);
      nose.position.set(0, -0.015, 0.30);
      headGroup.add(nose);

      // ขากรรไกรแยกไว้ให้แอนิเมชันเคี้ยวเดิมทำงานต่อได้
      const jawMesh = new THREE.Mesh(track(new THREE.SphereGeometry(1, 10, 8)), coatMat);
      jawMesh.scale.set(0.09, 0.045, 0.12);
      jawMesh.position.set(0, -0.105, 0.16);
      headGroup.add(jawMesh);

      // ดวงตาวางด้านข้างศีรษะ ไม่ยื่นออกมาเป็นทรงเหลี่ยม
      const eyeWhiteMat = track(new THREE.MeshStandardMaterial({ color: 0xfff7e8, roughness: 0.35 }));
      const eyePupilMat = track(new THREE.MeshStandardMaterial({ color: 0x171717, roughness: 0.2 }));
      const createSheepEye = (x: number) => {
        const eyeG = new THREE.Group();
        eyeG.position.set(x, 0.035, 0.075);
        const eye = new THREE.Mesh(track(new THREE.SphereGeometry(1, 10, 8)), eyeWhiteMat);
        eye.scale.set(0.035, 0.032, 0.025);
        eyeG.add(eye);
        const pupil = new THREE.Mesh(track(new THREE.SphereGeometry(1, 8, 6)), eyePupilMat);
        pupil.scale.set(0.015, 0.022, 0.012);
        pupil.position.set(Math.sign(x) * 0.023, 0, 0.012);
        eyeG.add(pupil);
        return eyeG;
      };
      headGroup.add(createSheepEye(0.145));
      headGroup.add(createSheepEye(-0.145));

      // หูแกะยาวออกด้านข้างและลาดลง ไม่ใช่หูตั้งแบบแพะ
      const earGeo = track(new THREE.SphereGeometry(1, 12, 8));
      const leftEar = new THREE.Group();
      leftEar.position.set(0.13, 0.035, -0.015);
      const leftEarMesh = new THREE.Mesh(earGeo, coatMat);
      leftEarMesh.scale.set(0.055, 0.045, 0.14);
      leftEarMesh.rotation.y = -0.22;
      leftEarMesh.rotation.z = -0.20;
      leftEar.add(leftEarMesh);
      headGroup.add(leftEar);

      const rightEar = new THREE.Group();
      rightEar.position.set(-0.13, 0.035, -0.015);
      const rightEarMesh = new THREE.Mesh(earGeo, coatMat);
      rightEarMesh.scale.set(0.055, 0.045, 0.14);
      rightEarMesh.rotation.y = 0.22;
      rightEarMesh.rotation.z = 0.20;
      rightEar.add(rightEarMesh);
      headGroup.add(rightEar);

      // เขามีเฉพาะแกะตัวผู้ที่กำหนดเป็นจ่าฝูง; ใช้โค้งหลายท่อนแทนกรวยตรง
      let beardMesh: THREE.Mesh | undefined; // คงฟิลด์เดิมไว้เพื่อไม่ให้กระทบ interface/animation
      if (isAlpha) {
        const hornMatLocal = hornMat;
        [-1, 1].forEach((side) => {
          const hornRoot = new THREE.Group();
          hornRoot.position.set(side * 0.075, 0.13, -0.055);
          hornRoot.rotation.z = side * -0.18;
          const hornBase = new THREE.Mesh(track(new THREE.TorusGeometry(0.075, 0.027, 6, 10, Math.PI * 0.78)), hornMatLocal);
          hornBase.rotation.x = Math.PI / 2;
          hornBase.rotation.z = side * 0.25;
          hornBase.scale.set(1.0, 1.15, 1.0);
          hornRoot.add(hornBase);
          const hornTip = new THREE.Mesh(track(new THREE.ConeGeometry(0.025, 0.10, 7)), hornMatLocal);
          hornTip.position.set(side * 0.07, 0.015, -0.04);
          hornTip.rotation.z = side * -0.65;
          hornRoot.add(hornTip);
          headGroup.add(hornRoot);
        });
      }

      neckGroup.add(headGroup);
      group.add(neckGroup);

      // ขาทั้ง 4: จุดหมุนอยู่บริเวณหัวไหล่/สะโพก มีท่อนบน-ข้อพับ-ท่อนล่าง-กีบ
      const upperLegGeo = track(new THREE.CylinderGeometry(0.047, 0.036, 0.23, 8));
      const lowerLegGeo = track(new THREE.CylinderGeometry(0.032, 0.025, 0.22, 8));
      const hoofGeo = track(new THREE.SphereGeometry(1, 10, 8));

      const createArticulatedLeg = (x: number, z: number) => {
        const legRoot = new THREE.Group();
        legRoot.position.set(x, 0.43, z);

        const upper = new THREE.Mesh(upperLegGeo, coatMat);
        upper.position.y = -0.105;
        upper.castShadow = true;
        legRoot.add(upper);

        const knee = new THREE.Group();
        knee.position.set(0, -0.19, 0);
        const lower = new THREE.Mesh(lowerLegGeo, coatMat);
        lower.position.y = -0.085;
        lower.scale.y = 0.86;
        lower.castShadow = true;
        knee.add(lower);

        const hoof = new THREE.Mesh(hoofGeo, hoofMat);
        hoof.scale.set(0.052, 0.033, 0.065);
        hoof.position.set(0, -0.19, 0.015);
        hoof.castShadow = true;
        knee.add(hoof);
        legRoot.add(knee);
        group.add(legRoot);
        return legRoot;
      };

      const legFL = createArticulatedLeg(0.19, 0.31);
      const legFR = createArticulatedLeg(-0.19, 0.31);
      const legBL = createArticulatedLeg(0.19, -0.34);
      const legBR = createArticulatedLeg(-0.19, -0.34);

      group.scale.setScalar(scale);
      scene.add(group);

      return {
        id,
        name,
        role,
        group,
        neckGroup,
        headGroup,
        jawMesh,
        leftEar,
        rightEar,
        tailGroup,
        beardMesh,
        udderMesh,
        legFL,
        legFR,
        legBL,
        legBR,
        pos: initPos.clone(),
        targetPos: initPos.clone(),
        direction: Math.random() * Math.PI * 2,
        targetDirection: Math.random() * Math.PI * 2,
        speed: (isKid ? 1.7 : isAlpha ? 1.25 : 1.05) * (0.9 + Math.random() * 0.25),
        state: 'idle',
        stateTimer: Math.random() * 3,
        walkCycle: Math.random() * Math.PI * 2,
        chewCycle: 0,
        bipedalProgress: 0,
        earFlickTimer: Math.random() * 2,
        scale,
      };
    };

    // ฝูงแพะ 6 ตัวที่มีบุคลิกและหน้าที่ต่างกัน
    const herd: GoatInstance[] = [
      createDetailedGoat('g_alpha', 'โกไลแอท (แกะตัวผู้จ่าฝูง)', 'buck_alpha', 0x3f3f46, new THREE.Vector3(-2.2, 0, 0.5)),
      createDetailedGoat('g_bella', 'เบลล่า (แม่แกะขนขาว)', 'doe_milker', 0xfafaf9, new THREE.Vector3(-0.4, 0, 0.2)),
      createDetailedGoat('g_caramel', 'คาราเมล (แม่แกะสีน้ำตาล)', 'doe_brown', 0x9a3412, new THREE.Vector3(-1.1, 0, -0.2)),
      createDetailedGoat('g_panda', 'แพนด้า (แม่แกะลายด่าง)', 'doe_alpine', 0xd4d4d8, new THREE.Vector3(0.3, 0, 0.7)),
      createDetailedGoat('g_pip', 'พิป (ลูกแกะจอมซน)', 'kid_playful', 0xfef08a, new THREE.Vector3(-0.8, 0, 0.6)),
      createDetailedGoat('g_nugget', 'นักเก็ต (ลูกแกะขี้เซา)', 'kid_sleepy', 0xf5f5f4, new THREE.Vector3(1.1, 0, 0.4)),
    ];
    goatsRef.current = herd;

    // H. Animation Loop & Behavioral Simulation
    let animId: number;
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;

      // ฟิสิกส์กอหญ้า
      const grasses = grassParticlesRef.current;
      for (let i = grasses.length - 1; i >= 0; i--) {
        const p = grasses[i];
        p.age += dt;

        if (!p.settled) {
          p.vel.y -= 9.8 * dt;
          p.mesh.position.addScaledVector(p.vel, dt);
          p.mesh.rotation.x += p.rotVel.x * dt;
          p.mesh.rotation.y += p.rotVel.y * dt;

          if (p.mesh.position.y <= p.groundY) {
            p.mesh.position.y = p.groundY;
            p.settled = true;
          }
        }

        if (p.eaten || p.age > 16) {
          p.mesh.scale.multiplyScalar(0.88);
          if (p.mesh.scale.x < 0.04) {
            scene.remove(p.mesh);
            grasses.splice(i, 1);
          }
        }
      }

      // ฟิสิกส์ละอองสายน้ำนม (Milk Jet FX)
      const jets = milkJetParticlesRef.current;
      for (let i = jets.length - 1; i >= 0; i--) {
        const j = jets[i];
        j.life -= dt;
        j.mesh.position.addScaledVector(j.vel, dt);
        if (j.life <= 0) {
          scene.remove(j.mesh);
          jets.splice(i, 1);
        }
      }

      // อัปเดตพฤติกรรม AI ของแพะแต่ละตัว
      herd.forEach((g) => {
        g.stateTimer -= dt;
        g.earFlickTimer -= dt;

        // ส่ายหางตลอดเวลา
        g.tailGroup.rotation.y = Math.sin(currentTime * 0.014) * 0.45;

        // กระดิกหูเป็นระยะ (Ear Flicking)
        if (g.earFlickTimer <= 0) {
          g.leftEar.rotation.x = Math.sin(currentTime * 0.03) * 0.35;
          g.rightEar.rotation.x = -Math.sin(currentTime * 0.03) * 0.35;
          if (g.earFlickTimer < -0.4) g.earFlickTimer = 1.5 + Math.random() * 3.5;
        }

        // คืนท่าจากการยืน 2 ขา ถ้าไม่ได้อยู่ใน state standing_up
        if (g.state !== 'standing_up') {
          g.bipedalProgress = Math.max(0, g.bipedalProgress - dt * 2.5);
        }

        // STATE 1: วิ่งหาเศษหญ้าที่โปรย
        if (g.state === 'seeking_food') {
          let closestDist = Infinity;
          let targetLeaf: GrassParticle | null = null;
          grasses.forEach((leaf) => {
            if (!leaf.eaten) {
              const dist = g.pos.distanceTo(leaf.mesh.position);
              if (dist < closestDist) {
                closestDist = dist;
                targetLeaf = leaf;
              }
            }
          });

          if (targetLeaf && closestDist > 0.42) {
            g.targetPos.copy((targetLeaf as GrassParticle).mesh.position);
            g.targetPos.y = 0;
            const dirX = g.targetPos.x - g.pos.x;
            const dirZ = g.targetPos.z - g.pos.z;
            g.targetDirection = Math.atan2(dirX, dirZ);

            g.walkCycle += dt * 14;
            const stepDist = g.speed * dt * 1.35;
            g.pos.x += Math.sin(g.targetDirection) * stepDist;
            g.pos.z += Math.cos(g.targetDirection) * stepDist;

            g.legFL.rotation.x = Math.sin(g.walkCycle) * 0.42;
            g.legBR.rotation.x = Math.sin(g.walkCycle) * 0.42;
            g.legFR.rotation.x = -Math.sin(g.walkCycle) * 0.42;
            g.legBL.rotation.x = -Math.sin(g.walkCycle) * 0.42;
          } else if (targetLeaf) {
            g.state = 'grazing';
            g.stateTimer = 2.4;
            (targetLeaf as GrassParticle).eaten = true;
            sound.playHarvest?.();
          } else {
            g.state = 'idle';
            g.stateTimer = 2.0;
          }
        }

        // STATE 2: เดินสำรวจพื้นที่
        else if (g.state === 'walking') {
          g.walkCycle += dt * 8.5;
          const stepDist = g.speed * dt;
          g.pos.x += Math.sin(g.targetDirection) * stepDist;
          g.pos.z += Math.cos(g.targetDirection) * stepDist;

          // ขอบเขตคอก
          g.pos.x = Math.max(-2.5, Math.min(2.5, g.pos.x));
          g.pos.z = Math.max(-1.5, Math.min(1.4, g.pos.z));

          g.legFL.rotation.x = Math.sin(g.walkCycle) * 0.34;
          g.legBR.rotation.x = Math.sin(g.walkCycle) * 0.34;
          g.legFR.rotation.x = -Math.sin(g.walkCycle) * 0.34;
          g.legBL.rotation.x = -Math.sin(g.walkCycle) * 0.34;

          g.neckGroup.rotation.x = 0;
          g.headGroup.rotation.x = 0;

          if (g.stateTimer <= 0) {
            // จ่าฝูงชอบปีนขึ้นยอดหิน / แม่แพะชอบยืน 2 ขาชะเง้อรางหญ้า
            if (g.role === 'buck_alpha' && Math.random() > 0.4) {
              g.targetPos.set(-2.3, 0, 0.4);
              g.state = 'idle';
              g.stateTimer = 4.0;
            } else if (g.role.startsWith('doe') && Math.random() > 0.6) {
              g.state = 'standing_up';
              g.stateTimer = 2.5;
            } else {
              g.state = Math.random() > 0.35 ? 'grazing' : 'idle';
              g.stateTimer = 2.5 + Math.random() * 3.5;
            }
            g.legFL.rotation.x = 0;
            g.legFR.rotation.x = 0;
            g.legBL.rotation.x = 0;
            g.legBR.rotation.x = 0;
          }
        }

        // STATE 3: ก้มกินหญ้า & เคี้ยวเอื้อง (Rumination Jaw Chew)
        else if (g.state === 'grazing') {
          g.chewCycle += dt * 9;
          g.neckGroup.rotation.x = 0.42;
          g.headGroup.rotation.x = 0.36;
          // ขากรรไกรบดซ้าย-ขวา
          g.jawMesh.position.x = Math.sin(g.chewCycle) * 0.025;
          g.headGroup.rotation.z = Math.sin(g.chewCycle) * 0.06;

          if (g.stateTimer <= 0) {
            g.neckGroup.rotation.x = 0;
            g.headGroup.rotation.x = 0;
            g.jawMesh.position.x = 0;
            g.state = 'idle';
            g.stateTimer = 2.0 + Math.random() * 2;
          }
        }

        // STATE 4: ยืน 2 ขาหลังชะเง้อกินใบไม้สูง (Bipedal Browsing)
        else if (g.state === 'standing_up') {
          g.bipedalProgress = Math.min(1, g.bipedalProgress + dt * 2.5);
          const p = g.bipedalProgress;
          g.group.rotation.x = -p * 0.65; // ยกลำตัวขึ้น 40 องศา
          g.legFL.rotation.x = -p * 0.8;
          g.legFR.rotation.x = -p * 0.8;
          g.legBL.rotation.x = p * 0.4;
          g.legBR.rotation.x = p * 0.4;
          g.neckGroup.rotation.x = -p * 0.3;

          if (g.stateTimer <= 0) {
            g.state = 'idle';
            g.stateTimer = 2.0;
          }
        }

        // STATE 5: กระโดดดีดตัว 360 องศา (Prancing & Hop)
        else if (g.state === 'prancing') {
          g.walkCycle += dt * 11;
          const hop = Math.abs(Math.sin(g.walkCycle));
          g.group.position.y = hop * 0.38;
          g.legFL.rotation.x = -0.5;
          g.legFR.rotation.x = -0.5;
          g.legBL.rotation.x = 0.6;
          g.legBR.rotation.x = 0.6;

          if (g.stateTimer <= 0) {
            g.group.position.y = 0;
            g.legFL.rotation.x = 0;
            g.legFR.rotation.x = 0;
            g.legBL.rotation.x = 0;
            g.legBR.rotation.x = 0;
            g.state = 'idle';
            g.stateTimer = 2.0;
          }
        }

        // STATE 6: Idle ยืนมอง & กระดิกหู
        else {
          g.walkCycle += dt * 2.2;
          g.headGroup.rotation.y = Math.sin(g.walkCycle) * 0.28;

          if (g.stateTimer <= 0) {
            g.state = 'walking';
            g.targetDirection = Math.random() * Math.PI * 2;
            g.stateTimer = 2.5 + Math.random() * 3.5;
          }
        }

        // การคำนวณปีนหิน 3 ระดับ (Multi-tier Rock Climbing Elevation)
        if (g.state !== 'prancing' && g.state !== 'standing_up') {
          const distToRock = Math.hypot(g.pos.x - (-2.2), g.pos.z - 0.4);
          let rockElevation = 0;
          if (distToRock < 0.45) {
            rockElevation = 0.65; // ยอดหินสูงสุด (Peak)
          } else if (distToRock < 0.8) {
            rockElevation = 0.38; // ชั้นที่สอง
          } else if (distToRock < 1.1) {
            rockElevation = 0.16; // ชั้นฐาน
          }
          g.group.position.y = THREE.MathUtils.lerp(g.group.position.y, rockElevation, 0.15);
        }

        g.group.position.x = g.pos.x;
        g.group.position.z = g.pos.z;

        // Smooth Rotation
        const targetRot = -g.targetDirection + Math.PI;
        g.group.rotation.y = THREE.MathUtils.lerp(g.group.rotation.y, targetRot, 0.1);
      });

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    // Responsive Canvas Resize Observer
    const updateSize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth || 320;
      const h = container.clientHeight || 200;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(() => updateSize());
    resizeObserver.observe(container);
    window.addEventListener('resize', updateSize);

    return () => {
      cancelAnimationFrame(animId);
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateSize);

      grassParticlesRef.current.forEach((p) => scene.remove(p.mesh));
      grassParticlesRef.current = [];
      milkJetParticlesRef.current.forEach((j) => scene.remove(j.mesh));
      milkJetParticlesRef.current = [];

      renderer.dispose();
      disposables.forEach((res) => res.dispose());
    };
  }, []);

  // 🎯 5. คลิกสัมผัสแพะ (Raycasting Interaction)
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.stopPropagation();
    if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const goatGroups = goatsRef.current.map((g) => g.group);
    const intersects = raycaster.intersectObjects(goatGroups, true);

    if (intersects.length > 0) {
      sound.playAnimal?.('cow'); // หรือเสียงแกะ

      const clickedGoat = goatsRef.current.find((g) => {
        let cur: THREE.Object3D | null = intersects[0].object;
        while (cur) {
          if (cur === g.group) return true;
          cur = cur.parent;
        }
        return false;
      }) || goatsRef.current[0];

      // กระตุ้นท่าพิเศษตามบทบาท
      if (clickedGoat.role === 'buck_alpha') {
        clickedGoat.state = 'standing_up';
        clickedGoat.stateTimer = 2.0;
        setActiveSpeech(`👑 ${clickedGoat.name}: "ฮึ่มมม! ข้าคือจ่าฝูงผู้พิชิตยอดหินชัน!" 🐐⛰️`);
      } else if (clickedGoat.role.startsWith('doe')) {
        clickedGoat.state = 'prancing';
        clickedGoat.stateTimer = 1.4;
        spawnMilkSquirts(clickedGoat.group.position);
        setActiveSpeech(`🥛 ${clickedGoat.name}: "แบ๊ะๆๆ! นมแพะออร์แกนิกหอมมันพร้อมส่งจ้า!" ✨`);
      } else {
        clickedGoat.state = 'prancing';
        clickedGoat.stateTimer = 1.6;
        setActiveSpeech(`🤸 ${clickedGoat.name}: "ดุ๊กดิ๊กๆ! วิ่งเล่นกระโดดดีดตัวสนุกจังเล้ย!" 🍀`);
      }

      setTimeout(() => setActiveSpeech(null), 3200);
    } else {
      spawnGrassScattering(0, 0);
      sound.playPlant?.();
    }
  };

  const handleFeed = () => {
    if (isFed) return;
    spawnGrassScattering(0, 0);
    sound.playPlant?.();
    if (onFeed) onFeed();

    setFeedEffect(true);
    setTimeout(() => setFeedEffect(false), 2000);
    setActiveSpeech('โปรยหญ้าเนเปียร์สดเขียวชอุ่ม! ฝูงแกะ 6 ตัวเดินเข้ามากินหญ้า 🌿🐐');
    setTimeout(() => setActiveSpeech(null), 3200);
  };

  const handleCollect = () => {
    sound.playHarvest?.();
    const milker = goatsRef.current.find((g) => g.role === 'doe_milker');
    if (milker) spawnMilkSquirts(milker.group.position);
    if (handleCollectAction) handleCollectAction();
  };

  return (
    <div
      ref={containerRef}
      className={`relative select-none ${
        seamless
          ? 'w-full h-full overflow-visible bg-transparent'
          : 'w-full h-[230px] sm:h-[270px] rounded-3xl overflow-hidden shadow-2xl border-4 border-[#5c3a21] bg-[#2a1a0f]'
      } ${className}`}
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-pointer touch-none"
        title="แตะที่ตัวแกะเพื่อดูท่าทาง หรือแตะพื้นเพื่อโปรยหญ้าสด!"
      />

      {!compact && (
        <div className="absolute top-2.5 inset-x-3 flex items-center justify-between pointer-events-none z-10">
          <div className="flex items-center gap-1.5 px-3.5 py-1 bg-[#231509]/90 backdrop-blur-sm rounded-full border border-amber-600/50 shadow-md">
            <span className="text-base">🐐</span>
            <span className="text-xs font-bold text-amber-200 font-['Kanit',sans-serif]">
              ฝูงแกะ 3D (แกะโตและลูกแกะ 6 ตัว)
            </span>
            {isFed && <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping ml-1" />}
          </div>

          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={handleFeed}
              disabled={isFed}
              className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 transition-transform active:scale-95 shadow-md ${
                isFed
                  ? 'bg-emerald-950/60 text-emerald-300/50 cursor-not-allowed border border-emerald-900'
                  : 'bg-gradient-to-b from-lime-500 to-emerald-600 hover:from-lime-400 text-emerald-950 border border-white cursor-pointer'
              }`}
            >
              <span>🌿</span>
              <span>{isFed ? 'แพะอิ่มแล้ว' : 'โปรยหญ้าสด'}</span>
            </button>

            {readyProduce > 0 && handleCollectAction && (
              <button
                type="button"
                onClick={handleCollect}
                className="px-3.5 py-1.5 bg-gradient-to-b from-blue-500 to-indigo-600 hover:from-blue-400 text-white font-bold text-xs rounded-xl border border-white shadow-md flex items-center gap-1 cursor-pointer animate-bounce transition-transform"
              >
                <span>🥛</span>
                <span>เก็บน้ำนม ({readyProduce})</span>
              </button>
            )}
          </div>
        </div>
      )}

      {compact && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-30 pointer-events-auto">
          {!isFed && onFeed && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleFeed();
              }}
              className="px-3 py-1 bg-lime-500 hover:bg-lime-400 text-emerald-950 rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🌿</span>
              <span>ให้หญ้า</span>
            </button>
          )}
          {readyProduce > 0 && handleCollectAction && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCollect();
              }}
              className="px-3 py-1 bg-blue-500 hover:bg-blue-400 text-white rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 animate-bounce transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🥛</span>
              <span>เก็บนม ({readyProduce})</span>
            </button>
          )}
        </div>
      )}

      {activeSpeech && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-black/85 text-amber-200 text-xs font-bold rounded-full border border-amber-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}

      {feedEffect && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-25">
          <span className="text-3xl animate-ping">🌿 🌿 🌿 🌿</span>
        </div>
      )}
    </div>
  );
};