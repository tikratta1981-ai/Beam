export { IsometricPig3D, type PigEntity, type IsometricPig3DProps } from './models/animals/IsometricPig3D';
export { default } from './models/animals/IsometricPig3D';
