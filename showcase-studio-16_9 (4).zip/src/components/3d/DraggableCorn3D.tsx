import React, { useEffect, useRef, memo } from 'react';
import * as THREE from 'three';

export interface DraggableCorn3DProps {
  isGrand: boolean;
  isReady: boolean;
  isWatered?: boolean;
  width: number;
  height: number;
}

export const DraggableCorn3D: React.FC<DraggableCorn3DProps> = memo(({
  isGrand,
  isReady,
  isWatered = true,
  width,
  height,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.OrthographicCamera | null>(null);
  const soilMatRef = useRef<THREE.MeshStandardMaterial | null>(null);

  // 1. Dynamic Resize
  useEffect(() => {
    if (!rendererRef.current || !cameraRef.current || width <= 0 || height <= 0) return;

    const aspect = width / height;
    const d = isGrand ? 175 : 145;

    cameraRef.current.left = -d * aspect;
    cameraRef.current.right = d * aspect;
    cameraRef.current.top = d;
    cameraRef.current.bottom = -d;
    cameraRef.current.updateProjectionMatrix();

    rendererRef.current.setSize(width, height);
  }, [width, height, isGrand]);

  // 2. Dynamic Soil Material Update
  useEffect(() => {
    if (soilMatRef.current) {
      soilMatRef.current.color.setHex(isWatered ? 0x2e1809 : 0x503117);
      soilMatRef.current.roughness = isWatered ? 0.75 : 0.95;
      soilMatRef.current.metalness = isWatered ? 0.08 : 0.0;
    }
  }, [isWatered]);

  // 3. Scene Setup with InstancedMesh
  useEffect(() => {
    const container = mountRef.current;
    if (!container || width <= 0 || height <= 0) return;

    const scene = new THREE.Scene();
    const aspect = width / height;
    const d = isGrand ? 175 : 145;

    const camera = new THREE.OrthographicCamera(
      -d * aspect,
      d * aspect,
      d,
      -d,
      1,
      1400
    );
    camera.position.set(220, 240, 220);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // --- Lights ---
    const hemiLight = new THREE.HemisphereLight(0xfffae8, 0x3d5a24, 1.35);
    scene.add(hemiLight);

    const sun = new THREE.DirectionalLight(0xfff5e0, 1.55);
    sun.position.set(160, 280, 120);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.bias = -0.0008;

    const shadowSize = isGrand ? 240 : 190;
    sun.shadow.camera.near = 50;
    sun.shadow.camera.far = 700;
    sun.shadow.camera.left = -shadowSize;
    sun.shadow.camera.right = shadowSize;
    sun.shadow.camera.top = shadowSize;
    sun.shadow.camera.bottom = -shadowSize;
    scene.add(sun);

    const fillLight = new THREE.DirectionalLight(0xa6df7a, 0.35);
    fillLight.position.set(-140, 90, -110);
    scene.add(fillLight);

    // --- Ground & Soil ---
    const shadowGeo = new THREE.PlaneGeometry(550, 550);
    const shadowMat = new THREE.ShadowMaterial({ opacity: 0.28 });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -0.05;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    const soilMat = new THREE.MeshStandardMaterial({
      color: isWatered ? 0x2e1809 : 0x503117,
      roughness: isWatered ? 0.75 : 0.95,
      metalness: isWatered ? 0.08 : 0.0,
    });
    soilMatRef.current = soilMat;

    // Ridges (แปลงดิน)
    const ridgeRows = 16;
    const rowSpacing = 16.5;
    const ridgeLength = isGrand ? 76 : 115;
    const ridgeGeo = new THREE.CylinderGeometry(2.8, 3.8, ridgeLength, 6);
    const blockCentersX = isGrand ? [-46, 46] : [0];
    const totalRidges = ridgeRows * blockCentersX.length;
    const ridgeMesh = new THREE.InstancedMesh(ridgeGeo, soilMat, totalRidges);
    ridgeMesh.receiveShadow = true;

    const dummy = new THREE.Object3D();
    let ridgeIdx = 0;
    blockCentersX.forEach((centerX) => {
      for (let r = 0; r < ridgeRows; r++) {
        dummy.position.set(centerX, 0.7, (r - (ridgeRows - 1) / 2) * rowSpacing);
        dummy.rotation.set(0, 0, Math.PI / 2);
        dummy.updateMatrix();
        ridgeMesh.setMatrixAt(ridgeIdx++, dummy.matrix);
      }
    });
    ridgeMesh.instanceMatrix.needsUpdate = true;
    scene.add(ridgeMesh);

    // --- ข้าวโพด (Corn Plants with InstancedMesh) ---
    const scale = isReady ? (isGrand ? 0.86 : 0.82) : (isGrand ? 0.60 : 0.52);
    const plantXPositions = isGrand
      ? [-62, -52, -40, -30, 30, 40, 52, 62]
      : [-36, -12, 12, 36];
    const totalPlants = ridgeRows * plantXPositions.length;

    // Materials
    const stalkMat = new THREE.MeshStandardMaterial({ color: 0x4f8e24, roughness: 0.55 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x64af2e, roughness: 0.42, side: THREE.DoubleSide });
    const tasselMat = new THREE.MeshStandardMaterial({ color: 0xd6b74b, roughness: 0.8 });
    const earMat = new THREE.MeshStandardMaterial({ color: isReady ? 0xffb703 : 0xdf9e0c, roughness: 0.32 });
    const huskMat = new THREE.MeshStandardMaterial({ color: 0x71ad34, roughness: 0.65 });
    const silkMat = new THREE.MeshStandardMaterial({ color: 0x823b18, roughness: 0.9 });

    // Geometries
    const stalkHeight = 24 * scale;
    const stalkGeo = new THREE.CylinderGeometry(0.5 * scale, 0.85 * scale, stalkHeight, 5);
    stalkGeo.translate(0, stalkHeight / 2, 0);

    const leafGeo = new THREE.PlaneGeometry(2.6 * scale, 12 * scale, 1, 2);
    leafGeo.translate(0, 6 * scale, 0);

    const tasselGeo = new THREE.ConeGeometry(0.7 * scale, 3.5 * scale, 4);
    tasselGeo.translate(0, stalkHeight + 1.2 * scale, 0);

    // Instanced Meshes
    const stalkMesh = new THREE.InstancedMesh(stalkGeo, stalkMat, totalPlants);
    stalkMesh.castShadow = true;
    scene.add(stalkMesh);

    const tasselMesh = new THREE.InstancedMesh(tasselGeo, tasselMat, totalPlants);
    scene.add(tasselMesh);

    const leafMeshes: THREE.InstancedMesh[] = [];
    for (let l = 0; l < 4; l++) {
      const lm = new THREE.InstancedMesh(leafGeo, leafMat, totalPlants);
      if (l >= 2) lm.castShadow = true;
      scene.add(lm);
      leafMeshes.push(lm);
    }

    let earMesh: THREE.InstancedMesh | null = null;
    let huskMesh: THREE.InstancedMesh | null = null;
    let silkMesh: THREE.InstancedMesh | null = null;

    let earGeo: THREE.ConeGeometry | null = null;
    let huskGeo: THREE.CylinderGeometry | null = null;
    let silkGeo: THREE.ConeGeometry | null = null;

    if (isReady) {
      earGeo = new THREE.ConeGeometry(1.4 * scale, 6.2 * scale, 6);
      earGeo.translate(0, 3.1 * scale, 0);

      huskGeo = new THREE.CylinderGeometry(1.5 * scale, 1.6 * scale, 3.6 * scale, 5, 1, true);
      huskGeo.translate(0, 1.7 * scale, 0);

      silkGeo = new THREE.ConeGeometry(0.5 * scale, 1.8 * scale, 4);
      silkGeo.translate(0, 6.8 * scale, 0);

      earMesh = new THREE.InstancedMesh(earGeo, earMat, totalPlants);
      earMesh.castShadow = true;
      huskMesh = new THREE.InstancedMesh(huskGeo, huskMat, totalPlants);
      silkMesh = new THREE.InstancedMesh(silkGeo, silkMat, totalPlants);

      scene.add(earMesh, huskMesh, silkMesh);
    }

    // เก็บ Metadata ตำแหน่งต้นไม้เพื่อคำนวณคลื่นลม
    const plantData: { x: number; z: number; waveOffset: number; r: number; c: number }[] = [];
    for (let r = 0; r < ridgeRows; r++) {
      const posZ = (r - (ridgeRows - 1) / 2) * rowSpacing;
      plantXPositions.forEach((posX, colIndex) => {
        plantData.push({
          x: posX,
          z: posZ,
          waveOffset: posX * 0.04 + posZ * 0.035,
          r,
          c: colIndex,
        });
      });
    }

    // Helper Objects สำหรับคำนวณ Matrix เพื่อเลี่ยง GC (Garbage Collection)
    const plantDummy = new THREE.Object3D();
    const partDummy = new THREE.Object3D();

    // --- Animation Loop ---
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();

      for (let i = 0; i < totalPlants; i++) {
        const p = plantData[i];
        
        // คำนวณการโยกของต้นข้าวโพด
        plantDummy.position.set(p.x, 0, p.z);
        plantDummy.rotation.set(
          Math.cos(t * 1.6 + p.waveOffset) * 0.018,
          0,
          Math.sin(t * 2.2 + p.waveOffset) * 0.032
        );
        plantDummy.updateMatrix();

        stalkMesh.setMatrixAt(i, plantDummy.matrix);
        tasselMesh.setMatrixAt(i, plantDummy.matrix);

        // คำนวณ Matrix ของใบ
        for (let l = 0; l < 4; l++) {
          partDummy.position.set(0, (4 + l * 4) * scale, 0);
          partDummy.rotation.set(0.62, (l * Math.PI) / 2 + ((p.r + p.c) % 2 ? 0.3 : 0), 0);
          partDummy.updateMatrix();

          // รวม Transform เข้ากับลำต้น
          dummy.matrix.multiplyMatrices(plantDummy.matrix, partDummy.matrix);
          leafMeshes[l].setMatrixAt(i, dummy.matrix);
        }

        // คำนวณ Matrix ของฝัก
        if (isReady && earMesh && huskMesh && silkMesh) {
          partDummy.position.set(1.2 * scale, stalkHeight * 0.44, 0);
          partDummy.rotation.set(0, 0, -0.52);
          partDummy.updateMatrix();

          dummy.matrix.multiplyMatrices(plantDummy.matrix, partDummy.matrix);
          earMesh.setMatrixAt(i, dummy.matrix);
          huskMesh.setMatrixAt(i, dummy.matrix);
          silkMesh.setMatrixAt(i, dummy.matrix);
        }
      }

      // แจ้ง Three.js ให้อัปเดตข้อมูล Buffer ไปยัง GPU
      stalkMesh.instanceMatrix.needsUpdate = true;
      tasselMesh.instanceMatrix.needsUpdate = true;
      for (let l = 0; l < 4; l++) {
        leafMeshes[l].instanceMatrix.needsUpdate = true;
      }
      if (isReady && earMesh && huskMesh && silkMesh) {
        earMesh.instanceMatrix.needsUpdate = true;
        huskMesh.instanceMatrix.needsUpdate = true;
        silkMesh.instanceMatrix.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };

    animate();

    // --- Cleanup ---
    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();

      shadowGeo.dispose();
      ridgeGeo.dispose();
      stalkGeo.dispose();
      leafGeo.dispose();
      tasselGeo.dispose();
      earGeo?.dispose();
      huskGeo?.dispose();
      silkGeo?.dispose();

      shadowMat.dispose();
      soilMat.dispose();
      stalkMat.dispose();
      leafMat.dispose();
      tasselMat.dispose();
      earMat.dispose();
      huskMat.dispose();
      silkMat.dispose();

      soilMatRef.current = null;
      rendererRef.current = null;
      cameraRef.current = null;

      container.innerHTML = '';
    };
  }, [isGrand, isReady]);

  return <div ref={mountRef} className="w-full h-full pointer-events-none" />;
});