import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../utils/audio';

export interface Pig3DProps {
  position?: [number, number, number];
  scale?: number;
  roamRadius?: number;
  readyProduce?: number;
  isFed?: boolean;
  onFeed?: () => void;
  onCollectProduce?: () => void;
  onClick?: () => void;
  seamless?: boolean;
  compact?: boolean;
  className?: string;
}

export const Pig3D: React.FC<Pig3DProps> = ({
  scale = 1,
  roamRadius = 1.5,
  readyProduce = 0,
  isFed = true,
  onFeed,
  onCollectProduce,
  onClick,
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 160;
    const height = container.clientHeight || 140;

    const disposables: (THREE.BufferGeometry | THREE.Material)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 100);
    camera.position.set(0, 3.2, 4.8);
    camera.lookAt(0, 0.5, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    // แสง
    const ambientLight = new THREE.AmbientLight(0xfff5ea, 1.3);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffdf0, 1.6);
    sunLight.position.set(4, 7, 3);
    sunLight.castShadow = true;
    scene.add(sunLight);

    // สีและวัสดุของหมู
    const pigPinkMat = track(new THREE.MeshStandardMaterial({ color: 0xf4a6b7, roughness: 0.7 }));
    const pigLightMat = track(new THREE.MeshStandardMaterial({ color: 0xfbcfe8, roughness: 0.8 }));
    const pigDarkMat = track(new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.6 }));
    const snoutMat = track(new THREE.MeshStandardMaterial({ color: 0xdb2777, roughness: 0.5 }));
    const eyeMat = track(new THREE.MeshBasicMaterial({ color: 0x1f2937 }));
    const hoofMat = track(new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.9 }));

    // โมเดลหมู
    const pigGroup = new THREE.Group();
    scene.add(pigGroup);

    // ลำตัว
    const bodyGeo = track(new THREE.SphereGeometry(0.7, 20, 16));
    const bodyMesh = new THREE.Mesh(bodyGeo, pigPinkMat);
    bodyMesh.scale.set(1.1, 0.9, 1.4);
    bodyMesh.position.set(0, 0.8, 0);
    bodyMesh.castShadow = true;
    pigGroup.add(bodyMesh);

    // หัว
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.95, 0.85);
    pigGroup.add(headGroup);

    const headGeo = track(new THREE.SphereGeometry(0.5, 16, 14));
    const headMesh = new THREE.Mesh(headGeo, pigPinkMat);
    headMesh.scale.set(1, 0.95, 1);
    headMesh.castShadow = true;
    headGroup.add(headMesh);

    // จมูก (Snout)
    const snoutGeo = track(new THREE.CylinderGeometry(0.2, 0.22, 0.22, 16));
    const snoutMesh = new THREE.Mesh(snoutGeo, snoutMat);
    snoutMesh.rotation.x = Math.PI / 2;
    snoutMesh.position.set(0, -0.05, 0.48);
    snoutMesh.castShadow = true;
    headGroup.add(snoutMesh);

    // รูจมูก
    const nostrilGeo = track(new THREE.CylinderGeometry(0.04, 0.04, 0.05, 8));
    const nostrilLeft = new THREE.Mesh(nostrilGeo, eyeMat);
    nostrilLeft.rotation.x = Math.PI / 2;
    nostrilLeft.position.set(-0.08, -0.05, 0.6);
    headGroup.add(nostrilLeft);

    const nostrilRight = new THREE.Mesh(nostrilGeo, eyeMat);
    nostrilRight.rotation.x = Math.PI / 2;
    nostrilRight.position.set(0.08, -0.05, 0.6);
    headGroup.add(nostrilRight);

    // ตา
    const eyeGeo = track(new THREE.SphereGeometry(0.06, 8, 8));
    const eyeLeft = new THREE.Mesh(eyeGeo, eyeMat);
    eyeLeft.position.set(-0.25, 0.16, 0.4);
    headGroup.add(eyeLeft);

    const eyeRight = new THREE.Mesh(eyeGeo, eyeMat);
    eyeRight.position.set(0.25, 0.16, 0.4);
    headGroup.add(eyeRight);

    // หู (2 ข้าง)
    const earGeo = track(new THREE.ConeGeometry(0.18, 0.35, 4));
    const earLeft = new THREE.Mesh(earGeo, pigDarkMat);
    earLeft.position.set(-0.32, 0.42, 0.15);
    earLeft.rotation.set(-0.3, 0.2, -0.6);
    headGroup.add(earLeft);

    const earRight = new THREE.Mesh(earGeo, pigDarkMat);
    earRight.position.set(0.32, 0.42, 0.15);
    earRight.rotation.set(-0.3, -0.2, 0.6);
    headGroup.add(earRight);

    // ขา 4 ขา
    const legGeo = track(new THREE.CylinderGeometry(0.11, 0.1, 0.5, 10));
    const hoofGeo = track(new THREE.CylinderGeometry(0.1, 0.12, 0.1, 10));

    const createLeg = (x: number, z: number) => {
      const legGroup = new THREE.Group();
      legGroup.position.set(x, 0.45, z);

      const legMesh = new THREE.Mesh(legGeo, pigLightMat);
      legMesh.position.set(0, -0.15, 0);
      legMesh.castShadow = true;
      legGroup.add(legMesh);

      const hoofMesh = new THREE.Mesh(hoofGeo, hoofMat);
      hoofMesh.position.set(0, -0.38, 0);
      legGroup.add(hoofMesh);

      pigGroup.add(legGroup);
      return legGroup;
    };

    const legFL = createLeg(-0.38, 0.55);
    const legFR = createLeg(0.38, 0.55);
    const legBL = createLeg(-0.38, -0.55);
    const legBR = createLeg(0.38, -0.55);

    // หางขด
    const tailGroup = new THREE.Group();
    tailGroup.position.set(0, 0.85, -1.05);
    const tailGeo = track(new THREE.TorusGeometry(0.12, 0.04, 8, 16, Math.PI * 1.6));
    const tailMesh = new THREE.Mesh(tailGeo, pigDarkMat);
    tailMesh.rotation.y = Math.PI / 2;
    tailGroup.add(tailMesh);
    pigGroup.add(tailGroup);

    pigGroup.scale.set(scale * 0.9, scale * 0.9, scale * 0.9);

    // อนิเมชัน
    let animId: number;
    let clock = new THREE.Clock();
    let isMoving = true;
    let targetX = 0;
    let targetZ = 0;
    let nextMoveTime = 2;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // สุ่มเปลี่ยนทิศทางเดิน
      nextMoveTime -= delta;
      if (nextMoveTime <= 0) {
        nextMoveTime = 2 + Math.random() * 3;
        targetX = (Math.random() - 0.5) * roamRadius;
        targetZ = (Math.random() - 0.5) * roamRadius;
        isMoving = Math.random() > 0.25;
      }

      if (isMoving) {
        const dx = targetX - pigGroup.position.x;
        const dz = targetZ - pigGroup.position.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.05) {
          const targetAngle = Math.atan2(dx, dz);
          pigGroup.rotation.y += (targetAngle - pigGroup.rotation.y) * 0.08;
          pigGroup.position.x += Math.sin(pigGroup.rotation.y) * 0.4 * delta;
          pigGroup.position.z += Math.cos(pigGroup.rotation.y) * 0.4 * delta;

          // ขยับขาเดิน
          const walkSpeed = 9;
          legFL.rotation.x = Math.sin(elapsed * walkSpeed) * 0.45;
          legBR.rotation.x = Math.sin(elapsed * walkSpeed) * 0.45;
          legFR.rotation.x = -Math.sin(elapsed * walkSpeed) * 0.45;
          legBL.rotation.x = -Math.sin(elapsed * walkSpeed) * 0.45;

          bodyMesh.position.y = 0.8 + Math.abs(Math.sin(elapsed * walkSpeed * 2)) * 0.04;
        } else {
          isMoving = false;
        }
      } else {
        // ยืนเฉยๆ หายใจ
        legFL.rotation.x *= 0.85;
        legFR.rotation.x *= 0.85;
        legBL.rotation.x *= 0.85;
        legBR.rotation.x *= 0.85;
        bodyMesh.position.y = 0.8 + Math.sin(elapsed * 2.5) * 0.02;
      }

      // ส่ายหาง
      tailGroup.rotation.z = Math.sin(elapsed * 6) * 0.25;
      headGroup.rotation.y = Math.sin(elapsed * 1.5) * 0.12;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth || 160;
      const h = container.clientHeight || 140;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      disposables.forEach((d) => d.dispose());
      renderer.dispose();
    };
  }, [scale, roamRadius]);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      sound.playAnimal('pig');
    } catch {}
    setActiveSpeech('อู๊ดๆ! 🐷');
    setTimeout(() => setActiveSpeech(null), 1800);
    onClick?.();
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      className={`relative cursor-pointer select-none ${seamless ? '' : 'w-40 h-36'} ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* บอลลูนคำพูดเสียงร้อง */}
      {activeSpeech && (
        <div className="absolute top-1 left-1/2 -translate-x-1/2 bg-white/95 text-pink-700 font-bold text-xs px-2.5 py-1 rounded-full shadow-lg border border-pink-200 animate-bounce whitespace-nowrap z-20">
          {activeSpeech}
        </div>
      )}

      {/* ป้ายผลผลิตพร้อมเก็บ */}
      {readyProduce > 0 && onCollectProduce && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onCollectProduce();
          }}
          className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500 hover:bg-amber-400 text-stone-900 font-black text-xs px-2 py-0.5 rounded-full shadow border-2 border-white flex items-center gap-1 z-30"
        >
          <span>🐷 เก็บผลผลิต ({readyProduce})</span>
        </button>
      )}

      {/* ป้ายให้อาหาร */}
      {!isFed && onFeed && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onFeed();
          }}
          className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-pink-500 hover:bg-pink-400 text-white font-bold text-[11px] px-2 py-0.5 rounded-full shadow border border-white flex items-center gap-1 z-30"
        >
          <span>ให้อาหาร 🥣</span>
        </button>
      )}
    </div>
  );
};

export default Pig3D;
