// src/components/3d/AnimatedCrop3D.tsx

import React from 'react';

interface AnimatedCrop3DProps {
  cropId: string;
  size?: number;
  className?: string;
}

export const AnimatedCrop3D: React.FC<AnimatedCrop3DProps> = ({
  cropId,
  size = 76,
  className = '',
}) => {
  return (
    <div
      style={{ width: `${size}px`, height: `${size}px` }}
      className={`relative flex items-center justify-center select-none ${className}`}
    >
      <style>{`
        @keyframes float-sway {
          0%, 100% { transform: translateY(0) rotate(0deg) scale(1); }
          50% { transform: translateY(-4px) rotate(2deg) scale(1.05); }
        }
        @keyframes pulse-shimmer {
          0%, 100% { filter: drop-shadow(0 4px 6px rgba(0,0,0,0.45)) brightness(1); }
          50% { filter: drop-shadow(0 8px 14px rgba(251,191,36,0.65)) brightness(1.15); }
        }
        .anim-crop-3d {
          animation: float-sway 3.2s ease-in-out infinite, pulse-shimmer 2.4s ease-in-out infinite;
          transform-origin: center bottom;
        }
      `}</style>

      {/* เงาตกกระทบบนแท่นวางสินค้า (Soft Base Shadow) */}
      <div className="absolute bottom-1 w-3/4 h-3.5 rounded-full bg-black/45 blur-xs pointer-events-none" />

      {/* โมเดลเวกเตอร์ 3D แยกตามชนิดพืชผล */}
      <div className="relative z-10 anim-crop-3d flex items-center justify-center">
        {/* 1. ข้าวสาลีทองคำ 3D (Golden Wheat Sheaf) */}
        {cropId === 'wheat' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <linearGradient id="wheatGold" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="40%" stopColor="#eab308" />
                <stop offset="100%" stopColor="#a16207" />
              </linearGradient>
            </defs>
            {/* ก้านข้าวสาลี */}
            <path d="M32 60 Q32 36 24 16 M32 60 Q34 38 40 18" stroke="#ca8a04" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            {/* เมล็ดรวงข้าวทอง 3 มิติ */}
            {[
              { cx: 28, cy: 18, r: 4.5, rot: -20 },
              { cx: 36, cy: 20, r: 4.5, rot: 25 },
              { cx: 27, cy: 27, r: 4.5, rot: -25 },
              { cx: 37, cy: 29, r: 4.5, rot: 20 },
              { cx: 29, cy: 36, r: 4, rot: -15 },
              { cx: 35, cy: 38, r: 4, rot: 15 },
              { cx: 32, cy: 12, r: 5, rot: 0 },
            ].map((seed, i) => (
              <ellipse
                key={i}
                cx={seed.cx}
                cy={seed.cy}
                rx={seed.r}
                ry={seed.r * 1.5}
                fill="url(#wheatGold)"
                stroke="#854d0e"
                strokeWidth="0.8"
                transform={`rotate(${seed.rot} ${seed.cx} ${seed.cy})`}
              />
            ))}
          </svg>
        )}

        {/* 2. ข้าวโพดหวาน 3D (Sweet Corn with Husk) */}
        {cropId === 'corn' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <linearGradient id="cornGold" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="50%" stopColor="#facc15" />
                <stop offset="100%" stopColor="#ca8a04" />
              </linearGradient>
              <linearGradient id="cornLeaf" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#4ade80" />
                <stop offset="100%" stopColor="#15803d" />
              </linearGradient>
            </defs>
            {/* ฝักข้าวโพด */}
            <path d="M26 12 C26 6, 38 6, 38 12 L39 44 C39 52, 25 52, 25 44 Z" fill="url(#cornGold)" stroke="#a16207" strokeWidth="1" />
            {/* เมล็ดข้าวโพดนูน */}
            {[14, 20, 26, 32, 38, 44].map((y, row) => (
              <g key={row}>
                <circle cx={29} cy={y} r={2.2} fill="#fef9c3" opacity="0.9" />
                <circle cx={35} cy={y} r={2.2} fill="#fef9c3" opacity="0.9" />
              </g>
            ))}
            {/* เปลือกใบเขียว 3D */}
            <path d="M22 52 C16 40, 18 24, 26 28 C22 38, 24 46, 26 52 Z" fill="url(#cornLeaf)" stroke="#166534" strokeWidth="0.8" />
            <path d="M42 52 C48 40, 46 24, 38 28 C42 38, 40 46, 38 52 Z" fill="url(#cornLeaf)" stroke="#166534" strokeWidth="0.8" />
          </svg>
        )}

        {/* 3. แครอทส้ม 3D (Crisp Orange Carrot) */}
        {cropId === 'carrot' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <linearGradient id="carrotGrad" x1="0%" y1="0%" x2="100%" y2="50%">
                <stop offset="0%" stopColor="#fed7aa" />
                <stop offset="35%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#c2410c" />
              </linearGradient>
            </defs>
            {/* ใบเขียวด้านบน */}
            <path d="M32 18 C30 8, 22 10, 24 18 C28 10, 36 8, 32 18 C36 10, 42 12, 36 18" fill="#22c55e" stroke="#15803d" strokeWidth="1" />
            {/* หัวแครอททรงกรวย 3D */}
            <path d="M22 20 C22 17, 42 17, 42 20 L35 56 C34 59, 30 59, 29 56 Z" fill="url(#carrotGrad)" stroke="#9a3412" strokeWidth="1" />
            {/* ริ้วรอยธรรมชาติ */}
            <path d="M26 28 Q32 30 38 28 M27 38 Q32 40 37 38 M29 48 Q32 49 35 48" stroke="#7c2d12" strokeWidth="1" strokeLinecap="round" opacity="0.6" />
          </svg>
        )}

        {/* 4. มะเขือเทศฉ่ำ 3D (Juicy Plump Tomato) */}
        {cropId === 'tomato' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <radialGradient id="tomatoRed" cx="35%" cy="35%" r="65%">
                <stop offset="0%" stopColor="#fca5a5" />
                <stop offset="30%" stopColor="#ef4444" />
                <stop offset="85%" stopColor="#b91c1c" />
                <stop offset="100%" stopColor="#7f1d1d" />
              </radialGradient>
            </defs>
            {/* ผลมะเขือเทศทรงกลมฉ่ำน้ำ */}
            <ellipse cx="32" cy="38" rx="20" ry="18" fill="url(#tomatoRed)" stroke="#991b1b" strokeWidth="1" />
            {/* ประกายไฮไลต์แสงสะท้อนทรงกลม */}
            <ellipse cx="26" cy="30" rx="6" ry="4" fill="white" opacity="0.55" transform="rotate(-20 26 30)" />
            {/* ขั้วใบมะเขือเทศรูปดาว */}
            <path d="M32 20 L34 14 L32 12 L30 14 Z M32 20 L38 18 L32 20 L26 18 Z M32 20 L36 24 L32 20 L28 24 Z" fill="#16a34a" stroke="#14532d" strokeWidth="0.8" />
          </svg>
        )}

        {/* 5. แตงกวากรอบ 3D (Crisp Fresh Cucumber) */}
        {cropId === 'cucumber' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <linearGradient id="cucumberGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#86efac" />
                <stop offset="40%" stopColor="#22c55e" />
                <stop offset="100%" stopColor="#14532d" />
              </linearGradient>
            </defs>
            {/* ผลแตงกวาโค้ง 3 มิติ */}
            <path d="M16 48 C12 36, 20 18, 38 16 C48 15, 52 24, 48 32 C40 48, 26 56, 16 48 Z" fill="url(#cucumberGrad)" stroke="#14532d" strokeWidth="1.2" />
            {/* ปุ่มหนามเล็กๆ บนผิวแตงกวา */}
            {[
              { cx: 24, cy: 38 }, { cx: 32, cy: 28 }, { cx: 40, cy: 24 },
              { cx: 28, cy: 46 }, { cx: 36, cy: 36 }, { cx: 44, cy: 30 }
            ].map((p, i) => (
              <circle key={i} cx={p.cx} cy={p.cy} r={1.5} fill="#bbf7d0" opacity="0.75" />
            ))}
          </svg>
        )}

        {/* 6. ดอกลาเวนเดอร์ 3D (Purple French Lavender Bouquet) -> แก้ไขบั๊กกล่องสี่เหลี่ยม ▯ 100% */}
        {cropId === 'lavender' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <linearGradient id="lavenderPurple" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#e9d5ff" />
                <stop offset="50%" stopColor="#a855f7" />
                <stop offset="100%" stopColor="#6b21a8" />
              </linearGradient>
            </defs>
            {/* ก้านดอกสีเขียว */}
            <path d="M32 58 L32 20 M24 56 Q28 42 27 26 M40 56 Q36 42 37 26" stroke="#15803d" strokeWidth="1.8" strokeLinecap="round" />
            {/* ช่อดอกลาเวนเดอร์สีม่วงไล่ระดับ 3D */}
            {[
              { cx: 32, cy: 14, r: 4.2 }, { cx: 29, cy: 20, r: 4 }, { cx: 35, cy: 20, r: 4 },
              { cx: 28, cy: 26, r: 4.2 }, { cx: 36, cy: 26, r: 4.2 }, { cx: 32, cy: 32, r: 4.5 },
              { cx: 26, cy: 22, r: 3.5 }, { cx: 24, cy: 28, r: 3.8 }, { cx: 27, cy: 34, r: 3.8 },
              { cx: 38, cy: 22, r: 3.5 }, { cx: 40, cy: 28, r: 3.8 }, { cx: 37, cy: 34, r: 3.8 },
            ].map((bud, i) => (
              <circle
                key={i}
                cx={bud.cx}
                cy={bud.cy}
                r={bud.r}
                fill="url(#lavenderPurple)"
                stroke="#581c87"
                strokeWidth="0.6"
              />
            ))}
            {/* ละอองประกายหอมฟุ้ง */}
            <circle cx={20} cy={16} r={1.5} fill="#f3e8ff" className="animate-ping" />
            <circle cx={44} cy={18} r={1.5} fill="#f3e8ff" className="animate-ping" />
          </svg>
        )}

        {/* 7. สตรอว์เบอร์รีหวาน 3D (Sweet Crimson Strawberry) */}
        {cropId === 'strawberry' && (
          <svg viewBox="0 0 64 64" width={size * 0.88} height={size * 0.88}>
            <defs>
              <radialGradient id="berryRed" cx="40%" cy="35%" r="65%">
                <stop offset="0%" stopColor="#fca5a5" />
                <stop offset="35%" stopColor="#dc2626" />
                <stop offset="100%" stopColor="#881337" />
              </radialGradient>
            </defs>
            {/* ผลสตรอว์เบอร์รีรูปหัวใจ */}
            <path d="M22 22 C14 28, 16 46, 32 58 C48 46, 50 28, 42 22 C37 18, 27 18, 22 22 Z" fill="url(#berryRed)" stroke="#7f1d1d" strokeWidth="1" />
            {/* เมล็ดสีทองบนผิวผล */}
            {[
              { cx: 26, cy: 28 }, { cx: 34, cy: 28 }, { cx: 30, cy: 34 },
              { cx: 24, cy: 38 }, { cx: 38, cy: 38 }, { cx: 31, cy: 44 }, { cx: 32, cy: 50 },
            ].map((seed, i) => (
              <ellipse key={i} cx={seed.cx} cy={seed.cy} rx={1.2} ry={1.8} fill="#fef08a" stroke="#ca8a04" strokeWidth="0.4" />
            ))}
            {/* กลีบเลี้ยงสีเขียวด้านบน */}
            <path d="M32 18 L32 10 M32 18 L24 16 L28 20 L20 22 L27 24 L32 20 L37 24 L44 22 L36 20 L40 16 Z" fill="#22c55e" stroke="#15803d" strokeWidth="0.8" />
          </svg>
        )}

        {/* กรณีเป็นพืชชนิดอื่น (Fallback) */}
        {cropId !== 'wheat' &&
          cropId !== 'corn' &&
          cropId !== 'carrot' &&
          cropId !== 'tomato' &&
          cropId !== 'cucumber' &&
          cropId !== 'lavender' &&
          cropId !== 'strawberry' && (
            <div className="text-4xl drop-shadow-[0_4px_8px_rgba(0,0,0,0.6)]">
              🌱
            </div>
          )}
      </div>
    </div>
  );
};