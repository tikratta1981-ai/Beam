import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';

export interface Well3DProps {
  onDrawWater?: () => void;
  seamless?: boolean;
  className?: string;
}

export const Well3D: React.FC<Well3DProps> = ({
  onDrawWater,
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 140;
    const height = container.clientHeight || 140;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 5.5);
    camera.lookAt(0, 0.7, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    const ambientLight = new THREE.AmbientLight(0xf0fdf4, 1.2);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffae6, 1.8);
    sunLight.position.set(5, 8, 5);
    sunLight.castShadow = true;
    scene.add(sunLight);

    const stoneMat = track(new THREE.MeshStandardMaterial({ color: 0x78716c, roughness: 0.9 }));
    const woodMat = track(new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.8 }));
    const roofMat = track(new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.7 }));
    const waterMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.1, metalness: 0.3 }));

    // บ่อหินทรงกระบอกกลวง (Cobblestone Well Wall)
    const wellWall = new THREE.Mesh(track(new THREE.CylinderGeometry(0.65, 0.7, 0.55, 12, 1, true)), stoneMat);
    wellWall.position.y = 0.28;
    wellWall.castShadow = true;
    wellWall.receiveShadow = true;
    scene.add(wellWall);

    // ผิวน้ำในบ่อ (Water surface)
    const water = new THREE.Mesh(track(new THREE.CircleGeometry(0.6, 12)), waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = 0.25;
    scene.add(water);

    // เสาไม้ค้ำหลังคา 2 ข้าง
    const postGeo = track(new THREE.BoxGeometry(0.08, 1.2, 0.08));
    const p1 = new THREE.Mesh(postGeo, woodMat);
    p1.position.set(0.55, 0.8, 0);
    p1.castShadow = true;
    scene.add(p1);

    const p2 = new THREE.Mesh(postGeo, woodMat);
    p2.position.set(-0.55, 0.8, 0);
    p2.castShadow = true;
    scene.add(p2);

    // คานไม้บน
    const beam = new THREE.Mesh(track(new THREE.BoxGeometry(1.2, 0.08, 0.08)), woodMat);
    beam.position.set(0, 1.35, 0);
    scene.add(beam);

    // หลังคาทรงจั่วคลุมบ่อ
    const roof = new THREE.Mesh(track(new THREE.ConeGeometry(0.85, 0.45, 4)), roofMat);
    roof.position.set(0, 1.6, 0);
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    scene.add(roof);

    // ถังน้ำไม้แขวนรอก (Hanging Bucket)
    const bucket = new THREE.Mesh(track(new THREE.CylinderGeometry(0.12, 0.1, 0.18, 8)), woodMat);
    bucket.position.set(0, 0.75, 0);
    bucket.castShadow = true;
    scene.add(bucket);

    let animId: number;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);

      // ผิวน้ำกระเพื่อมและถังแกว่งเล็กน้อย
      bucket.position.y = 0.75 + Math.sin(time * 0.003) * 0.05;
      bucket.rotation.y = Math.sin(time * 0.002) * 0.2;

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, []);

  const handleClick = () => {
    sound.playWater();
    if (onDrawWater) onDrawWater();
    setActiveSpeech('ตักน้ำใสบริสุทธิ์จากบ่อหิน 💧✨');
    setTimeout(() => setActiveSpeech(null), 2000);
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      className={`relative w-full h-full select-none cursor-pointer ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />

      {activeSpeech && (
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-stone-900/90 text-cyan-200 text-[10px] font-bold rounded-full border border-cyan-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}
    </div>
  );
};
