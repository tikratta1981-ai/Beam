import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export interface House3DProps {
  type?: 'farmhouse' | 'barn_silo';
  seamless?: boolean;
  className?: string;
}

export const House3D: React.FC<House3DProps> = ({
  type = 'farmhouse',
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 176;
    const height = container.clientHeight || 160;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.8, 6.5);
    camera.lookAt(0, 0.9, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    const ambientLight = new THREE.AmbientLight(0xfff7ed, 1.25);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfffae6, 1.8);
    sunLight.position.set(5, 10, 6);
    sunLight.castShadow = true;
    scene.add(sunLight);

    const woodMat = track(new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.7 }));
    const wallMat = track(new THREE.MeshStandardMaterial({ color: 0xb91c1c, roughness: 0.6 })); // Red barn wall
    const roofMat = track(new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.6 }));
    const whiteTrimMat = track(new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.5 }));
    const siloMat = track(new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.4, roughness: 0.4 }));

    if (type === 'barn_silo') {
      // โรงนาแดง + หอเก็บเมล็ดพืชไซโล (Red Barn & Silo)
      const barn = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 1.2, 1.4)), wallMat);
      barn.position.set(-0.25, 0.6, 0);
      barn.castShadow = true;
      scene.add(barn);

      // หลังคาโรงนาโค้ง/จั่วแบบคันถนาถ (Gambrel Roof)
      const roof = new THREE.Mesh(track(new THREE.ConeGeometry(1.35, 0.7, 4)), roofMat);
      roof.position.set(-0.25, 1.55, 0);
      roof.rotation.y = Math.PI / 4;
      roof.castShadow = true;
      scene.add(roof);

      // ไซโลทรงกระบอก (Silo Tower)
      const silo = new THREE.Mesh(track(new THREE.CylinderGeometry(0.38, 0.38, 1.8, 12)), siloMat);
      silo.position.set(0.95, 0.9, 0);
      silo.castShadow = true;
      scene.add(silo);

      // โดมยอดไซโล
      const siloDome = new THREE.Mesh(track(new THREE.SphereGeometry(0.38, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2)), siloMat);
      siloDome.position.set(0.95, 1.8, 0);
      scene.add(siloDome);

      // ประตูโรงนาลาย X สีขาว
      const door = new THREE.Mesh(track(new THREE.BoxGeometry(0.55, 0.8, 0.05)), whiteTrimMat);
      door.position.set(-0.25, 0.4, 0.71);
      scene.add(door);
    } else {
      // บ้านพักชาวสวน (Farmhouse)
      const house = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 1.0, 1.3)), wallMat);
      house.position.set(0, 0.5, 0);
      house.castShadow = true;
      scene.add(house);

      // หลังคาจั่วไม้
      const roof = new THREE.Mesh(track(new THREE.ConeGeometry(1.4, 0.65, 4)), roofMat);
      roof.position.set(0, 1.32, 0);
      roof.rotation.y = Math.PI / 4;
      roof.castShadow = true;
      scene.add(roof);

      // ระเบียงหน้าบ้าน (Porch)
      const porchFloor = new THREE.Mesh(track(new THREE.BoxGeometry(1.7, 0.1, 0.55)), woodMat);
      porchFloor.position.set(0, 0.05, 0.85);
      scene.add(porchFloor);

      // เสาระเบียง
      const postGeo = track(new THREE.BoxGeometry(0.06, 0.7, 0.06));
      const p1 = new THREE.Mesh(postGeo, whiteTrimMat);
      p1.position.set(0.7, 0.4, 1.05);
      scene.add(p1);
      const p2 = new THREE.Mesh(postGeo, whiteTrimMat);
      p2.position.set(-0.7, 0.4, 1.05);
      scene.add(p2);

      // ปล่องไฟบ้าน (Chimney)
      const stoneMat = track(new THREE.MeshStandardMaterial({ color: 0x78716c, roughness: 0.9 }));
      const chimney = new THREE.Mesh(track(new THREE.BoxGeometry(0.28, 0.9, 0.28)), stoneMat);
      chimney.position.set(-0.5, 1.45, -0.2);
      scene.add(chimney);
    }

    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, [type]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full select-none ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />
    </div>
  );
};
