import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';
import { setupRealisticLighting, getSoilPBRTexture, getWoodPBRTexture } from '../../../../utils/three/threeTextures';

export interface Sheep3DProps {
  readyProduce: number;           // จำนวนขนแกะที่พร้อมเก็บ
  isFed: boolean;                 // สถานะว่ากินอิ่มอยู่หรือไม่
  onFeed?: () => void;
  onCollectProduce?: () => void;
  seamless?: boolean;             // ไร้ขอบ กลืนกับพื้นดินฟาร์ม
  compact?: boolean;              // โหมดขนาดกะทัดรัดบนแผนที่
  className?: string;
}

interface SheepInstance {
  group: THREE.Group;
  head: THREE.Group;
  woolGroup: THREE.Group;
  legs: THREE.Group[];
  type: 'adult' | 'lamb';
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  direction: number;
  speed: number;
  state: 'grazing' | 'walking' | 'idle' | 'bouncing';
  stateTimer: number;
  walkCycle: number;
  scale: number;
}

export const Sheep3D: React.FC<Sheep3DProps> = ({
  readyProduce,
  isFed,
  onFeed,
  onCollectProduce,
  seamless = false,
  compact = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);
  const [feedEffect, setFeedEffect] = useState(false);

  const sheepRef = useRef<SheepInstance[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const woolBasketRef = useRef<THREE.Group | null>(null);

  // แสดงผลก้อนขนแกะ 3D ตามจำนวน readyProduce จริง
  useEffect(() => {
    if (!woolBasketRef.current) return;
    const basket = woolBasketRef.current;

    while (basket.children.length > 0) {
      const obj = basket.children[0] as THREE.Mesh;
      basket.remove(obj);
      obj.geometry?.dispose();
      if (Array.isArray(obj.material)) obj.material.forEach((m: THREE.Material) => m.dispose());
      else (obj.material as THREE.Material)?.dispose();
    }

    const woolCount = Math.min(readyProduce, 6);
    const woolGeo = new THREE.SphereGeometry(0.12, 10, 8);
    const woolMat = new THREE.MeshStandardMaterial({
      color: 0xf5f5f4,
      roughness: 0.9,
    });

    for (let i = 0; i < woolCount; i++) {
      const ball = new THREE.Mesh(woolGeo, woolMat);
      const angle = (i / Math.max(woolCount, 1)) * Math.PI * 2;
      const r = 0.16 + (i % 2) * 0.06;
      ball.position.set(Math.cos(angle) * r, 0.08 + Math.floor(i / 3) * 0.08, Math.sin(angle) * r);
      ball.scale.set(1.1, 0.95, 1.05);
      ball.castShadow = true;
      basket.add(ball);
    }
  }, [readyProduce]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 200;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 5.2, 7.5);
    camera.lookAt(0, 0.4, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    setupRealisticLighting(scene, renderer);

    // ทุ่งหญ้าแกะแบบ Radial Feathered PBR
    const groundMesh = new THREE.Mesh(
      track(new THREE.PlaneGeometry(8, 5.5)),
      track(new THREE.MeshStandardMaterial({ map: getSoilPBRTexture(), transparent: true, roughness: 0.95 }))
    );
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);

    // ดอกไม้ป่าขาวและโคลเวอร์ 3D
    const cloverMat = track(new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.8 }));
    for (let c = 0; c < 16; c++) {
      const angle = (c / 16) * Math.PI * 2;
      const dist = 1.9 + Math.random() * 0.7;
      const clv = new THREE.Mesh(track(new THREE.DodecahedronGeometry(0.08, 0)), cloverMat);
      clv.position.set(Math.cos(angle) * dist, 0.08, Math.sin(angle) * dist);
      scene.add(clv);
    }

    // รั้วไม้สีขาวคอกแกะ
    const fenceGroup = new THREE.Group();
    const whiteFenceMat = track(new THREE.MeshStandardMaterial({ color: 0xf3f4f6, roughness: 0.7 }));
    const postGeo = track(new THREE.CylinderGeometry(0.045, 0.05, 0.55, 6));
    const railGeo = track(new THREE.BoxGeometry(1.2, 0.06, 0.035));

    for (let x = -2.8; x <= 2.8; x += 1.1) {
      const post = new THREE.Mesh(postGeo, whiteFenceMat);
      post.position.set(x, 0.28, -1.8);
      fenceGroup.add(post);
    }
    for (let x = -2.25; x <= 2.25; x += 1.1) {
      const railTop = new THREE.Mesh(railGeo, whiteFenceMat);
      railTop.position.set(x, 0.4, -1.8);
      const railBot = new THREE.Mesh(railGeo, whiteFenceMat);
      railBot.position.set(x, 0.2, -1.8);
      fenceGroup.add(railTop);
      fenceGroup.add(railBot);
    }
    scene.add(fenceGroup);

    // ตะกร้าสานเก็บขนแกะ (Wicker Basket)
    const basketGroup = new THREE.Group();
    basketGroup.position.set(-2.0, 0, -1.0);

    const basketMesh = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.45, 0.35, 0.35, 12, 1, true)),
      track(new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.85, side: THREE.DoubleSide }))
    );
    basketMesh.position.y = 0.18;
    basketGroup.add(basketMesh);

    const basketBottom = new THREE.Mesh(
      track(new THREE.CircleGeometry(0.35, 12)),
      track(new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 }))
    );
    basketBottom.rotation.x = -Math.PI / 2;
    basketBottom.position.y = 0.02;
    basketGroup.add(basketBottom);

    const woolBasket = new THREE.Group();
    woolBasket.position.set(0, 0.15, 0);
    basketGroup.add(woolBasket);
    woolBasketRef.current = woolBasket;
    scene.add(basketGroup);

    // โมเดลแกะขนปุย 3D (Fluffy Cloud-like Sheep)
    const woolMat = track(new THREE.MeshStandardMaterial({ color: 0xfafaf9, roughness: 0.9 }));
    const skinMat = track(new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.7 }));

    const createSheep = (type: 'adult' | 'lamb', initPos: THREE.Vector3): SheepInstance => {
      const group = new THREE.Group();
      group.position.copy(initPos);

      const isLamb = type === 'lamb';
      const scale = isLamb ? 0.55 : 0.95;

      // ลำตัวก้อนเมฆขนปุย (Puffy Wool Body via overlapping spheres)
      const woolGroup = new THREE.Group();
      const mainWool = new THREE.Mesh(track(new THREE.SphereGeometry(0.45, 10, 8)), woolMat);
      mainWool.scale.set(1.1, 0.9, 1.35);
      mainWool.position.y = 0.55;
      mainWool.castShadow = true;
      woolGroup.add(mainWool);

      // ก้อนขนรอบตัว
      const puffOffsets = [
        { x: 0.25, y: 0.65, z: 0.2, s: 0.25 },
        { x: -0.25, y: 0.65, z: 0.2, s: 0.25 },
        { x: 0.28, y: 0.5, z: -0.25, s: 0.28 },
        { x: -0.28, y: 0.5, z: -0.25, s: 0.28 },
        { x: 0, y: 0.72, z: 0, s: 0.3 },
      ];

      puffOffsets.forEach((p) => {
        const puff = new THREE.Mesh(track(new THREE.SphereGeometry(p.s, 8, 6)), woolMat);
        puff.position.set(p.x, p.y, p.z);
        woolGroup.add(puff);
      });
      group.add(woolGroup);

      // หัวแกะ (Sheep Face & Ears)
      const head = new THREE.Group();
      head.position.set(0, 0.72, 0.55);

      const face = new THREE.Mesh(track(new THREE.SphereGeometry(0.2, 8, 8)), skinMat);
      face.scale.set(0.9, 1.1, 1.15);
      head.add(face);

      // ดวงตาแกะประกายเงา (Glossy Sheep Eyes)
      const eyeMat = track(new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1 }));
      const eyeL = new THREE.Mesh(track(new THREE.SphereGeometry(0.04, 6, 6)), eyeMat);
      eyeL.position.set(0.16, 0.04, 0.14);
      head.add(eyeL);
      const eyeR = new THREE.Mesh(track(new THREE.SphereGeometry(0.04, 6, 6)), eyeMat);
      eyeR.position.set(-0.16, 0.04, 0.14);
      head.add(eyeR);

      // ขนบนหัว
      const headCap = new THREE.Mesh(track(new THREE.SphereGeometry(0.16, 8, 6)), woolMat);
      headCap.position.set(0, 0.16, -0.04);
      head.add(headCap);

      // หูสองข้างห้อยตก
      const earL = new THREE.Mesh(track(new THREE.BoxGeometry(0.16, 0.06, 0.08)), skinMat);
      earL.position.set(0.22, 0.05, 0);
      earL.rotation.z = -0.3;
      head.add(earL);

      const earR = new THREE.Mesh(track(new THREE.BoxGeometry(0.16, 0.06, 0.08)), skinMat);
      earR.position.set(-0.22, 0.05, 0);
      earR.rotation.z = 0.3;
      head.add(earR);

      group.add(head);

      // ขา 4 ข้าง
      const legs: THREE.Group[] = [];
      const legGeo = track(new THREE.CylinderGeometry(0.045, 0.04, 0.35, 6));

      const legPositions = [
        { x: 0.2, z: 0.3 },
        { x: -0.2, z: 0.3 },
        { x: 0.2, z: -0.3 },
        { x: -0.2, z: -0.3 },
      ];

      legPositions.forEach((pos) => {
        const legGroup = new THREE.Group();
        legGroup.position.set(pos.x, 0.35, pos.z);
        const legMesh = new THREE.Mesh(legGeo, skinMat);
        legMesh.position.y = -0.15;
        legGroup.add(legMesh);
        group.add(legGroup);
        legs.push(legGroup);
      });

      group.scale.set(scale, scale, scale);
      group.userData = { isSheep: true, type };
      scene.add(group);

      return {
        group,
        head,
        woolGroup,
        legs,
        type,
        pos: initPos.clone(),
        targetPos: initPos.clone(),
        direction: Math.random() * Math.PI * 2,
        speed: isLamb ? 1.1 : 0.7,
        state: 'grazing',
        stateTimer: 2.0 + Math.random() * 2.5,
        walkCycle: 0,
        scale,
      };
    };

    const sheeps: SheepInstance[] = [
      createSheep('adult', new THREE.Vector3(-0.9, 0, 0.3)),
      createSheep('adult', new THREE.Vector3(0.8, 0, -0.4)),
      createSheep('lamb', new THREE.Vector3(-0.1, 0, 0.8)),
    ];
    sheepRef.current = sheeps;

    let lastTime = performance.now();
    let animId: number;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      sheeps.forEach((shp) => {
        shp.stateTimer -= dt;
        if (shp.stateTimer <= 0) {
          if (shp.state === 'grazing') {
            shp.state = Math.random() < 0.6 ? 'walking' : 'idle';
            shp.stateTimer = 2.0 + Math.random() * 2.5;
            if (shp.state === 'walking') {
              shp.targetPos.set((Math.random() - 0.5) * 3.4, 0, (Math.random() - 0.5) * 2.2);
            }
          } else {
            shp.state = 'grazing';
            shp.stateTimer = 2.5 + Math.random() * 3.0;
          }
        }

        if (shp.state === 'grazing') {
          shp.head.rotation.x = 0.45 + Math.sin(time * 0.006) * 0.08;
          shp.woolGroup.position.y = Math.sin(time * 0.003) * 0.02;
        } else if (shp.state === 'walking') {
          shp.head.rotation.x = 0.08;
          const dx = shp.targetPos.x - shp.pos.x;
          const dz = shp.targetPos.z - shp.pos.z;
          const dist = Math.hypot(dx, dz);

          if (dist > 0.12) {
            const step = Math.min(dist, shp.speed * dt);
            shp.pos.x += (dx / dist) * step;
            shp.pos.z += (dz / dist) * step;
            shp.direction = Math.atan2(dx, dz);
            shp.walkCycle += dt * 10;

            shp.legs[0].rotation.x = Math.sin(shp.walkCycle) * 0.4;
            shp.legs[1].rotation.x = -Math.sin(shp.walkCycle) * 0.4;
            shp.legs[2].rotation.x = -Math.sin(shp.walkCycle) * 0.4;
            shp.legs[3].rotation.x = Math.sin(shp.walkCycle) * 0.4;
          } else {
            shp.state = 'grazing';
            shp.legs.forEach((l) => (l.rotation.x = 0));
          }
          shp.group.position.copy(shp.pos);
          shp.group.rotation.y = shp.direction;
        } else if (shp.state === 'bouncing') {
          const hop = Math.max(0, Math.sin(time * 0.016)) * 0.3;
          shp.group.position.y = shp.pos.y + hop;
          shp.woolGroup.scale.set(1.0 + Math.sin(time * 0.02) * 0.1, 1.0 - Math.sin(time * 0.02) * 0.08, 1.0);
        }
      });

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      const w = entry.contentRect.width;
      const h = entry.contentRect.height;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, []);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    sound.playSuccessChime();

    if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);
    const intersects = raycaster.intersectObjects(
      sheepRef.current.map((s) => s.group),
      true
    );

    let clicked = sheepRef.current[0];
    if (intersects.length > 0) {
      let current: THREE.Object3D | null = intersects[0].object;
      while (current && !current.userData?.isSheep) current = current.parent;
      const found = sheepRef.current.find((s) => s.group === current);
      if (found) clicked = found;
    }

    if (clicked) {
      clicked.state = 'bouncing';
      clicked.stateTimer = 1.0;
      const messages = {
        adult: 'แบ๊ะๆๆ! แกะขนปุยอารมณ์ดี ขนนุ่มฟูพร้อมตัดแล้ว 🧶✨',
        lamb: 'แบ๊ะๆ! ลูกแกะกระโดดดุ๊กดิ๊กเล็มหญ้าอ่อน 🐑',
      };
      setActiveSpeech(messages[clicked.type]);
      setTimeout(() => setActiveSpeech(null), 2500);
    }
  };

  const handleFeed = () => {
    sound.playSuccessChime();
    setFeedEffect(true);
    setTimeout(() => setFeedEffect(false), 2000);

    sheepRef.current.forEach((s) => {
      s.state = 'walking';
      s.targetPos.set((Math.random() - 0.5) * 1.5, 0, (Math.random() - 0.5) * 1.2);
      s.stateTimer = 1.0;
    });

    if (onFeed) onFeed();
    setActiveSpeech('ให้อาหารแกะแล้ว! ฝูงแกะขนปุยเคี้ยวหญ้าอย่างมีความสุข 🌿🐑');
    setTimeout(() => setActiveSpeech(null), 3000);
  };

  const handleCollect = () => {
    sound.playHarvest();
    if (onCollectProduce) onCollectProduce();
  };

  return (
    <div
      ref={containerRef}
      className={`relative select-none ${
        seamless
          ? 'w-full h-full overflow-visible bg-transparent'
          : 'w-full h-[220px] sm:h-[260px] rounded-3xl overflow-hidden shadow-2xl border-4 border-[#2f6336] bg-[#0c2413]'
      } ${className}`}
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-pointer touch-none"
        title="แตะที่ตัวแกะเพื่อให้กระโดดและส่งเสียงร้อง!"
      />

      {!compact && (
        <div className="absolute top-2.5 inset-x-3 flex items-center justify-between pointer-events-none z-10">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-[#091a0e]/90 backdrop-blur-xs rounded-full border border-emerald-500/50 shadow-md">
            <span className="text-base">🐑</span>
            <span className="text-xs font-bold text-emerald-200 font-['Kanit',sans-serif]">
              ทุ่งแกะขนปุย 3D
            </span>
            {isFed && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
          </div>

          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={handleFeed}
              disabled={isFed}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 transition-transform active:scale-95 shadow-md ${
                isFed
                  ? 'bg-emerald-950/60 text-emerald-300/50 cursor-not-allowed border border-emerald-900'
                  : 'bg-gradient-to-b from-emerald-400 to-green-600 hover:from-emerald-300 text-white border border-white cursor-pointer'
              }`}
            >
              <span>🌾</span>
              <span>{isFed ? 'แกะอิ่มแล้ว' : 'ให้หญ้าโคลเวอร์'}</span>
            </button>

            {readyProduce > 0 && onCollectProduce && (
              <button
                type="button"
                onClick={handleCollect}
                className="px-3 py-1.5 bg-gradient-to-b from-amber-400 to-yellow-500 hover:from-amber-300 text-amber-950 font-bold text-xs rounded-xl border border-white shadow-md flex items-center gap-1 cursor-pointer animate-bounce transition-transform"
              >
                <span>🧶</span>
                <span>ตัดขนแกะ ({readyProduce})</span>
              </button>
            )}
          </div>
        </div>
      )}

      {compact && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-30 pointer-events-auto">
          {!isFed && onFeed && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleFeed();
              }}
              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🌾</span>
              <span>ให้หญ้า</span>
            </button>
          )}
          {readyProduce > 0 && onCollectProduce && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCollect();
              }}
              className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-amber-950 rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 animate-bounce transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🧶</span>
              <span>ตัดขน ({readyProduce})</span>
            </button>
          )}
        </div>
      )}

      {activeSpeech && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-black/85 text-emerald-200 text-xs font-bold rounded-full border border-emerald-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}

      {feedEffect && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-25">
          <span className="text-2xl animate-ping">🌿 🌿 🌿 🌿</span>
        </div>
      )}
    </div>
  );
};
