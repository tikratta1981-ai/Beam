import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';
import { setupRealisticLighting, getSoilPBRTexture, getWoodPBRTexture, getCowHideTexture } from '../../../../utils/three/threeTextures';

export interface Cow3DProps {
  readyProduce: number;           // จำนวนนมสดที่พร้อมเก็บ
  isFed: boolean;                 // สถานะว่ากินอิ่มอยู่หรือไม่
  onFeed?: () => void;
  onCollectProduce?: () => void;
  seamless?: boolean;             // ไร้ขอบ กลืนกับพื้นดินฟาร์ม
  compact?: boolean;              // โหมดขนาดกะทัดรัดบนแผนที่
  className?: string;
}

interface CowInstance {
  group: THREE.Group;
  head: THREE.Group;
  jaw: THREE.Mesh;
  tail: THREE.Group;
  legs: THREE.Group[];
  type: 'adult' | 'calf';
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  direction: number;
  speed: number;
  state: 'grazing' | 'walking' | 'idle' | 'happy';
  stateTimer: number;
  chewTimer: number;
  walkCycle: number;
  scale: number;
}

export const Cow3D: React.FC<Cow3DProps> = ({
  readyProduce,
  isFed,
  onFeed,
  onCollectProduce,
  seamless = false,
  compact = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);
  const [feedEffect, setFeedEffect] = useState(false);

  const cowsRef = useRef<CowInstance[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const milkGroupRef = useRef<THREE.Group | null>(null);

  // แสดงผลขวดนม 3D ตามจำนวน readyProduce จริง
  useEffect(() => {
    if (!milkGroupRef.current) return;
    const milkGroup = milkGroupRef.current;

    while (milkGroup.children.length > 0) {
      const obj = milkGroup.children[0] as THREE.Mesh;
      milkGroup.remove(obj);
      obj.geometry?.dispose();
      if (Array.isArray(obj.material)) obj.material.forEach((m: THREE.Material) => m.dispose());
      else (obj.material as THREE.Material)?.dispose();
    }

    const bottleCount = Math.min(readyProduce, 6);
    const bottleGeo = new THREE.CylinderGeometry(0.06, 0.08, 0.22, 8);
    const capGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.05, 8);
    const bottleMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.2,
      metalness: 0.1,
    });
    const capMat = new THREE.MeshStandardMaterial({
      color: 0x3b82f6,
      roughness: 0.4,
    });

    for (let i = 0; i < bottleCount; i++) {
      const bGroup = new THREE.Group();
      const bottle = new THREE.Mesh(bottleGeo, bottleMat);
      bottle.position.y = 0.11;
      bottle.castShadow = true;
      bGroup.add(bottle);

      const cap = new THREE.Mesh(capGeo, capMat);
      cap.position.y = 0.23;
      bGroup.add(cap);

      const angle = (i / Math.max(bottleCount, 1)) * Math.PI * 2;
      const r = 0.18 + (i % 2) * 0.08;
      bGroup.position.set(Math.cos(angle) * r, 0.05, Math.sin(angle) * r);
      milkGroup.add(bGroup);
    }
  }, [readyProduce]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 200;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 5.5, 7.8);
    camera.lookAt(0, 0.4, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    setupRealisticLighting(scene, renderer);

    // ผืนดินทุ่งหญ้าคอกวัวแบบ Radial Feathered PBR
    const groundMesh = new THREE.Mesh(
      track(new THREE.PlaneGeometry(8.2, 5.8)),
      track(new THREE.MeshStandardMaterial({ map: getSoilPBRTexture(), transparent: true, roughness: 0.9 }))
    );
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);

    // กอหญ้าเขียวสดรอบคอก
    const grassMat = track(new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.8 }));
    for (let g = 0; g < 18; g++) {
      const angle = (g / 18) * Math.PI * 2;
      const dist = 2.0 + Math.random() * 0.7;
      const tuft = new THREE.Mesh(track(new THREE.ConeGeometry(0.09, 0.3, 4)), grassMat);
      tuft.position.set(Math.cos(angle) * dist, 0.15, Math.sin(angle) * dist);
      tuft.rotation.z = (Math.random() - 0.5) * 0.3;
      scene.add(tuft);
    }

    // รั้วไม้คอกวัว
    const fenceGroup = new THREE.Group();
    const woodMat = track(new THREE.MeshStandardMaterial({ map: getWoodPBRTexture(), color: 0x78350f, roughness: 0.85 }));
    const postGeo = track(new THREE.CylinderGeometry(0.05, 0.055, 0.6, 6));
    const railGeo = track(new THREE.BoxGeometry(1.2, 0.07, 0.04));

    for (let x = -2.8; x <= 2.8; x += 1.1) {
      const post = new THREE.Mesh(postGeo, woodMat);
      post.position.set(x, 0.3, -1.8);
      fenceGroup.add(post);
    }
    for (let x = -2.25; x <= 2.25; x += 1.1) {
      const railTop = new THREE.Mesh(railGeo, woodMat);
      railTop.position.set(x, 0.45, -1.8);
      const railBot = new THREE.Mesh(railGeo, woodMat);
      railBot.position.set(x, 0.22, -1.8);
      fenceGroup.add(railTop);
      fenceGroup.add(railBot);
    }
    scene.add(fenceGroup);

    // เพิงคอกวัวหลังคาสีฟ้า/ไม้ (Shelter)
    const shelterGroup = new THREE.Group();
    shelterGroup.position.set(-2.2, 0, -1.1);

    const shelterWall = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.1, 0.85, 0.9)),
      track(new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.7 }))
    );
    shelterWall.position.y = 0.42;
    shelterGroup.add(shelterWall);

    const shelterRoof = new THREE.Mesh(
      track(new THREE.ConeGeometry(0.85, 0.45, 4)),
      track(new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.6 }))
    );
    shelterRoof.position.y = 1.05;
    shelterRoof.rotation.y = Math.PI / 4;
    shelterGroup.add(shelterRoof);

    // ถังไม้วางนม
    const milkPlatform = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.45, 0.45, 0.12, 10)),
      track(new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.8 }))
    );
    milkPlatform.position.set(0, 0.06, 0.7);
    shelterGroup.add(milkPlatform);

    const milkGroup = new THREE.Group();
    milkGroup.position.set(0, 0.12, 0.7);
    shelterGroup.add(milkGroup);
    milkGroupRef.current = milkGroup;
    scene.add(shelterGroup);

    // รางหญ้าฟาง (Hay Rack)
    const hayRack = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.3, 0.28, 0.45)),
      woodMat
    );
    hayRack.position.set(2.0, 0.14, 0.5);
    scene.add(hayRack);

    const hayFill = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.2, 0.2, 0.38)),
      track(new THREE.MeshStandardMaterial({ color: 0xeab308, roughness: 0.9 }))
    );
    hayFill.position.set(2.0, 0.22, 0.5);
    scene.add(hayFill);

    // สร้างโมเดลวัว 3D (Holstein Cow)
    const whiteMat = track(new THREE.MeshStandardMaterial({ map: getCowHideTexture(), roughness: 0.65 }));
    const blackMat = track(new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.65 }));
    const pinkMat = track(new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.4 }));
    const hornMat = track(new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.5 }));
    const hoofMat = track(new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.8 }));

    const createCow = (type: 'adult' | 'calf', initPos: THREE.Vector3): CowInstance => {
      const group = new THREE.Group();
      group.position.copy(initPos);

      const isCalf = type === 'calf';
      const scale = isCalf ? 0.55 : 1.0;

      // ลำตัวทรงกล่องมน (Cow Body with Patches)
      const body = new THREE.Mesh(track(new THREE.BoxGeometry(0.7, 0.65, 1.25)), whiteMat);
      body.position.y = 0.72;
      body.castShadow = true;
      group.add(body);

      // ลวดลายด่างดำของวัวฮอลสไตน์ (Black patches)
      const patch1 = new THREE.Mesh(track(new THREE.BoxGeometry(0.72, 0.45, 0.5)), blackMat);
      patch1.position.set(0, 0.75, 0.1);
      group.add(patch1);

      const patch2 = new THREE.Mesh(track(new THREE.BoxGeometry(0.72, 0.35, 0.35)), blackMat);
      patch2.position.set(0, 0.8, -0.4);
      group.add(patch2);

      // หัววัว (Cow Head)
      const head = new THREE.Group();
      head.position.set(0, 0.98, 0.65);

      const headBox = new THREE.Mesh(track(new THREE.BoxGeometry(0.44, 0.45, 0.45)), whiteMat);
      head.add(headBox);

      const headPatch = new THREE.Mesh(track(new THREE.BoxGeometry(0.24, 0.46, 0.46)), blackMat);
      headPatch.position.set(0.1, 0, 0);
      head.add(headPatch);

      // จมูกชมพู (Snout & Jaw)
      const snout = new THREE.Mesh(track(new THREE.BoxGeometry(0.36, 0.22, 0.25)), pinkMat);
      snout.position.set(0, -0.12, 0.28);
      head.add(snout);

      // รูจมูกวัว (Nostrils)
      const nostrilMat = track(new THREE.MeshStandardMaterial({ color: 0x831843 }));
      const nL = new THREE.Mesh(track(new THREE.SphereGeometry(0.035, 6, 6)), nostrilMat);
      nL.position.set(0.08, -0.05, 0.14);
      snout.add(nL);
      const nR = new THREE.Mesh(track(new THREE.SphereGeometry(0.035, 6, 6)), nostrilMat);
      nR.position.set(-0.08, -0.05, 0.14);
      snout.add(nR);

      // ดวงตาวัวประกายมันเงา (Cow Eyes)
      const eyeMat = track(new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.1 }));
      const eyeL = new THREE.Mesh(track(new THREE.SphereGeometry(0.048, 6, 6)), eyeMat);
      eyeL.position.set(0.24, 0.08, 0.16);
      head.add(eyeL);
      const eyeR = new THREE.Mesh(track(new THREE.SphereGeometry(0.048, 6, 6)), eyeMat);
      eyeR.position.set(-0.24, 0.08, 0.16);
      head.add(eyeR);

      // ขากรรไกรขยับเคี้ยวเอื้อง (Jaw)
      const jaw = new THREE.Mesh(track(new THREE.BoxGeometry(0.34, 0.08, 0.2)), pinkMat);
      jaw.position.set(0, -0.22, 0.25);
      head.add(jaw);

      // เขาคู่ (Horns)
      const hornL = new THREE.Mesh(track(new THREE.ConeGeometry(0.045, 0.18, 5)), hornMat);
      hornL.rotation.z = Math.PI / 4;
      hornL.position.set(0.22, 0.28, 0);
      head.add(hornL);

      const hornR = new THREE.Mesh(track(new THREE.ConeGeometry(0.045, 0.18, 5)), hornMat);
      hornR.rotation.z = -Math.PI / 4;
      hornR.position.set(-0.22, 0.28, 0);
      head.add(hornR);

      // หูวัว (Ears)
      const earL = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.07, 0.08)), whiteMat);
      earL.position.set(0.26, 0.12, -0.05);
      head.add(earL);

      const earR = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.07, 0.08)), blackMat);
      earR.position.set(-0.26, 0.12, -0.05);
      head.add(earR);

      group.add(head);

      // ขา 4 ข้าง (4 Legs)
      const legs: THREE.Group[] = [];
      const legGeo = track(new THREE.CylinderGeometry(0.065, 0.06, 0.42, 6));
      const hoofGeo = track(new THREE.CylinderGeometry(0.065, 0.07, 0.1, 6));

      const legPositions = [
        { x: 0.24, z: 0.42 },
        { x: -0.24, z: 0.42 },
        { x: 0.24, z: -0.42 },
        { x: -0.24, z: -0.42 },
      ];

      legPositions.forEach((pos) => {
        const legGroup = new THREE.Group();
        legGroup.position.set(pos.x, 0.4, pos.z);

        const legMesh = new THREE.Mesh(legGeo, whiteMat);
        legMesh.position.y = -0.16;
        legGroup.add(legMesh);

        const hoofMesh = new THREE.Mesh(hoofGeo, hoofMat);
        hoofMesh.position.y = -0.34;
        legGroup.add(hoofMesh);

        group.add(legGroup);
        legs.push(legGroup);
      });

      // หางวัวสะบัด (Tail)
      const tail = new THREE.Group();
      tail.position.set(0, 0.85, -0.65);
      const tailMesh = new THREE.Mesh(track(new THREE.CylinderGeometry(0.025, 0.02, 0.45, 5)), whiteMat);
      tailMesh.position.y = -0.2;
      tail.add(tailMesh);
      const tuftMesh = new THREE.Mesh(track(new THREE.SphereGeometry(0.06, 6, 6)), blackMat);
      tuftMesh.position.y = -0.42;
      tail.add(tuftMesh);
      group.add(tail);

      // เต้านมวัว (Udder)
      if (!isCalf) {
        const udder = new THREE.Mesh(track(new THREE.SphereGeometry(0.16, 8, 8)), pinkMat);
        udder.position.set(0, 0.44, -0.1);
        group.add(udder);
      }

      group.scale.set(scale, scale, scale);
      group.userData = { isCow: true, type };
      scene.add(group);

      return {
        group,
        head,
        jaw,
        tail,
        legs,
        type,
        pos: initPos.clone(),
        targetPos: initPos.clone(),
        direction: Math.random() * Math.PI * 2,
        speed: isCalf ? 1.0 : 0.6,
        state: 'grazing',
        stateTimer: 2.0 + Math.random() * 2.0,
        chewTimer: 0,
        walkCycle: 0,
        scale,
      };
    };

    const cows: CowInstance[] = [
      createCow('adult', new THREE.Vector3(-0.8, 0, 0.2)),
      createCow('adult', new THREE.Vector3(0.9, 0, -0.4)),
      createCow('calf', new THREE.Vector3(-0.2, 0, 0.8)),
    ];
    cowsRef.current = cows;

    // Animation Loop
    let lastTime = performance.now();
    let animId: number;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      cows.forEach((cow) => {
        cow.stateTimer -= dt;
        if (cow.stateTimer <= 0) {
          if (cow.state === 'grazing') {
            cow.state = Math.random() < 0.6 ? 'walking' : 'idle';
            cow.stateTimer = 2.0 + Math.random() * 3.0;
            if (cow.state === 'walking') {
              cow.targetPos.set((Math.random() - 0.5) * 3.2, 0, (Math.random() - 0.5) * 2.0);
            }
          } else {
            cow.state = 'grazing';
            cow.stateTimer = 2.5 + Math.random() * 3.0;
          }
        }

        // สะบัดหางเป็นธรรมชาติ
        cow.tail.rotation.z = Math.sin(time * 0.005 + cow.scale) * 0.35;

        if (cow.state === 'grazing') {
          cow.chewTimer += dt * 4;
          cow.jaw.position.x = Math.sin(cow.chewTimer) * 0.04;
          cow.head.rotation.x = 0.35 + Math.sin(cow.chewTimer * 0.5) * 0.08;
          cow.group.rotation.x = 0;
        } else if (cow.state === 'walking') {
          cow.jaw.position.x = 0;
          cow.head.rotation.x = 0.05;
          const dx = cow.targetPos.x - cow.pos.x;
          const dz = cow.targetPos.z - cow.pos.z;
          const dist = Math.hypot(dx, dz);

          if (dist > 0.15) {
            const step = Math.min(dist, cow.speed * dt);
            cow.pos.x += (dx / dist) * step;
            cow.pos.z += (dz / dist) * step;
            cow.direction = Math.atan2(dx, dz);
            cow.walkCycle += dt * 8;

            cow.legs[0].rotation.x = Math.sin(cow.walkCycle) * 0.35;
            cow.legs[1].rotation.x = -Math.sin(cow.walkCycle) * 0.35;
            cow.legs[2].rotation.x = -Math.sin(cow.walkCycle) * 0.35;
            cow.legs[3].rotation.x = Math.sin(cow.walkCycle) * 0.35;
          } else {
            cow.state = 'grazing';
            cow.legs.forEach((l) => (l.rotation.x = 0));
          }
          cow.group.position.copy(cow.pos);
          cow.group.rotation.y = cow.direction;
        } else if (cow.state === 'happy') {
          const hop = Math.max(0, Math.sin(time * 0.015)) * 0.25;
          cow.group.position.y = cow.pos.y + hop;
          cow.head.rotation.z = Math.sin(time * 0.02) * 0.2;
        }
      });

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      const w = entry.contentRect.width;
      const h = entry.contentRect.height;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, []);

  // Raycaster แตะตัววัว
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    sound.playAnimal('cow');

    if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((e.clientX - rect.left) / rect.width) * 2 - 1,
      -((e.clientY - rect.top) / rect.height) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);
    const intersects = raycaster.intersectObjects(
      cowsRef.current.map((c) => c.group),
      true
    );

    let clicked = cowsRef.current[0];
    if (intersects.length > 0) {
      let current: THREE.Object3D | null = intersects[0].object;
      while (current && !current.userData?.isCow) current = current.parent;
      const found = cowsRef.current.find((c) => c.group === current);
      if (found) clicked = found;
    }

    if (clicked) {
      clicked.state = 'happy';
      clicked.stateTimer = 1.0;
      const messages = {
        adult: 'มอออออ! แม่วัวอารมณ์ดี เคี้ยวหญ้าฟางกรุบกรอบ 🥛✨',
        calf: 'มอออ~ ลูกวัวกระดิกหูวิ่งเล่นอย่างร่าเริง 🐮',
      };
      setActiveSpeech(messages[clicked.type]);
      setTimeout(() => setActiveSpeech(null), 2500);
    }
  };

  const handleFeed = () => {
    sound.playAnimal('cow');
    setFeedEffect(true);
    setTimeout(() => setFeedEffect(false), 2000);

    cowsRef.current.forEach((cow) => {
      cow.state = 'walking';
      cow.targetPos.set((Math.random() - 0.5) * 1.5, 0, (Math.random() - 0.5) * 1.2);
      cow.stateTimer = 1.2;
    });

    if (onFeed) onFeed();
    setActiveSpeech('ให้อาหารวัวแล้ว! วัวเดินมารุมกินหญ้าอย่างเอร็ดอร่อย 🌾🐄');
    setTimeout(() => setActiveSpeech(null), 3000);
  };

  const handleCollect = () => {
    sound.playHarvest();
    if (onCollectProduce) onCollectProduce();
  };

  return (
    <div
      ref={containerRef}
      className={`relative select-none ${
        seamless
          ? 'w-full h-full overflow-visible bg-transparent'
          : 'w-full h-[220px] sm:h-[260px] rounded-3xl overflow-hidden shadow-2xl border-4 border-[#254b8c] bg-[#0d223a]'
      } ${className}`}
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-pointer touch-none"
        title="แตะที่ตัววัวเพื่อให้กระโดดและส่งเสียงร้อง!"
      />

      {/* Header Overlay (สำหรับใน Modal) */}
      {!compact && (
        <div className="absolute top-2.5 inset-x-3 flex items-center justify-between pointer-events-none z-10">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-[#0b1d30]/90 backdrop-blur-xs rounded-full border border-blue-500/50 shadow-md">
            <span className="text-base">🐮</span>
            <span className="text-xs font-bold text-sky-200 font-['Kanit',sans-serif]">
              คอกโคนมฮอลสไตน์ 3D
            </span>
            {isFed && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
          </div>

          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={handleFeed}
              disabled={isFed}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 transition-transform active:scale-95 shadow-md ${
                isFed
                  ? 'bg-blue-950/60 text-blue-300/50 cursor-not-allowed border border-blue-900'
                  : 'bg-gradient-to-b from-sky-400 to-blue-600 hover:from-sky-300 text-white border border-white cursor-pointer'
              }`}
            >
              <span>🌾</span>
              <span>{isFed ? 'วัวอิ่มแล้ว' : 'ให้หญ้าฟาง'}</span>
            </button>

            {readyProduce > 0 && onCollectProduce && (
              <button
                type="button"
                onClick={handleCollect}
                className="px-3 py-1.5 bg-gradient-to-b from-emerald-500 to-green-600 hover:from-emerald-400 text-white font-bold text-xs rounded-xl border border-white shadow-md flex items-center gap-1 cursor-pointer animate-bounce transition-transform"
              >
                <span>🥛</span>
                <span>เก็บน้ำนม ({readyProduce})</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Compact Overlay (บนแผนที่ฟาร์ม) */}
      {compact && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-30 pointer-events-auto">
          {!isFed && onFeed && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleFeed();
              }}
              className="px-2.5 py-1 bg-sky-500 hover:bg-sky-400 text-white rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🌾</span>
              <span>ให้หญ้า</span>
            </button>
          )}
          {readyProduce > 0 && onCollectProduce && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCollect();
              }}
              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 animate-bounce transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🥛</span>
              <span>เก็บนม ({readyProduce})</span>
            </button>
          )}
        </div>
      )}

      {activeSpeech && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-black/85 text-sky-200 text-xs font-bold rounded-full border border-sky-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}

      {feedEffect && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-25">
          <span className="text-2xl animate-ping">🌾 🌾 🌾 🌾</span>
        </div>
      )}
    </div>
  );
};
