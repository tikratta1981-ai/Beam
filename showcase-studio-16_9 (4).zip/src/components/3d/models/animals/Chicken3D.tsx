// src/components/3d/Chicken3D.tsx
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';
import {
  getHenFeatherTexture,
  getRoosterFeatherTexture,
  getChickDownTexture,
  getChickenCombTexture,
  getChickenLegTexture,
  getEggTexture,
  getStrawTexture,
  getWoodPBRTexture,
  getGalvanizedMetalTexture,
} from '../../../../utils/three/threeTextures';

export interface Chicken3DProps {
  readyProduce: number;           // จำนวนไข่ที่พร้อมเก็บ (จะแสดงเป็นฟองไข่ 3D จริง)
  isFed: boolean;                 // สถานะว่าสัตว์กินอิ่มอยู่หรือไม่
  onFeed?: () => void;            // Callback เมื่อกดโปรยอาหาร
  onCollectEggs?: () => void;     // Callback เมื่อกดเก็บไข่เข้าคลัง
  seamless?: boolean;             // ไร้ขอบ ผืนดินไล่ระดับกลืนกับหญ้าฟาร์ม
  compact?: boolean;              // ซ่อน Header Overlay เพื่อให้กลืนกับฉากฟาร์ม
  className?: string;
}

interface ChickenInstance {
  group: THREE.Group;
  head: THREE.Group;
  leftWing: THREE.Group;
  rightWing: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftFoot: THREE.Group;
  rightFoot: THREE.Group;
  type: 'hen' | 'rooster' | 'chick';
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  direction: number;
  speed: number;
  state: 'pecking' | 'walking' | 'idle' | 'scratching' | 'hopping' | 'seeking_food';
  stateTimer: number;
  peckCounter: number;
  walkCycle: number;
  scratchStep: number;
  scale: number;
  baseY: number;
}

interface GrainParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  rotVel: THREE.Vector3;
  groundY: number;
  settled: boolean;
  eaten: boolean;
  age: number;
}

interface DustParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
}

export const Chicken3D: React.FC<Chicken3DProps> = ({
  readyProduce,
  isFed,
  onFeed,
  onCollectEggs,
  seamless = false,
  compact = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);
  const [feedEffect, setFeedEffect] = useState(false);

  const chickensRef = useRef<ChickenInstance[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const eggsGroupRef = useRef<THREE.Group | null>(null);
  const grainsRef = useRef<GrainParticle[]>([]);
  const dustRef = useRef<DustParticle[]>([]);
  const grainGeoRef = useRef<THREE.BufferGeometry | null>(null);
  const grainMatRef = useRef<THREE.Material | null>(null);

  // 🥚 แสดงผลไข่ 3D ในรังฟางตาม readyProduce
  useEffect(() => {
    if (!eggsGroupRef.current) return;
    const eggsGroup = eggsGroupRef.current;

    while (eggsGroup.children.length > 0) {
      const obj = eggsGroup.children[0] as THREE.Mesh;
      eggsGroup.remove(obj);
      obj.geometry.dispose();
      if (Array.isArray(obj.material)) obj.material.forEach((m: THREE.Material) => m.dispose());
      else obj.material.dispose();
    }

    const eggCount = Math.min(readyProduce, 6);
    if (eggCount <= 0) return;

    const eggTex = getEggTexture();
    const eggGeo = new THREE.SphereGeometry(0.075, 14, 12);
    eggGeo.scale(0.85, 1.35, 0.85);
    const eggMat = new THREE.MeshStandardMaterial({
      map: eggTex,
      roughness: 0.35,
      metalness: 0.05,
    });

    for (let i = 0; i < eggCount; i++) {
      const egg = new THREE.Mesh(eggGeo, eggMat);
      const angle = (i / Math.max(eggCount, 1)) * Math.PI * 2;
      const r = 0.12 + (i % 2) * 0.07;
      egg.position.set(Math.cos(angle) * r, 0.06, Math.sin(angle) * r);
      egg.rotation.set(
        0.2 + (Math.random() - 0.5) * 0.4,
        Math.random() * Math.PI * 2,
        0.3 + (Math.random() - 0.5) * 0.4
      );
      egg.castShadow = true;
      egg.receiveShadow = true;
      eggsGroup.add(egg);
    }
  }, [readyProduce]);

  // 🌾 ฟังก์ชันโปรยเมล็ดข้าวโพด 3D
  const spawnGrainScattering = useCallback((originX = 0, originZ = 0) => {
    if (!sceneRef.current || !grainGeoRef.current || !grainMatRef.current) return;
    const scene = sceneRef.current;
    const geo = grainGeoRef.current;
    const mat = grainMatRef.current;

    for (let i = 0; i < 35; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      const startX = originX + (Math.random() - 0.5) * 0.6;
      const startY = 1.6 + Math.random() * 0.4;
      const startZ = originZ + (Math.random() - 0.5) * 0.6;
      mesh.position.set(startX, startY, startZ);
      mesh.scale.setScalar(0.7 + Math.random() * 0.5);
      mesh.castShadow = true;
      scene.add(mesh);

      const targetAngle = Math.random() * Math.PI * 2;
      const horizSpeed = 0.8 + Math.random() * 1.5;
      grainsRef.current.push({
        mesh,
        vel: new THREE.Vector3(
          Math.cos(targetAngle) * horizSpeed,
          1.8 + Math.random() * 1.2,
          Math.sin(targetAngle) * horizSpeed
        ),
        rotVel: new THREE.Vector3(
          (Math.random() - 0.5) * 12,
          (Math.random() - 0.5) * 12,
          (Math.random() - 0.5) * 12
        ),
        groundY: 0.03 + Math.random() * 0.02,
        settled: false,
        eaten: false,
        age: 0,
      });
    }

    // กระตุ้นให้ไก่ทั้งหมดวิ่งมากิน
    chickensRef.current.forEach((c) => {
      c.state = 'seeking_food';
      c.stateTimer = 5 + Math.random() * 3;
      c.speed = (c.type === 'chick' ? 2.0 : 1.6) * (0.9 + Math.random() * 0.3);
    });
  }, []);

  // 🎬 Three.js Scene Setup & Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 200;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    // 1. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 100);
    // มุมกล้องเอียงลงสไตล์ Isometric เล็กน้อย ให้สอดรับกับมุมมองแผนที่ฟาร์ม
    camera.position.set(0, 4.8, 6.4);
    camera.lookAt(0, 0.35, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 2. แสงแดดและแสงสะท้อนหญ้าฟาร์ม (Green Grass Bounce Light)
    const hemiLight = new THREE.HemisphereLight(0xfff7ed, 0x5a8a30, 0.95);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffae0, 1.45);
    sunLight.position.set(4.5, 9.0, 5.0);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.bias = -0.0008;
    sunLight.shadow.camera.near = 0.5;
    sunLight.shadow.camera.far = 25;
    sunLight.shadow.camera.left = -4.5;
    sunLight.shadow.camera.right = 4.5;
    sunLight.shadow.camera.top = 4.0;
    sunLight.shadow.camera.bottom = -4.0;
    scene.add(sunLight);

    // Rim light เบาๆ เพื่อให้ขนไก่มีมิติคมชัด
    const rimLight = new THREE.DirectionalLight(0xfef08a, 0.35);
    rimLight.position.set(-5, 4, -4);
    scene.add(rimLight);

    // 3. ผืนดินที่กลืนกับพื้นหลัง (ShadowMaterial + Feathered Straw/Soil Scatter)
    const shadowGround = new THREE.Mesh(
      track(new THREE.PlaneGeometry(12, 9)),
      track(new THREE.ShadowMaterial({ opacity: 0.32 }))
    );
    shadowGround.rotation.x = -Math.PI / 2;
    shadowGround.position.y = 0.001;
    shadowGround.receiveShadow = true;
    scene.add(shadowGround);

    // เลเยอร์เศษฟางและรอยดินคุ้ยเขี่ย
    const createFeatheredDirtStrawTexture = () => {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 512;
      const ctx = c.getContext('2d')!;

      const grad = ctx.createRadialGradient(256, 256, 30, 256, 256, 250);
      grad.addColorStop(0, 'rgba(80, 48, 22, 0.52)');
      grad.addColorStop(0.45, 'rgba(70, 42, 18, 0.35)');
      grad.addColorStop(0.75, 'rgba(60, 36, 16, 0.12)');
      grad.addColorStop(1, 'rgba(60, 36, 16, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 512, 512);

      ctx.lineWidth = 1.4;
      for (let i = 0; i < 280; i++) {
        const rx = Math.random() * 512;
        const ry = Math.random() * 512;
        const dist = Math.hypot(rx - 256, ry - 256);
        if (dist < 235) {
          const alpha = (1 - dist / 240) * 0.65;
          ctx.strokeStyle = `rgba(234, 179, 8, ${alpha})`;
          ctx.beginPath();
          ctx.moveTo(rx, ry);
          ctx.lineTo(rx + (Math.random() - 0.5) * 16, ry + (Math.random() - 0.5) * 16);
          ctx.stroke();
        }
      }
      return track(new THREE.CanvasTexture(c));
    };

    const dirtDecal = new THREE.Mesh(
      track(new THREE.PlaneGeometry(6.2, 4.4)),
      track(new THREE.MeshStandardMaterial({
        map: createFeatheredDirtStrawTexture(),
        transparent: true,
        roughness: 0.95,
        depthWrite: false,
      }))
    );
    dirtDecal.rotation.x = -Math.PI / 2;
    dirtDecal.position.set(-0.2, 0.002, -0.3);
    dirtDecal.receiveShadow = true;
    scene.add(dirtDecal);

    // 4. เล้าไก่ไม้คลาสสิก (Rustic Wooden Coop)
    const woodTex = getWoodPBRTexture();
    const strawTex = getStrawTexture();
    const coopWoodMat = track(new THREE.MeshStandardMaterial({
      map: woodTex,
      roughness: 0.78,
      metalness: 0.05,
    }));

    const coopGroup = new THREE.Group();
    coopGroup.position.set(-2.0, 0, -1.1);

    const coopBody = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.2, 0.85, 0.95)),
      coopWoodMat
    );
    coopBody.position.y = 0.46;
    coopBody.castShadow = true;
    coopBody.receiveShadow = true;
    coopGroup.add(coopBody);

    const roofMat = track(new THREE.MeshStandardMaterial({
      color: 0x8b3a1a,
      roughness: 0.65,
    }));
    const coopRoof = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.35, 0.1, 1.1)),
      roofMat
    );
    coopRoof.position.set(0, 0.92, 0);
    coopRoof.rotation.x = 0.12;
    coopRoof.castShadow = true;
    coopGroup.add(coopRoof);

    const doorHole = new THREE.Mesh(
      track(new THREE.PlaneGeometry(0.38, 0.5)),
      track(new THREE.MeshBasicMaterial({ color: 0x1c1208 }))
    );
    doorHole.position.set(0.2, 0.38, 0.48);
    coopGroup.add(doorHole);

    const ramp = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.34, 0.03, 0.65)),
      coopWoodMat
    );
    ramp.position.set(0.2, 0.15, 0.75);
    ramp.rotation.x = -0.45;
    ramp.castShadow = true;
    coopGroup.add(ramp);

    const strawBed = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.38, 0.44, 0.1, 14)),
      track(new THREE.MeshStandardMaterial({
        map: strawTex,
        roughness: 0.9,
      }))
    );
    strawBed.position.set(-0.35, 0.05, 0.65);
    strawBed.receiveShadow = true;
    coopGroup.add(strawBed);

    const eggsGroup = new THREE.Group();
    eggsGroup.position.set(-0.35, 0.08, 0.65);
    coopGroup.add(eggsGroup);
    eggsGroupRef.current = eggsGroup;

    scene.add(coopGroup);

    // 5. รั้วไม้ (Fence)
    const fenceGroup = new THREE.Group();
    const postGeo = track(new THREE.CylinderGeometry(0.045, 0.05, 0.55, 6));
    const railGeo = track(new THREE.BoxGeometry(1.2, 0.055, 0.04));

    for (let x = -2.7; x <= 2.7; x += 1.08) {
      const post = new THREE.Mesh(postGeo, coopWoodMat);
      post.position.set(x, 0.27, -1.8);
      post.castShadow = true;
      post.receiveShadow = true;
      fenceGroup.add(post);
    }
    for (let x = -2.16; x <= 2.16; x += 1.08) {
      const railTop = new THREE.Mesh(railGeo, coopWoodMat);
      railTop.position.set(x, 0.38, -1.8);
      railTop.castShadow = true;
      fenceGroup.add(railTop);

      const railBot = new THREE.Mesh(railGeo, coopWoodMat);
      railBot.position.set(x, 0.2, -1.8);
      railBot.castShadow = true;
      fenceGroup.add(railBot);
    }
    scene.add(fenceGroup);

    // 6. รางอาหารไม้และถังน้ำ
    const trough = new THREE.Mesh(
      track(new THREE.BoxGeometry(1.1, 0.16, 0.32)),
      coopWoodMat
    );
    trough.position.set(1.9, 0.08, 0.4);
    trough.castShadow = true;
    trough.receiveShadow = true;
    scene.add(trough);

    const cornInTrough = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.98, 0.05, 0.22)),
      track(new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 }))
    );
    cornInTrough.position.set(1.9, 0.14, 0.4);
    scene.add(cornInTrough);

    const metalTex = getGalvanizedMetalTexture();
    const watererMat = track(new THREE.MeshStandardMaterial({
      map: metalTex,
      roughness: 0.35,
      metalness: 0.6,
    }));
    const waterer = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.18, 0.22, 0.4, 12)),
      watererMat
    );
    waterer.position.set(2.3, 0.2, -0.6);
    waterer.castShadow = true;
    scene.add(waterer);

    const waterPan = new THREE.Mesh(
      track(new THREE.CylinderGeometry(0.28, 0.3, 0.06, 12)),
      track(new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.5 }))
    );
    waterPan.position.set(2.3, 0.03, -0.6);
    scene.add(waterPan);

    // 7. เมล็ดข้าวโพด Grain Prototype
    const grainGeo = track(new THREE.SphereGeometry(0.038, 6, 6));
    grainGeo.scale(1.0, 1.4, 0.8);
    const grainMat = track(new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      roughness: 0.3,
      metalness: 0.1,
    }));
    grainGeoRef.current = grainGeo;
    grainMatRef.current = grainMat;

    // 8. ฝุ่นดินกระจาย
    const dustGeo = track(new THREE.SphereGeometry(0.04, 5, 4));
    const dustMat = track(new THREE.MeshBasicMaterial({
      color: 0x92400e,
      transparent: true,
      opacity: 0.45,
    }));

    const spawnDust = (x: number, y: number, z: number) => {
      for (let i = 0; i < 4; i++) {
        const mesh = new THREE.Mesh(dustGeo, dustMat.clone());
        mesh.position.set(x, y + 0.03, z);
        mesh.scale.setScalar(0.6 + Math.random() * 0.8);
        scene.add(mesh);
        dustRef.current.push({
          mesh,
          vel: new THREE.Vector3(
            (Math.random() - 0.5) * 0.4,
            0.3 + Math.random() * 0.3,
            (Math.random() - 0.5) * 0.4
          ),
          life: 0,
          maxLife: 0.45 + Math.random() * 0.25,
        });
      }
    };

    // 9. ฟังก์ชันสร้างโมเดลตัวไก่ 3D
    const combTex = getChickenCombTexture();
    const legTex = getChickenLegTexture();
    const combMat = track(new THREE.MeshStandardMaterial({
      map: combTex,
      roughness: 0.45,
    }));
    const legMat = track(new THREE.MeshStandardMaterial({
      map: legTex,
      roughness: 0.65,
    }));
    const beakMat = track(new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.35,
    }));
    const eyeMat = track(new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.1,
      metalness: 0.3,
    }));

    const createChicken = (type: 'hen' | 'rooster' | 'chick', initPos: THREE.Vector3): ChickenInstance => {
      const group = new THREE.Group();
      group.position.copy(initPos);

      const isRooster = type === 'rooster';
      const isChick = type === 'chick';
      const scale = isChick ? 0.48 : isRooster ? 1.15 : (0.86 + Math.random() * 0.12);

      const bodyTex = isChick
        ? getChickDownTexture()
        : isRooster
        ? getRoosterFeatherTexture()
        : getHenFeatherTexture();

      const bodyMat = track(new THREE.MeshStandardMaterial({
        map: bodyTex,
        roughness: 0.68,
        metalness: isRooster ? 0.15 : 0.05,
      }));

      const body = new THREE.Mesh(track(new THREE.SphereGeometry(0.36, 12, 10)), bodyMat);
      body.scale.set(1.0, 0.92, 1.28);
      body.position.y = 0.44;
      body.castShadow = true;
      body.receiveShadow = true;
      group.add(body);

      const head = new THREE.Group();
      head.position.set(0, 0.64, 0.32);

      const headMesh = new THREE.Mesh(track(new THREE.SphereGeometry(0.18, 10, 8)), bodyMat);
      headMesh.scale.set(0.9, 1.05, 1.0);
      headMesh.castShadow = true;
      head.add(headMesh);

      const beak = new THREE.Mesh(track(new THREE.ConeGeometry(0.065, 0.16, 6)), beakMat);
      beak.rotation.x = Math.PI / 2;
      beak.position.set(0, -0.02, 0.22);
      beak.castShadow = true;
      head.add(beak);

      const eyeGeo = track(new THREE.SphereGeometry(0.032, 6, 6));
      const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
      leftEye.position.set(0.13, 0.05, 0.08);
      head.add(leftEye);

      const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
      rightEye.position.set(-0.13, 0.05, 0.08);
      head.add(rightEye);

      if (!isChick) {
        const combH = isRooster ? 0.24 : 0.12;
        const combGeo = track(new THREE.BoxGeometry(0.04, combH, 0.24));
        const comb = new THREE.Mesh(combGeo, combMat);
        comb.position.set(0, 0.16 + (isRooster ? 0.06 : 0), 0.02);
        comb.castShadow = true;
        head.add(comb);

        const wattleGeo = track(new THREE.SphereGeometry(0.05, 6, 6));
        wattleGeo.scale(0.5, 1.4, 0.8);
        const wattleL = new THREE.Mesh(wattleGeo, combMat);
        wattleL.position.set(0.045, -0.12, 0.12);
        head.add(wattleL);

        const wattleR = new THREE.Mesh(wattleGeo, combMat);
        wattleR.position.set(-0.045, -0.12, 0.12);
        head.add(wattleR);
      }
      group.add(head);

      const wingGeo = track(new THREE.BoxGeometry(0.06, 0.28, 0.5));
      const leftWingGroup = new THREE.Group();
      leftWingGroup.position.set(0.32, 0.46, 0);
      const leftWingMesh = new THREE.Mesh(wingGeo, bodyMat);
      leftWingMesh.position.set(0.02, -0.06, -0.08);
      leftWingMesh.castShadow = true;
      leftWingGroup.add(leftWingMesh);
      group.add(leftWingGroup);

      const rightWingGroup = new THREE.Group();
      rightWingGroup.position.set(-0.32, 0.46, 0);
      const rightWingMesh = new THREE.Mesh(wingGeo, bodyMat);
      rightWingMesh.position.set(-0.02, -0.06, -0.08);
      rightWingMesh.castShadow = true;
      rightWingGroup.add(rightWingMesh);
      group.add(rightWingGroup);

      if (isRooster) {
        const tailGroup = new THREE.Group();
        tailGroup.position.set(0, 0.52, -0.42);
        for (let t = 0; t < 5; t++) {
          const feather = new THREE.Mesh(
            track(new THREE.BoxGeometry(0.04, 0.5, 0.14)),
            bodyMat
          );
          feather.position.set((t - 2) * 0.045, 0.22, -(t % 2) * 0.08);
          feather.rotation.x = -0.75 - t * 0.1;
          feather.castShadow = true;
          tailGroup.add(feather);
        }
        group.add(tailGroup);
      } else if (!isChick) {
        const henTail = new THREE.Mesh(
          track(new THREE.ConeGeometry(0.16, 0.32, 6)),
          bodyMat
        );
        henTail.rotation.x = -1.1;
        henTail.position.set(0, 0.52, -0.42);
        henTail.castShadow = true;
        group.add(henTail);
      }

      const legBoneGeo = track(new THREE.CylinderGeometry(0.025, 0.02, 0.22, 6));
      const footGeo = track(new THREE.BoxGeometry(0.09, 0.02, 0.12));

      const leftLeg = new THREE.Group();
      leftLeg.position.set(0.14, 0.24, 0);
      const legMeshL = new THREE.Mesh(legBoneGeo, legMat);
      legMeshL.position.y = -0.1;
      legMeshL.castShadow = true;
      leftLeg.add(legMeshL);

      const leftFoot = new THREE.Group();
      leftFoot.position.set(0, -0.21, 0.02);
      const footMeshL = new THREE.Mesh(footGeo, legMat);
      footMeshL.castShadow = true;
      leftFoot.add(footMeshL);
      leftLeg.add(leftFoot);
      group.add(leftLeg);

      const rightLeg = new THREE.Group();
      rightLeg.position.set(-0.14, 0.24, 0);
      const legMeshR = new THREE.Mesh(legBoneGeo, legMat);
      legMeshR.position.y = -0.1;
      legMeshR.castShadow = true;
      rightLeg.add(legMeshR);

      const rightFoot = new THREE.Group();
      rightFoot.position.set(0, -0.21, 0.02);
      const footMeshR = new THREE.Mesh(footGeo, legMat);
      footMeshR.castShadow = true;
      rightFoot.add(footMeshR);
      rightLeg.add(rightFoot);
      group.add(rightLeg);

      group.scale.setScalar(scale);
      scene.add(group);

      return {
        group,
        head,
        leftWing: leftWingGroup,
        rightWing: rightWingGroup,
        leftLeg,
        rightLeg,
        leftFoot,
        rightFoot,
        type,
        pos: initPos.clone(),
        targetPos: initPos.clone(),
        direction: Math.random() * Math.PI * 2,
        speed: (isChick ? 1.4 : isRooster ? 1.0 : 0.85) * (0.85 + Math.random() * 0.3),
        state: 'idle',
        stateTimer: Math.random() * 2,
        peckCounter: Math.random() * Math.PI,
        walkCycle: Math.random() * Math.PI * 2,
        scratchStep: 0,
        scale,
        baseY: 0,
      };
    };

    // ฝูงไก่ในลาน: แม่ไก่ 11 ตัว (เดิม 1 + เพิ่มใหม่อีก 10 ตัว), พ่อไก่โต้ง 1, ลูกเจี๊ยบ 2
    const flock: ChickenInstance[] = [
      createChicken('hen', new THREE.Vector3(-0.6, 0, 0.2)),
      createChicken('rooster', new THREE.Vector3(0.7, 0, -0.4)),
      createChicken('chick', new THREE.Vector3(-0.9, 0, 0.5)),
      createChicken('chick', new THREE.Vector3(-0.4, 0, 0.6)),

      // 🐔 เพิ่มแม่ไก่อีก 10 ตัว กระจายตามจุดต่างๆ ในลานฟาร์ม
      createChicken('hen', new THREE.Vector3(0.3, 0, 0.8)),
      createChicken('hen', new THREE.Vector3(-1.3, 0, 0.1)),
      createChicken('hen', new THREE.Vector3(1.2, 0, -0.2)),
      createChicken('hen', new THREE.Vector3(-0.2, 0, -0.7)),
      createChicken('hen', new THREE.Vector3(1.5, 0, 0.9)),
      createChicken('hen', new THREE.Vector3(-1.5, 0, 0.85)),
      createChicken('hen', new THREE.Vector3(0.8, 0, 0.35)),
      createChicken('hen', new THREE.Vector3(-0.8, 0, -0.9)),
      createChicken('hen', new THREE.Vector3(0.0, 0, 0.05)),
      createChicken('hen', new THREE.Vector3(1.1, 0, -0.9)),
    ];
    chickensRef.current = flock;

    // 10. Animation Loop
    let animId: number;
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;

      // A. ฟิสิกส์เมล็ดข้าวโพด Grain Particles
      const grains = grainsRef.current;
      for (let i = grains.length - 1; i >= 0; i--) {
        const g = grains[i];
        g.age += dt;

        if (!g.settled) {
          g.vel.y -= 9.8 * dt;
          g.mesh.position.x += g.vel.x * dt;
          g.mesh.position.y += g.vel.y * dt;
          g.mesh.position.z += g.vel.z * dt;

          g.mesh.rotation.x += g.rotVel.x * dt;
          g.mesh.rotation.y += g.rotVel.y * dt;

          if (g.mesh.position.y <= g.groundY) {
            g.mesh.position.y = g.groundY;
            g.vel.y = -g.vel.y * 0.35;
            g.vel.x *= 0.5;
            g.vel.z *= 0.5;
            if (Math.abs(g.vel.y) < 0.2) {
              g.settled = true;
            }
          }
        }

        if (g.eaten || g.age > 15) {
          g.mesh.scale.multiplyScalar(0.9);
          if (g.mesh.scale.x < 0.05) {
            scene.remove(g.mesh);
            grains.splice(i, 1);
          }
        }
      }

      // B. ฝุ่นดิน Dust Particles
      const dusts = dustRef.current;
      for (let i = dusts.length - 1; i >= 0; i--) {
        const d = dusts[i];
        d.life += dt;
        d.mesh.position.addScaledVector(d.vel, dt);
        d.mesh.scale.multiplyScalar(1.03);
        const mat = d.mesh.material as THREE.MeshBasicMaterial;
        mat.opacity = 0.45 * (1 - d.life / d.maxLife);

        if (d.life >= d.maxLife) {
          scene.remove(d.mesh);
          dusts.splice(i, 1);
        }
      }

      // C. การเคลื่อนไหวของฝูงไก่ทั้งหมด
      flock.forEach((c) => {
        c.stateTimer -= dt;

        if (c.state === 'seeking_food') {
          let closestDist = Infinity;
          let targetGrain: GrainParticle | null = null;
          grains.forEach((g) => {
            if (!g.eaten) {
              const d = c.pos.distanceTo(g.mesh.position);
              if (d < closestDist) {
                closestDist = d;
                targetGrain = g;
              }
            }
          });

          if (targetGrain && closestDist > 0.35) {
            c.targetPos.copy((targetGrain as GrainParticle).mesh.position);
            c.targetPos.y = 0;
            const dirX = c.targetPos.x - c.pos.x;
            const dirZ = c.targetPos.z - c.pos.z;
            c.direction = Math.atan2(dirX, dirZ);
            c.walkCycle += dt * 16;

            const stepDist = c.speed * dt * 1.5;
            c.pos.x += Math.sin(c.direction) * stepDist;
            c.pos.z += Math.cos(c.direction) * stepDist;
            c.group.position.x = c.pos.x;
            c.group.position.z = c.pos.z;

            c.head.position.z = 0.32 + Math.sin(c.walkCycle * 2) * 0.08;
            c.leftLeg.rotation.x = Math.sin(c.walkCycle) * 0.65;
            c.rightLeg.rotation.x = -Math.sin(c.walkCycle) * 0.65;
          } else if (targetGrain) {
            c.state = 'pecking';
            c.stateTimer = 1.2;
            (targetGrain as GrainParticle).eaten = true;
            sound.playHarvest();
          } else {
            c.state = 'idle';
            c.stateTimer = 2.0;
          }
        } else if (c.state === 'walking') {
          c.walkCycle += dt * 9;
          const stepDist = c.speed * dt;
          c.pos.x += Math.sin(c.direction) * stepDist;
          c.pos.z += Math.cos(c.direction) * stepDist;

          c.pos.x = Math.max(-2.5, Math.min(2.5, c.pos.x));
          c.pos.z = Math.max(-1.5, Math.min(1.4, c.pos.z));

          c.group.position.x = c.pos.x;
          c.group.position.z = c.pos.z;

          c.head.position.z = 0.32 + Math.sin(c.walkCycle * 2) * 0.06;
          c.head.position.y = 0.64 + Math.abs(Math.sin(c.walkCycle)) * 0.03;

          c.leftLeg.rotation.x = Math.sin(c.walkCycle) * 0.55;
          c.rightLeg.rotation.x = -Math.sin(c.walkCycle) * 0.55;

          c.leftWing.rotation.z = Math.abs(Math.sin(c.walkCycle)) * 0.15;
          c.rightWing.rotation.z = -Math.abs(Math.sin(c.walkCycle)) * 0.15;

          if (c.stateTimer <= 0) {
            c.state = Math.random() > 0.4 ? 'scratching' : 'pecking';
            c.stateTimer = 1.5 + Math.random() * 2;
            c.peckCounter = 0;
            c.scratchStep = 0;
            c.leftLeg.rotation.x = 0;
            c.rightLeg.rotation.x = 0;
          }
        } else if (c.state === 'scratching') {
          c.walkCycle += dt * 10;
          c.scratchStep += dt;
          if (c.scratchStep < 0.35) {
            c.rightLeg.rotation.x = -0.7;
            c.group.position.y = 0.03;
          } else if (c.scratchStep < 0.7) {
            c.rightLeg.rotation.x = 0;
            c.leftLeg.rotation.x = -0.7;
            c.group.position.y = 0.03;
            if (Math.random() < 0.3) spawnDust(c.pos.x, 0, c.pos.z);
          } else {
            c.state = 'pecking';
            c.stateTimer = 1.0;
          }
        } else if (c.state === 'pecking') {
          c.peckCounter += dt * 7;
          const dip = Math.sin(c.peckCounter);
          c.head.rotation.x = dip > 0 ? dip * 0.9 : 0;
          c.head.position.y = 0.64 - (dip > 0 ? dip * 0.28 : 0);
          c.head.position.z = 0.32 + (dip > 0 ? dip * 0.12 : 0);

          if (c.stateTimer <= 0) {
            c.head.rotation.x = 0;
            c.head.position.y = 0.64;
            c.head.position.z = 0.32;
            c.state = 'idle';
            c.stateTimer = 1.0 + Math.random() * 2.5;
          }
        } else if (c.state === 'hopping') {
          c.walkCycle += dt * 12;
          const hop = Math.sin(c.walkCycle);
          c.group.position.y = Math.max(0, hop * 0.25);
          c.leftWing.rotation.z = Math.abs(hop) * 0.8;
          c.rightWing.rotation.z = -Math.abs(hop) * 0.8;

          if (c.stateTimer <= 0) {
            c.group.position.y = 0;
            c.leftWing.rotation.z = 0;
            c.rightWing.rotation.z = 0;
            c.state = 'idle';
            c.stateTimer = 2.0;
          }
        } else {
          c.walkCycle += dt * 2;
          c.head.rotation.y = Math.sin(c.walkCycle) * 0.45;

          if (c.stateTimer <= 0) {
            c.state = 'walking';
            c.direction = Math.random() * Math.PI * 2;
            c.stateTimer = 2.5 + Math.random() * 3.5;
          }
        }

        const targetRot = -c.direction + Math.PI;
        c.group.rotation.y = THREE.MathUtils.lerp(c.group.rotation.y, targetRot, 0.12);
      });

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth || 320;
      const h = container.clientHeight || 200;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      disposables.forEach((res) => res.dispose());
    };
  }, []);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.stopPropagation();
    if (!canvasRef.current || !cameraRef.current || !sceneRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const chickenGroups = chickensRef.current.map((c) => c.group);
    const intersects = raycaster.intersectObjects(chickenGroups, true);

    if (intersects.length > 0) {
      sound.playAnimal('chicken');
      const clickedChicken = chickensRef.current.find((c) => {
        let cur: THREE.Object3D | null = intersects[0].object;
        while (cur) {
          if (cur === c.group) return true;
          cur = cur.parent;
        }
        return false;
      }) || chickensRef.current[0];

      clickedChicken.state = 'hopping';
      clickedChicken.stateTimer = 1.0;
      clickedChicken.walkCycle = 0;

      const quotes = [
        'กุ๊กๆๆ! ฝูงแม่ไก่อารมณ์ดีมากจ้า 🌾🐔',
        'เอ้กอีเอ้กเอ้ก! อารมณ์ดี ขนเงาวับ ☀️',
        'จิ๊บๆ! ลูกเจี๊ยบวิ่งตามแม่ไก่แจ้ 🐥✨',
        'กุ๊กกรู้ว! แม่ไก่คุ้ยหาของกินอย่างเพลินใจ 🐔🌾',
      ];
      setActiveSpeech(quotes[Math.floor(Math.random() * quotes.length)]);
      setTimeout(() => setActiveSpeech(null), 3000);
    } else {
      spawnGrainScattering(0, 0);
      sound.playPlant();
    }
  };

  const handleFeed = () => {
    if (isFed) return;
    spawnGrainScattering(0, 0);
    sound.playPlant();
    if (onFeed) onFeed();

    setFeedEffect(true);
    setTimeout(() => setFeedEffect(false), 2000);
    setActiveSpeech('โปรยธัญพืชทองคำ! ฝูงไก่วิ่งมารุมจิกอย่างเอร็ดอร่อย 🌾✨');
    setTimeout(() => setActiveSpeech(null), 3000);
  };

  const handleCollect = () => {
    sound.playHarvest();
    if (onCollectEggs) onCollectEggs();
  };

  return (
    <div
      ref={containerRef}
      className={`relative select-none ${
        seamless
          ? 'w-full h-full overflow-visible bg-transparent'
          : 'w-full h-[220px] sm:h-[260px] rounded-3xl overflow-hidden shadow-2xl border-4 border-[#8c5225] bg-[#3a200d]'
      } ${className}`}
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-pointer touch-none"
        title="แตะที่ตัวไก่เพื่อให้กระโดดและส่งเสียงร้อง หรือแตะพื้นเพื่อโปรยข้าว!"
      />

      {!compact && (
        <div className="absolute top-2.5 inset-x-3 flex items-center justify-between pointer-events-none z-10">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-[#2b1406]/90 backdrop-blur-xs rounded-full border border-amber-600/50 shadow-md">
            <span className="text-base">🐔</span>
            <span className="text-xs font-bold text-amber-200 font-['Kanit',sans-serif]">
              เล้าไก่ไข่อารมณ์ดี 3D (ฝูงแม่ไก่ 11 ตัว)
            </span>
            {isFed && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
          </div>

          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={handleFeed}
              disabled={isFed}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 transition-transform active:scale-95 shadow-md ${
                isFed
                  ? 'bg-amber-900/60 text-amber-300/50 cursor-not-allowed border border-amber-800'
                  : 'bg-gradient-to-b from-amber-500 to-amber-600 hover:from-amber-400 text-amber-950 border border-white cursor-pointer'
              }`}
            >
              <span>🌾</span>
              <span>{isFed ? 'ไก่อิ่มแล้ว' : 'โปรยอาหาร'}</span>
            </button>

            {readyProduce > 0 && onCollectEggs && (
              <button
                type="button"
                onClick={handleCollect}
                className="px-3 py-1.5 bg-gradient-to-b from-emerald-500 to-green-600 hover:from-emerald-400 text-white font-bold text-xs rounded-xl border border-white shadow-md flex items-center gap-1 cursor-pointer animate-bounce transition-transform"
              >
                <span>🥚</span>
                <span>เก็บไข่ ({readyProduce})</span>
              </button>
            )}
          </div>
        </div>
      )}

      {compact && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-30 pointer-events-auto">
          {!isFed && onFeed && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleFeed();
              }}
              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-amber-950 rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🌾</span>
              <span>โปรยข้าว</span>
            </button>
          )}
          {readyProduce > 0 && onCollectEggs && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCollect();
              }}
              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-white rounded-full font-black text-[11px] shadow-lg border-2 border-white flex items-center gap-1 animate-bounce transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>🥚</span>
              <span>เก็บไข่ ({readyProduce})</span>
            </button>
          )}
        </div>
      )}

      {activeSpeech && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-black/85 text-amber-200 text-xs font-bold rounded-full border border-amber-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}

      {feedEffect && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-25">
          <span className="text-2xl animate-ping">🌾 🌾 🌾 🌾</span>
        </div>
      )}
    </div>
  );
};