// src/components/3d/IsometricPig3D.tsx

import React, { useState, useRef, useEffect, memo } from 'react';
import { Sparkles, Utensils, Move, Check } from 'lucide-react';

export interface PigEntity {
  id: string;
  name?: string;
  breed?: string;
  weightKg?: number;
  x: number;
  y: number;
  fedAt: number | null;
  durationSec: number;
  isReady: boolean;
  produceName: string;
  produceIcon: string;
}

export interface IsometricPig3DProps {
  pig: PigEntity;
  boundary?: { minX: number; maxX: number; minY: number; maxY: number };
  onFeedClick: (pigId: string) => void;
  onCollectClick: (pigId: string) => void;
  onMove: (pigId: string, newX: number, newY: number) => void;
  onOpenScroll?: (pigId: string) => void;
}

// 1. แยก Style Keyframes ไว้ภายนอก Component ป้องกันการ mount ซ้ำซ้อน
const PIG_STYLES = `
  @keyframes iso-pig-snout {
    0%, 100% { transform: translate(0, 0); }
    50% { transform: translate(1px, 1px); }
  }
  @keyframes iso-pig-tail {
    0%, 100% { transform: rotate(0deg); }
    50% { transform: rotate(-22deg); }
  }
  .anim-iso-tail { animation: iso-pig-tail 0.35s ease-in-out infinite; transform-origin: 106px 47px; }
  .anim-iso-snout { animation: iso-pig-snout 2.5s ease-in-out infinite; }
`;

export const IsometricPig3D: React.FC<IsometricPig3DProps> = memo(({
  pig,
  onFeedClick,
  onCollectClick,
  onMove,
  onOpenScroll,
}) => {
  const [isMoveMode, setIsMoveMode] = useState(false);

  // References สำหรับควบคุม DOM ตรงๆ (Direct DOM Manipulation เพื่อ 60FPS)
  const containerRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const backFarLegRef = useRef<SVGGraphicsElement>(null);
  const frontFarLegRef = useRef<SVGGraphicsElement>(null);
  const backNearLegRef = useRef<SVGGraphicsElement>(null);
  const frontNearLegRef = useRef<SVGGraphicsElement>(null);

  // พิกัดภายในระบบฟิสิกส์ (ไม่ทำให้ Component Re-render)
  const posRef = useRef({ x: pig.x ?? 640, y: pig.y ?? 480 });
  const dragRef = useRef<{ startX: number; startY: number; initX: number; initY: number } | null>(null);

  // ซิงค์ตำแหน่งเมื่อ Props จาก Parent มีการเปลี่ยนแปลง
  useEffect(() => {
    posRef.current = { x: pig.x, y: pig.y };
    if (containerRef.current) {
      containerRef.current.style.left = `${pig.x}px`;
      containerRef.current.style.top = `${pig.y}px`;
      containerRef.current.style.zIndex = `${Math.floor(pig.y) + 15}`;
    }
  }, [pig.x, pig.y]);

  // ฟังก์ชันอัปเดตท่าทางขาและลำตัวผ่าน CSS Transform โดยตรง
  const updateVisualPose = (facingLeft: boolean, bob: number, legAngle: number) => {
    if (bodyRef.current) {
      bodyRef.current.style.transform = `${facingLeft ? 'scaleX(-1)' : 'scaleX(1)'} translateY(-${bob}px)`;
    }
    const legTransform1 = `rotate(${legAngle}deg)`;
    const legTransform2 = `rotate(${-legAngle}deg)`;

    if (backNearLegRef.current) backNearLegRef.current.style.transform = legTransform1;
    if (frontNearLegRef.current) frontNearLegRef.current.style.transform = legTransform2;
    if (backFarLegRef.current) backFarLegRef.current.style.transform = legTransform2;
    if (frontFarLegRef.current) frontFarLegRef.current.style.transform = legTransform1;
  };

  // Game Loop: ระบบเดินเตาะแตะแบบ Isometric 60FPS (ตัด React Re-render ทิ้ง 100%)
  useEffect(() => {
    if (isMoveMode) return;

    let animFrame: number;
    let wanderTimer: ReturnType<typeof setTimeout>;
    let isWalking = false;
    let facingLeft = false;

    const roamRadius = 32;

    const wanderStep = () => {
      const angle = Math.random() * Math.PI * 2;
      const dist = Math.random() * roamRadius;
      
      const originX = pig.x;
      const originY = pig.y;
      const targetX = originX + Math.cos(angle) * dist;
      const targetY = originY + Math.sin(angle) * (dist * 0.55);

      facingLeft = targetX < posRef.current.x;
      isWalking = true;

      const startX = posRef.current.x;
      const startY = posRef.current.y;
      const duration = 2200 + Math.random() * 800;
      const startTime = performance.now();

      const runFrame = (time: number) => {
        const elapsed = time - startTime;
        const progress = Math.min(elapsed / duration, 1);

        // คำนวณก้าวเดินเตาะแตะ
        const waddle = Math.sin((elapsed / 1000) * 11);
        const legAngle = isWalking ? waddle * 13 : 0;
        const bob = isWalking ? Math.abs(waddle) * 2.2 : 0;

        // คำนวณพิกัดใหม่
        const curX = startX + (targetX - startX) * progress;
        const curY = startY + (targetY - startY) * progress;

        posRef.current = { x: curX, y: curY };

        // อัปเดตผ่าน DOM โดยตรง ไม่ผ่าน setState
        if (containerRef.current) {
          containerRef.current.style.left = `${curX}px`;
          containerRef.current.style.top = `${curY}px`;
          containerRef.current.style.zIndex = `${Math.floor(curY) + 15}`;
        }

        updateVisualPose(facingLeft, bob, legAngle);

        if (progress < 1) {
          animFrame = requestAnimationFrame(runFrame);
        } else {
          isWalking = false;
          updateVisualPose(facingLeft, 0, 0);
          wanderTimer = setTimeout(wanderStep, 2500 + Math.random() * 3000);
        }
      };

      animFrame = requestAnimationFrame(runFrame);
    };

    wanderTimer = setTimeout(wanderStep, 1000 + Math.random() * 1500);

    return () => {
      cancelAnimationFrame(animFrame);
      clearTimeout(wanderTimer);
    };
  }, [pig.x, pig.y, isMoveMode]);

  // ระบบ Drag & Drop: Drag ลื่นไหล และยิง callback onMove เฉพาะตอนปล่อยนิ้ว (PointerUp)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isMoveMode) return;
    e.stopPropagation();
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initX: posRef.current.x,
      initY: posRef.current.y,
    };
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {}
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current || !isMoveMode) return;
    e.stopPropagation();
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    const nextX = Math.round(dragRef.current.initX + dx);
    const nextY = Math.round(dragRef.current.initY + dy);

    posRef.current = { x: nextX, y: nextY };

    // อัปเดตตำแหน่งลากทันทีบน DOM
    if (containerRef.current) {
      containerRef.current.style.left = `${nextX}px`;
      containerRef.current.style.top = `${nextY}px`;
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current) return;
    e.stopPropagation();
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {}

    // ยิง onMove บันทึกลง State หลักของฟาร์มเพียงครั้งเดียวเมื่อปล่อยมือ
    onMove(pig.id, posRef.current.x, posRef.current.y);
    dragRef.current = null;
  };

  return (
    <>
      {/* ฝัง global style ครั้งเดียว */}
      <style>{PIG_STYLES}</style>

      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        style={{
          left: `${posRef.current.x}px`,
          top: `${posRef.current.y}px`,
          transform: 'translate(-50%, -75%)',
          touchAction: 'none',
          zIndex: isMoveMode ? 9999 : Math.floor(posRef.current.y) + 15,
        }}
        className="absolute select-none pointer-events-auto group cursor-pointer"
      >
        {/* บ่อโคลนธรรมชาติรอบตัว (Mud Puddle) */}
        <div className="absolute -left-12 -top-2 w-44 h-24 pointer-events-none -z-10 opacity-70">
          <svg viewBox="0 0 160 80" className="w-full h-full">
            <path
              d="M 25,45 C 10,40 12,65 35,70 C 60,75 110,75 135,65 C 155,55 150,35 130,30 C 110,25 95,20 75,22 C 45,20 35,35 25,45 Z"
              fill="#5b3823"
              opacity="0.85"
            />
            <path
              d="M 38,48 C 28,45 30,60 48,63 C 70,68 105,66 122,58 C 138,50 132,38 118,34 C 100,30 85,26 68,28 C 48,27 42,38 38,48 Z"
              fill="#442614"
              opacity="0.9"
            />
          </svg>
        </div>

        {/* วงแหวนโหมดจัดตำแหน่ง */}
        {isMoveMode && (
          <div className="absolute inset-x-[-15px] bottom-0 h-10 rounded-full border-2 border-dashed border-amber-300 bg-amber-400/20 animate-pulse pointer-events-none" />
        )}

        {/* ตัวหมู (สเกลและมุมมอง Isometric 3D) */}
        <div
          ref={bodyRef}
          className={`relative transition-transform duration-75 ${
            isMoveMode ? 'scale-105 cursor-grab active:cursor-grabbing' : 'hover:scale-105'
          }`}
        >
          <svg
            viewBox="0 0 140 100"
            className="w-28 h-20 sm:w-32 sm:h-24 overflow-visible filter drop-shadow-lg pointer-events-none"
          >
            <defs>
              <linearGradient id={`pig_body_${pig.id}`} x1="30%" y1="10%" x2="60%" y2="90%">
                <stop offset="0%" stopColor="#ffccd7" />
                <stop offset="35%" stopColor="#f7abbb" />
                <stop offset="70%" stopColor="#e5899e" />
                <stop offset="100%" stopColor="#be5770" />
              </linearGradient>

              <radialGradient id={`pig_head_${pig.id}`} cx="40%" cy="40%" r="60%">
                <stop offset="0%" stopColor="#ffd8e0" />
                <stop offset="50%" stopColor="#f5a4b5" />
                <stop offset="85%" stopColor="#d87087" />
                <stop offset="100%" stopColor="#b04961" />
              </radialGradient>

              <linearGradient id={`pig_snout_${pig.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#f98ea5" />
                <stop offset="100%" stopColor="#c74967" />
              </linearGradient>
            </defs>

            {/* เงาตกกระทบบนพื้น */}
            <ellipse cx="65" cy="82" rx="42" ry="14" fill="#2b1509" opacity="0.65" filter="blur(3px)" />

            {/* ขาหลังไกล */}
            <g ref={backFarLegRef} style={{ transformOrigin: '92px 65px' }}>
              <rect x="88" y="60" width="10" height="20" rx="4" fill="#a4465b" />
              <path d="M 88,77 L 98,77 L 97,81 L 89,81 Z" fill="#3d1b11" />
            </g>

            {/* ขาหน้าไกล */}
            <g ref={frontFarLegRef} style={{ transformOrigin: '52px 65px' }}>
              <rect x="47" y="62" width="9.5" height="19" rx="4" fill="#a4465b" />
              <path d="M 47,78 L 56.5,78 L 55.5,82 L 48,82 Z" fill="#3d1b11" />
            </g>

            {/* หางหมูม้วนดุ๊กดิ๊ก */}
            <path
              className="anim-iso-tail"
              d="M 106,47 C 114,44 117,37 114,33 C 111,29 105,33 111,39 C 115,43 118,40 120,42"
              fill="none"
              stroke="#f5a4b5"
              strokeWidth="3.2"
              strokeLinecap="round"
            />

            {/* ลำตัวทรงกระบอก Isometric */}
            <path
              d="M 42,50 C 42,32 62,26 86,30 C 105,33 112,46 110,60 C 108,74 88,76 66,74 C 48,72 42,62 42,50 Z"
              fill={`url(#pig_body_${pig.id})`}
            />

            {/* ไฮไลท์สันหลัง */}
            <path
              d="M 52,36 C 68,32 88,33 100,39 C 94,44 74,40 52,42 Z"
              fill="#ffffff"
              opacity="0.3"
            />

            {/* ขาหลังใกล้ */}
            <g ref={backNearLegRef} style={{ transformOrigin: '82px 68px' }}>
              <rect x="76" y="62" width="11" height="23" rx="5" fill="#f19bb0" stroke="#a4465b" strokeWidth="0.8" />
              <path d="M 76,82 L 87,82 L 86,86 L 77,86 Z" fill="#462215" />
            </g>

            {/* ขาหน้าใกล้ */}
            <g ref={frontNearLegRef} style={{ transformOrigin: '40px 68px' }}>
              <rect x="36" y="64" width="10.5" height="22" rx="5" fill="#f19bb0" stroke="#a4465b" strokeWidth="0.8" />
              <path d="M 36,83 L 46.5,83 L 45.5,87 L 37,87 Z" fill="#462215" />
            </g>

            {/* หัวหมู Isometric */}
            <ellipse
              cx="37"
              cy="54"
              rx="19"
              ry="18"
              fill={`url(#pig_head_${pig.id})`}
              stroke="#b85169"
              strokeWidth="0.8"
            />

            {/* หูหลัง */}
            <path d="M 36,36 C 36,24 47,26 44,38 Z" fill="#b85169" />

            {/* หูหน้าพับลง */}
            <path
              d="M 27,37 C 22,30 33,26 36,36 C 37,42 32,46 27,42 Z"
              fill="#f7a8b9"
              stroke="#a4465b"
              strokeWidth="0.9"
            />
            <path d="M 27,35 C 24,31 31,29 33,36 Z" fill="#8d2b42" />

            {/* ตาหมู Isometric */}
            <circle cx="28" cy="48" r="2.2" fill="#1f0e08" />
            <circle cx="27.5" cy="47.5" r="0.7" fill="#ffffff" />
            <path d="M 25,45 Q 29,44 32,46" stroke="#8d2b42" strokeWidth="0.9" fill="none" opacity="0.6" />

            {/* จมูกหมู */}
            <g className="anim-iso-snout">
              <ellipse
                cx="17"
                cy="58"
                rx="7.5"
                ry="8.5"
                fill={`url(#pig_snout_${pig.id})`}
                stroke="#8d2b42"
                strokeWidth="1.2"
              />
              <ellipse cx="15.5" cy="58" rx="1.3" ry="2.2" fill="#3a0b15" />
              <ellipse cx="19" cy="58.5" rx="1.3" ry="2.2" fill="#3a0b15" />
              <ellipse cx="16.5" cy="53.5" rx="4" ry="2" fill="#ffffff" opacity="0.45" />
            </g>
          </svg>

          {/* ป้าย Action ด้านบนหัวหมู */}
          <div className="absolute -top-7 left-1/2 -translate-x-1/2 flex items-center gap-1 z-20 pointer-events-auto">
            {!pig.fedAt && !pig.isReady && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onFeedClick(pig.id);
                }}
                className="px-2.5 py-0.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-black text-[10px] rounded-full shadow-md border border-amber-200 flex items-center gap-1 active:scale-95 animate-bounce cursor-pointer whitespace-nowrap"
              >
                <Utensils className="w-2.5 h-2.5" />
                <span>ให้อาหาร</span>
              </button>
            )}

            {pig.fedAt && !pig.isReady && (
              <div className="px-2 py-0.5 bg-stone-900/90 text-amber-300 font-bold text-[9px] rounded-full border border-amber-400/50 shadow flex items-center gap-1 whitespace-nowrap">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                <span>กำลังกิน... 🥣</span>
              </div>
            )}

            {pig.isReady && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onCollectClick(pig.id);
                }}
                className="px-2.5 py-0.5 bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-stone-950 font-black text-[10px] rounded-full shadow-lg border border-white flex items-center gap-1 animate-bounce active:scale-95 cursor-pointer whitespace-nowrap"
              >
                <Sparkles className="w-3 h-3 text-amber-900" />
                <span>เก็บ {pig.produceIcon || '🥓'}</span>
              </button>
            )}

            {/* ปุ่มเปิดม้วนกระดาษ */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                if (onOpenScroll) onOpenScroll(pig.id);
                else onFeedClick(pig.id);
              }}
              className="w-5 h-5 rounded-full bg-stone-900/80 border border-amber-400 text-amber-200 flex items-center justify-center text-[10px] shadow hover:scale-110 transition active:scale-95 cursor-pointer"
              title="เปิดม้วนกระดาษสารบบปศุสัตว์"
            >
              📜
            </button>
          </div>
        </div>

        {/* ปุ่มสลับโหมดจัดวาง */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsMoveMode(!isMoveMode);
          }}
          className={`absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[9px] font-bold shadow border flex items-center gap-0.5 transition-transform active:scale-90 cursor-pointer ${
            isMoveMode
              ? 'bg-emerald-600 text-white border-white scale-105'
              : 'bg-stone-900/80 text-amber-200 border-amber-400/40 hover:bg-stone-800'
          }`}
        >
          {isMoveMode ? (
            <>
              <Check className="w-2.5 h-2.5 text-emerald-200" />
              <span>วาง</span>
            </>
          ) : (
            <>
              <Move className="w-2 h-2" />
              <span>ย้าย</span>
            </>
          )}
        </button>
      </div>
    </>
  );
});

export default IsometricPig3D;