export { Pig3D, type Pig3DProps } from '../../Pig3D';
export { default } from '../../Pig3D';
