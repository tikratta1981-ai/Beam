import React, { useEffect, useRef, useState, useCallback, memo } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';
import { Zap, Sparkles } from 'lucide-react';

export interface CropPlot3DData {
  id: string;
  name: string;
  type: 'corn' | 'wheat';
  icon: string;
  x: number;
  y: number;
  width: number;
  height: number;
  progress: number;
  isReady: boolean;
}

interface FarmCrops3DProps {
  isEditMode: boolean;
  onHarvestCrop?: (crop: CropPlot3DData, clientX: number, clientY: number) => void;
  onSpeedUpCrop?: (cropId: string) => void;
}

const DEFAULT_CROPS: CropPlot3DData[] = [
  {
    id: 'crop_corn_main',
    name: 'แปลงข้าวโพดหวาน 3D',
    type: 'corn',
    icon: '🌽',
    x: 480,
    y: 440,
    width: 280,
    height: 190,
    progress: 1.0,
    isReady: true,
  },
];

export const FarmCrops3D: React.FC<FarmCrops3DProps> = ({
  isEditMode,
  onHarvestCrop,
  onSpeedUpCrop,
}) => {
  const [crops, setCrops] = useState<CropPlot3DData[]>(DEFAULT_CROPS);

  const handleHarvest = useCallback((crop: CropPlot3DData, e: React.MouseEvent) => {
    if (isEditMode) return;
    e.stopPropagation();

    if (crop.isReady) {
      try {
        sound.playHarvest();
      } catch {}

      if (onHarvestCrop) {
        onHarvestCrop(crop, e.clientX, e.clientY);
      }

      setCrops((prev) =>
        prev.map((c) =>
          c.id === crop.id ? { ...c, progress: 0.15, isReady: false } : c
        )
      );
    }
  }, [isEditMode, onHarvestCrop]);

  const handleSpeedUp = useCallback((cropId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      sound.playSuccessChime();
    } catch {}

    setCrops((prev) =>
      prev.map((c) =>
        c.id === cropId ? { ...c, progress: 1.0, isReady: true } : c
      )
    );

    if (onSpeedUpCrop) onSpeedUpCrop(cropId);
  }, [onSpeedUpCrop]);

  return (
    <div className="absolute inset-0 pointer-events-none z-30">
      {crops.map((crop) => (
        <div
          key={crop.id}
          style={{
            position: 'absolute',
            left: `${crop.x}px`,
            top: `${crop.y}px`,
            width: `${crop.width}px`,
            height: `${crop.height}px`,
            zIndex: Math.round(crop.y + crop.height * 0.8),
          }}
          className={`interactive-target select-none ${
            isEditMode ? 'pointer-events-none' : 'pointer-events-auto'
          }`}
        >
          {/* Canvas Three.js ที่ปลอดภัย ไร้ Memory Leak */}
          <SingleCropCanvas
            progress={crop.progress}
            isReady={crop.isReady}
            width={crop.width}
            height={crop.height}
            onClick={(e) => handleHarvest(crop, e)}
          />

          {/* ป้ายแสดงสถานะบนหัวแปลง */}
          {!isEditMode && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 pointer-events-auto flex flex-col items-center z-40">
              {crop.isReady ? (
                <button
                  type="button"
                  onClick={(e) => handleHarvest(crop, e)}
                  className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 text-stone-900 px-3.5 py-1 rounded-full font-black text-xs shadow-2xl border-2 border-white animate-bounce flex items-center gap-1.5 cursor-pointer hover:scale-105 active:scale-95 transition-transform"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-700 animate-spin" />
                  <span>เก็บเกี่ยว {crop.icon}!</span>
                </button>
              ) : (
                <div className="flex items-center gap-1.5 bg-stone-900/90 backdrop-blur-xs px-2.5 py-0.5 rounded-full border border-amber-400/80 shadow-md">
                  <span className="text-[10px] font-mono font-bold text-yellow-300">
                    🌽 โต {Math.round(crop.progress * 100)}%
                  </span>
                  <button
                    type="button"
                    onClick={(e) => handleSpeedUp(crop.id, e)}
                    className="text-[9px] text-cyan-300 hover:text-white font-bold flex items-center gap-0.5 cursor-pointer"
                  >
                    <Zap className="w-2.5 h-2.5 text-cyan-400" /> 1💎
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

// ============================================================================
// 🌽 THREE.JS CANVASES & SHADERS (High-Performance Engine)
// ============================================================================
interface SingleCropCanvasProps {
  progress: number;
  isReady: boolean;
  width: number;
  height: number;
  onClick: (e: React.MouseEvent) => void;
}

const SingleCropCanvas: React.FC<SingleCropCanvasProps> = memo(({
  progress,
  isReady,
  width,
  height,
  onClick,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const plantsGroupRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene และ Isometric Camera
    const scene = new THREE.Scene();
    const aspect = width / height;
    const d = 85;
    const camera = new THREE.OrthographicCamera(
      -d * aspect,
      d * aspect,
      d,
      -d,
      1,
      1000
    );
    camera.position.set(130, 160, 130);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. แสงธรรมชาติ
    const hemiLight = new THREE.HemisphereLight(0xfff7ed, 0x4a7c29, 1.15);
    scene.add(hemiLight);

    const sun = new THREE.DirectionalLight(0xffeedd, 1.4);
    sun.position.set(80, 150, 70);
    sun.castShadow = true;
    sun.shadow.mapSize.width = 512;
    sun.shadow.mapSize.height = 512;
    scene.add(sun);

    // 3. ระนาบรับเงาโปร่งใส (Seamless Shadow)
    const shadowGeo = new THREE.PlaneGeometry(210, 140);
    const shadowMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    // 4. สันร่องดิน 3D ไถพรวน 3 ร่อง
    const ridgeMat = new THREE.MeshStandardMaterial({
      color: 0x3d200e,
      roughness: 0.95,
    });
    const ridgeGeo = new THREE.CylinderGeometry(4.2, 5.5, 165, 8);

    for (let r = -1; r <= 1; r++) {
      const ridge = new THREE.Mesh(ridgeGeo, ridgeMat);
      ridge.rotation.z = Math.PI / 2;
      ridge.position.set(0, 1.5, r * 35);
      ridge.receiveShadow = true;
      scene.add(ridge);
    }

    // 5. Shared Materials ป้องกัน Memory Leak
    const stalkMat = new THREE.MeshStandardMaterial({ color: 0x589b27, roughness: 0.55 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x6bb832, roughness: 0.45, side: THREE.DoubleSide });
    const earMat = new THREE.MeshStandardMaterial({ color: 0xfcc02a, roughness: 0.35 });
    const huskMat = new THREE.MeshStandardMaterial({ color: 0x7ebf38, roughness: 0.6 });
    const silkMat = new THREE.MeshStandardMaterial({ color: 0x8a3915, roughness: 0.8 });

    // 6. Geometry ต้นข้าวโพด
    const scale = Math.max(0.2, progress);
    const stalkGeo = new THREE.CylinderGeometry(0.85 * scale, 1.35 * scale, 34 * scale, 6);
    const leafGeo = new THREE.PlaneGeometry(4 * scale, 19 * scale, 1, 3);
    const earGeo = new THREE.ConeGeometry(2.2 * scale, 9.5 * scale, 8);
    const huskGeo = new THREE.CylinderGeometry(2.4 * scale, 2.5 * scale, 5.5 * scale, 6, 1, true);
    const silkGeo = new THREE.ConeGeometry(0.85 * scale, 2.8 * scale, 5);

    const plantsGroup = new THREE.Group();
    plantsGroupRef.current = plantsGroup;

    const rows = 3;
    const cols = 5;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const plant = new THREE.Group();

        // ลำต้น
        const stalk = new THREE.Mesh(stalkGeo, stalkMat);
        stalk.position.y = (34 * scale) / 2;
        stalk.castShadow = true;
        plant.add(stalk);

        // ใบข้าวโพด 6 ใบ
        for (let l = 0; l < 6; l++) {
          const leaf = new THREE.Mesh(leafGeo, leafMat);
          const angle = (l * Math.PI * 2) / 6;
          leaf.position.set(
            Math.sin(angle) * 1.5 * scale,
            (7 + l * 4) * scale,
            Math.cos(angle) * 1.5 * scale
          );
          leaf.rotation.x = 0.65;
          leaf.rotation.y = angle;
          leaf.castShadow = true;
          plant.add(leaf);
        }

        // ฝักข้าวโพด (ถ้า progress >= 0.6)
        if (progress >= 0.6) {
          const earGroup = new THREE.Group();
          const ear = new THREE.Mesh(earGeo, earMat);
          ear.position.y = 4.8 * scale;
          ear.castShadow = true;
          earGroup.add(ear);

          const husk = new THREE.Mesh(huskGeo, huskMat);
          husk.position.y = 2.6 * scale;
          earGroup.add(husk);

          const silk = new THREE.Mesh(silkGeo, silkMat);
          silk.position.y = 10.8 * scale;
          earGroup.add(silk);

          earGroup.position.set(2.2 * scale, 14 * scale, 0);
          earGroup.rotation.z = -0.55;
          plant.add(earGroup);
        }

        const posX = (c - (cols - 1) / 2) * 30 + Math.sin(c * 17 + r) * 3;
        const posZ = (r - 1) * 35 + Math.cos(r * 29 + c) * 3;
        plant.position.set(posX, 0, posZ);

        plantsGroup.add(plant);
      }
    }
    scene.add(plantsGroup);

    // 7. Loop ลมพัดไหว
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();

      if (plantsGroupRef.current) {
        plantsGroupRef.current.children.forEach((plant, idx) => {
          const wave = Math.sin(t * 2.2 + idx * 0.35);
          plant.rotation.z = wave * 0.04;
          plant.rotation.x = Math.cos(t * 1.8 + idx * 0.28) * 0.025;
        });
      }

      renderer.render(scene, camera);
    };
    animate();

    // 8. Cleanup หน่วยความจำอย่างถูกต้อง
    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      ridgeGeo.dispose();
      ridgeMat.dispose();
      stalkGeo.dispose();
      stalkMat.dispose();
      leafGeo.dispose();
      leafMat.dispose();
      earGeo.dispose();
      earMat.dispose();
      huskGeo.dispose();
      huskMat.dispose();
      silkGeo.dispose();
      silkMat.dispose();
      container.innerHTML = '';
    };
  }, [progress, width, height]);

  return (
    <div
      ref={mountRef}
      onClick={onClick}
      className="w-full h-full cursor-pointer hover:scale-[1.02] transition-transform duration-200"
    />
  );
});