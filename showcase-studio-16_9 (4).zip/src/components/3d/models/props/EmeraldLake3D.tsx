// src/components/3d/EmeraldLake3D.tsx
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface EmeraldLake3DProps {
  gameState: string;
  onBobberClick?: () => void;
  timeOfDay?: 'day' | 'twilight' | 'night';
}

export const EmeraldLake3D: React.FC<EmeraldLake3DProps> = ({
  gameState,
  onBobberClick,
  timeOfDay = 'day',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const bobberRef = useRef<THREE.Group | null>(null);
  const waterMeshRef = useRef<THREE.Mesh | null>(null);
  const lineMeshRef = useRef<THREE.Line | null>(null);
  const firefliesRef = useRef<THREE.Points | null>(null);
  const lanternLightRef = useRef<THREE.PointLight | null>(null);
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const hemiLightRef = useRef<THREE.HemisphereLight | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const skyColor = timeOfDay === 'night' ? 0x091428 : timeOfDay === 'twilight' ? 0xf97316 : 0xdcf4f8;
    scene.background = new THREE.Color(skyColor);
    scene.fog = new THREE.FogExp2(skyColor, 0.016);

    const width = Math.max(container.clientWidth || 800, 320);
    const height = Math.max(container.clientHeight || 600, 240);

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 1000);
    camera.position.set(24, 20, 28);
    camera.lookAt(0, 1, 0);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: false,
        powerPreference: 'high-performance',
      });
    } catch (err) {
      console.error('WebGL init error:', err);
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2.0));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // แสง
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x3d6e42, 0.75);
    scene.add(hemiLight);
    hemiLightRef.current = hemiLight;

    const sunLight = new THREE.DirectionalLight(0xfff7e6, 1.8);
    sunLight.position.set(30, 45, 20);
    sunLight.castShadow = true;
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // โคมไฟไม้ญี่ปุ่นริมสะพาน (Lantern PointLight)
    const lanternLight = new THREE.PointLight(0xfbbf24, 2.5, 18);
    lanternLight.position.set(-3.5, 2.8, 4.5);
    scene.add(lanternLight);
    lanternLightRef.current = lanternLight;

    // ฐานเกาะ
    const cliffMat = new THREE.MeshStandardMaterial({ color: 0x5c4a3b, roughness: 0.9 });
    const islandCliff = new THREE.Mesh(
      new THREE.CylinderGeometry(18, 18, 4, 32, 1, false, 0, Math.PI * 1.55),
      cliffMat
    );
    islandCliff.position.y = -1;
    scene.add(islandCliff);

    const grassMat = new THREE.MeshStandardMaterial({ color: 0x59982f, roughness: 0.8 });
    const hillMesh = new THREE.Mesh(
      new THREE.SphereGeometry(18, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.28),
      grassMat
    );
    hillMesh.rotation.x = Math.PI;
    hillMesh.position.y = 1;
    scene.add(hillMesh);

    // ผิวน้ำมรกต PBR
    const waterMat = new THREE.MeshPhysicalMaterial({
      color: 0x18a7b5,
      transmission: 0.82,
      transparent: true,
      roughness: 0.1,
      ior: 1.333,
      thickness: 4.0,
    });
    const waterMesh = new THREE.Mesh(new THREE.CylinderGeometry(9.5, 9.5, 3.8, 32), waterMat);
    waterMesh.position.set(0.5, 0.4, 1.5);
    scene.add(waterMesh);
    waterMeshRef.current = waterMesh;

    // ก้นบ่อ
    const bedMat = new THREE.MeshStandardMaterial({ color: 0x1b4347 });
    const lakeBed = new THREE.Mesh(new THREE.CylinderGeometry(9.2, 8.8, 0.5, 24), bedMat);
    lakeBed.position.set(0.5, -1.4, 1.5);
    scene.add(lakeBed);

    // 🪵 3D สะพานไม้เทียบเรือ (Wooden Dock)
    const dockGroup = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.7 });
    const woodPillarMat = new THREE.MeshStandardMaterial({ color: 0x5c3a21, roughness: 0.9 });

    // เสาสะพาน
    for (let px = -6; px <= -1; px += 2.5) {
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 2.8, 8), woodPillarMat);
      pillar.position.set(px, 0.2, 4.5);
      dockGroup.add(pillar);
    }
    // แผ่นไม้สะพาน
    for (let bx = -6.5; bx <= -0.5; bx += 0.55) {
      const plank = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.12, 2.2), woodMat);
      plank.position.set(bx, 1.5, 4.5);
      dockGroup.add(plank);
    }
    // 🏮 โคมไฟไม้ญี่ปุ่นบนสะพาน
    const lanternPole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.4, 8), woodPillarMat);
    lanternPole.position.set(-3.5, 2.2, 4.5);
    dockGroup.add(lanternPole);

    const lanternBox = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.5, 0.4),
      new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xf59e0b, emissiveIntensity: 0.6 })
    );
    lanternBox.position.set(-3.5, 2.8, 4.5);
    dockGroup.add(lanternBox);

    const lanternRoof = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.25, 4), woodPillarMat);
    lanternRoof.position.set(-3.5, 3.15, 4.5);
    lanternRoof.rotation.y = Math.PI * 0.25;
    dockGroup.add(lanternRoof);
    scene.add(dockGroup);

    // 🪷 3D ใบบัวลอยน้ำและดอกบัว (Lily Pads & Lotus)
    const lilyMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.6 });
    const lotusMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.3 });

    const lilyPadPositions = [
      { x: 3.5, z: 2.2, s: 0.8 },
      { x: 4.2, z: 1.5, s: 0.6 },
      { x: -1.2, z: -1.8, s: 0.9 },
      { x: 0.8, z: 4.8, s: 0.75 },
    ];
    lilyPadPositions.forEach((lp, idx) => {
      const pad = new THREE.Mesh(new THREE.CylinderGeometry(lp.s, lp.s, 0.04, 16), lilyMat);
      pad.position.set(lp.x, 0.44, lp.z);
      scene.add(pad);

      if (idx % 2 === 0) {
        const lotus = new THREE.Mesh(new THREE.ConeGeometry(lp.s * 0.35, 0.25, 8), lotusMat);
        lotus.position.set(lp.x, 0.54, lp.z);
        scene.add(lotus);
      }
    });

    // ✨ 3D หิ่งห้อยเรืองแสงยามค่ำคืน (Fireflies)
    const fireflyCount = 20;
    const fireflyGeo = new THREE.BufferGeometry();
    const fireflyPos = new Float32Array(fireflyCount * 3);
    for (let i = 0; i < fireflyCount; i++) {
      fireflyPos[i * 3] = (Math.random() - 0.5) * 14;
      fireflyPos[i * 3 + 1] = 0.8 + Math.random() * 2.5;
      fireflyPos[i * 3 + 2] = (Math.random() - 0.5) * 14;
    }
    fireflyGeo.setAttribute('position', new THREE.BufferAttribute(fireflyPos, 3));
    const fireflyMat = new THREE.PointsMaterial({
      color: 0xfef08a,
      size: 0.35,
      transparent: true,
      opacity: 0.85,
    });
    const fireflies = new THREE.Points(fireflyGeo, fireflyMat);
    scene.add(fireflies);
    firefliesRef.current = fireflies;

    // ฝูงปลา 3D
    const fishes: THREE.Group[] = [];
    const fishColors = [0xe85d04, 0xf48c06, 0x2ec4b6, 0xffd166];

    for (let i = 0; i < 7; i++) {
      const fish = new THREE.Group();
      const body = new THREE.Mesh(
        new THREE.ConeGeometry(0.2, 0.8, 6),
        new THREE.MeshStandardMaterial({ color: fishColors[i % fishColors.length] })
      );
      body.rotateZ(Math.PI * 0.5);
      fish.add(body);

      fish.userData = {
        radius: 2.2 + Math.random() * 5.0,
        angle: Math.random() * Math.PI * 2,
        speed: 0.009 + Math.random() * 0.01,
        yBase: -0.3 - Math.random() * 0.8,
      };
      scene.add(fish);
      fishes.push(fish);
    }

    // ทุ่นลอยน้ำ
    const bobber = new THREE.Group();
    const topSphere = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 12, 12, 0, Math.PI * 2, 0, Math.PI * 0.5),
      new THREE.MeshStandardMaterial({ color: 0xef233c })
    );
    const btmSphere = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 12, 12, 0, Math.PI * 2, Math.PI * 0.5, Math.PI * 0.5),
      new THREE.MeshStandardMaterial({ color: 0xffffff })
    );
    bobber.add(topSphere);
    bobber.add(btmSphere);
    bobber.position.set(1.5, 2.05, 2.2);
    bobber.visible = false;
    scene.add(bobber);
    bobberRef.current = bobber;

    // สายเบ็ด
    const lineMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 });
    const lineGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(-4, 3.8, 5),
      new THREE.Vector3(1.5, 2.05, 2.2),
    ]);
    const lineMesh = new THREE.Line(lineGeo, lineMat);
    lineMesh.visible = false;
    scene.add(lineMesh);
    lineMeshRef.current = lineMesh;

    // Loop แอนิเมชัน
    const clock = new THREE.Clock();
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      if (waterMeshRef.current) {
        waterMeshRef.current.position.y = 0.4 + Math.sin(elapsedTime * 1.5) * 0.04;
      }

      // ขยับหิ่งห้อย
      if (firefliesRef.current && firefliesRef.current.visible) {
        const positions = firefliesRef.current.geometry.attributes.position.array as Float32Array;
        for (let i = 0; i < fireflyCount; i++) {
          positions[i * 3 + 1] += Math.sin(elapsedTime * 3 + i) * 0.006;
          positions[i * 3] += Math.cos(elapsedTime * 1.5 + i) * 0.005;
        }
        firefliesRef.current.geometry.attributes.position.needsUpdate = true;
      }

      fishes.forEach((fish) => {
        const u = fish.userData;
        u.angle += u.speed;
        fish.position.x = 0.5 + Math.cos(u.angle) * u.radius;
        fish.position.z = 1.5 + Math.sin(u.angle) * u.radius;
        fish.position.y = u.yBase + Math.sin(elapsedTime * 2) * 0.08;
        fish.rotation.y = -u.angle - Math.PI * 0.5;
      });

      if (bobberRef.current && bobberRef.current.visible) {
        if (gameState === 'waiting') {
          bobberRef.current.position.y = 2.05 + Math.sin(elapsedTime * 3) * 0.05;
        } else if (gameState === 'nibbling') {
          bobberRef.current.position.y = 1.95 + Math.sin(elapsedTime * 12) * 0.12;
        } else if (gameState === 'hooked') {
          bobberRef.current.position.y = 1.6 + Math.sin(elapsedTime * 25) * 0.25;
        } else if (gameState === 'reeling') {
          bobberRef.current.position.y = 2.0 + Math.sin(elapsedTime * 18) * 0.15;
          bobberRef.current.position.x = 1.5 + Math.sin(elapsedTime * 5) * 0.6;
        }

        if (lineMeshRef.current) {
          const positions = lineMeshRef.current.geometry.attributes.position.array as Float32Array;
          positions[3] = bobberRef.current.position.x;
          positions[4] = bobberRef.current.position.y;
          positions[5] = bobberRef.current.position.z;
          lineMeshRef.current.geometry.attributes.position.needsUpdate = true;
        }
      }

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = Math.max(container.clientWidth || 800, 320);
      const h = Math.max(container.clientHeight || 600, 240);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh || obj instanceof THREE.Line || obj instanceof THREE.Points) {
          if (obj.geometry) obj.geometry.dispose();
          if (obj.material) {
            if (Array.isArray(obj.material)) {
              obj.material.forEach((m) => m.dispose());
            } else {
              obj.material.dispose();
            }
          }
        }
      });
      renderer.dispose();
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // อัปเดตแสงและบรรยากาศตามช่วงเวลา timeOfDay
  useEffect(() => {
    if (!sceneRef.current || !sunLightRef.current || !hemiLightRef.current || !lanternLightRef.current) return;

    if (timeOfDay === 'night') {
      const nightSky = 0x091428;
      sceneRef.current.background = new THREE.Color(nightSky);
      if (sceneRef.current.fog) sceneRef.current.fog.color.setHex(nightSky);
      sunLightRef.current.color.setHex(0x82b1ff); // แสงจันทร์
      sunLightRef.current.intensity = 0.9;
      hemiLightRef.current.color.setHex(0x1e3a8a);
      hemiLightRef.current.groundColor.setHex(0x07111e);
      hemiLightRef.current.intensity = 0.45;
      lanternLightRef.current.intensity = 3.5;
      if (firefliesRef.current) firefliesRef.current.visible = true;
    } else if (timeOfDay === 'twilight') {
      const twilightSky = 0xf97316;
      sceneRef.current.background = new THREE.Color(twilightSky);
      if (sceneRef.current.fog) sceneRef.current.fog.color.setHex(twilightSky);
      sunLightRef.current.color.setHex(0xffaa44);
      sunLightRef.current.intensity = 1.4;
      hemiLightRef.current.color.setHex(0xfde047);
      hemiLightRef.current.groundColor.setHex(0x78350f);
      hemiLightRef.current.intensity = 0.65;
      lanternLightRef.current.intensity = 2.0;
      if (firefliesRef.current) firefliesRef.current.visible = true;
    } else {
      const daySky = 0xdcf4f8;
      sceneRef.current.background = new THREE.Color(daySky);
      if (sceneRef.current.fog) sceneRef.current.fog.color.setHex(daySky);
      sunLightRef.current.color.setHex(0xfff7e6);
      sunLightRef.current.intensity = 1.8;
      hemiLightRef.current.color.setHex(0xffffff);
      hemiLightRef.current.groundColor.setHex(0x3d6e42);
      hemiLightRef.current.intensity = 0.75;
      lanternLightRef.current.intensity = 0.2;
      if (firefliesRef.current) firefliesRef.current.visible = false;
    }
  }, [timeOfDay]);

  useEffect(() => {
    if (!bobberRef.current || !lineMeshRef.current) return;
    const isVisible = gameState !== 'idle';
    bobberRef.current.visible = isVisible;
    lineMeshRef.current.visible = isVisible;
  }, [gameState]);

  return (
    <div
      ref={mountRef}
      onClick={onBobberClick}
      className="relative w-full h-full cursor-crosshair select-none"
    />
  );
};