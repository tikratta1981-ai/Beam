import React, { useEffect, useRef, memo } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';
import { Zap, Sparkles } from 'lucide-react';

export interface CornPlot3DProps {
  id?: string;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  progress?: number;       // 0.0 ถึง 1.0 (ระดับความเติบโต)
  isReady?: boolean;       // พร้อมเก็บเกี่ยวหรือไม่
  isWatered?: boolean;     // รดน้ำแล้วหรือยัง
  onHarvest?: (e: React.MouseEvent) => void;
  onSpeedUp?: () => void;
  isEditMode?: boolean;
}

export const CornPlot3D: React.FC<CornPlot3DProps> = memo(({
  id = 'corn_plot_main',
  x = 0,
  y = 0,
  width = 280,
  height = 190,
  progress = 1.0,
  isReady = true,
  isWatered = true,
  onHarvest,
  onSpeedUp,
  isEditMode = false,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. ฉากและกล้อง Isometric Orthographic
    const scene = new THREE.Scene();
    const aspect = width / height;
    const viewSize = 88;
    const camera = new THREE.OrthographicCamera(
      -viewSize * aspect,
      viewSize * aspect,
      viewSize,
      -viewSize,
      1,
      1000
    );

    camera.position.set(140, 175, 140);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. แสงบรรยากาศธรรมชาติ
    const hemiLight = new THREE.HemisphereLight(0xfff8ea, 0x4f8222, 1.25);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xffeed8, 1.5);
    sunLight.position.set(90, 160, 75);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 450;
    const d = 95;
    sunLight.shadow.camera.left = -d;
    sunLight.shadow.camera.right = d;
    sunLight.shadow.camera.top = d;
    sunLight.shadow.camera.bottom = -d;
    sunLight.shadow.bias = -0.0008;
    scene.add(sunLight);

    // 3. ระนาบรับเงาโปร่งใส กลืนกับพื้นหลังเดิม 100%
    const shadowGeo = new THREE.PlaneGeometry(210, 145);
    const shadowMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.05;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    // สันร่องดินไถพรวน 3D
    const soilColor = isWatered ? 0x3d200e : 0x5a3318;
    const ridgeMat = new THREE.MeshStandardMaterial({
      color: soilColor,
      roughness: 0.95,
      metalness: 0.05,
    });

    const ridgesGroup = new THREE.Group();
    for (let r = -1; r <= 1; r++) {
      const ridgeGeo = new THREE.CylinderGeometry(4.2, 5.8, 168, 8);
      const ridge = new THREE.Mesh(ridgeGeo, ridgeMat);
      ridge.rotation.z = Math.PI / 2;
      ridge.position.set(0, 1.6, r * 36);
      ridge.receiveShadow = true;
      ridgesGroup.add(ridge);
    }
    scene.add(ridgesGroup);

    // 4. วัสดุสำหรับต้นข้าวโพด
    const currentScale = Math.max(0.18, Math.min(1.0, progress));

    const stalkMat = new THREE.MeshStandardMaterial({
      color: 0x56962a,
      roughness: 0.55,
    });

    const leafMat = new THREE.MeshStandardMaterial({
      color: 0x6db932,
      roughness: 0.45,
      side: THREE.DoubleSide,
    });

    const kernelMat = new THREE.MeshStandardMaterial({
      color: isReady ? 0xffbf1a : 0xe5a914,
      roughness: 0.32,
      metalness: 0.08,
    });

    const huskMat = new THREE.MeshStandardMaterial({
      color: 0x7ebf38,
      roughness: 0.62,
    });

    const silkMat = new THREE.MeshStandardMaterial({
      color: 0x8a3915,
      roughness: 0.8,
    });

    const tasselMat = new THREE.MeshStandardMaterial({
      color: 0xdbb437,
      roughness: 0.6,
    });

    // ฟังก์ชันสร้างต้นข้าวโพด 1 ต้น
    const createCornStalk = (posX: number, posZ: number, seed: number) => {
      const stalkGroup = new THREE.Group();
      const plantHeight = 36 * currentScale;

      // ลำต้นปล้องข้อ
      const stalkGeo = new THREE.CylinderGeometry(
        0.85 * currentScale,
        1.35 * currentScale,
        plantHeight,
        6
      );
      const stalkMesh = new THREE.Mesh(stalkGeo, stalkMat);
      stalkMesh.position.y = plantHeight / 2;
      stalkMesh.castShadow = true;
      stalkMesh.receiveShadow = true;
      stalkGroup.add(stalkMesh);

      // เกสรตัวผู้บนยอด (Tassel on Top เมื่อโต >= 65%)
      if (progress >= 0.65) {
        const tasselGeo = new THREE.ConeGeometry(1.5 * currentScale, 6.5 * currentScale, 5);
        const tasselMesh = new THREE.Mesh(tasselGeo, tasselMat);
        tasselMesh.position.y = plantHeight + 2.5 * currentScale;
        tasselMesh.castShadow = true;
        stalkGroup.add(tasselMesh);
      }

      // ใบเรียวยาวโค้งทอดตัวลง
      const leafCount = 6;
      for (let i = 0; i < leafCount; i++) {
        const leafGeo = new THREE.PlaneGeometry(4.0 * currentScale, 20 * currentScale, 1, 3);
        const leafMesh = new THREE.Mesh(leafGeo, leafMat);

        const angle = (i * Math.PI * 2) / leafCount + seed;
        const leafY = (7 + i * 4.2) * currentScale;

        leafMesh.position.set(
          Math.sin(angle) * 1.5 * currentScale,
          leafY,
          Math.cos(angle) * 1.5 * currentScale
        );
        leafMesh.rotation.x = 0.66;
        leafMesh.rotation.y = angle;
        leafMesh.castShadow = true;
        stalkGroup.add(leafMesh);
      }

      // ฝักข้าวโพดสีทอง (เมื่อโต >= 50%)
      if (progress >= 0.5) {
        const earGroup = new THREE.Group();

        // 1. ฝักเมล็ดข้าวโพด
        const earGeo = new THREE.ConeGeometry(2.3 * currentScale, 10 * currentScale, 8);
        const earMesh = new THREE.Mesh(earGeo, kernelMat);
        earMesh.position.y = 5 * currentScale;
        earMesh.castShadow = true;
        earGroup.add(earMesh);

        // 2. กาบห่อหุ้มโคนฝัก
        const huskGeo = new THREE.CylinderGeometry(
          2.5 * currentScale,
          2.6 * currentScale,
          5.5 * currentScale,
          6,
          1,
          true
        );
        const huskMesh = new THREE.Mesh(huskGeo, huskMat);
        huskMesh.position.y = 2.8 * currentScale;
        earGroup.add(huskMesh);

        // 3. เส้นไหมข้าวโพดสีน้ำตาลทองแดง
        const silkGeo = new THREE.ConeGeometry(0.85 * currentScale, 3.0 * currentScale, 5);
        const silkMesh = new THREE.Mesh(silkGeo, silkMat);
        silkMesh.position.y = 11.2 * currentScale;
        earGroup.add(silkMesh);

        // จัดมุมเอียงของฝักให้ยื่นออกจากซอกใบ 33 องศา
        earGroup.position.set(2.3 * currentScale, 15 * currentScale, 0);
        earGroup.rotation.z = -0.58;
        earGroup.rotation.y = seed > 0 ? 0.35 : -0.35;
        stalkGroup.add(earGroup);
      }

      stalkGroup.position.set(posX, 0, posZ);
      return stalkGroup;
    };

    // 5. ปลูก 3 แถว x 5 คอลัมน์ (รวม 15 ต้น)
    const fieldGroup = new THREE.Group();
    const rows = 3;
    const cols = 5;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const posX = (c - (cols - 1) / 2) * 32;
        const posZ = (r - 1) * 36;

        const jitterX = Math.sin(c * 17.1 + r) * 3.2;
        const jitterZ = Math.cos(r * 29.3 + c) * 3.2;
        const seedAngle = c * 1.3 + r * 2.1;

        fieldGroup.add(createCornStalk(posX + jitterX, posZ + jitterZ, seedAngle));
      }
    }
    scene.add(fieldGroup);

    // 6. แอนิเมชันลมพัดพลิ้วไหว
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();

      fieldGroup.children.forEach((stalk, index) => {
        const sway = Math.sin(t * 2.3 + index * 0.38);
        stalk.rotation.z = sway * 0.042;
        stalk.rotation.x = Math.cos(t * 1.8 + index * 0.32) * 0.028;
      });

      renderer.render(scene, camera);
    };
    animate();

    // 7. Cleanup
    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      ridgeMat.dispose();
      stalkMat.dispose();
      leafMat.dispose();
      kernelMat.dispose();
      huskMat.dispose();
      silkMat.dispose();
      tasselMat.dispose();
      container.innerHTML = '';
    };
  }, [width, height, progress, isReady, isWatered]);

  const handlePlotClick = (e: React.MouseEvent) => {
    if (isEditMode) return;
    e.stopPropagation();

    if (isReady && onHarvest) {
      try {
        sound.playHarvest();
      } catch {}
      onHarvest(e);
    }
  };

  return (
    <div
      style={{
        position: x !== 0 || y !== 0 ? 'absolute' : 'relative',
        left: x !== 0 ? `${x}px` : undefined,
        top: y !== 0 ? `${y}px` : undefined,
        width: `${width}px`,
        height: `${height}px`,
      }}
      className="select-none pointer-events-auto cursor-pointer group"
      onClick={handlePlotClick}
    >
      <div
        ref={mountRef}
        className="w-full h-full transition-transform duration-200 group-hover:scale-[1.02]"
      />

      {/* Floating Status UI */}
      {!isEditMode && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 pointer-events-auto flex flex-col items-center z-40">
          {isReady ? (
            <button
              type="button"
              onClick={handlePlotClick}
              className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 text-stone-900 px-3.5 py-1 rounded-full font-black text-xs shadow-2xl border-2 border-white animate-bounce flex items-center gap-1.5 cursor-pointer hover:scale-110 active:scale-95 transition-transform"
            >
              <Sparkles className="w-4 h-4 text-amber-700 animate-spin" />
              <span>เก็บเกี่ยวข้าวโพด 🌽</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 bg-stone-900/90 backdrop-blur-xs px-2.5 py-0.5 rounded-full border border-amber-400/80 shadow-md">
              <span className="text-[10px] font-mono font-bold text-yellow-300">
                🌽 โต {Math.round(progress * 100)}%
              </span>
              {onSpeedUp && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    sound.playSuccessChime();
                    onSpeedUp();
                  }}
                  className="text-[9px] text-cyan-300 hover:text-white font-bold flex items-center gap-0.5 cursor-pointer transition-colors"
                  title="เร่งโตด้วย 1 เพชร"
                >
                  <Zap className="w-2.5 h-2.5 text-cyan-400" /> 1💎
                </button>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
});