import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Plot } from '../../../../types/game';
import { CROPS } from '../../../../data/initialData';
import { Plus, Zap } from 'lucide-react';
import { setupRealisticLighting, getSoilPBRTexture, getWoodPBRTexture } from '../../../../utils/three/threeTextures';

export interface Plot3DProps {
  plot: Plot;
  onClick: () => void;
  onSpeedUp?: () => void;
  timeRemainingText?: string;
  isEditMode?: boolean;
}

export const Plot3D: React.FC<Plot3DProps> = ({
  plot,
  onClick,
  onSpeedUp,
  timeRemainingText,
  isEditMode = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 128;
    const height = container.clientHeight || 128;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 5.0);
    camera.lookAt(0, 0.3, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    setupRealisticLighting(scene, renderer);

    // ดินแปลงเกษตร 3D (Raised Soil Bed with Furrows)
    const soilMat = track(new THREE.MeshStandardMaterial({ map: getSoilPBRTexture(), color: 0x543216, roughness: 0.95 }));
    const woodBorderMat = track(new THREE.MeshStandardMaterial({ map: getWoodPBRTexture(), color: 0x854d0e, roughness: 0.85 }));

    // ขอบไม้ล้อมรอบแปลง
    const borderGeoX = track(new THREE.BoxGeometry(1.5, 0.18, 0.08));
    const borderGeoZ = track(new THREE.BoxGeometry(0.08, 0.18, 1.5));

    const bTop = new THREE.Mesh(borderGeoX, woodBorderMat);
    bTop.position.set(0, 0.09, -0.71);
    scene.add(bTop);

    const bBot = new THREE.Mesh(borderGeoX, woodBorderMat);
    bBot.position.set(0, 0.09, 0.71);
    scene.add(bBot);

    const bLeft = new THREE.Mesh(borderGeoZ, woodBorderMat);
    bLeft.position.set(-0.71, 0.09, 0);
    scene.add(bLeft);

    const bRight = new THREE.Mesh(borderGeoZ, woodBorderMat);
    bRight.position.set(0.71, 0.09, 0);
    scene.add(bRight);

    // ดินนูนเป็นร่อง 3 ร่อง
    for (let r = -0.4; r <= 0.4; r += 0.4) {
      const furrow = new THREE.Mesh(track(new THREE.BoxGeometry(1.3, 0.14, 0.28)), soilMat);
      furrow.position.set(0, 0.07, r);
      furrow.castShadow = true;
      furrow.receiveShadow = true;
      scene.add(furrow);
    }

    // พืชผล 3D (Crops Geometry)
    const cropsGroup = new THREE.Group();
    cropsGroup.position.y = 0.14;

    if (plot.cropId) {
      const isReady = plot.isReady;
      const cropColor =
        plot.cropId === 'corn'
          ? 0xeab308
          : plot.cropId === 'tomato'
          ? 0xef4444
          : plot.cropId === 'lavender'
          ? 0xa855f7
          : plot.cropId === 'cucumber'
          ? 0x22c55e
          : 0xf59e0b; // wheat / carrot

      const cropStemMat = track(new THREE.MeshStandardMaterial({ color: isReady ? cropColor : 0x4ade80, roughness: 0.6 }));
      const cropFruitMat = track(new THREE.MeshStandardMaterial({ color: cropColor, roughness: 0.4 }));

      // สร้างแถวพืชผล 3x3 กอ
      for (let x = -0.4; x <= 0.4; x += 0.4) {
        for (let z = -0.4; z <= 0.4; z += 0.4) {
          const plant = new THREE.Group();
          plant.position.set(x, 0, z);

          if (!isReady) {
            // ต้นอ่อนกำลังโต (Sprout)
            const sprout = new THREE.Mesh(track(new THREE.ConeGeometry(0.06, 0.22, 5)), cropStemMat);
            sprout.position.y = 0.11;
            plant.add(sprout);
          } else {
            // พืชโตเต็มวัย พร้อมเก็บเกี่ยว (Full Crop)
            const stem = new THREE.Mesh(track(new THREE.CylinderGeometry(0.02, 0.025, 0.42, 6)), cropStemMat);
            stem.position.y = 0.21;
            stem.castShadow = true;
            plant.add(stem);

            const fruit = new THREE.Mesh(track(new THREE.SphereGeometry(0.08, 8, 6)), cropFruitMat);
            fruit.position.y = 0.4;
            fruit.castShadow = true;
            plant.add(fruit);
          }
          cropsGroup.add(plant);
        }
      }
    }
    scene.add(cropsGroup);

    let animId: number;

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);

      // ต้นพืชพริ้วไหวเบาๆ
      if (plot.cropId) {
        cropsGroup.children.forEach((plant, idx) => {
          plant.rotation.z = Math.sin(time * 0.003 + idx) * 0.08;
          if (plot.isReady) {
            plant.position.y = Math.sin(time * 0.005 + idx) * 0.02;
          }
        });
      }

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, [plot.cropId, plot.isReady]);

  return (
    <div
      ref={containerRef}
      onClick={(e) => {
        if (isEditMode) return;
        e.stopPropagation();
        onClick();
      }}
      className="relative w-full h-full select-none cursor-pointer flex flex-col items-center justify-center group"
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />

      {/* Floating Status Badge */}
      {plot.cropId ? (
        plot.isReady ? (
          <div className="absolute -top-3 z-30 bg-white/95 rounded-full px-2.5 py-1 shadow-2xl border-2 border-amber-400 animate-bounce flex items-center gap-1">
            <span className="text-base">{CROPS[plot.cropId]?.icon || '🌾'}</span>
            <span className="text-[10px] font-black text-emerald-600 whitespace-nowrap">เก็บเกี่ยว!</span>
          </div>
        ) : (
          <div className="absolute -top-3 z-30 flex flex-col items-center bg-stone-900/90 px-2 py-0.5 rounded-full border border-amber-500 shadow-md">
            <span className="text-[9px] font-mono text-yellow-300 font-bold whitespace-nowrap">
              {timeRemainingText || 'กำลังโต...'}
            </span>
            {onSpeedUp && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSpeedUp();
                }}
                className="text-[8px] text-cyan-300 hover:text-white font-bold flex items-center gap-0.5 mt-0.5"
              >
                <Zap className="w-2.5 h-2.5" /> 1💎
              </button>
            )}
          </div>
        )
      ) : (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center bg-black/60 px-2.5 py-1 rounded-xl border border-dashed border-amber-400 text-amber-200">
          <Plus className="w-4 h-4 text-amber-300" />
          <span className="text-[9px] font-bold">ปลูกพืช</span>
        </div>
      )}
    </div>
  );
};
