// src/components/3d/FarmCharacters3D.tsx
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { sound } from '../../../../utils/audio/index';
import {
  getFabricDenimTexture,
  getFabricPlaidTexture,
  getStrawHatTexture,
  getLeatherBootTexture,
} from '../../../../utils/three/threeTextures';
import { Sparkles, Heart } from 'lucide-react';

interface Waypoint {
  x: number;
  z: number;
  action?: 'idle' | 'water' | 'inspect' | 'rest' | 'work' | 'dig' | 'till' | 'fish' | 'watch_fish' | 'feed_fish' | 'inspect_dock' | 'carry' | 'walk';
  actionDuration?: number;
}

type CharacterType = 'emma' | 'lily' | 'daisy' | 'bob' | 'somchai' | 'fisher_girl' | 'dock_worker';

interface CharacterInstance {
  id: string;
  name: string;
  role: string;
  avatar: string;
  type: CharacterType;
  group: THREE.Group;
  head: THREE.Group;
  hat?: THREE.Group;
  torso: THREE.Mesh;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  prop?: THREE.Group;
  waterDroplets?: THREE.Points;
  soilParticles?: THREE.Points;
  waterRippleMesh?: THREE.Mesh;
  feedParticlesMesh?: THREE.Points;
  shadowMesh: THREE.Mesh;
  waypoints: Waypoint[];
  currentWaypointIndex: number;
  pos: THREE.Vector3;
  targetPos: THREE.Vector3;
  speed: number;
  rotationY: number;
  walkCycle: number;
  state: 'walking' | 'idle' | 'acting' | 'waving';
  stateTimer: number;
  quotes: string[];
}

interface CharacterScreenPos {
  id: string;
  name: string;
  role: string;
  avatar: string;
  screenX: number;
  screenY: number;
}

interface FarmCharacters3DProps {
  isEditMode?: boolean;
  onCharacterClick?: (character: { name: string; role: string; quote: string }) => void;
  onOpenFishing?: () => void;
  inventory?: Record<string, any>;
  onFeedCatFish?: () => void;
  className?: string;
}

const WIDTH = 1440;
const HEIGHT = 960;

export const FarmCharacters3D: React.FC<FarmCharacters3DProps> = ({
  isEditMode = false,
  onCharacterClick,
  onOpenFishing,
  inventory = {},
  onFeedCatFish,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const charactersRef = useRef<CharacterInstance[]>([]);
  const [characterScreenPositions, setCharacterScreenPositions] = useState<CharacterScreenPos[]>([]);

  const [activeSpeech, setActiveSpeech] = useState<{
    id: string;
    name: string;
    avatar: string;
    text: string;
    screenX: number;
    screenY: number;
  } | null>(null);

  const [floatingHeart, setFloatingHeart] = useState<{
    id: number;
    x: number;
    y: number;
  } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const disposables: (THREE.BufferGeometry | THREE.Material)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material>(res: T): T => {
      disposables.push(res);
      return res;
    };

    // 1. Scene & Isometric Camera setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, WIDTH / HEIGHT, 0.1, 100);
    camera.position.set(0, 10.5, 13.5);
    camera.lookAt(0, 0, 0);
    camera.updateMatrixWorld();

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(WIDTH, HEIGHT);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // 2. แสงบรรยากาศธรรมชาติ
    const hemiLight = new THREE.HemisphereLight(0xfff7ed, 0x4d8c28, 0.95);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfffae0, 1.4);
    sunLight.position.set(6, 12, 8);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(1024, 1024);
    sunLight.shadow.bias = -0.0008;
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0xfef08a, 0.4);
    rimLight.position.set(-6, 8, -6);
    scene.add(rimLight);

    // 3. ฟังก์ชันแปลงพิกัดพิกเซลบนแผนที่ (1440 x 960) เป็นพิกัด 3D บนระนาบ y=0
    const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const raycaster = new THREE.Raycaster();

    const pxToWorld3D = (pxX: number, pxY: number): THREE.Vector3 => {
      const ndcX = (pxX / WIDTH) * 2 - 1;
      const ndcY = -(pxY / HEIGHT) * 2 + 1;
      raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), camera);
      const target = new THREE.Vector3();
      raycaster.ray.intersectPlane(groundPlane, target);
      return target || new THREE.Vector3(0, 0, 0);
    };

    // 4. Textures & Materials
    const denimTex = getFabricDenimTexture();
    const plaidRedTex = getFabricPlaidTexture('#dc2626', '#facc15');
    const plaidBlueTex = getFabricPlaidTexture('#0284c7', '#38bdf8');
    const plaidAmberTex = getFabricPlaidTexture('#d97706', '#fef08a');
    const strawHatTex = getStrawHatTexture();
    const leatherTex = getLeatherBootTexture();

    const skinMat = track(new THREE.MeshStandardMaterial({
      color: 0xfbd0b0,
      roughness: 0.6,
      metalness: 0.05,
    }));
    const skinTanMat = track(new THREE.MeshStandardMaterial({
      color: 0xedb382,
      roughness: 0.65,
    }));
    const hairBlondeMat = track(new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.7,
    }));
    const hairBrownMat = track(new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.75,
    }));
    const hairAuburnMat = track(new THREE.MeshStandardMaterial({
      color: 0x7c2d12,
      roughness: 0.75,
    }));
    const hairDarkMat = track(new THREE.MeshStandardMaterial({
      color: 0x1c1917,
      roughness: 0.8,
    }));

    const denimMat = track(new THREE.MeshStandardMaterial({ map: denimTex, roughness: 0.8 }));
    const plaidRedMat = track(new THREE.MeshStandardMaterial({ map: plaidRedTex, roughness: 0.75 }));
    const plaidBlueMat = track(new THREE.MeshStandardMaterial({ map: plaidBlueTex, roughness: 0.75 }));
    const plaidAmberMat = track(new THREE.MeshStandardMaterial({ map: plaidAmberTex, roughness: 0.75 }));
    const pinkClothMat = track(new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.7 }));
    const strawHatMat = track(new THREE.MeshStandardMaterial({ map: strawHatTex, roughness: 0.7 }));
    const leatherMat = track(new THREE.MeshStandardMaterial({ map: leatherTex, roughness: 0.5 }));

    const shadowMat = track(new THREE.MeshBasicMaterial({
      color: 0x12260c,
      transparent: true,
      opacity: 0.42,
    }));

    // ละอองน้ำ
    const dropletGeo = track(new THREE.BufferGeometry());
    const dropletCount = 18;
    const dropletPos = new Float32Array(dropletCount * 3);
    for (let i = 0; i < dropletCount; i++) {
      dropletPos[i * 3] = (Math.random() - 0.5) * 0.15;
      dropletPos[i * 3 + 1] = -Math.random() * 0.3;
      dropletPos[i * 3 + 2] = (Math.random() - 0.5) * 0.15;
    }
    dropletGeo.setAttribute('position', new THREE.BufferAttribute(dropletPos, 3));
    const dropletMat = track(new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.035,
      transparent: true,
      opacity: 0.75,
    }));

    // Particle สะเก็ดดินกระเด็นตอนขุด/พรวน
    const soilParticleGeo = track(new THREE.BufferGeometry());
    const soilCount = 24;
    const soilPositions = new Float32Array(soilCount * 3);
    for (let i = 0; i < soilCount; i++) {
      soilPositions[i * 3] = (Math.random() - 0.5) * 0.28;
      soilPositions[i * 3 + 1] = Math.random() * 0.18;
      soilPositions[i * 3 + 2] = (Math.random() - 0.5) * 0.28;
    }
    soilParticleGeo.setAttribute('position', new THREE.BufferAttribute(soilPositions, 3));
    const soilParticleMat = track(new THREE.PointsMaterial({
      color: 0x5c3317,
      size: 0.04,
      transparent: true,
      opacity: 0.85,
    }));

    // ระลอกคลื่นน้ำตอนตกปลาและให้อาหารปลาในบ่อ
    const rippleGeo = track(new THREE.RingGeometry(0.08, 0.14, 20));
    rippleGeo.rotateX(-Math.PI / 2);
    const rippleMat = track(new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.75,
      side: THREE.DoubleSide,
    }));

    // เม็ดอาหารปลาตอนคนงานโปรยอาหาร
    const feedParticleGeo = track(new THREE.BufferGeometry());
    const feedCount = 18;
    const feedPositions = new Float32Array(feedCount * 3);
    for (let i = 0; i < feedCount; i++) {
      feedPositions[i * 3] = (Math.random() - 0.5) * 0.3;
      feedPositions[i * 3 + 1] = -Math.random() * 0.2;
      feedPositions[i * 3 + 2] = (Math.random() - 0.5) * 0.3;
    }
    feedParticleGeo.setAttribute('position', new THREE.BufferAttribute(feedPositions, 3));
    const feedParticleMat = track(new THREE.PointsMaterial({
      color: 0xd97706,
      size: 0.038,
      transparent: true,
      opacity: 0.9,
    }));

    // เสื้อผ้าเฉพาะทาง
    const cyanSailorMat = track(new THREE.MeshStandardMaterial({ color: 0x06b6d4, roughness: 0.65 }));
    const navyWorkerMat = track(new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.75 }));

    // 5. ฟังก์ชันสร้างโมเดลตัวละคร 3D (ปรับสเกลให้เล็กลงน่ารัก สมส่วน)
    const createCharacter = (
      id: string,
      name: string,
      role: string,
      avatar: string,
      type: CharacterType,
      waypointsPx: { x: number; y: number; action?: 'idle' | 'water' | 'inspect' | 'rest' | 'work' | 'dig' | 'till' | 'fish' | 'watch_fish' | 'feed_fish' | 'inspect_dock' | 'carry' | 'walk'; actionDuration?: number }[],
      quotes: string[]
    ): CharacterInstance => {
      const group = new THREE.Group();
      const isFemale = type === 'emma' || type === 'lily' || type === 'daisy' || type === 'fisher_girl';

      // 🌟 ปรับขนาดโมเดลให้เล็กลงกะทัดรัด สไตล์ Chibi Isometric สวยงาม
      const scale = isFemale ? 0.46 : 0.52;
      const currentSkin = (type === 'somchai' || type === 'dock_worker') ? skinTanMat : skinMat;

      // เงาสัมผัสดิน (ปรับให้พอดีกับเท้า)
      const shadowGeo = track(new THREE.CircleGeometry(0.26, 16));
      shadowGeo.scale(1.0, 0.6, 1.0);
      const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
      shadowMesh.rotation.x = -Math.PI / 2;
      shadowMesh.position.y = 0.01;
      group.add(shadowMesh);

      // วงระลอกคลื่นน้ำ (สำหรับกิจกรรมตกปลา/ริมน้ำ)
      const waterRippleMesh = new THREE.Mesh(rippleGeo, rippleMat);
      waterRippleMesh.position.set(0, 0.02, 0.45);
      waterRippleMesh.visible = false;
      group.add(waterRippleMesh);

      // เม็ดอาหารปลา
      const feedParticlesMesh = new THREE.Points(feedParticleGeo, feedParticleMat);
      feedParticlesMesh.position.set(0, 0.25, 0.5);
      feedParticlesMesh.visible = false;
      group.add(feedParticlesMesh);

      // ลำตัว (Torso)
      const torsoW = isFemale ? 0.36 : 0.44;
      const torsoH = 0.46;
      const torsoD = isFemale ? 0.22 : 0.26;
      const torsoGeo = track(new THREE.BoxGeometry(torsoW, torsoH, torsoD));

      let torsoMat: THREE.Material = plaidRedMat;
      if (type === 'bob') torsoMat = plaidBlueMat;
      if (type === 'somchai') torsoMat = plaidAmberMat;
      if (type === 'daisy') torsoMat = pinkClothMat;
      if (type === 'fisher_girl') torsoMat = cyanSailorMat;
      if (type === 'dock_worker') torsoMat = navyWorkerMat;

      const torso = new THREE.Mesh(torsoGeo, torsoMat);
      torso.position.y = 0.76;
      torso.castShadow = true;
      group.add(torso);

      // เอี๊ยมยีนส์ทับเสื้อ
      const bibGeo = track(new THREE.BoxGeometry(torsoW * 0.9, torsoH * 0.75, torsoD * 1.06));
      const bib = new THREE.Mesh(bibGeo, denimMat);
      bib.position.set(0, -0.06, 0);
      torso.add(bib);

      // กระดุมทองเหลือง
      const buttonGeo = track(new THREE.SphereGeometry(0.02, 6, 6));
      const buttonMat = track(new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.85, roughness: 0.3 }));
      const btnL = new THREE.Mesh(buttonGeo, buttonMat);
      btnL.position.set(torsoW * 0.25, 0.12, torsoD * 0.54);
      torso.add(btnL);
      const btnR = new THREE.Mesh(buttonGeo, buttonMat);
      btnR.position.set(-torsoW * 0.25, 0.12, torsoD * 0.54);
      torso.add(btnR);

      // ศีรษะ (Head)
      const head = new THREE.Group();
      head.position.set(0, 1.14, 0);

      const headGeo = track(new THREE.SphereGeometry(0.2, 12, 10));
      headGeo.scale(0.92, 1.0, 0.95);
      const headMesh = new THREE.Mesh(headGeo, currentSkin);
      headMesh.castShadow = true;
      head.add(headMesh);

      // ดวงตา
      const eyeMat = track(new THREE.MeshBasicMaterial({ color: 0x1e293b }));
      const eyeGeo = track(new THREE.SphereGeometry(0.03, 6, 6));
      const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
      leftEye.position.set(0.07, 0.02, 0.18);
      head.add(leftEye);
      const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
      rightEye.position.set(-0.07, 0.02, 0.18);
      head.add(rightEye);

      // แก้มชมพู
      const blushMat = track(new THREE.MeshBasicMaterial({ color: 0xf43f5e, transparent: true, opacity: 0.5 }));
      const blushGeo = track(new THREE.CircleGeometry(0.035, 8));
      const blushL = new THREE.Mesh(blushGeo, blushMat);
      blushL.position.set(0.12, -0.03, 0.16);
      blushL.rotation.y = 0.4;
      head.add(blushL);
      const blushR = new THREE.Mesh(blushGeo, blushMat);
      blushR.position.set(-0.12, -0.03, 0.16);
      blushR.rotation.y = -0.4;
      head.add(blushR);

      // รอยยิ้ม
      const smileGeo = track(new THREE.TorusGeometry(0.04, 0.008, 4, 8, Math.PI));
      const smileMat = track(new THREE.MeshBasicMaterial({ color: 0xb91c1c }));
      const smile = new THREE.Mesh(smileGeo, smileMat);
      smile.rotation.x = Math.PI;
      smile.position.set(0, -0.06, 0.185);
      head.add(smile);

      // ทรงผม
      const hairGeo = track(new THREE.SphereGeometry(0.21, 10, 8));
      if (type === 'emma') {
        const hairTop = new THREE.Mesh(hairGeo, hairBlondeMat);
        hairTop.position.set(0, 0.04, -0.02);
        head.add(hairTop);

        const braidGeo = track(new THREE.CylinderGeometry(0.035, 0.02, 0.28, 6));
        const braidL = new THREE.Mesh(braidGeo, hairBlondeMat);
        braidL.position.set(0.18, -0.16, -0.05);
        braidL.rotation.z = -0.25;
        head.add(braidL);

        const braidR = new THREE.Mesh(braidGeo, hairBlondeMat);
        braidR.position.set(-0.18, -0.16, -0.05);
        braidR.rotation.z = 0.25;
        head.add(braidR);
      } else if (type === 'lily') {
        const hairTop = new THREE.Mesh(hairGeo, hairAuburnMat);
        hairTop.position.set(0, 0.04, -0.02);
        head.add(hairTop);

        const ponytailGeo = track(new THREE.CylinderGeometry(0.04, 0.02, 0.22, 6));
        const ponytail = new THREE.Mesh(ponytailGeo, hairAuburnMat);
        ponytail.position.set(0, -0.1, -0.18);
        ponytail.rotation.x = 0.5;
        head.add(ponytail);
      } else if (type === 'daisy') {
        const hairTop = new THREE.Mesh(hairGeo, hairBrownMat);
        hairTop.position.set(0, 0.04, -0.02);
        head.add(hairTop);

        const sideHairL = new THREE.Mesh(track(new THREE.CylinderGeometry(0.04, 0.03, 0.18, 6)), hairBrownMat);
        sideHairL.position.set(0.16, -0.1, 0.05);
        head.add(sideHairL);
        const sideHairR = new THREE.Mesh(track(new THREE.CylinderGeometry(0.04, 0.03, 0.18, 6)), hairBrownMat);
        sideHairR.position.set(-0.16, -0.1, 0.05);
        head.add(sideHairR);
      } else if (type === 'fisher_girl') {
        const hairTop = new THREE.Mesh(hairGeo, hairAuburnMat);
        hairTop.position.set(0, 0.04, -0.02);
        head.add(hairTop);

        const ponyGeo = track(new THREE.CylinderGeometry(0.04, 0.022, 0.26, 6));
        const ponyL = new THREE.Mesh(ponyGeo, hairAuburnMat);
        ponyL.position.set(0.18, -0.14, -0.06);
        ponyL.rotation.z = -0.3;
        ponyL.rotation.x = 0.25;
        head.add(ponyL);

        const ponyR = new THREE.Mesh(ponyGeo, hairAuburnMat);
        ponyR.position.set(-0.18, -0.14, -0.06);
        ponyR.rotation.z = 0.3;
        ponyR.rotation.x = 0.25;
        head.add(ponyR);

        // ดอกไม้ประดับผม
        const flowerMat = track(new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.5 }));
        const flower = new THREE.Mesh(track(new THREE.SphereGeometry(0.04, 6, 6)), flowerMat);
        flower.position.set(0.16, 0.06, 0.14);
        head.add(flower);
      } else if (type === 'dock_worker') {
        const hairMesh = new THREE.Mesh(hairGeo, hairDarkMat);
        hairMesh.position.set(0, 0.04, -0.03);
        head.add(hairMesh);
      } else if (type === 'bob') {
        const hairMesh = new THREE.Mesh(hairGeo, hairBrownMat);
        hairMesh.position.set(0, 0.04, -0.03);
        head.add(hairMesh);
      } else {
        const hairMesh = new THREE.Mesh(hairGeo, hairDarkMat);
        hairMesh.position.set(0, 0.04, -0.03);
        head.add(hairMesh);
      }

      // หมวก
      const hatGroup = new THREE.Group();
      hatGroup.position.set(0, 0.15, 0);

      if (type === 'emma') {
        const brimGeo = track(new THREE.CylinderGeometry(0.42, 0.44, 0.03, 16));
        const crownGeo = track(new THREE.CylinderGeometry(0.22, 0.23, 0.16, 14));
        const brim = new THREE.Mesh(brimGeo, strawHatMat);
        brim.castShadow = true;
        const crown = new THREE.Mesh(crownGeo, strawHatMat);
        crown.position.y = 0.08;
        crown.castShadow = true;

        const ribbonMat = track(new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.6 }));
        const ribbon = new THREE.Mesh(track(new THREE.CylinderGeometry(0.235, 0.235, 0.04, 14)), ribbonMat);
        ribbon.position.y = 0.03;

        hatGroup.add(brim, crown, ribbon);
        hatGroup.rotation.x = -0.12;
      } else if (type === 'daisy') {
        const brim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.38, 0.4, 0.03, 16)), strawHatMat);
        const crown = new THREE.Mesh(track(new THREE.CylinderGeometry(0.2, 0.21, 0.14, 14)), strawHatMat);
        crown.position.y = 0.07;
        const bowMat = track(new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.6 }));
        const bow = new THREE.Mesh(track(new THREE.BoxGeometry(0.08, 0.04, 0.04)), bowMat);
        bow.position.set(0, 0.05, 0.21);
        hatGroup.add(brim, crown, bow);
      } else if (type === 'fisher_girl') {
        const brim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.4, 0.44, 0.03, 16)), strawHatMat);
        const crown = new THREE.Mesh(track(new THREE.CylinderGeometry(0.21, 0.22, 0.15, 14)), strawHatMat);
        crown.position.y = 0.07;
        const ribbonMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.6 }));
        const ribbon = new THREE.Mesh(track(new THREE.CylinderGeometry(0.225, 0.225, 0.035, 14)), ribbonMat);
        ribbon.position.y = 0.035;
        hatGroup.add(brim, crown, ribbon);
        hatGroup.rotation.x = -0.06;
      } else if (type === 'dock_worker') {
        const capMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.7 }));
        const crown = new THREE.Mesh(track(new THREE.SphereGeometry(0.22, 10, 8)), capMat);
        crown.scale.set(1.0, 0.6, 1.1);
        const visor = new THREE.Mesh(track(new THREE.BoxGeometry(0.26, 0.02, 0.18)), capMat);
        visor.position.set(0, -0.04, 0.22);
        visor.rotation.x = 0.15;
        hatGroup.add(crown, visor);
      } else if (type === 'somchai') {
        const brim = new THREE.Mesh(track(new THREE.CylinderGeometry(0.44, 0.46, 0.03, 16)), strawHatMat);
        const crown = new THREE.Mesh(track(new THREE.CylinderGeometry(0.23, 0.24, 0.14, 14)), strawHatMat);
        crown.position.y = 0.07;
        hatGroup.add(brim, crown);
        hatGroup.rotation.x = 0.08;
      } else if (type === 'bob') {
        const capMat = track(new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.7 }));
        const crown = new THREE.Mesh(track(new THREE.SphereGeometry(0.22, 10, 8)), capMat);
        crown.scale.set(1.0, 0.6, 1.1);
        const visor = new THREE.Mesh(track(new THREE.BoxGeometry(0.26, 0.02, 0.18)), capMat);
        visor.position.set(0, -0.04, 0.22);
        visor.rotation.x = 0.15;
        hatGroup.add(crown, visor);
      } else {
        const bandanaMat = track(new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.7 }));
        const bandana = new THREE.Mesh(track(new THREE.SphereGeometry(0.215, 10, 8)), bandanaMat);
        bandana.scale.set(1.02, 0.7, 1.02);
        hatGroup.add(bandana);
      }
      head.add(hatGroup);
      group.add(head);

      // แขน (Arms)
      const armGeo = track(new THREE.CylinderGeometry(0.055, 0.048, 0.34, 6));
      const handGeo = track(new THREE.SphereGeometry(0.05, 6, 6));

      const leftArm = new THREE.Group();
      leftArm.position.set(torsoW * 0.58, 0.92, 0);
      const armMeshL = new THREE.Mesh(armGeo, torsoMat);
      armMeshL.position.y = -0.15;
      armMeshL.castShadow = true;
      leftArm.add(armMeshL);
      const handL = new THREE.Mesh(handGeo, currentSkin);
      handL.position.y = -0.32;
      leftArm.add(handL);
      group.add(leftArm);

      const rightArm = new THREE.Group();
      rightArm.position.set(-torsoW * 0.58, 0.92, 0);
      const armMeshR = new THREE.Mesh(armGeo, torsoMat);
      armMeshR.position.y = -0.15;
      armMeshR.castShadow = true;
      rightArm.add(armMeshR);
      const handR = new THREE.Mesh(handGeo, currentSkin);
      handR.position.y = -0.32;
      rightArm.add(handR);
      group.add(rightArm);

      // Props ในมือ
      const prop = new THREE.Group();
      let waterDropletsMesh: THREE.Points | undefined;
      let soilParticlesMesh: THREE.Points | undefined;

      if (type === 'emma') {
        const canMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.3, roughness: 0.4 }));
        const canBody = new THREE.Mesh(track(new THREE.CylinderGeometry(0.08, 0.1, 0.16, 10)), canMat);
        const spout = new THREE.Mesh(track(new THREE.CylinderGeometry(0.02, 0.028, 0.15, 6)), canMat);
        spout.rotation.z = -0.7;
        spout.position.set(0.11, 0.05, 0);
        canBody.add(spout);
        prop.add(canBody);
        prop.position.set(0, -0.38, 0.08);

        waterDropletsMesh = new THREE.Points(dropletGeo, dropletMat);
        waterDropletsMesh.position.set(0.2, -0.05, 0);
        waterDropletsMesh.visible = false;
        prop.add(waterDropletsMesh);
        rightArm.add(prop);
      } else if (type === 'somchai' || type === 'bob') {
        const woodMat = track(new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.8 }));
        const ironMat = track(new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7, roughness: 0.4 }));
        const handle = new THREE.Mesh(track(new THREE.CylinderGeometry(0.022, 0.022, 0.85, 6)), woodMat);
        const blade = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.14, 0.02)), ironMat);
        blade.position.y = 0.4;
        handle.add(blade);
        handle.rotation.x = 0.25;
        handle.rotation.z = 0.15;
        prop.add(handle);
        prop.position.set(0, -0.15, 0.1);
        rightArm.add(prop);

        soilParticlesMesh = new THREE.Points(soilParticleGeo, soilParticleMat);
        soilParticlesMesh.position.set(0, -0.65, 0.35);
        soilParticlesMesh.visible = false;
        group.add(soilParticlesMesh);
      } else if (type === 'fisher_girl') {
        // คันเบ็ดตกปลาในมือขวา
        const rodMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.4, roughness: 0.4 }));
        const woodGripMat = track(new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 }));
        const reelMat = track(new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.8, roughness: 0.3 }));
        const bobberRedMat = track(new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.4 }));
        const bobberWhiteMat = track(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 }));

        const handle = new THREE.Mesh(track(new THREE.CylinderGeometry(0.02, 0.02, 0.22, 6)), woodGripMat);
        const pole = new THREE.Mesh(track(new THREE.CylinderGeometry(0.008, 0.016, 0.95, 6)), rodMat);
        pole.position.y = 0.55;
        handle.add(pole);

        const reel = new THREE.Mesh(track(new THREE.CylinderGeometry(0.035, 0.035, 0.04, 8)), reelMat);
        reel.rotation.z = Math.PI / 2;
        reel.position.set(0.03, 0.1, 0.02);
        handle.add(reel);

        // ทุ่นลอยปลา
        const bobberGroup = new THREE.Group();
        const bTop = new THREE.Mesh(track(new THREE.SphereGeometry(0.03, 6, 6)), bobberRedMat);
        const bBot = new THREE.Mesh(track(new THREE.SphereGeometry(0.03, 6, 6)), bobberWhiteMat);
        bTop.position.y = 0.025;
        bBot.position.y = -0.025;
        bobberGroup.add(bTop, bBot);
        bobberGroup.position.set(0.08, 0.9, 0.08);
        handle.add(bobberGroup);

        handle.rotation.x = -0.35;
        handle.rotation.z = 0.18;
        prop.add(handle);
        prop.position.set(0, -0.2, 0.1);
        rightArm.add(prop);

        // ตะกร้าสะพายใส่ปลา
        const creelMat = track(new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.85 }));
        const creel = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.15, 0.13)), creelMat);
        creel.position.set(0, -0.32, 0);
        leftArm.add(creel);
      } else if (type === 'dock_worker') {
        // ลังไม้บรรจุปลาสดและน้ำแข็ง
        const crateWoodMat = track(new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.85 }));
        const iceMat = track(new THREE.MeshStandardMaterial({ color: 0xe0f2fe, roughness: 0.2, transparent: true, opacity: 0.8 }));
        const fishMat = track(new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.6, roughness: 0.3 }));

        const crate = new THREE.Group();
        const box = new THREE.Mesh(track(new THREE.BoxGeometry(0.3, 0.17, 0.22)), crateWoodMat);
        crate.add(box);

        const ice = new THREE.Mesh(track(new THREE.BoxGeometry(0.27, 0.05, 0.19)), iceMat);
        ice.position.y = 0.07;
        crate.add(ice);

        for (let f = 0; f < 3; f++) {
          const fishBody = new THREE.Mesh(track(new THREE.ConeGeometry(0.035, 0.14, 6)), fishMat);
          fishBody.rotation.z = Math.PI / 2 + (f - 1) * 0.25;
          fishBody.rotation.x = 0.2;
          fishBody.position.set((f - 1) * 0.07, 0.11, (f % 2 === 0 ? 0.02 : -0.03));
          crate.add(fishBody);
        }

        crate.position.set(0, -0.16, 0.2);
        prop.add(crate);
        rightArm.add(prop);
      } else if (type === 'lily') {
        const basketMat = track(new THREE.MeshStandardMaterial({ color: 0xca8a04, roughness: 0.8 }));
        const basket = new THREE.Mesh(track(new THREE.CylinderGeometry(0.12, 0.09, 0.15, 8)), basketMat);
        const eggGeo = track(new THREE.SphereGeometry(0.035, 6, 6));
        const eggMat = track(new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.4 }));
        const egg = new THREE.Mesh(eggGeo, eggMat);
        egg.position.set(0.02, 0.07, 0.02);
        basket.add(egg);
        prop.add(basket);
        prop.position.set(0, -0.36, 0);
        leftArm.add(prop);
      } else {
        const wheatMat = track(new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.6 }));
        const sheaf = new THREE.Mesh(track(new THREE.CylinderGeometry(0.05, 0.02, 0.35, 6)), wheatMat);
        sheaf.rotation.x = 0.4;
        prop.add(sheaf);
        prop.position.set(0, -0.28, 0.1);
        leftArm.add(prop);
      }

      // ขาและรองเท้าบูท
      const legGeo = track(new THREE.CylinderGeometry(0.075, 0.065, 0.36, 6));
      const bootGeo = track(new THREE.BoxGeometry(0.11, 0.13, 0.18));

      const leftLeg = new THREE.Group();
      leftLeg.position.set(torsoW * 0.25, 0.5, 0);
      const legMeshL = new THREE.Mesh(legGeo, denimMat);
      legMeshL.position.y = -0.15;
      legMeshL.castShadow = true;
      leftLeg.add(legMeshL);
      const bootL = new THREE.Mesh(bootGeo, leatherMat);
      bootL.position.set(0, -0.3, 0.03);
      bootL.castShadow = true;
      leftLeg.add(bootL);
      group.add(leftLeg);

      const rightLeg = new THREE.Group();
      rightLeg.position.set(-torsoW * 0.25, 0.5, 0);
      const legMeshR = new THREE.Mesh(legGeo, denimMat);
      legMeshR.position.y = -0.15;
      legMeshR.castShadow = true;
      rightLeg.add(legMeshR);
      const bootR = new THREE.Mesh(bootGeo, leatherMat);
      bootR.position.set(0, -0.3, 0.03);
      bootR.castShadow = true;
      rightLeg.add(bootR);
      group.add(rightLeg);

      group.scale.setScalar(scale);

      const waypoints3D: Waypoint[] = waypointsPx.map((wp) => {
        const p3d = pxToWorld3D(wp.x, wp.y);
        return {
          x: p3d.x,
          z: p3d.z,
          action: wp.action || 'idle',
          actionDuration: wp.actionDuration || 3.0,
        };
      });

      const initialPos = new THREE.Vector3(waypoints3D[0].x, 0, waypoints3D[0].z);
      group.position.copy(initialPos);
      scene.add(group);

      return {
        id,
        name,
        role,
        avatar,
        type,
        group,
        head,
        hat: hatGroup,
        torso,
        leftArm,
        rightArm,
        leftLeg,
        rightLeg,
        prop,
        waterDroplets: waterDropletsMesh,
        soilParticles: soilParticlesMesh,
        waterRippleMesh,
        feedParticlesMesh,
        shadowMesh,
        waypoints: waypoints3D,
        currentWaypointIndex: 0,
        pos: initialPos,
        targetPos: initialPos.clone(),
        speed: isFemale ? 0.65 : 0.72,
        rotationY: 0,
        walkCycle: Math.random() * Math.PI * 2,
        state: 'walking',
        stateTimer: 0,
        quotes,
      };
    };

    // 6. ข้อมูลตัวละคร
    const characters: CharacterInstance[] = [
      createCharacter(
        'char_emma',
        'เอ็มม่า (สาวชาวสวน)',
        'เจ้าของสวนและดูแลแปลงเกษตร',
        '👩‍🌾',
        'emma',
        [
          { x: 340, y: 520, action: 'water', actionDuration: 4.5 },
          { x: 440, y: 520, action: 'water', actionDuration: 4.0 },
          { x: 360, y: 440, action: 'inspect', actionDuration: 3.5 },
          { x: 230, y: 440, action: 'idle', actionDuration: 3.0 },
          { x: 180, y: 230, action: 'inspect', actionDuration: 3.5 },
          { x: 460, y: 360, action: 'rest', actionDuration: 3.0 },
        ],
        [
          'สวัสดีจ้าชาวสวน! วันนี้พืชผลในแปลงงอกงามและสดชื่นมากเลยนะ 🌱✨',
          'ฉันเพิ่งรดน้ำแปลงมะเขือเทศกับข้าวโพดเสร็จ ดินชุ่มฉ่ำกำลังดีเลยจ้ะ 🍅🌽',
          'ถ้าต้องการเก็บเกี่ยวไวขึ้น อย่าลืมใช้เพชรช่วยเร่งโตนะจ๊ะ 💎',
          'อากาศวันนี้ดีจังเลย เหมาะกับการเพาะปลูกที่สุด! 🌸☀️',
        ]
      ),
      createCharacter(
        'char_lily',
        'ลิลี่ (ผู้ช่วยดูแลสัตว์)',
        'ให้อาหารและเก็บผลผลิตสัตว์',
        '👧',
        'lily',
        [
          { x: 1040, y: 270, action: 'inspect', actionDuration: 4.0 },
          { x: 1080, y: 440, action: 'inspect', actionDuration: 4.0 },
          { x: 1220, y: 440, action: 'idle', actionDuration: 3.5 },
          { x: 800, y: 210, action: 'inspect', actionDuration: 3.5 },
          { x: 920, y: 350, action: 'rest', actionDuration: 3.0 },
        ],
        [
          'ไก่ในเล้าอารมณ์ดีมากเลยจ้ะ ออกไข่ฟองโตเต็มรังฟางเลย! 🐔🥚',
          'วัวนมชอบกินข้าวโพดหวานมากเลยจ้ะ วันนี้น้ำนมสดหวานฉ่ำเลยนะ 🐮🥛',
          'แกะขนปุยนุ่มฟูมาก ถ้ามีข้าวสาลีมาให้พวกมันจะดีใจสุดๆ เลย 🐑✨',
          'อย่าลืมแวะไปลูบหัวสัตว์บ่อยๆ นะคะ สัตว์จะมีความสุขมาก! 💖🐾',
        ]
      ),
      createCharacter(
        'char_daisy',
        'เดซี่ (ฝ่ายเก็บเกี่ยว)',
        'ดูแลสวนดอกไม้และเก็บผลผลิต',
        '👱‍♀️',
        'daisy',
        [
          { x: 320, y: 400, action: 'inspect', actionDuration: 4.0 },
          { x: 740, y: 150, action: 'work', actionDuration: 4.5 },
          { x: 860, y: 150, action: 'work', actionDuration: 4.0 },
          { x: 576, y: 336, action: 'inspect', actionDuration: 3.5 },
          { x: 420, y: 460, action: 'rest', actionDuration: 3.0 },
        ],
        [
          'ดอกไม้ในฟาร์มบานสะพรั่งส่งกลิ่นหอมชื่นใจมากเลยค่ะ 🌸🌼',
          'แอปเปิลกับส้มผลดกฉ่ำน้ำ พร้อมส่งเข้าโรงงานแยมแล้วจ้ะ 🍎🍊',
          'ทำงานท่ามกลางธรรมชาติแบบนี้ สดชื่นที่สุดเลย! 🍯✨',
        ]
      ),
      createCharacter(
        'char_bob',
        'ลุงบ็อบ (คนงานฟาร์ม)',
        'ดูแลโรงเก็บผลผลิตและพรวนดิน',
        '👨‍🌾',
        'bob',
        [
          { x: 480, y: 520, action: 'till', actionDuration: 4.5 },
          { x: 350, y: 220, action: 'inspect', actionDuration: 4.0 },
          { x: 150, y: 310, action: 'idle', actionDuration: 3.5 },
          { x: 550, y: 290, action: 'inspect', actionDuration: 4.0 },
          { x: 620, y: 430, action: 'inspect', actionDuration: 3.5 },
        ],
        [
          'โรงนาแข็งแรง ปลอดภัยดีครับ! สินค้าถูกจัดเก็บเป็นระเบียบเรียบร้อย 📦🌾',
          'ช่วยพรวนดินเปิดหน้าดินให้ร่วนซุย ผักโตไวแน่นอนครับ! ⛏️💪',
          'เตาอบขนมปังกำลังส่งกลิ่นหอมกรุ่นเลยครับนายหัว! 🍞🔥',
        ]
      ),
      createCharacter(
        'char_somchai',
        'สมชาย (คนงานขุดดิน)',
        'ขุดหลุม ยกร่อง และเตรียมดินเพาะปลูก',
        '💪',
        'somchai',
        [
          { x: 200, y: 560, action: 'dig', actionDuration: 5.0 },
          { x: 320, y: 560, action: 'till', actionDuration: 4.5 },
          { x: 440, y: 580, action: 'dig', actionDuration: 5.0 },
          { x: 280, y: 460, action: 'till', actionDuration: 4.0 },
          { x: 230, y: 380, action: 'rest', actionDuration: 3.0 },
        ],
        [
          'ดินร่วนซุยดีมากครับนายหัว! ขุดเตรียมแปลงไว้พร้อมลงเมล็ดพันธุ์แล้ว! ⛏️🌱',
          'ดินดำฮิวมัสแน่นเอี๊ยด แร่ธาตุเต็มเปี่ยม ขุดยกแปลงเสร็จไวแน่นอนครับ! 💪🌾',
          'เหงื่อไหลไคลย้อยแต่ชื่นใจครับ เห็นแปลงผักสวยงามแล้วหายเหนื่อยเลย! 🍅✨',
        ]
      ),
      // 🌟 1. ตัวละครหญิงเดินไปเดินมาตามทางบ่อตกปลา: มายด์ (สาวนักตกปลา)
      createCharacter(
        'char_maya',
        'มายด์ (สาวนักตกปลา)',
        'เดินเล่นริมสระมรกตและตกปลาตามทางสะพาน',
        '🎣',
        'fisher_girl',
        [
          { x: 410, y: 615, action: 'rest', actionDuration: 3.5 }, // จุดชมวิวทางลงบ่อปลา
          { x: 335, y: 675, action: 'inspect', actionDuration: 3.0 }, // โค้งต้นไม้ริมทาง
          { x: 250, y: 730, action: 'watch_fish', actionDuration: 4.5 }, // ทางเข้าสะพานไม้ริมบ่อ ดูฝูงปลา
          { x: 175, y: 785, action: 'fish', actionDuration: 6.5 }, // ปลายสะพานไม้ ตกปลา หย่อนสายลงน้ำ
          { x: 220, y: 835, action: 'watch_fish', actionDuration: 4.0 }, // เดินเลียบขอบบ่อปลาด้านล่าง
          { x: 310, y: 770, action: 'rest', actionDuration: 3.5 }, // พักริมทางเดินรับลมเย็น
          { x: 385, y: 680, action: 'inspect', actionDuration: 3.0 }, // เดินตรวจความเรียบร้อยตามทาง
        ],
        [
          'สวัสดีจ้า! วันนี้บ่อปลาน้ำใสแจ๋วเลย มีฝูงปลาคาร์ปมรกตว่ายเล่นเต็มไปหมด 🐟✨',
          'ตรงปลายสะพานไม้ตกปลา มีปลาตัวใหญ่แวะมากินเหยื่อบ่อยมากเลยนะจ๊ะ 🎣🌊',
          'เดินรับลมเย็นๆ ริมน้ำแล้วสบายใจสุดๆ บรรยากาศรอบสระน้ำสดชื่นที่สุดเลย! 💖🌿',
          'ถ้าอยากตกปลาสนุกๆ แตะที่บ่อตกปลาแล้วมาลุ้นปลาระดับตำนานกันนะจ๊ะ! 🌟🐠',
        ]
      ),
      // 🌟 2. ตัวละครคนงานเดินไปเดินมาตามทางบ่อตกปลา: สมศักดิ์ (คนงานบ่อปลา)
      createCharacter(
        'char_somsak',
        'สมศักดิ์ (คนงานบ่อปลา)',
        'ดูแลท่าเรือ ให้อาหารปลา และขนส่งลังปลาสด',
        '👷‍♂️',
        'dock_worker',
        [
          { x: 490, y: 550, action: 'work', actionDuration: 4.0 }, // ทางแยกหน้าฟาร์ม ตรวจสอบใบส่งสินค้า
          { x: 420, y: 620, action: 'carry', actionDuration: 3.0 }, // เดินยกกล่องปลาสดลงตามทาง
          { x: 340, y: 685, action: 'inspect', actionDuration: 3.0 }, // ตรวจดูทางเดินหินกรวด
          { x: 260, y: 750, action: 'feed_fish', actionDuration: 5.5 }, // หัวสะพานไม้ โปรยอาหารเม็ดให้ฝูงปลา
          { x: 195, y: 815, action: 'inspect_dock', actionDuration: 4.5 }, // ตรวจเช็คสะพานเทียบท่าและถังพักปลา
          { x: 275, y: 820, action: 'carry', actionDuration: 3.5 }, // ยกกล่องปลาเตรียมขึ้นไปส่ง
          { x: 355, y: 730, action: 'rest', actionDuration: 3.5 }, // พักวางกล่องปลา ปาดเหงื่อชื่นใจ
          { x: 445, y: 630, action: 'carry', actionDuration: 3.0 }, // เดินขนกล่องปลาขึ้นสู่ฟาร์ม
        ],
        [
          'สวัสดีครับนายหัว! ผมกำลังขนส่งลังปลาสดๆ จากบ่อตกปลาขึ้นฟาร์มครับ สดใหม่ทุกลัง! 📦🐟',
          'สะพานไม้ริมบ่อปลาตรวจเช็คเรียบร้อยแล้ว มั่นคงแข็งแรง ปลอดภัย 100% ครับ! 🔨💪',
          'เพิ่งโปรยอาหารปลาไปครับ ฝูงปลาคาร์ปกับปลากะพงว่ายแย่งอาหารกันคึกคักเลย! 🌾🌊',
          'น้ำในบ่อสะอาดไหลเวียนดี ปลาโตไวแข็งแรง ขายได้ราคาดีแน่นอนครับ! ✨💰',
        ]
      ),
    ];

    // 🐾 แมวส้มริมบ่อตกปลา (3D Orange Pond Cat)
    const catGroup = new THREE.Group();
    const catScale = 0.38;
    catGroup.scale.setScalar(catScale);

    const orangeFurMat = track(new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.8 }));
    const whiteFurMat = track(new THREE.MeshStandardMaterial({ color: 0xfefce8, roughness: 0.8 }));
    const catEyeMat = track(new THREE.MeshStandardMaterial({ color: 0x84cc16, roughness: 0.2 }));
    const catNoseMat = track(new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.4 }));

    const catShadowGeo = track(new THREE.CircleGeometry(0.24, 16));
    catShadowGeo.scale(1.0, 0.7, 1.0);
    const catShadow = new THREE.Mesh(catShadowGeo, shadowMat);
    catShadow.rotation.x = -Math.PI / 2;
    catShadow.position.y = 0.01;
    catGroup.add(catShadow);

    const catBodyGeo = track(new THREE.SphereGeometry(0.22, 10, 8));
    catBodyGeo.scale(0.85, 1.1, 0.95);
    const catBody = new THREE.Mesh(catBodyGeo, orangeFurMat);
    catBody.position.y = 0.22;
    catBody.castShadow = true;
    catGroup.add(catBody);

    const catBelly = new THREE.Mesh(track(new THREE.SphereGeometry(0.14, 8, 8)), whiteFurMat);
    catBelly.position.set(0, 0.2, 0.11);
    catGroup.add(catBelly);

    const catHead = new THREE.Group();
    catHead.position.set(0, 0.46, 0.08);
    const catHeadMesh = new THREE.Mesh(track(new THREE.SphereGeometry(0.18, 10, 8)), orangeFurMat);
    catHeadMesh.scale.set(1.05, 0.95, 1.0);
    catHeadMesh.castShadow = true;
    catHead.add(catHeadMesh);

    const earGeo = track(new THREE.ConeGeometry(0.065, 0.12, 4));
    const earL = new THREE.Mesh(earGeo, orangeFurMat);
    earL.position.set(0.1, 0.17, 0);
    earL.rotation.z = -0.25;
    catHead.add(earL);
    const earR = new THREE.Mesh(earGeo, orangeFurMat);
    earR.position.set(-0.1, 0.17, 0);
    earR.rotation.z = 0.25;
    catHead.add(earR);

    const eyeGeo = track(new THREE.SphereGeometry(0.025, 6, 6));
    const eyeL = new THREE.Mesh(eyeGeo, catEyeMat);
    eyeL.position.set(0.06, 0.02, 0.16);
    catHead.add(eyeL);
    const eyeR = new THREE.Mesh(eyeGeo, catEyeMat);
    eyeR.position.set(-0.06, 0.02, 0.16);
    catHead.add(eyeR);

    const nose = new THREE.Mesh(track(new THREE.ConeGeometry(0.018, 0.02, 3)), catNoseMat);
    nose.rotation.x = Math.PI / 2;
    nose.position.set(0, -0.02, 0.18);
    catHead.add(nose);
    catGroup.add(catHead);

    const pawGeo = track(new THREE.CylinderGeometry(0.04, 0.045, 0.18, 6));
    const pawL = new THREE.Mesh(pawGeo, whiteFurMat);
    pawL.position.set(0.08, 0.09, 0.14);
    catGroup.add(pawL);
    const pawR = new THREE.Mesh(pawGeo, whiteFurMat);
    pawR.position.set(-0.08, 0.09, 0.14);
    catGroup.add(pawR);

    const catTail = new THREE.Group();
    catTail.position.set(0, 0.1, -0.16);
    const tailMesh = new THREE.Mesh(track(new THREE.CylinderGeometry(0.03, 0.02, 0.32, 6)), orangeFurMat);
    tailMesh.position.set(0, 0.14, -0.06);
    tailMesh.rotation.x = -0.6;
    catTail.add(tailMesh);
    catGroup.add(catTail);

    const catP3d = pxToWorld3D(232, 752);
    catGroup.position.set(catP3d.x, 0, catP3d.z);
    catGroup.rotation.y = -1.2;
    scene.add(catGroup);

    charactersRef.current = characters;

    // 7. Animation Loop
    let animId: number;
    let lastTime = performance.now();
    let frameCounter = 0;

    const animate = (currentTime: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;
      frameCounter++;

      if (isEditMode) {
        renderer.render(scene, camera);
        return;
      }

      // น้องแมวส่ายหางและผงกหัวเบาๆ
      const catTime = currentTime * 0.0025;
      catTail.rotation.y = Math.sin(catTime * 2.2) * 0.45;
      catTail.rotation.z = Math.cos(catTime * 2.2) * 0.2;
      catHead.rotation.x = Math.sin(catTime * 1.2) * 0.08;
      catHead.rotation.y = Math.sin(catTime * 0.8) * 0.18;

      characters.forEach((char) => {
        if (char.state === 'walking') {
          if (char.waterDroplets) char.waterDroplets.visible = false;
          if (char.soilParticles) char.soilParticles.visible = false;
          if (char.waterRippleMesh) char.waterRippleMesh.visible = false;
          if (char.feedParticlesMesh) char.feedParticlesMesh.visible = false;

          const targetWp = char.waypoints[char.currentWaypointIndex];
          const dx = targetWp.x - char.pos.x;
          const dz = targetWp.z - char.pos.z;
          const dist = Math.hypot(dx, dz);

          if (dist > 0.12) {
            const targetAngle = Math.atan2(dx, dz);
            char.rotationY = THREE.MathUtils.lerp(char.rotationY, targetAngle, 0.12);
            char.group.rotation.y = char.rotationY;

            const step = char.speed * dt;
            char.pos.x += Math.sin(targetAngle) * step;
            char.pos.z += Math.cos(targetAngle) * step;
            char.group.position.x = char.pos.x;
            char.group.position.z = char.pos.z;

            char.walkCycle += dt * 7.5;
            const swing = Math.sin(char.walkCycle);

            char.leftLeg.rotation.x = swing * 0.55;
            char.rightLeg.rotation.x = -swing * 0.55;

            // ท่าทางแขนขณะเดินตามบทบาท
            if (char.type === 'dock_worker') {
              // คนงานเดินอุ้มกล่องปลาอย่างทะมัดทะแมง
              char.leftArm.rotation.x = -0.65 + swing * 0.08;
              char.rightArm.rotation.x = -0.65 - swing * 0.08;
              char.leftArm.rotation.z = 0.22;
              char.rightArm.rotation.z = -0.22;
              char.torso.position.y = 0.76 + Math.abs(swing) * 0.02;
            } else if (char.type === 'fisher_girl') {
              // สาวนักตกปลาเดินสะพายคันเบ็ดสบายๆ
              char.rightArm.rotation.x = -0.45 + swing * 0.15;
              char.rightArm.rotation.z = -0.15;
              char.leftArm.rotation.x = -swing * 0.45;
              char.leftArm.rotation.z = 0;
              char.torso.position.y = 0.76 + Math.abs(swing) * 0.025;
            } else {
              char.leftArm.rotation.x = -swing * 0.45;
              char.rightArm.rotation.x = swing * 0.45;
              char.torso.position.y = 0.76 + Math.abs(swing) * 0.025;
            }

            char.head.position.y = 1.14 + Math.abs(swing) * 0.025;
            if (char.hat) char.hat.rotation.z = swing * 0.04;
          } else {
            char.state = 'acting';
            char.stateTimer = targetWp.actionDuration || 3.0;
            char.leftLeg.rotation.x = 0;
            char.rightLeg.rotation.x = 0;
            char.leftArm.rotation.x = 0;
            char.rightArm.rotation.x = 0;
          }
        } else if (char.state === 'acting') {
          char.stateTimer -= dt;
          const targetWp = char.waypoints[char.currentWaypointIndex];

          if (targetWp.action === 'dig') {
            const digCycle = (char.stateTimer * 3.5) % Math.PI;
            const digPower = Math.sin(digCycle);

            char.torso.rotation.x = 0.35 + digPower * 0.2;
            char.head.rotation.x = 0.4;
            char.rightArm.rotation.x = -1.2 + digPower * 1.6;
            char.leftArm.rotation.x = -0.8 + digPower * 1.2;
            char.leftArm.rotation.z = -0.3;

            char.leftLeg.rotation.x = -0.15;
            char.rightLeg.rotation.x = 0.15;

            if (char.soilParticles) {
              const isHitting = digPower > 0.75;
              char.soilParticles.visible = isHitting;
              if (isHitting) {
                char.soilParticles.rotation.y += dt * 8;
              }
            }
          } else if (targetWp.action === 'till') {
            const tillCycle = Math.sin(char.stateTimer * 6.5);

            char.torso.rotation.x = 0.25;
            char.head.rotation.x = 0.3;
            char.rightArm.rotation.x = -0.7 + tillCycle * 0.35;
            char.leftArm.rotation.x = -0.5 + tillCycle * 0.25;

            if (char.soilParticles) {
              char.soilParticles.visible = true;
              char.soilParticles.rotation.y += dt * 3;
            }
          } else if (targetWp.action === 'water') {
            const waterCycle = Math.sin(char.stateTimer * 4);
            char.rightArm.rotation.x = -0.65 + waterCycle * 0.2;
            char.torso.rotation.x = 0.12;
            char.head.rotation.x = 0.2;
            if (char.waterDroplets) {
              char.waterDroplets.visible = true;
              char.waterDroplets.rotation.y += dt * 4;
            }
          } else if (targetWp.action === 'fish') {
            // สาวนักตกปลาหย่อนสายเบ็ดลงน้ำ มีทุ่นกระตุกและระลอกคลื่นน้ำ
            const fishCycle = Math.sin(char.stateTimer * 2.5);
            char.rightArm.rotation.x = -1.1 + fishCycle * 0.14;
            char.rightArm.rotation.z = -0.15;
            char.leftArm.rotation.x = -0.85 + Math.sin(char.stateTimer * 5.5) * 0.1;
            char.leftArm.rotation.z = 0.18;
            char.torso.rotation.x = 0.18;
            char.head.rotation.x = 0.28;

            if (char.waterRippleMesh) {
              char.waterRippleMesh.visible = true;
              const rScale = 1.0 + ((char.stateTimer * 1.5) % 1.0) * 1.4;
              char.waterRippleMesh.scale.set(rScale, 1, rScale);
            }
          } else if (targetWp.action === 'watch_fish') {
            // โน้มตัวมองดูปลาในสระมรกตอย่างเพลิดเพลิน
            const watchCycle = Math.sin(char.stateTimer * 1.8);
            char.torso.rotation.x = 0.26;
            char.head.rotation.x = 0.32;
            char.head.rotation.y = watchCycle * 0.35;
            char.leftArm.rotation.z = -0.3;
            char.rightArm.rotation.z = 0.3;
            char.leftArm.rotation.x = -0.2;
            char.rightArm.rotation.x = -0.2;
          } else if (targetWp.action === 'feed_fish') {
            // คนงานโปรยอาหารเม็ดให้ฝูงปลาในบ่อ
            const feedThrow = Math.sin(char.stateTimer * 4.5);
            char.rightArm.rotation.x = -1.2 + feedThrow * 0.65;
            char.rightArm.rotation.z = -0.2;
            char.leftArm.rotation.x = -0.6;
            char.torso.rotation.x = 0.22;
            char.head.rotation.x = 0.3;

            if (char.feedParticlesMesh) {
              const isTossing = feedThrow > 0.15;
              char.feedParticlesMesh.visible = isTossing;
              if (isTossing) {
                char.feedParticlesMesh.rotation.y += dt * 4;
              }
            }
            if (char.waterRippleMesh) {
              char.waterRippleMesh.visible = true;
              const rScale = 1.0 + ((char.stateTimer * 2.2) % 1.0) * 1.6;
              char.waterRippleMesh.scale.set(rScale, 1, rScale);
            }
          } else if (targetWp.action === 'inspect_dock') {
            // คนงานตรวจเช็คความแข็งแรงของสะพานไม้และถังพักปลา
            const hammerCycle = Math.sin(char.stateTimer * 6.5);
            char.torso.rotation.x = 0.36;
            char.head.rotation.x = 0.42;
            char.rightArm.rotation.x = -0.8 + hammerCycle * 0.35;
            char.leftArm.rotation.x = -0.3;
          } else if (targetWp.action === 'carry') {
            // อุ้มกล่องปลาอย่างมั่นคง
            char.leftArm.rotation.x = -0.75;
            char.rightArm.rotation.x = -0.75;
            char.leftArm.rotation.z = 0.25;
            char.rightArm.rotation.z = -0.25;
            char.torso.rotation.x = -0.05;
          } else if (targetWp.action === 'work') {
            const workCycle = Math.sin(char.stateTimer * 5);
            char.rightArm.rotation.x = -0.4 + workCycle * 0.35;
            char.torso.rotation.x = 0.1;
          } else if (targetWp.action === 'inspect') {
            const inspectCycle = Math.sin(char.stateTimer * 2);
            char.head.rotation.y = inspectCycle * 0.35;
            char.torso.rotation.x = 0.06;
          } else if (targetWp.action === 'rest') {
            char.leftArm.rotation.z = -0.4;
            char.rightArm.rotation.z = 0.4;
            char.head.rotation.y = Math.sin(char.stateTimer) * 0.2;
          } else {
            char.head.rotation.y = Math.sin(char.stateTimer * 1.5) * 0.2;
          }

          if (char.stateTimer <= 0) {
            if (char.waterDroplets) char.waterDroplets.visible = false;
            if (char.soilParticles) char.soilParticles.visible = false;
            if (char.waterRippleMesh) char.waterRippleMesh.visible = false;
            if (char.feedParticlesMesh) char.feedParticlesMesh.visible = false;
            char.currentWaypointIndex = (char.currentWaypointIndex + 1) % char.waypoints.length;
            char.state = 'walking';
            char.torso.rotation.x = 0;
            char.head.rotation.x = 0;
            char.head.rotation.y = 0;
            char.leftArm.rotation.z = 0;
            char.rightArm.rotation.z = 0;
            char.leftLeg.rotation.x = 0;
            char.rightLeg.rotation.x = 0;
          }
        } else if (char.state === 'waving') {
          char.stateTimer -= dt;
          char.leftArm.rotation.z = -1.6 + Math.sin(char.stateTimer * 14) * 0.45;
          char.head.rotation.y = Math.sin(char.stateTimer * 4) * 0.15;
          char.torso.position.y = 0.76 + Math.abs(Math.sin(char.stateTimer * 8)) * 0.05;

          if (char.stateTimer <= 0) {
            char.leftArm.rotation.z = 0;
            char.state = 'walking';
          }
        }
      });

      // Projection พิกัดปุ่มคลิกบนหน้าจอ
      if (frameCounter % 2 === 0) {
        const positions: CharacterScreenPos[] = characters.map((c) => {
          const v = c.pos.clone();
          v.y = 0.45; // จุดศูนย์กลางตามสเกลที่เล็กลง
          v.project(camera);
          return {
            id: c.id,
            name: c.name,
            role: c.role,
            avatar: c.avatar,
            screenX: (v.x * 0.5 + 0.5) * WIDTH,
            screenY: (-v.y * 0.5 + 0.5) * HEIGHT,
          };
        });

        // ตำแหน่งคลิกของน้องแมวส้ม
        const catPos3d = catGroup.position.clone();
        catPos3d.y = 0.28;
        catPos3d.project(camera);
        positions.push({
          id: 'char_cat',
          name: 'น้องแมวส้ม (ริมบ่อปลา)',
          role: 'ผู้พิทักษ์สะพานไม้และขอปลากิน',
          avatar: '🐱',
          screenX: (catPos3d.x * 0.5 + 0.5) * WIDTH,
          screenY: (-catPos3d.y * 0.5 + 0.5) * HEIGHT,
        });

        setCharacterScreenPositions(positions);
      }

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();
      disposables.forEach((res) => {
        if (!(res instanceof THREE.Texture)) {
          res.dispose();
        }
      });
    };
  }, [isEditMode]);

  const handleCharacterClick = useCallback(
    (charId: string, clientX: number, clientY: number, screenX: number, screenY: number) => {
      if (isEditMode) return;

      if (charId === 'char_cat') {
        sound.playClick();
        const hasAnyFish = Object.values(inventory).some(
          (it: any) => it.id?.startsWith('fish_') && it.count > 0
        );
        const text = hasAnyFish
          ? 'เหมียววว! ได้กลิ่นปลาสดๆ หอมเตะจมูกเลย 🐟✨ ให้น้องแมวกินปลา 1 ตัวเพื่อรับพรนำโชคไหมเหมียว?'
          : 'เหมียว~ (น้องแมวส้มนั่งรอกินปลาสดๆ จากสระน้ำมรกตอยู่นะ แวะไปตกปลามาฝากหน่อยจิ! 🐾)';

        setActiveSpeech({
          id: 'char_cat',
          name: 'น้องแมวส้ม (ริมบ่อปลา)',
          avatar: '🐱',
          text,
          screenX,
          screenY: screenY - 45,
        });
        setFloatingHeart({
          id: Date.now(),
          x: screenX,
          y: screenY - 35,
        });
        setTimeout(() => setActiveSpeech(null), 5500);
        setTimeout(() => setFloatingHeart(null), 1200);
        return;
      }

      const char = charactersRef.current.find((c) => c.id === charId);
      if (!char) return;

      if (char.type === 'fisher_girl' || char.type === 'dock_worker') {
        sound.playWater();
      } else {
        sound.playSuccessChime();
      }
      char.state = 'waving';
      char.stateTimer = 2.8;

      const quote = char.quotes[Math.floor(Math.random() * char.quotes.length)];

      setActiveSpeech({
        id: char.id,
        name: char.name,
        avatar: char.avatar,
        text: quote,
        screenX,
        screenY: screenY - 45,
      });

      setFloatingHeart({
        id: Date.now(),
        x: screenX,
        y: screenY - 35,
      });

      setTimeout(() => setActiveSpeech(null), 4500);
      setTimeout(() => setFloatingHeart(null), 1200);

      if (onCharacterClick) {
        onCharacterClick({
          name: char.name,
          role: char.role,
          quote,
        });
      }
    },
    [isEditMode, onCharacterClick, inventory]
  );

  if (isEditMode) return null;

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 pointer-events-none select-none overflow-visible z-30 ${className}`}
    >
      <canvas
        ref={canvasRef}
        width={WIDTH}
        height={HEIGHT}
        className="w-full h-full pointer-events-none select-none"
      />

      {/* จุดสัมผัสคลิกของตัวละครและสัตว์เลี้ยง */}
      {characterScreenPositions.map((pos) => (
        <div
          key={pos.id}
          style={{
            position: 'absolute',
            left: `${pos.screenX}px`,
            top: `${pos.screenY}px`,
            width: '42px',
            height: '56px',
            transform: 'translate(-50%, -65%)',
          }}
          onClick={(e) => {
            e.stopPropagation();
            handleCharacterClick(pos.id, e.clientX, e.clientY, pos.screenX, pos.screenY);
          }}
          className="pointer-events-auto cursor-pointer group flex flex-col items-center justify-start rounded-full select-none"
          title={`แตะเพื่อทักทาย ${pos.name}`}
        >
          {/* Badge แสดงชื่อเมื่อ Hover */}
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 -translate-y-3.5 bg-stone-900/90 text-amber-200 text-[9px] font-black px-2 py-0.5 rounded-full border border-amber-400 shadow-xl pointer-events-none whitespace-nowrap flex items-center gap-1">
            <span>{pos.avatar}</span>
            <span>{pos.name}</span>
          </div>
        </div>
      ))}

      {/* Floating Heart Effect */}
      {floatingHeart && (
        <div
          key={floatingHeart.id}
          className="absolute z-50 transform -translate-x-1/2 -translate-y-8 animate-bounce pointer-events-none"
          style={{ left: `${floatingHeart.x}px`, top: `${floatingHeart.y}px` }}
        >
          <div className="flex items-center gap-1 bg-rose-500 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-2xl border border-white">
            <Heart className="w-3 h-3 fill-white" />
            <span>+ความสุขในฟาร์ม!</span>
          </div>
        </div>
      )}

      {/* Dialogue Speech Bubble */}
      {activeSpeech && (
        <div
          className="absolute z-50 transform -translate-x-1/2 -translate-y-full pointer-events-auto transition-all duration-300"
          style={{ left: `${activeSpeech.screenX}px`, top: `${activeSpeech.screenY}px` }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="bg-stone-900/95 text-white p-2.5 rounded-2xl shadow-2xl border-2 border-amber-400 w-60 max-w-xs flex flex-col gap-1.5 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-1 border-b border-stone-800">
              <div className="flex items-center gap-1">
                <span className="text-base">{activeSpeech.avatar}</span>
                <span className="text-[11px] font-black text-amber-300">{activeSpeech.name}</span>
              </div>
              <Sparkles className="w-3 h-3 text-yellow-400 animate-spin" />
            </div>
            <p className="text-[11px] text-amber-100 font-medium leading-relaxed mt-0.5">
              "{activeSpeech.text}"
            </p>

            {/* ปุ่มทางลัดชวนตกปลาของมายด์ */}
            {activeSpeech.id === 'char_maya' && onOpenFishing && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenFishing();
                  setActiveSpeech(null);
                }}
                className="mt-1 w-full py-1.5 px-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-black shadow flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
              >
                <span>🎣</span>
                <span>ไปตกปลากับมายด์ทันที</span>
              </button>
            )}

            {/* ปุ่มทางลัดตรวจสระน้ำของสมศักดิ์ */}
            {activeSpeech.id === 'char_somsak' && onOpenFishing && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenFishing();
                  setActiveSpeech(null);
                }}
                className="mt-1 w-full py-1.5 px-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-xl text-xs font-black shadow flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
              >
                <span>🎣</span>
                <span>ตรวจสอบสระน้ำและตกปลา</span>
              </button>
            )}

            {/* ปุ่มให้อาหารน้องแมวส้ม */}
            {activeSpeech.id === 'char_cat' && (
              <div className="mt-1 flex flex-col gap-1.5">
                {Object.values(inventory).some((it: any) => it.id?.startsWith('fish_') && it.count > 0) ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onFeedCatFish?.();
                      setActiveSpeech(null);
                    }}
                    className="w-full py-1.5 px-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-black shadow flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                  >
                    <span>🐟</span>
                    <span>ให้น้องแมวส้มกินปลา 1 ตัว (+พรโชคดี)</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenFishing?.();
                      setActiveSpeech(null);
                    }}
                    className="w-full py-1.5 px-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-black shadow flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                  >
                    <span>🎣</span>
                    <span>ไปตกปลาในสระมรกตเลย</span>
                  </button>
                )}
              </div>
            )}

            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-x-6 border-x-transparent border-t-6 border-t-stone-900" />
          </div>
        </div>
      )}
    </div>
  );
};