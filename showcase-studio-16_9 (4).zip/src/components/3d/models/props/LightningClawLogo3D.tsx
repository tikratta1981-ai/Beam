import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface LightningClawProps {
  className?: string;
  size?: number; // ขนาดกว้าง-ยาว (px)
}

export const LightningClawLogo3D: React.FC<LightningClawProps> = ({
  className = '',
  size = 220,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;

    // --- Scene, Camera, Renderer ---
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.set(0, 0, 5.5);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(size, size);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0); // โปร่งแสง 100%
    container.appendChild(renderer.domElement);

    // --- สร้างจุดสายฟ้าแบบ Dynamic Lightning Ribbons ---
    const boltCount = 3; // จำนวนแขนสายฟ้ากรงเล็บ
    const pointsPerBolt = 16;
    const boltLines: THREE.Line[] = [];

    const lightningMat = new THREE.LineBasicMaterial({
      color: 0xffe066, // แสงสายฟ้าสีทองสว่าง
      linewidth: 3,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });

    const blueClawMat = new THREE.LineBasicMaterial({
      color: 0x60a5fa, // กรงเล็บประกายสีฟ้าคราม
      linewidth: 2,
      transparent: true,
      opacity: 0.7,
      blending: THREE.AdditiveBlending,
    });

    for (let i = 0; i < boltCount; i++) {
      const positions = new Float32Array(pointsPerBolt * 3);
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      
      const line = new THREE.Line(geometry, i % 2 === 0 ? lightningMat : blueClawMat);
      scene.add(line);
      boltLines.push(line);
    }

    // ฟังก์ชันสุ่มฟาดสายฟ้าแบบกรงเล็บโอบรอบเหรียญ (รัศมี R ~ 1.8)
    const generateClawArc = (line: THREE.Line, baseAngle: number) => {
      const posAttr = line.geometry.attributes.position as THREE.BufferAttribute;
      const array = posAttr.array as Float32Array;
      const radius = 1.9;
      const arcSpread = 0.9; // ความยาวของกรงเล็บ

      for (let j = 0; j < pointsPerBolt; j++) {
        const t = j / (pointsPerBolt - 1);
        const angle = baseAngle + t * arcSpread;
        // การกระตุกแบบหยักของสายฟ้า (Jitter)
        const jitter = (Math.random() - 0.5) * 0.22;
        const r = radius + jitter;

        const x = Math.cos(angle) * r;
        const y = Math.sin(angle) * r;
        const z = (Math.random() - 0.5) * 0.35; // ความลึก 3 มิติ

        array[j * 3] = x;
        array[j * 3 + 1] = y;
        array[j * 3 + 2] = z;
      }
      posAttr.needsUpdate = true;
    };

    // --- Particle สะเก็ดประกายไฟ (Sparks) รอบเหรียญ ---
    const sparkCount = 35;
    const sparkGeo = new THREE.BufferGeometry();
    const sparkPos = new Float32Array(sparkCount * 3);
    for (let i = 0; i < sparkCount * 3; i += 3) {
      const theta = Math.random() * Math.PI * 2;
      const r = 1.6 + Math.random() * 0.5;
      sparkPos[i] = Math.cos(theta) * r;
      sparkPos[i + 1] = Math.sin(theta) * r;
      sparkPos[i + 2] = (Math.random() - 0.5) * 0.6;
    }
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPos, 3));
    const sparkMat = new THREE.PointsMaterial({
      color: 0xfef08a,
      size: 0.08,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });
    const sparkPoints = new THREE.Points(sparkGeo, sparkMat);
    scene.add(sparkPoints);

    // --- Animation Gameloop ---
    let frameId: number;
    let clock = 0;

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      clock += 0.05;

      // สายฟ้าฟาดสุ่มตำแหน่งและจังหวะ (Flash Jitter)
      boltLines.forEach((line, index) => {
        if (Math.random() > 0.45) {
          const baseAngle = clock * 2.2 + (index * (Math.PI * 2)) / boltCount;
          generateClawArc(line, baseAngle);
          line.visible = true;
        } else {
          // จังหวะวาบดับเสี้ยววินาทีให้ดูสมจริง
          line.visible = Math.random() > 0.2;
        }
      });

      // หมุนสะเก็ดไฟเบาๆ
      sparkPoints.rotation.z += 0.015;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(frameId);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [size]);

  return (
    <div
      ref={mountRef}
      className={`pointer-events-none select-none ${className}`}
      style={{ width: size, height: size }}
    />
  );
};