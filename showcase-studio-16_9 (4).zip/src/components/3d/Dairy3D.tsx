import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../utils/audio';
import { setupRealisticLighting, getWoodPBRTexture } from '../../utils/threeTextures';

export interface Dairy3DProps {
  isProducing: boolean;
  productName?: string;
  onClick?: () => void;
  seamless?: boolean;
  className?: string;
}

export const Dairy3D: React.FC<Dairy3DProps> = ({
  isProducing,
  productName,
  onClick,
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 160;
    const height = container.clientHeight || 160;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 5.8);
    camera.lookAt(0, 0.6, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    setupRealisticLighting(scene, renderer);

    const woodMat = track(new THREE.MeshStandardMaterial({ map: getWoodPBRTexture(), color: 0x854d0e, roughness: 0.8 }));
    const roofMat = track(new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.6 }));
    const metalMat = track(new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.7, roughness: 0.3 }));
    const cheeseMat = track(new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.5 }));

    // พื้นไม้โรงแปรรูป
    const floor = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 0.15, 1.5)), woodMat);
    floor.position.y = 0.08;
    floor.receiveShadow = true;
    scene.add(floor);

    // เสาไม้ 4 มุม
    const postGeo = track(new THREE.BoxGeometry(0.1, 1.1, 0.1));
    const postPositions = [
      { x: 0.65, z: 0.6 },
      { x: -0.65, z: 0.6 },
      { x: 0.65, z: -0.6 },
      { x: -0.65, z: -0.6 },
    ];
    postPositions.forEach((pos) => {
      const p = new THREE.Mesh(postGeo, woodMat);
      p.position.set(pos.x, 0.65, pos.z);
      p.castShadow = true;
      scene.add(p);
    });

    // หลังคาทรงจั่วสีฟ้าสดใส (Gabled Blue Roof)
    const roof = new THREE.Mesh(track(new THREE.ConeGeometry(1.2, 0.55, 4)), roofMat);
    roof.position.set(0, 1.4, 0);
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    scene.add(roof);

    // ถังปั่นเนย/นมสแตนเลส (Butter Churn Vat)
    const churnGroup = new THREE.Group();
    churnGroup.position.set(-0.25, 0.45, 0);

    const vat = new THREE.Mesh(track(new THREE.CylinderGeometry(0.35, 0.3, 0.65, 12)), metalMat);
    vat.castShadow = true;
    churnGroup.add(vat);

    // ก้านหมุนปั่นเนย (Churn Handle)
    const handleGroup = new THREE.Group();
    handleGroup.position.y = 0.4;
    const rod = new THREE.Mesh(track(new THREE.CylinderGeometry(0.02, 0.02, 0.25, 6)), metalMat);
    handleGroup.add(rod);
    const arm = new THREE.Mesh(track(new THREE.BoxGeometry(0.25, 0.03, 0.04)), woodMat);
    arm.position.set(0.1, 0.12, 0);
    handleGroup.add(arm);
    churnGroup.add(handleGroup);
    scene.add(churnGroup);

    // ชั้นวางชีสและเนย (Cheese shelf)
    const shelf = new THREE.Mesh(track(new THREE.BoxGeometry(0.4, 0.6, 0.8)), woodMat);
    shelf.position.set(0.45, 0.45, 0.1);
    shelf.castShadow = true;
    scene.add(shelf);

    // ก้อนชีสกลมสีเหลืองทอง (Cheese wheels)
    const cheeseGeo = track(new THREE.CylinderGeometry(0.12, 0.12, 0.08, 10));
    const cheese1 = new THREE.Mesh(cheeseGeo, cheeseMat);
    cheese1.position.set(0.45, 0.8, -0.1);
    scene.add(cheese1);

    const cheese2 = new THREE.Mesh(cheeseGeo, cheeseMat);
    cheese2.position.set(0.45, 0.8, 0.18);
    scene.add(cheese2);

    let animId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      if (isProducing) {
        handleGroup.rotation.y += dt * 5;
        churnGroup.position.y = 0.45 + Math.sin(time * 0.015) * 0.015;
      }

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, [isProducing]);

  const handleClick = () => {
    sound.playClick();
    if (onClick) onClick();
    setActiveSpeech(isProducing ? `กำลังผลิต: ${productName || 'ชีส/เนย'} 🧀🥛` : 'โรงแปรรูปนมเนย 🥛✨');
    setTimeout(() => setActiveSpeech(null), 2000);
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      className={`relative w-full h-full select-none cursor-pointer ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />

      {activeSpeech && (
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-stone-900/90 text-sky-200 text-[10px] font-bold rounded-full border border-sky-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}
    </div>
  );
};
