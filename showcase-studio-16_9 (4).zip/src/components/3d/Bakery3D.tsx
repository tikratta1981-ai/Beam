import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sound } from '../../utils/audio';
import { setupRealisticLighting, getBrickPBRTexture, getWoodPBRTexture } from '../../utils/threeTextures';

export interface Bakery3DProps {
  isProducing: boolean;
  productName?: string;
  onClick?: () => void;
  seamless?: boolean;
  className?: string;
}

export const Bakery3D: React.FC<Bakery3DProps> = ({
  isProducing,
  productName,
  onClick,
  seamless = false,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeSpeech, setActiveSpeech] = useState<string | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const width = container.clientWidth || 160;
    const height = container.clientHeight || 160;

    const disposables: (THREE.BufferGeometry | THREE.Material | THREE.Texture)[] = [];
    const track = <T extends THREE.BufferGeometry | THREE.Material | THREE.Texture>(res: T): T => {
      disposables.push(res);
      return res;
    };

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 5.8);
    camera.lookAt(0, 0.6, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;

    setupRealisticLighting(scene, renderer);

    // แสงไฟเตาอบ (Oven Fire Glow)
    const fireLight = new THREE.PointLight(0xf97316, isProducing ? 3.5 : 1.0, 5);
    fireLight.position.set(0, 0.65, 0.3);
    scene.add(fireLight);

    // ฐานหินเตาอบ (Stone base)
    const stoneMat = track(new THREE.MeshStandardMaterial({ color: 0x78716c, roughness: 0.9 }));
    const brickMat = track(new THREE.MeshStandardMaterial({ map: getBrickPBRTexture(), color: 0xb45309, roughness: 0.8 }));
    const woodMat = track(new THREE.MeshStandardMaterial({ map: getWoodPBRTexture(), color: 0x854d0e, roughness: 0.7 }));
    const breadMat = track(new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.5 }));

    const baseMesh = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 0.45, 1.5)), stoneMat);
    baseMesh.position.y = 0.22;
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    scene.add(baseMesh);

    // โดมเตาอบอิฐแดง (Oven Brick Dome)
    const domeMesh = new THREE.Mesh(
      track(new THREE.SphereGeometry(0.75, 12, 10, 0, Math.PI * 2, 0, Math.PI / 2)),
      brickMat
    );
    domeMesh.position.set(0, 0.45, -0.05);
    domeMesh.castShadow = true;
    scene.add(domeMesh);

    // ช่องเปิดเตาอบ (Oven Arch Opening)
    const archMat = track(new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.9 }));
    const arch = new THREE.Mesh(track(new THREE.CylinderGeometry(0.32, 0.32, 0.35, 10, 1, false, 0, Math.PI)), archMat);
    arch.rotation.x = Math.PI / 2;
    arch.position.set(0, 0.6, 0.6);
    scene.add(arch);

    // ถ่านไฟในเตา
    const embers = new THREE.Mesh(
      track(new THREE.BoxGeometry(0.4, 0.08, 0.3)),
      track(new THREE.MeshBasicMaterial({ color: isProducing ? 0xef4444 : 0x78350f }))
    );
    embers.position.set(0, 0.48, 0.3);
    scene.add(embers);

    // ปล่องไฟเตาอบ (Chimney)
    const chimney = new THREE.Mesh(track(new THREE.BoxGeometry(0.35, 1.2, 0.35)), brickMat);
    chimney.position.set(-0.45, 1.0, -0.45);
    chimney.castShadow = true;
    scene.add(chimney);

    const chimneyCap = new THREE.Mesh(track(new THREE.BoxGeometry(0.45, 0.1, 0.45)), stoneMat);
    chimneyCap.position.set(-0.45, 1.62, -0.45);
    scene.add(chimneyCap);

    // โต๊ะวางถาดขนมปัง (Bread table & Loaves)
    const table = new THREE.Mesh(track(new THREE.BoxGeometry(0.65, 0.4, 0.35)), woodMat);
    table.position.set(0.65, 0.38, 0.65);
    scene.add(table);

    const loaf1 = new THREE.Mesh(track(new THREE.SphereGeometry(0.1, 8, 6)), breadMat);
    loaf1.scale.set(1.4, 0.8, 0.9);
    loaf1.position.set(0.6, 0.63, 0.65);
    loaf1.rotation.y = 0.3;
    scene.add(loaf1);

    const loaf2 = new THREE.Mesh(track(new THREE.CylinderGeometry(0.04, 0.04, 0.28, 6)), breadMat);
    loaf2.rotation.z = Math.PI / 2;
    loaf2.position.set(0.7, 0.63, 0.68);
    scene.add(loaf2);

    // อนุภาคควันลอยจากปล่องไฟ (Smoke particles)
    const smokeMat = track(new THREE.MeshBasicMaterial({ color: 0xe5e5e5, transparent: true, opacity: 0.6 }));
    const smokePuffs: { mesh: THREE.Mesh; vy: number; vx: number; initY: number }[] = [];

    for (let i = 0; i < 5; i++) {
      const puff = new THREE.Mesh(track(new THREE.SphereGeometry(0.1 + i * 0.03, 6, 6)), smokeMat);
      puff.position.set(-0.45, 1.7 + i * 0.28, -0.45);
      scene.add(puff);
      smokePuffs.push({
        mesh: puff,
        vy: 0.5 + Math.random() * 0.3,
        vx: (Math.random() - 0.5) * 0.1,
        initY: 1.7,
      });
    }

    let animId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      animId = requestAnimationFrame(animate);
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      // แสงไฟกะพริบ
      if (isProducing) {
        fireLight.intensity = 2.4 + Math.sin(time * 0.012) * 0.8;
      }

      // ควันลอยขึ้น
      smokePuffs.forEach((p) => {
        p.mesh.position.y += p.vy * dt;
        p.mesh.position.x += p.vx * dt;
        const dist = p.mesh.position.y - p.initY;
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.65 - dist * 0.35);

        if (p.mesh.position.y > p.initY + 1.6) {
          p.mesh.position.set(-0.45, p.initY, -0.45);
        }
      });

      renderer.render(scene, camera);
    };

    animId = requestAnimationFrame(animate);

    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry) return;
      camera.aspect = entry.contentRect.width / entry.contentRect.height;
      camera.updateProjectionMatrix();
      renderer.setSize(entry.contentRect.width, entry.contentRect.height);
    });
    ro.observe(container);

    return () => {
      ro.disconnect();
      cancelAnimationFrame(animId);
      disposables.forEach((item) => item.dispose());
      renderer.dispose();
    };
  }, [isProducing]);

  const handleClick = (e: React.MouseEvent) => {
    sound.playClick();
    if (onClick) onClick();
    setActiveSpeech(isProducing ? `กำลังอบ: ${productName || 'ขนมปัง'} 🍞🔥` : 'เตาอบขนมปังหอมกรุ่น 🍞✨');
    setTimeout(() => setActiveSpeech(null), 2000);
  };

  return (
    <div
      ref={containerRef}
      onClick={handleClick}
      className={`relative w-full h-full select-none cursor-pointer ${
        seamless ? 'overflow-visible bg-transparent' : 'rounded-2xl overflow-hidden'
      } ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full touch-none" />

      {activeSpeech && (
        <div className="absolute -top-7 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-stone-900/90 text-amber-200 text-[10px] font-bold rounded-full border border-amber-400 shadow-xl pointer-events-none whitespace-nowrap z-30 animate-fade-in">
          {activeSpeech}
        </div>
      )}
    </div>
  );
};
