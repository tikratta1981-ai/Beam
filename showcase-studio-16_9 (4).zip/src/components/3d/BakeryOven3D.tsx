import React, { useEffect, useRef, memo } from 'react';
import * as THREE from 'three';

export interface BakeryOven3DProps {
  isProducing: boolean;
  width: number;
  height: number;
}

export const BakeryOven3D: React.FC<BakeryOven3DProps> = memo(({ isProducing, width, height }) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    const aspect = width / height;
    const d = 34;

    const camera = new THREE.OrthographicCamera(
      -d * aspect,
      d * aspect,
      d,
      -d,
      1,
      500
    );
    camera.position.set(70, 85, 70);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'low-power',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 1. แสงไฟในฉาก
    const hemiLight = new THREE.HemisphereLight(0xfff8ea, 0x5a3d1b, 1.2);
    scene.add(hemiLight);

    const sun = new THREE.DirectionalLight(0xffeedd, 1.4);
    sun.position.set(40, 80, 40);
    sun.castShadow = true;
    scene.add(sun);

    // แสงเปลวไฟส้มอบอุ่นจากในเตา (เรืองแสงเมื่อกำลังอบ)
    const fireLight = new THREE.PointLight(0xff7700, isProducing ? 2.5 : 0.4, 40);
    fireLight.position.set(0, 4, 8);
    scene.add(fireLight);

    // 2. ระนาบรับเงาโปร่งใส
    const shadowGeo = new THREE.PlaneGeometry(50, 40);
    const shadowMat = new THREE.ShadowMaterial({ opacity: 0.32 });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.receiveShadow = true;
    scene.add(shadowPlane);

    // 3. โครงสร้างเตาอบ 3D (Base + Dome + Chimney)
    const ovenGroup = new THREE.Group();

    // ฐานหินศิลา (Stone Foundation)
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x6e6259, roughness: 0.9 });
    const baseGeo = new THREE.BoxGeometry(26, 6, 26);
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = 3;
    baseMesh.castShadow = true;
    baseMesh.receiveShadow = true;
    ovenGroup.add(baseMesh);

    // โดมเตาอบอิฐดินเผา (Clay Brick Dome)
    const domeMat = new THREE.MeshStandardMaterial({ color: 0xba5d32, roughness: 0.75 });
    const domeGeo = new THREE.SphereGeometry(12, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2);
    const domeMesh = new THREE.Mesh(domeGeo, domeMat);
    domeMesh.position.y = 6;
    domeMesh.castShadow = true;
    domeMesh.receiveShadow = true;
    ovenGroup.add(domeMesh);

    // ปล่องควันหิน (Stone Chimney)
    const chimneyMat = new THREE.MeshStandardMaterial({ color: 0x5a5047, roughness: 0.95 });
    const chimneyGeo = new THREE.CylinderGeometry(2.8, 3.2, 14, 8);
    const chimney = new THREE.Mesh(chimneyGeo, chimneyMat);
    chimney.position.set(-5, 17, -5);
    chimney.castShadow = true;
    ovenGroup.add(chimney);

    // ปากช่องเตาอบ (Arch Opening)
    const innerFireMat = new THREE.MeshBasicMaterial({ color: isProducing ? 0xff4400 : 0x221100 });
    const mouthGeo = new THREE.CylinderGeometry(4.5, 4.5, 5, 12, 1, false, 0, Math.PI);
    const mouth = new THREE.Mesh(mouthGeo, innerFireMat);
    mouth.rotation.x = Math.PI / 2;
    mouth.position.set(0, 7.5, 10.5);
    ovenGroup.add(mouth);

    // ถาดไม้ใส่ฟืนด้านข้าง
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.8 });
    const woodGeo = new THREE.CylinderGeometry(1.2, 1.2, 8, 6);
    const wood1 = new THREE.Mesh(woodGeo, woodMat);
    wood1.rotation.z = Math.PI / 2;
    wood1.position.set(12, 2, 4);
    ovenGroup.add(wood1);

    scene.add(ovenGroup);

    // 4. อนุภาคควัน 3D (Volumetric Smoke Particles)
    const smokeParticles: THREE.Mesh[] = [];
    const smokeMat = new THREE.MeshStandardMaterial({
      color: 0xeeeeee,
      transparent: true,
      opacity: 0.6,
      roughness: 1.0,
    });
    const smokeGeo = new THREE.DodecahedronGeometry(1.6, 1);

    for (let i = 0; i < 9; i++) {
      const smokeMesh = new THREE.Mesh(smokeGeo, smokeMat.clone());
      smokeMesh.position.set(-5, 23 + i * 2.5, -5);
      smokeMesh.visible = isProducing;
      scene.add(smokeMesh);
      smokeParticles.push(smokeMesh);
    }

    // 5. แอนิเมชันลูป (ควันลอยขึ้น + เปลวไฟกะพริบ)
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // เปลวไฟวูบวาบ
      if (isProducing) {
        fireLight.intensity = 2.0 + Math.sin(elapsed * 12) * 0.8;
      }

      // ฟิสิกส์ควันลอยม้วนตัว
      smokeParticles.forEach((p, idx) => {
        if (!isProducing) {
          p.visible = false;
          return;
        }
        p.visible = true;

        const cycle = ((elapsed * 1.6 + idx * 0.4) % 3.0);
        p.position.y = 23 + cycle * 9;
        p.position.x = -5 + Math.sin(cycle * 3 + idx) * 2.5;
        p.position.z = -5 + Math.cos(cycle * 2 + idx) * 2;

        const s = 0.8 + cycle * 0.7;
        p.scale.set(s, s, s);

        const mat = p.material as THREE.MeshStandardMaterial;
        mat.opacity = Math.max(0, 0.65 - cycle * 0.22);
      });

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();
      baseGeo.dispose();
      baseMat.dispose();
      domeGeo.dispose();
      domeMat.dispose();
      chimneyGeo.dispose();
      chimneyMat.dispose();
      mouthGeo.dispose();
      innerFireMat.dispose();
      woodGeo.dispose();
      woodMat.dispose();
      smokeGeo.dispose();
      smokeParticles.forEach((p) => {
        (p.material as THREE.Material).dispose();
      });
      container.innerHTML = '';
    };
  }, [isProducing, width, height]);

  return <div ref={mountRef} className="w-full h-full pointer-events-none" />;
});
