import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play } from 'lucide-react';
import { sound } from '../utils/audio/index';
import confetti from 'canvas-confetti';
import * as THREE from 'three';

interface LoadingScreenProps {
  isOpen: boolean;
  onFinish: () => void;
}

const LOADING_STEPS = [
  { at: 0, text: '🌾 กำลังจัดเตรียมผืนดินและแปลงเกษตรกรรม...' },
  { at: 18, text: '🌱 เตรียมเมล็ดพันธุ์ข้าวสาลี ข้าวโพด และพืชผัก...' },
  { at: 38, text: '🐔 ตรวจเช็กเล้าไก่ ทุ่งแกะ และคอกโคนม...' },
  { at: 58, text: '🍞 อุ่นเตาอบขนมปังและจัดระเบียบโรงนา...' },
  { at: 78, text: '🚚 เตรียมกระดานส่งสินค้าตลาดเมืองบางแค...' },
  { at: 92, text: '✨ ซิงค์ข้อมูลฟาร์มของคุณให้พร้อมสมบูรณ์...' },
  { at: 100, text: '🎉 ระบบเตรียมความพร้อม 100% เรียบร้อยแล้ว!' },
];

/**
 * ⚡ คอมโพเนนต์สายฟ้ากรงเล็บ 3D (3D Lightning Claws Overlay)
 * แสดงผลเป็นเลเยอร์โปร่งใส ไม่กระทบการคลิกหรือตรรกะของเกม
 */
const LightningClawsOverlay: React.FC<{ size?: number }> = ({ size = 230 }) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;

    // สร้าง Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.set(0, 0, 5.5);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(size, size);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0); // พื้นหลังโปร่งใส 100%
    container.appendChild(renderer.domElement);

    // วัสดุสายฟ้าทองคำ และกรงเล็บประกายฟ้าคราม
    const goldBoltMat = new THREE.LineBasicMaterial({
      color: 0xffdf5e,
      linewidth: 3,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
    });

    const cyanBoltMat = new THREE.LineBasicMaterial({
      color: 0x67e8f9,
      linewidth: 2,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });

    // สร้างกรงเล็บสายฟ้า 4 เส้นหลัก
    const boltCount = 4;
    const pointsPerBolt = 18;
    const boltLines: THREE.Line[] = [];

    for (let i = 0; i < boltCount; i++) {
      const positions = new Float32Array(pointsPerBolt * 3);
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const line = new THREE.Line(geometry, i % 2 === 0 ? goldBoltMat : cyanBoltMat);
      scene.add(line);
      boltLines.push(line);
    }

    // ฟังก์ชันคำนวณส่วนโค้งสายฟ้าตวัดแบบกรงเล็บ (Claw Arcs)
    const updateClawArc = (line: THREE.Line, baseAngle: number) => {
      const posAttr = line.geometry.attributes.position as THREE.BufferAttribute;
      const array = posAttr.array as Float32Array;
      const radius = 1.95; // โอบรอบรัศมีเหรียญ B.P.
      const arcSpread = 0.85;

      for (let j = 0; j < pointsPerBolt; j++) {
        const t = j / (pointsPerBolt - 1);
        const angle = baseAngle + t * arcSpread;
        // การกระตุกแบบหยักของสายฟ้า (Jitter & Sharp Claws)
        const jitter = (Math.random() - 0.5) * 0.24;
        const r = radius + jitter;

        array[j * 3] = Math.cos(angle) * r;
        array[j * 3 + 1] = Math.sin(angle) * r;
        array[j * 3 + 2] = (Math.random() - 0.5) * 0.35; // ความลึก 3 มิติ
      }
      posAttr.needsUpdate = true;
    };

    // สะเก็ดประกายไฟ 3D วิ่งวนรอบเหรียญ
    const sparkCount = 36;
    const sparkGeo = new THREE.BufferGeometry();
    const sparkPos = new Float32Array(sparkCount * 3);
    for (let i = 0; i < sparkCount * 3; i += 3) {
      const angle = Math.random() * Math.PI * 2;
      const r = 1.65 + Math.random() * 0.55;
      sparkPos[i] = Math.cos(angle) * r;
      sparkPos[i + 1] = Math.sin(angle) * r;
      sparkPos[i + 2] = (Math.random() - 0.5) * 0.5;
    }
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPos, 3));
    const sparkMat = new THREE.PointsMaterial({
      color: 0xfef08a,
      size: 0.085,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const sparks = new THREE.Points(sparkGeo, sparkMat);
    scene.add(sparks);

    // แอนิเมชันลูป 60 FPS
    let animId: number;
    let clock = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      clock += 0.06;

      // สุ่มฟาดและวาบสายฟ้า
      boltLines.forEach((line, idx) => {
        if (Math.random() > 0.38) {
          const baseAngle = clock * 2.4 + (idx * (Math.PI * 2)) / boltCount;
          updateClawArc(line, baseAngle);
          line.visible = true;
        } else {
          line.visible = Math.random() > 0.25;
        }
      });

      // หมุนสะเก็ดไฟเบาๆ
      sparks.rotation.z += 0.015;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [size]);

  return (
    <div
      ref={mountRef}
      className="pointer-events-none select-none"
      style={{ width: size, height: size }}
    />
  );
};

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ isOpen, onFinish }) => {
  const [progress, setProgress] = useState<number>(0);
  const [statusText, setStatusText] = useState<string>('🌾 กำลังเริ่มต้นระบบฟาร์ม...');
  const [isReady, setIsReady] = useState<boolean>(false);
  const [soundMuted, setSoundMuted] = useState<boolean>(!sound.soundEnabled);
  const [fadeOut, setFadeOut] = useState<boolean>(false);

  const lastSoundMilestoneRef = useRef<number>(-1);
  const intervalRef = useRef<number | null>(null);

  // เริ่มต้นกระบวนการโหลด 0 -> 100%
  useEffect(() => {
    if (!isOpen) return;

    setProgress(0);
    setIsReady(false);
    setFadeOut(false);
    lastSoundMilestoneRef.current = -1;

    // จำลองการโหลดแบบมีสเต็ปนุ่มนวล
    intervalRef.current = window.setInterval(() => {
      setProgress((prev) => {
        let increment = Math.floor(Math.random() * 4) + 2;
        if (prev >= 80 && prev < 95) increment = 2;
        if (prev >= 95) increment = 1;

        const next = Math.min(100, prev + increment);

        // อัปเดตข้อความสเตตัสตามช่วงเปอร์เซ็นต์
        const currentStep = [...LOADING_STEPS].reverse().find((s) => next >= s.at);
        if (currentStep) {
          setStatusText(currentStep.text);
        }

        // เล่นเสียง SFX เมื่อถึงก้าวสำคัญ (ทุกๆ 15%)
        const milestone = Math.floor(next / 15);
        if (milestone > lastSoundMilestoneRef.current && next < 100) {
          lastSoundMilestoneRef.current = milestone;
          try {
            sound.playLoadingTick(next);
          } catch {}
        }

        // เมื่อถึง 100%
        if (next >= 100) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          setIsReady(true);
          try {
            sound.playLoadingComplete();
            confetti({
              particleCount: 80,
              spread: 80,
              origin: { y: 0.65 },
            });
          } catch {}
        }

        return next;
      });
    }, 60);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isOpen]);

  // สลับเสียง
  const handleToggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextState = !soundMuted;
    setSoundMuted(nextState);
    sound.soundEnabled = !nextState;
    if (!nextState) {
      try {
        sound.playClick();
      } catch {}
    }
  };

  // กดยืนยันเข้าเกม
  const handleEnterGame = () => {
    try {
      sound.playSuccessChime();
    } catch {}
    setFadeOut(true);
    setTimeout(() => {
      onFinish();
    }, 450);
  };

  if (!isOpen) return null;

  return (
    <div
      onClick={() => {
        if (isReady) handleEnterGame();
      }}
      className={`fixed inset-0 z-[9999] flex flex-col justify-between select-none overflow-hidden transition-opacity duration-500 ${
        fadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* ภาพพื้นหลัง Splash Screen คุณภาพสูง */}
      <div className="absolute inset-0">
        <img
          src="/loading_screen.jpg"
          alt="Beam Farm Splash"
          className="w-full h-full object-cover object-center filter brightness-95"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/farm_bg.jpg';
          }}
        />
        {/* ฟิล์มเกรเดียนท์เพิ่มมิติความคมชัด */}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/50 to-black/40" />
      </div>

      {/* แถบด้านบน: โลโก้ และปุ่มเปิด/ปิดเสียง */}
      <div className="relative z-10 flex items-center justify-between p-4 sm:p-6 pointer-events-auto">
        <div className="flex items-center gap-2.5 bg-stone-900/85 border-2 border-amber-400/90 rounded-2xl px-4 py-2 shadow-2xl backdrop-blur-md">
          <span className="text-2xl sm:text-3xl">🌾</span>
          <div>
            <h1 className="text-base sm:text-lg font-black text-amber-200 tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
              Beam Farm (B.P.)
            </h1>
            <span className="text-[10px] sm:text-xs text-amber-300 font-bold block -mt-0.5">
              ปลูกวันนี้... เพื่ออนาคตที่ดีกว่า
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleToggleSound}
          className="flex items-center gap-1.5 bg-stone-900/85 hover:bg-stone-800 border-2 border-amber-400/80 text-amber-200 hover:text-white px-3 py-2 rounded-2xl shadow-2xl transition-all active:scale-95 cursor-pointer backdrop-blur-md"
          title={soundMuted ? 'เปิดเสียง' : 'ปิดเสียง'}
        >
          {soundMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />}
          <span className="text-xs font-bold">{soundMuted ? 'ปิดเสียง' : 'เปิดเสียง'}</span>
        </button>
      </div>

      {/* ส่วนล่าง: ตราเหรียญทานตะวัน B.P. + สายฟ้ากรงเล็บ 3D เหนือหลอดโหลดโดยตรง */}
      <div className="relative z-10 w-full max-w-xl mx-auto px-4 pb-6 sm:pb-10 pointer-events-auto flex flex-col items-center">
        
        {/* 🌟 1. ตราสัญลักษณ์เหรียญทองทานตะวัน B.P. + กรงเล็บสายฟ้า 3D (ลบป้ายออกแล้ว) */}
        <div className="relative mb-5 flex items-center justify-center pointer-events-none">
          {/* แสงออร่าสีทองเปล่งประกายด้านหลัง */}
          <div className="absolute inset-0 rounded-full bg-amber-400/30 blur-2xl animate-pulse scale-95" />
          
          {/* รูปเหรียญทองทานตะวัน B.P. */}
          <img
            src="/logo_bp.png"
            alt="Emblem B.P."
            className="relative z-10 w-40 h-40 sm:w-48 sm:h-48 object-contain drop-shadow-[0_12px_28px_rgba(0,0,0,0.85)] animate-gentle-breathe"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />

          {/* ⚡ เอฟเฟกต์กรงเล็บสายฟ้า 3D Overlay ล้อมรอบเหรียญ */}
          <div className="absolute z-20 inset-0 flex items-center justify-center">
            <LightningClawsOverlay size={240} />
          </div>
        </div>

        {/* 📊 2. แผงควบคุมหลอด Progress Bar 0% - 100% & ปุ่มเข้าเกม */}
        <div className="bg-stone-950/85 border-[3px] border-amber-500/80 rounded-3xl p-4 sm:p-5 shadow-2xl backdrop-blur-md flex flex-col gap-3 w-full">
          {/* ข้อความสเตตัสและตัวเลขอัตราร้อยละ */}
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <span className="font-extrabold text-amber-200 tracking-wide flex items-center gap-1.5 truncate max-w-[80%]">
              <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              {statusText}
            </span>
            <span className="font-black text-base sm:text-lg text-yellow-300 drop-shadow">
              {progress}%
            </span>
          </div>

          {/* หลอดความคืบหน้า 3D สีทอง พร้อมเอฟเฟกต์แสงสะท้อน */}
          <div className="relative w-full h-6 sm:h-7 bg-stone-900 rounded-full overflow-hidden border-2 border-amber-600/90 shadow-inner p-0.5">
            <div
              className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-150 ease-out shadow-[0_0_12px_rgba(251,191,36,0.6)] relative overflow-hidden"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/35 to-transparent w-full animate-[shimmer_1.8s_infinite]" />
            </div>

            {/* ไอคอนนำทางตามหัวหลอด */}
            {progress > 5 && progress < 100 && (
              <div
                className="absolute top-1/2 -translate-y-1/2 text-sm sm:text-base pointer-events-none transition-all duration-150"
                style={{ left: `calc(${progress}% - 14px)` }}
              >
                🚜
              </div>
            )}
          </div>

          {/* ปุ่มพร้อมเข้าสู่ฟาร์มเมื่อครบ 100% */}
          {isReady ? (
            <button
              type="button"
              onClick={handleEnterGame}
              className="w-full py-3 sm:py-3.5 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:brightness-110 text-white font-black text-sm sm:text-base rounded-2xl shadow-[0_0_20px_rgba(16,185,129,0.7)] border-2 border-white animate-bounce flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>แตะเพื่อเข้าสู่ฟาร์มทันที (Enter Farm)</span>
            </button>
          ) : (
            <div className="text-center text-[11px] text-stone-400">
              แตะที่ใดก็ได้เพื่อเปิดใช้งานเสียง • ระบบกำลังเตรียมทรัพยากร
            </div>
          )}
        </div>

      </div>
    </div>
  );
};