import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  AudioTierState,
  TMJState,
  RigPin,
  StudioConfig,
  AmuletData,
  AmuletViewMode,
} from '../types/viseme';
import { AvatarRenderer, DEFAULT_RIG_PINS } from '../avatar/avatar-renderer';
import { globalHairRig } from '../physics/hair-rig';
import { Anatomy3DEngine } from '../utils/three/anatomy-3d-engine';

interface StudioCanvas169Props {
  audioState: AudioTierState;
  tmjState: TMJState;
  config: StudioConfig;
  selectedAmulet: AmuletData;
  amuletAngle: AmuletViewMode;
  isRecording: boolean;
  recordingSeconds: number;
  onPinChange?: (pins: RigPin[]) => void;
  anatomyEngine: Anatomy3DEngine | null;
}

export const StudioCanvas169: React.FC<StudioCanvas169Props> = ({
  audioState,
  tmjState,
  config,
  selectedAmulet,
  amuletAngle,
  isRecording,
  recordingSeconds,
  onPinChange,
  anatomyEngine,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const avatarRendererRef = useRef<AvatarRenderer>(new AvatarRenderer());
  const [pins, setPins] = useState<RigPin[]>(DEFAULT_RIG_PINS);
  const [draggedPinId, setDraggedPinId] = useState<string | null>(null);

  // Optical Loupe zoom state
  const [loupeActive, setLoupeActive] = useState(false);
  const [loupePos, setLoupePos] = useState({ x: 0.8, y: 0.45 });

  // Amulet image cache
  const amuletImagesRef = useRef<{ [key: string]: HTMLImageElement }>({});

  useEffect(() => {
    // Preload amulet SVG views
    ['front', 'back', 'edge', 'base'].forEach(angle => {
      const src = selectedAmulet.views[angle as AmuletViewMode];
      if (src && !amuletImagesRef.current[`${selectedAmulet.id}_${angle}`]) {
        const img = new Image();
        img.src = src;
        amuletImagesRef.current[`${selectedAmulet.id}_${angle}`] = img;
      }
    });
  }, [selectedAmulet]);

  // Main 60 FPS Render Loop
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const render = (time: number) => {
      animId = requestAnimationFrame(render);
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = canvas.width;
      const height = canvas.height;

      // Update avatar blink state
      avatarRendererRef.current.update(dt);

      // 1. Clear & Render Studio Backdrop
      drawStudioBackground(ctx, width, height, config.studioTheme);

      // 2. Render 3D Skeleton underlay if overlay mode enabled
      if (config.showSkeleton3D && config.skeletonPosition === 'overlay' && anatomyEngine) {
        const threeDom = anatomyEngine.getDomElement();
        if (threeDom) {
          ctx.save();
          ctx.globalAlpha = config.skeletonOpacity;
          // Center three.js skeletal overlay directly on avatar chest/head
          const sWidth = width * 0.55;
          const sHeight = height * 0.95;
          const sx = (width - sWidth) * 0.42;
          const sy = (height - sHeight) * 0.45;
          ctx.drawImage(threeDom, sx, sy, sWidth, sHeight);
          ctx.restore();
        }
      }

      // 3. Render Biomechanical Avatar
      avatarRendererRef.current.render(
        ctx,
        width,
        height,
        tmjState,
        audioState.visemes,
        pins,
        globalHairRig,
        config.avatarMode,
        config.showPins
      );

      // 4. Render 3D Skeleton Picture-In-Picture (PIP) if PIP mode selected
      if (config.showSkeleton3D && config.skeletonPosition === 'pip' && anatomyEngine) {
        const threeDom = anatomyEngine.getDomElement();
        if (threeDom) {
          drawSkeletonPIP(ctx, width, height, threeDom, config.skeletonOpacity);
        }
      }

      // 5. Render Amulet Showcase Stage
      if (config.showAmulet) {
        drawAmuletStage(
          ctx,
          width,
          height,
          selectedAmulet,
          amuletAngle,
          amuletImagesRef.current,
          config.amuletMode,
          loupeActive,
          loupePos
        );
      }

      // 6. Real-time Studio HUD & Safe Zones
      if (config.showHUD) {
        drawStudioHUD(ctx, width, height, audioState, tmjState, isRecording, recordingSeconds);
      }
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [audioState, tmjState, config, selectedAmulet, amuletAngle, pins, isRecording, recordingSeconds, anatomyEngine, loupeActive, loupePos]);

  // Background Theme Renderer
  const drawStudioBackground = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    theme: StudioConfig['studioTheme']
  ) => {
    const bgGrad = ctx.createRadialGradient(w * 0.5, h * 0.45, 100, w * 0.5, h * 0.5, w * 0.7);

    if (theme === 'velvet-red') {
      bgGrad.addColorStop(0, '#380a12');
      bgGrad.addColorStop(0.65, '#1e0409');
      bgGrad.addColorStop(1, '#0b0103');
    } else if (theme === 'deep-obsidian') {
      bgGrad.addColorStop(0, '#101721');
      bgGrad.addColorStop(0.6, '#080d14');
      bgGrad.addColorStop(1, '#020407');
    } else if (theme === 'gold-sanctuary') {
      bgGrad.addColorStop(0, '#2d1f0b');
      bgGrad.addColorStop(0.6, '#180f04');
      bgGrad.addColorStop(1, '#090501');
    } else {
      // cyber-cyan
      bgGrad.addColorStop(0, '#0a2333');
      bgGrad.addColorStop(0.65, '#05121b');
      bgGrad.addColorStop(1, '#02070a');
    }

    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Subtle Studio Grid Lines
    ctx.strokeStyle = theme === 'cyber-cyan' ? 'rgba(0, 240, 255, 0.05)' : 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    const gridSize = 60;
    for (let x = 0; x < w; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
  };

  // Skeleton PIP in corner
  const drawSkeletonPIP = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    threeDom: HTMLCanvasElement,
    opacity: number
  ) => {
    const pipW = w * 0.24;
    const pipH = pipW * (9 / 16);
    const pipX = 24;
    const pipY = h - pipH - 24;

    ctx.save();
    // Glassmorphic backing
    ctx.fillStyle = 'rgba(6, 18, 28, 0.85)';
    ctx.beginPath();
    ctx.roundRect(pipX, pipY, pipW, pipH, 8);
    ctx.fill();

    // Border
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.6)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Render Three.js canvas in PIP
    ctx.globalAlpha = opacity;
    ctx.drawImage(threeDom, pipX + 4, pipY + 4, pipW - 8, pipH - 8);

    // Label
    ctx.globalAlpha = 1.0;
    ctx.font = 'bold 10px monospace';
    ctx.fillStyle = '#00f0ff';
    ctx.fillText('3D X-RAY SKELETON (TMJ)', pipX + 12, pipY + 18);
    ctx.restore();
  };

  // Amulet Showcase Stage with 4 angles & plaque
  const drawAmuletStage = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    amulet: AmuletData,
    angle: AmuletViewMode,
    imageCache: { [key: string]: HTMLImageElement },
    mode: 'floating' | 'pip' | 'side-by-side',
    isLoupe: boolean,
    loupe: { x: number; y: number }
  ) => {
    ctx.save();
    const stageW = w * 0.32;
    const stageH = h * 0.76;
    const stageX = w * 0.64;
    const stageY = h * 0.12;

    // Display Card Container
    ctx.beginPath();
    ctx.roundRect(stageX, stageY, stageW, stageH, 12);
    ctx.fillStyle = 'rgba(12, 10, 8, 0.78)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.6)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Gold Corner Accents
    const cornerSize = 14;
    ctx.strokeStyle = '#ffd700';
    ctx.lineWidth = 2.5;
    // Top-left
    ctx.beginPath();
    ctx.moveTo(stageX, stageY + cornerSize);
    ctx.lineTo(stageX, stageY);
    ctx.lineTo(stageX + cornerSize, stageY);
    ctx.stroke();
    // Top-right
    ctx.beginPath();
    ctx.moveTo(stageX + stageW - cornerSize, stageY);
    ctx.lineTo(stageX + stageW, stageY);
    ctx.lineTo(stageX + stageW, stageY + cornerSize);
    ctx.stroke();

    // Plaque Header
    ctx.font = 'bold 15px sans-serif';
    ctx.fillStyle = '#ffd700';
    ctx.fillText(amulet.thaiName, stageX + 18, stageY + 34);

    ctx.font = '11px sans-serif';
    ctx.fillStyle = '#c5b494';
    ctx.fillText(amulet.name, stageX + 18, stageY + 52);

    // 4 Angles Tabs indicator
    const tabY = stageY + 68;
    const tabW = (stageW - 36) / 4;
    const angles: { key: AmuletViewMode; label: string }[] = [
      { key: 'front', label: 'หน้า FRONT' },
      { key: 'back', label: 'หลัง BACK' },
      { key: 'edge', label: 'ขอบ EDGE' },
      { key: 'base', label: 'ก้น BASE' },
    ];

    angles.forEach((item, idx) => {
      const tx = stageX + 18 + idx * tabW;
      const isSelected = item.key === angle;

      ctx.beginPath();
      ctx.roundRect(tx, tabY, tabW - 4, 22, 4);
      ctx.fillStyle = isSelected ? 'rgba(212, 175, 55, 0.35)' : 'rgba(255, 255, 255, 0.06)';
      ctx.fill();
      if (isSelected) {
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }

      ctx.font = isSelected ? 'bold 10px sans-serif' : '9px sans-serif';
      ctx.fillStyle = isSelected ? '#ffffff' : '#998e79';
      ctx.textAlign = 'center';
      ctx.fillText(item.label, tx + (tabW - 4) / 2, tabY + 15);
      ctx.textAlign = 'left';
    });

    // Amulet Center Display Box
    const boxX = stageX + 24;
    const boxY = stageY + 104;
    const boxW = stageW - 48;
    const boxH = stageH * 0.58;

    // Glowing Halo background
    const haloGrad = ctx.createRadialGradient(boxX + boxW / 2, boxY + boxH / 2, 20, boxX + boxW / 2, boxY + boxH / 2, boxW * 0.6);
    haloGrad.addColorStop(0, 'rgba(255, 215, 0, 0.22)');
    haloGrad.addColorStop(0.7, 'rgba(212, 175, 55, 0.06)');
    haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = haloGrad;
    ctx.fillRect(boxX, boxY, boxW, boxH);

    // Draw Amulet Image
    const cachedImg = imageCache[`${amulet.id}_${angle}`];
    if (cachedImg && cachedImg.complete) {
      const imgAspect = cachedImg.naturalWidth / (cachedImg.naturalHeight || 1);
      let drawW = boxW * 0.78;
      let drawH = drawW / imgAspect;
      if (drawH > boxH * 0.92) {
        drawH = boxH * 0.92;
        drawW = drawH * imgAspect;
      }
      const dx = boxX + (boxW - drawW) / 2;
      const dy = boxY + (boxH - drawH) / 2;

      ctx.drawImage(cachedImg, dx, dy, drawW, drawH);

      // Loupe Magnifier Lens
      if (isLoupe) {
        const lx = w * loupe.x;
        const ly = h * loupe.y;
        const radius = 45;

        ctx.save();
        ctx.beginPath();
        ctx.arc(lx, ly, radius, 0, Math.PI * 2);
        ctx.clip();

        // 2x optical zoom
        ctx.fillStyle = '#1c150e';
        ctx.fillRect(lx - radius, ly - radius, radius * 2, radius * 2);
        ctx.drawImage(
          cachedImg,
          (lx - dx) * 0.8,
          (ly - dy) * 0.8,
          drawW * 2,
          drawH * 2
        );

        ctx.restore();

        // Loupe Brass Ring
        ctx.beginPath();
        ctx.arc(lx, ly, radius, 0, Math.PI * 2);
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 3;
        ctx.stroke();
      }
    }

    // Historical Metadata Footer
    const footerY = stageY + stageH - 56;
    ctx.font = '10px sans-serif';
    ctx.fillStyle = '#e2d1b3';
    ctx.fillText(`แหล่งกำเนิด: ${amulet.origin}`, stageX + 18, footerY);
    ctx.fillText(`ยุคสมัย: ${amulet.era}`, stageX + 18, footerY + 16);
    ctx.fillText(`มวลสาร: ${amulet.material}`, stageX + 18, footerY + 32);

    ctx.restore();
  };

  // Tri-Rate HUD & Broadcast Overlay
  const drawStudioHUD = (
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    audio: AudioTierState,
    tmj: TMJState,
    recording: boolean,
    recSecs: number
  ) => {
    ctx.save();

    // 1. Top Broadcast Bar
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.fillRect(0, 0, w, 38);

    // Title / Logo
    ctx.font = 'bold 13px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('SHOWCASE STUDIO 16:9', 24, 24);

    ctx.font = '11px monospace';
    ctx.fillStyle = '#00f0ff';
    ctx.fillText('v2.0.0 BIOMECHANICAL', 188, 24);

    // Tri-Rate Badges
    const badgeX = 350;
    ctx.font = '10px monospace';
    ctx.fillStyle = '#34d399';
    ctx.fillText('● 240Hz AUDIO DSP', badgeX, 24);
    ctx.fillStyle = '#60a5fa';
    ctx.fillText('● 120Hz TMJ PHYSICS', badgeX + 140, 24);
    ctx.fillStyle = '#f472b6';
    ctx.fillText('● 60Hz 1080p ENCODE', badgeX + 300, 24);

    // Recording Indicator
    if (recording) {
      const isPulse = Math.floor(Date.now() / 500) % 2 === 0;
      ctx.beginPath();
      ctx.arc(w - 110, 19, 6, 0, Math.PI * 2);
      ctx.fillStyle = isPulse ? '#ef4444' : '#991b1b';
      ctx.fill();

      ctx.font = 'bold 12px monospace';
      ctx.fillStyle = '#ef4444';
      const mm = Math.floor(recSecs / 60).toString().padStart(2, '0');
      const ss = (recSecs % 60).toString().padStart(2, '0');
      ctx.fillText(`REC ${mm}:${ss}`, w - 95, 24);
    }

    // 2. Bottom Telemetry Bar
    const botY = h - 36;
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.fillRect(0, botY, w, 36);

    // Thai Visemes Real-time Readout
    ctx.font = '11px sans-serif';
    ctx.fillStyle = '#e2e8f0';
    let activeViseme = 'IDLE พักกราม';
    if (audio.visemes.lipLock > 0.4) activeViseme = 'ม/บ/พ/ป (Lip Lock)';
    else if (audio.visemes.pharynxOpen > 0.3) activeViseme = 'อา/อะ (Pharynx Open)';
    else if (audio.visemes.zygoSpread > 0.3) activeViseme = 'อี/เอ (Zygo Spread)';
    else if (audio.visemes.orbicRound > 0.3) activeViseme = 'อู/โอ (Orbic Round)';
    else if (audio.visemes.tipCurl > 0.3) activeViseme = 'ด/ต/น/ล/ร (Tip Curl)';
    else if (audio.visemes.velarDorsum > 0.3) activeViseme = 'ก/ข/ค/ง (Velar Dorsum)';
    else if (audio.visemes.dentalTuck > 0.3) activeViseme = 'ฟ/ฝ (Dental Tuck)';

    ctx.fillText(`สระภาษาไทย: ${activeViseme}`, 24, botY + 22);

    // TMJ Condyle displacement
    ctx.font = '10px monospace';
    ctx.fillStyle = '#38bdf8';
    const angleDeg = (tmj.jawAngle * (180 / Math.PI)).toFixed(1);
    ctx.fillText(`TMJ θ: ${angleDeg}° | Y: ${tmj.jawTranslationY.toFixed(1)}mm | Z: ${tmj.jawTranslationZ.toFixed(1)}mm`, 260, botY + 22);

    // Audio Formants
    ctx.fillStyle = '#a78bfa';
    ctx.fillText(`F1: ${audio.formants.f1}Hz | F2: ${audio.formants.f2}Hz`, 560, botY + 22);

    // Respiration cycle
    ctx.fillStyle = '#34d399';
    const breathSec = (tmj.respirationPhase / (Math.PI * 2) * 3.8).toFixed(1);
    ctx.fillText(`Respiration: ${breathSec}s/3.8s`, 730, botY + 22);

    ctx.restore();
  };

  // Mouse & Touch interaction for Draggable Golden Pins
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    // Check click on Loupe toggle
    if (e.shiftKey) {
      setLoupeActive(!loupeActive);
      setLoupePos({ x: (e.clientX - rect.left) / rect.width, y: (e.clientY - rect.top) / rect.height });
      return;
    }

    if (!config.showPins) return;

    // Find nearest pin
    const cx = canvas.width * 0.48;
    const cy = canvas.height * 0.48;
    const scale = Math.min(canvas.width, canvas.height) * 0.0028;

    pins.forEach(pin => {
      const px = cx + (pin.normX - 0.5) * 120 * scale;
      const py = cy + (pin.normY - 0.5) * 160 * scale;
      const dist = Math.hypot(x - px, y - py);
      if (dist < 18) {
        setDraggedPinId(pin.id);
      }
    });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (loupeActive) {
      const canvas = canvasRef.current;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        setLoupePos({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        });
      }
    }

    if (!draggedPinId || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const cx = canvas.width * 0.48;
    const cy = canvas.height * 0.48;
    const scale = Math.min(canvas.width, canvas.height) * 0.0028;

    const normX = Math.max(0, Math.min(1, (x - cx) / (120 * scale) + 0.5));
    const normY = Math.max(0, Math.min(1, (y - cy) / (160 * scale) + 0.5));

    const updated = pins.map(p => (p.id === draggedPinId ? { ...p, normX, normY } : p));
    setPins(updated);
    if (onPinChange) onPinChange(updated);
  };

  const handleMouseUp = () => {
    setDraggedPinId(null);
  };

  return (
    <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden shadow-2xl border border-neutral-800">
      <canvas
        id="showcase-studio-main-canvas"
        ref={canvasRef}
        width={1920}
        height={1080}
        className="w-full h-full object-contain cursor-crosshair"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
    </div>
  );
};
