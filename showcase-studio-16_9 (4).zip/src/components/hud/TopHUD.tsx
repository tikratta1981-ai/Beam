import React, { useState, useRef, useCallback } from 'react';
import { Settings, Plus, Mail, Users, Volume2, VolumeX, Music, Camera, Cloud, User } from 'lucide-react';
import { sound } from '../../utils/audio/index';
import { UserProfile } from '../../types/auth';

interface TopHUDProps {
  coins: number;
  gems: number;
  energy: number;
  maxEnergy: number;
  energyTimer: string;
  level: number;
  xp: number;
  maxXp: number;
  farmName: string;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onOpenSettings: () => void;
  onOpenMail: () => void;
  onOpenFriends: () => void;
  onOpenShop: (tab?: string) => void;
  onOpenCloudSync?: () => void;
  onOpenAuth?: () => void;
  currentUser?: UserProfile | null;
  unreadMailCount: number;
}

export const TopHUD: React.FC<TopHUDProps> = ({
  coins,
  gems,
  energy,
  maxEnergy,
  energyTimer,
  level,
  xp,
  maxXp,
  farmName,
  soundEnabled,
  musicEnabled,
  onToggleSound,
  onToggleMusic,
  onOpenSettings,
  onOpenMail,
  onOpenFriends,
  onOpenShop,
  onOpenCloudSync,
  onOpenAuth,
  currentUser,
  unreadMailCount,
}) => {
  const xpPercent = Math.min(100, Math.round((xp / maxXp) * 100));
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Helper สั่งงานทันทีโดยไม่มี delay 300ms บน Touchscreen และตัดการส่งผ่าน Event ไปยังแผนที่
  const fastAction = useCallback((callback?: () => void, playSound: boolean = true) => {
    return (e: React.MouseEvent | React.PointerEvent) => {
      e.stopPropagation();
      if (playSound) {
        try {
          sound.playClick();
        } catch {}
      }
      if (callback) {
        callback();
      }
    };
  }, []);

  // ดึงรูปโปรไฟล์ที่เคยเซฟไว้ หรือใช้รูปเริ่มต้น
  const [avatarUrl, setAvatarUrl] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('beam_farm_player_avatar');
      if (saved) return saved;
    } catch {}
    return '/src/assets/images/farmer_boy_avatar_1790916713349.jpg';
  });

  // เมื่อคลิกที่รูปวงกลมตัวละคร
  const handleAvatarClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    try { sound.playClick(); } catch {}
    fileInputRef.current?.click();
  };

  // จัดการเมื่อเลือกไฟล์รูปภาพจากเครื่อง
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('กรุณาเลือกไฟล์รูปภาพเท่านั้นครับ (PNG, JPG, WebP)');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('ขนาดรูปภาพใหญ่เกินไป (ไม่ควรเกิน 5MB)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Data = event.target?.result as string;
      if (base64Data) {
        setAvatarUrl(base64Data);
        try {
          localStorage.setItem('beam_farm_player_avatar', base64Data);
          try { sound.playSuccessChime(); } catch {}
        } catch (err) {
          console.warn('LocalStorage error:', err);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <header className="hud-top relative z-30 flex flex-wrap items-center justify-between gap-2 p-2 sm:p-3 pointer-events-none select-none">
      {/* Input File สำหรับเลือกรูป */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Left: Player Profile & Level */}
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        className="hud-profile pointer-events-auto flex items-center gap-2 game-wood-panel rounded-2xl p-1.5 sm:p-2 pr-3 shadow-lg touch-manipulation"
      >
        {/* Avatar Frame */}
        <div
          className="relative group cursor-pointer touch-manipulation active:scale-95 transition-transform"
          onClick={handleAvatarClick}
          title="คลิกเพื่ออัปโหลดรูปโปรไฟล์ตัวเอง"
        >
          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 border-amber-300 overflow-hidden bg-gradient-to-b from-sky-300 to-emerald-400 flex items-center justify-center shadow-md relative group-hover:scale-105 transition-transform">
            <img
              src={avatarUrl}
              alt="Farmer Avatar"
              className="w-full h-full object-cover select-none pointer-events-none"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <span className="text-2xl sm:text-3xl select-none hidden" role="img" aria-label="Farmer">
              🧑‍🌾
            </span>

            <div className="absolute inset-0 bg-black/55 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white">
              <Camera className="w-4 h-4 sm:w-5 sm:h-5 drop-shadow" />
              <span className="text-[7px] sm:text-[8px] font-bold mt-0.5 tracking-tight drop-shadow">เปลี่ยนรูป</span>
            </div>
          </div>

          {/* Level Badge */}
          <div className="absolute -bottom-1 -left-1 bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-900 font-extrabold text-[10px] sm:text-xs px-1.5 py-0.5 rounded-full border border-amber-200 shadow z-10 pointer-events-none">
            Lv. {level}
          </div>
        </div>

        {/* Name & XP Bar */}
        <div className="flex flex-col justify-center min-w-[120px] sm:min-w-[155px]">
          <div className="flex items-center justify-between gap-1 text-white text-xs sm:text-sm font-bold drop-shadow">
            <span className="truncate max-w-[110px] sm:max-w-[140px] font-black">{farmName}</span>
            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={fastAction(onOpenSettings)}
              className="text-amber-200 hover:text-white active:scale-90 transition-transform cursor-pointer p-1 rounded hover:bg-white/10 touch-manipulation"
              title="ตั้งค่า"
            >
              <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4 pointer-events-none" />
            </button>
          </div>

          {/* XP Progress Bar */}
          <div className="mt-1 relative w-full bg-stone-900/70 rounded-full h-3 sm:h-3.5 border border-amber-900/60 overflow-hidden shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-500 rounded-full"
              style={{ width: `${xpPercent}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-[9px] sm:text-[10px] text-white font-bold tracking-tight drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)] pointer-events-none">
              {xp.toLocaleString()} / {maxXp.toLocaleString()} XP
            </div>
          </div>
        </div>
      </div>

      {/* Middle & Right: Currencies & Quick Actions */}
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        className="hud-stats pointer-events-auto flex items-center gap-1.5 sm:gap-2.5 flex-wrap justify-end touch-manipulation no-scrollbar"
      >
        {/* Gold Coins */}
        <div className="flex items-center bg-stone-900/80 backdrop-blur-sm border-2 border-amber-500/80 rounded-full pl-1.5 pr-1 py-0.5 sm:py-1 shadow-md">
          <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-inner text-sm sm:text-base border border-amber-200 pointer-events-none">
            🪙
          </div>
          <span className="text-white font-extrabold text-xs sm:text-sm px-2 tracking-wide tabular-nums drop-shadow pointer-events-none">
            {coins.toLocaleString()}
          </span>
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={fastAction(() => onOpenShop('coins'))}
            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full game-btn-green flex items-center justify-center text-white font-bold text-xs shadow hover:brightness-110 active:scale-90 transition-transform cursor-pointer touch-manipulation"
            title="ซื้อเหรียญทอง"
          >
            <Plus className="w-3.5 h-3.5 pointer-events-none" />
          </button>
        </div>

        {/* Gems / Diamonds */}
        <div className="flex items-center bg-stone-900/80 backdrop-blur-sm border-2 border-cyan-400/80 rounded-full pl-1.5 pr-1 py-0.5 sm:py-1 shadow-md">
          <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-tr from-cyan-600 to-sky-300 flex items-center justify-center shadow-inner text-sm sm:text-base border border-cyan-200 pointer-events-none">
            💎
          </div>
          <span className="text-cyan-200 font-extrabold text-xs sm:text-sm px-2 tracking-wide tabular-nums drop-shadow pointer-events-none">
            {gems.toLocaleString()}
          </span>
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={fastAction(() => onOpenShop('gems'))}
            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full game-btn-green flex items-center justify-center text-white font-bold text-xs shadow hover:brightness-110 active:scale-90 transition-transform cursor-pointer touch-manipulation"
            title="เติมเพชร"
          >
            <Plus className="w-3.5 h-3.5 pointer-events-none" />
          </button>
        </div>

        {/* Energy */}
        <div className="flex items-center bg-stone-900/80 backdrop-blur-sm border-2 border-emerald-500/80 rounded-full pl-1.5 pr-1 py-0.5 sm:py-1 shadow-md">
          <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-tr from-emerald-500 to-green-300 flex items-center justify-center shadow-inner text-sm sm:text-base border border-emerald-200 pointer-events-none">
            ⚡
          </div>
          <div className="flex flex-col px-1.5 leading-none pointer-events-none">
            <span className="text-white font-extrabold text-xs sm:text-sm tabular-nums drop-shadow">
              {energy}/{maxEnergy}
            </span>
            <span className="text-[9px] text-emerald-300 font-medium tracking-tight">
              {energyTimer}
            </span>
          </div>
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={fastAction(() => onOpenShop('energy'))}
            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full game-btn-green flex items-center justify-center text-white font-bold text-xs shadow hover:brightness-110 active:scale-90 transition-transform cursor-pointer touch-manipulation"
            title="เพิ่มพลังงาน"
          >
            <Plus className="w-3.5 h-3.5 pointer-events-none" />
          </button>
        </div>

        {/* Login / Profile Account button */}
        {onOpenAuth && (
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={fastAction(onOpenAuth)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full shadow-md active:scale-90 transition-transform cursor-pointer border touch-manipulation ${
              currentUser && currentUser.provider !== 'guest'
                ? 'bg-stone-900/85 border-emerald-500/80 text-emerald-200 hover:bg-stone-800'
                : 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 border-amber-300 text-white'
            }`}
            title={
              currentUser && currentUser.provider !== 'guest'
                ? `เข้าสู่ระบบโดย: ${currentUser.displayName} (${currentUser.provider})`
                : 'เข้าสู่ระบบด้วย Gmail หรือ Facebook เพื่อเซฟฟาร์มบน Cloud'
            }
          >
            {currentUser && currentUser.provider !== 'guest' ? (
              <>
                <div className="w-5 h-5 rounded-full bg-emerald-600 border border-emerald-300 flex items-center justify-center text-[10px] font-black text-white pointer-events-none">
                  {currentUser.provider === 'google' ? 'G' : 'f'}
                </div>
                <span className="text-[10px] sm:text-xs font-black truncate max-w-[55px] sm:max-w-[85px] pointer-events-none">
                  {currentUser.displayName}
                </span>
              </>
            ) : (
              <>
                <User className="w-3.5 h-3.5 text-amber-200 pointer-events-none" />
                <span className="text-[10px] sm:text-xs font-black text-amber-100 pointer-events-none">
                  ล็อกอิน
                </span>
              </>
            )}
          </button>
        )}

        {/* Cloud Sync button */}
        {onOpenCloudSync && (
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={fastAction(onOpenCloudSync)}
            className="relative w-8 h-8 sm:w-10 sm:h-10 rounded-full game-wood-panel flex items-center justify-center text-cyan-200 hover:text-white shadow-md active:scale-90 transition-transform cursor-pointer border border-cyan-500/50 hover:border-cyan-300 touch-manipulation"
            title="Cloud Save & ซิงก์ข้ามเครื่อง"
          >
            <Cloud className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-300 pointer-events-none" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-white pointer-events-none" />
          </button>
        )}

        {/* Mail / Inbox button */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenMail)}
          className="relative w-8 h-8 sm:w-10 sm:h-10 rounded-full game-wood-panel flex items-center justify-center text-amber-200 hover:text-white shadow-md active:scale-90 transition-transform cursor-pointer touch-manipulation"
          title="กล่องข้อความ"
        >
          <Mail className="w-4 h-4 sm:w-5 sm:h-5 pointer-events-none" />
          {unreadMailCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center border border-white animate-pulse pointer-events-none">
              {unreadMailCount}
            </span>
          )}
        </button>

        {/* Friends button */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenFriends)}
          className="w-8 h-8 sm:w-10 sm:h-10 rounded-full game-wood-panel flex items-center justify-center text-amber-200 hover:text-white shadow-md active:scale-90 transition-transform cursor-pointer touch-manipulation"
          title="เพื่อนและเพื่อนบ้าน"
        >
          <Users className="w-4 h-4 sm:w-5 sm:h-5 pointer-events-none" />
        </button>

        {/* Sound FX Toggle (ตอบสนองทันที) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onToggleSound, false)}
          className={`w-7 h-7 sm:w-9 sm:h-9 rounded-full flex items-center justify-center text-xs shadow transition-all active:scale-90 cursor-pointer touch-manipulation ${
            soundEnabled
              ? 'bg-amber-600/90 text-white border border-amber-300'
              : 'bg-stone-800 text-stone-400 border border-stone-600'
          }`}
          title={soundEnabled ? 'ปิดเสียงเอฟเฟกต์' : 'เปิดเสียงเอฟเฟกต์'}
        >
          {soundEnabled ? (
            <Volume2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 pointer-events-none" />
          ) : (
            <VolumeX className="w-3.5 h-3.5 sm:w-4 sm:h-4 pointer-events-none" />
          )}
        </button>

        {/* Country Ambient Music Toggle (ตอบสนองทันที) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onToggleMusic, false)}
          className={`w-7 h-7 sm:w-9 sm:h-9 rounded-full flex items-center justify-center text-xs shadow transition-all active:scale-90 cursor-pointer touch-manipulation ${
            musicEnabled
              ? 'bg-emerald-600/90 text-white border border-emerald-300 animate-pulse'
              : 'bg-stone-800 text-stone-400 border border-stone-600'
          }`}
          title={musicEnabled ? 'ปิดเพลงคลอ' : 'เปิดเพลงคลอ'}
        >
          <Music className="w-3.5 h-3.5 sm:w-4 sm:h-4 pointer-events-none" />
        </button>
      </div>
    </header>
  );
};