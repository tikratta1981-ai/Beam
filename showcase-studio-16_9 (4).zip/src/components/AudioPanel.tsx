import React, { useState } from 'react';
import { AudioTierState, ThaiVisemes } from '../types';
import { globalAudioTier } from '../audio/audio-tier';
import { Mic, MicOff, Volume2, Sparkles, Sliders, Play, RotateCcw } from 'lucide-react';

interface AudioPanelProps {
  audioState: AudioTierState;
}

const THAI_PHRASES = [
  { label: 'ยินดีต้อนรับ', text: 'สวัสดีครับ ยินดีต้อนรับสู่ โชว์เคส สตูดิโอ 16 ต่อ 9 ระบบวิดีโออวตารชีวกลศาสตร์' },
  { label: 'พระสมเด็จวัดระฆัง', text: 'ขอแนะนำ พระสมเด็จวัดระฆังโฆสิตาราม พิมพ์ใหญ่ จักรพรรดิแห่งพระเครื่องเบญจภาคี' },
  { label: 'ทดสอบสระ 7 เสียง', text: 'ม อา อี อู ด ก ฟ มา ดู ปากกา ฝนตก กาบินไปมา' },
  { label: 'ระบบฟิสิกส์ TMJ', text: 'การเคลื่อนไหวของข้อต่อขากรรไกร มีทั้งการหมุนและการสไลด์ของคอนไดล์' },
];

export const AudioPanel: React.FC<AudioPanelProps> = ({ audioState }) => {
  const [customText, setCustomText] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);

  const toggleMic = async () => {
    if (audioState.isListening && audioState.inputMode === 'mic') {
      globalAudioTier.stopMicrophone();
    } else {
      await globalAudioTier.startMicrophone();
    }
  };

  const handleSpeak = async (textToSpeak: string) => {
    if (!textToSpeak.trim()) return;
    setIsSpeaking(true);
    await globalAudioTier.speakThaiTTS(textToSpeak);
    setIsSpeaking(false);
  };

  const visemeEntries: { key: keyof ThaiVisemes; label: string; sub: string; color: string }[] = [
    { key: 'lipLock', label: 'ม / บ / พ / ป', sub: 'Lip Lock (ปิดริมฝีปาก)', color: 'bg-rose-500' },
    { key: 'pharynxOpen', label: 'อา / อะ', sub: 'Pharynx Open (อ้าปากกว้าง)', color: 'bg-amber-500' },
    { key: 'zygoSpread', label: 'อี / เอ', sub: 'Zygo Spread (ฉีกยิ้มยืดปาก)', color: 'bg-emerald-500' },
    { key: 'orbicRound', label: 'อู / โอ', sub: 'Orbic Round (ห่อปากยื่น)', color: 'bg-cyan-500' },
    { key: 'tipCurl', label: 'ด / ต / น / ล / ร', sub: 'Tip Curl (ยกปลายลิ้นแตะ)', color: 'bg-blue-500' },
    { key: 'velarDorsum', label: 'ก / ข / ค / ง', sub: 'Velar Dorsum (โคนลิ้นยก)', color: 'bg-indigo-500' },
    { key: 'dentalTuck', label: 'ฟ / ฝ', sub: 'Dental Tuck (ฟันบนทับปากล่าง)', color: 'bg-purple-500' },
  ];

  return (
    <div id="audio-dsp-panel" className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-5 text-neutral-100 flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <h2 className="font-semibold text-sm tracking-wide text-neutral-200">
            240Hz AUDIO DSP & THAI VISEMES
          </h2>
        </div>
        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
          DSP RATE: 240Hz
        </span>
      </div>

      {/* Mic & TTS Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Live Mic Control */}
        <div className="bg-neutral-950/60 p-4 rounded-lg border border-neutral-800/80 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-neutral-300 flex items-center gap-1.5">
              <Mic className="w-4 h-4 text-emerald-400" /> ไมโครโฟนสด (Live Mic)
            </span>
            <button
              id="btn-toggle-mic"
              onClick={toggleMic}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
                audioState.isListening && audioState.inputMode === 'mic'
                  ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-900/40'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/40'
              }`}
            >
              {audioState.isListening && audioState.inputMode === 'mic' ? (
                <>
                  <MicOff className="w-3.5 h-3.5" /> ปิดไมค์ (Mute)
                </>
              ) : (
                <>
                  <Mic className="w-3.5 h-3.5" /> เปิดไมค์ (Live)
                </>
              )}
            </button>
          </div>

          {/* Noise Gate & Auto-Gain */}
          <div className="flex flex-col gap-2 pt-2 border-t border-neutral-800/60">
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span>Noise Gate (ประตูดักเสียงรบกวน)</span>
              <span className="font-mono text-neutral-300">{audioState.noiseGate.toFixed(3)}</span>
            </div>
            <input
              type="range"
              min="0.005"
              max="0.08"
              step="0.002"
              value={audioState.noiseGate}
              onChange={e => globalAudioTier.setNoiseGate(parseFloat(e.target.value))}
              className="w-full accent-emerald-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
            />

            <div className="flex items-center justify-between text-xs text-neutral-400 pt-1">
              <span>Auto-Gain Normalization</span>
              <button
                onClick={() => globalAudioTier.setAutoGain(!audioState.autoGain)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono ${
                  audioState.autoGain ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700' : 'bg-neutral-800 text-neutral-400'
                }`}
              >
                {audioState.autoGain ? 'ON (เปิด)' : 'OFF (ปิด)'}
              </button>
            </div>
          </div>
        </div>

        {/* TTS Thai Speech Synthesizer */}
        <div className="bg-neutral-950/60 p-4 rounded-lg border border-neutral-800/80 flex flex-col gap-3">
          <span className="text-xs font-medium text-neutral-300 flex items-center gap-1.5">
            <Volume2 className="w-4 h-4 text-cyan-400" /> สังเคราะห์เสียงพูดภาษาไทย (Thai TTS)
          </span>

          {/* Preset Buttons */}
          <div className="flex flex-wrap gap-1.5">
            {THAI_PHRASES.map((item, idx) => (
              <button
                key={idx}
                id={`btn-phrase-${idx}`}
                disabled={isSpeaking}
                onClick={() => handleSpeak(item.text)}
                className="text-[11px] px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Custom Input */}
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="พิมพ์ข้อความภาษาไทยที่นี่..."
              value={customText}
              onChange={e => setCustomText(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') handleSpeak(customText);
              }}
              className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-1.5 text-xs text-neutral-200 placeholder:text-neutral-500 focus:outline-none focus:border-cyan-500"
            />
            <button
              id="btn-speak-custom"
              disabled={isSpeaking || !customText.trim()}
              onClick={() => handleSpeak(customText)}
              className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white rounded-lg text-xs font-medium flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5" /> พูด
            </button>
          </div>
        </div>
      </div>

      {/* 7 Thai Viseme Dynamic Meters */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between text-xs text-neutral-400">
          <span className="font-semibold text-neutral-200 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-amber-400" /> 7 THAI VISEME ARTICULATION METERS (ระดับการออกเสียง 7 รูปปาก)
          </span>
          <button
            onClick={() => globalAudioTier.resetVisemes()}
            className="text-[11px] text-neutral-400 hover:text-neutral-200 flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" /> รีเซ็ต
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {visemeEntries.map(item => {
            const val = audioState.visemes[item.key];
            const pct = Math.round(val * 100);
            return (
              <div
                key={item.key}
                onClick={() => globalAudioTier.triggerVisemePreset(item.key)}
                className="bg-neutral-950/70 p-2.5 rounded-lg border border-neutral-800/80 hover:border-neutral-700 cursor-pointer transition flex flex-col gap-1.5"
                title="คลิกเพื่อทดสอบรูปปากนี้ทันที"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-200">{item.label}</span>
                  <span className="font-mono text-[11px] text-neutral-400">{pct}%</span>
                </div>
                <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${item.color} transition-all duration-75`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="text-[10px] text-neutral-400 truncate">{item.sub}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mini Formant Spectrogram */}
      <div className="bg-neutral-950/60 p-3 rounded-lg border border-neutral-800 flex items-center justify-between text-xs font-mono text-neutral-400">
        <div className="flex items-center gap-4">
          <span>RMS Volume: <strong className="text-white">{(audioState.volume * 100).toFixed(0)}%</strong></span>
          <span>F1 Formant: <strong className="text-amber-400">{audioState.formants.f1} Hz</strong></span>
          <span>F2 Formant: <strong className="text-cyan-400">{audioState.formants.f2} Hz</strong></span>
        </div>
        <div className="flex items-center gap-1">
          {Array.from(audioState.spectrumData.slice(0, 24)).map((val: number, idx) => (
            <div
              key={idx}
              className="w-1 bg-cyan-500/80 rounded-t"
              style={{ height: `${Math.max(2, (Number(val) / 255) * 20)}px` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
