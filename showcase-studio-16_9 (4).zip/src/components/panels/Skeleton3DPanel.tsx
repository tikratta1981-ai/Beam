import React, { useEffect, useRef } from 'react';
import { CameraPreset, StudioConfig } from '../../types/viseme';
import { Anatomy3DEngine } from '../../utils/three/anatomy-3d-engine';
import { Eye, Layers, Compass, Maximize2 } from 'lucide-react';

interface Skeleton3DPanelProps {
  anatomyEngine: Anatomy3DEngine | null;
  config: StudioConfig;
  onConfigChange: (newConfig: Partial<StudioConfig>) => void;
}

export const Skeleton3DPanel: React.FC<Skeleton3DPanelProps> = ({
  anatomyEngine,
  config,
  onConfigChange,
}) => {
  const threeContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!anatomyEngine || !threeContainerRef.current) return;
    // Mount the Three.js viewport if not already mounted
    const el = anatomyEngine.getDomElement();
    if (el && !threeContainerRef.current.contains(el)) {
      threeContainerRef.current.innerHTML = '';
      threeContainerRef.current.appendChild(el);
      anatomyEngine.resize(
        threeContainerRef.current.clientWidth || 400,
        threeContainerRef.current.clientHeight || 260
      );
    }
  }, [anatomyEngine]);

  const setCameraPreset = (preset: CameraPreset) => {
    if (anatomyEngine) {
      anatomyEngine.setCameraPreset(preset);
    }
    onConfigChange({ cameraPreset: preset });
  };

  const handleOpacityChange = (val: number) => {
    if (anatomyEngine) {
      anatomyEngine.setXRayOpacity(val);
    }
    onConfigChange({ skeletonOpacity: val });
  };

  const presets: { key: CameraPreset; label: string; desc: string }[] = [
    { key: 'FRONT', label: 'ด้านหน้า (FRONT)', desc: 'มุมมองตรงระนาบ Coronal' },
    { key: 'PROFILE', label: 'ด้านข้าง (PROFILE)', desc: 'มุมมองข้างระนาบ Sagittal' },
    { key: 'TOP', label: 'มุมบน (TOP)', desc: 'มุมกดจากกะโหลกศีรษะ' },
    { key: 'TMJ', label: 'ซูมข้อต่อ (TMJ)', desc: 'ซูมเจาะลึก Condyle & Disc' },
    { key: 'WIDE', label: 'มุมกว้าง (WIDE)', desc: 'มุมกว้างทั้งศีรษะและลำตัว' },
  ];

  return (
    <div id="skeleton-3d-panel" className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-5 text-neutral-100 flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <h2 className="font-semibold text-sm tracking-wide text-neutral-200">
            THREE.JS 3D X-RAY ANATOMY & SKELETON
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs text-neutral-400 flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={config.showSkeleton3D}
              onChange={e => onConfigChange({ showSkeleton3D: e.target.checked })}
              className="accent-cyan-500 rounded"
            />
            เปิดแสดงโครงกระดูก 3D
          </label>
        </div>
      </div>

      {/* 3D Interactive Viewport Container */}
      <div className="relative w-full h-64 bg-neutral-950 rounded-xl overflow-hidden border border-neutral-800">
        <div ref={threeContainerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
        <div className="absolute bottom-2 left-2 bg-neutral-900/80 backdrop-blur px-2.5 py-1 rounded text-[10px] font-mono text-cyan-300 border border-neutral-700/60 flex items-center gap-1.5">
          <Compass className="w-3 h-3 text-cyan-400" /> ลากเมาส์เพื่อหมุน 3D | เลื่อนลูกกลิ้งเพื่อซูม
        </div>
      </div>

      {/* 5 Camera Presets */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-semibold text-neutral-300">
          5 CAMERA PRESETS (5 มุมกล้องมาตรฐาน):
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {presets.map(p => {
            const isSelected = config.cameraPreset === p.key;
            return (
              <button
                key={p.key}
                id={`btn-cam-${p.key.toLowerCase()}`}
                onClick={() => setCameraPreset(p.key)}
                className={`py-2 px-2.5 rounded-lg text-xs font-semibold transition text-center flex flex-col gap-0.5 ${
                  isSelected
                    ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/40 border border-cyan-400'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700/80'
                }`}
              >
                <span>{p.label}</span>
                <span className="text-[9px] font-normal opacity-75 truncate">{p.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Mode & Opacity controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Placement Mode */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <span className="text-xs font-medium text-neutral-300">
            โหมดการแสดงผลในสตูดิโอ 16:9
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onConfigChange({ skeletonPosition: 'overlay' })}
              className={`py-1.5 px-3 rounded text-xs font-medium ${
                config.skeletonPosition === 'overlay'
                  ? 'bg-cyan-700 text-white border border-cyan-500'
                  : 'bg-neutral-800 text-neutral-400'
              }`}
            >
              ซ้อนทับภาพ (X-Ray Overlay)
            </button>
            <button
              onClick={() => onConfigChange({ skeletonPosition: 'pip' })}
              className={`py-1.5 px-3 rounded text-xs font-medium ${
                config.skeletonPosition === 'pip'
                  ? 'bg-cyan-700 text-white border border-cyan-500'
                  : 'bg-neutral-800 text-neutral-400'
              }`}
            >
              หน้าต่างมุมจอ (PIP Box)
            </button>
          </div>
        </div>

        {/* X-Ray Cyan Opacity */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 font-medium">ความโปร่งใส X-Ray Cyan</span>
            <span className="font-mono text-cyan-400">{Math.round(config.skeletonOpacity * 100)}%</span>
          </div>
          <input
            type="range"
            min="0.1"
            max="1.0"
            step="0.05"
            value={config.skeletonOpacity}
            onChange={e => handleOpacityChange(parseFloat(e.target.value))}
            className="w-full accent-cyan-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
