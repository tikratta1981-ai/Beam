import React, { useRef } from 'react';
import { AmuletData, AmuletViewMode, StudioConfig } from '../../types/viseme';
import { SAMPLE_AMULETS } from '../../amulet/amulet-extension';
import { Gem, RotateCw, Image as ImageIcon, Upload, Sparkles, Palette } from 'lucide-react';

interface AmuletExtensionPanelProps {
  selectedAmulet: AmuletData;
  onSelectAmulet: (amulet: AmuletData) => void;
  amuletAngle: AmuletViewMode;
  onAngleChange: (angle: AmuletViewMode) => void;
  autoFlip: boolean;
  onToggleAutoFlip: (enabled: boolean) => void;
  autoFlipInterval: number;
  onIntervalChange: (interval: number) => void;
  config: StudioConfig;
  onConfigChange: (newConfig: Partial<StudioConfig>) => void;
  onCustomImageUpload: (angle: AmuletViewMode, dataUrl: string) => void;
}

export const AmuletExtensionPanel: React.FC<AmuletExtensionPanelProps> = ({
  selectedAmulet,
  onSelectAmulet,
  amuletAngle,
  onAngleChange,
  autoFlip,
  onToggleAutoFlip,
  autoFlipInterval,
  onIntervalChange,
  config,
  onConfigChange,
  onCustomImageUpload,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const uploadAngleTargetRef = useRef<AmuletViewMode>('front');

  const angles: { key: AmuletViewMode; label: string; desc: string }[] = [
    { key: 'front', label: 'ด้านหน้า (FRONT)', desc: 'องค์พระ ลวดลาย พิมพ์ทรง ซุ้มครอบแก้ว' },
    { key: 'back', label: 'ด้านหลัง (BACK)', desc: 'รอยยุบ รอยย่น ยันต์ รอยปาด หลังกาบหมาก' },
    { key: 'edge', label: 'ด้านขอบ (EDGE)', desc: 'รอยตัดตอก รอยปริแยก มวลสารเนื้อใน' },
    { key: 'base', label: 'ด้านก้น (BASE)', desc: 'รอยเสียบ รอยแทง รอยประกบพิมพ์' },
  ];

  const studioThemes: { key: StudioConfig['studioTheme']; label: string; bg: string }[] = [
    { key: 'velvet-red', label: 'กำมะหยี่แดง (Velvet Red)', bg: 'bg-red-950 border-red-800' },
    { key: 'deep-obsidian', label: 'ดำออบซิเดียน (Deep Obsidian)', bg: 'bg-neutral-950 border-neutral-800' },
    { key: 'gold-sanctuary', label: 'ทองคำเรืองรอง (Gold Sanctuary)', bg: 'bg-amber-950 border-amber-800' },
    { key: 'cyber-cyan', label: 'ไซเบอร์แล็บ (Cyber Cyan)', bg: 'bg-cyan-950 border-cyan-800' },
  ];

  const handleTriggerUpload = (angle: AmuletViewMode) => {
    uploadAngleTargetRef.current = angle;
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      const dataUrl = evt.target?.result as string;
      if (dataUrl) {
        onCustomImageUpload(uploadAngleTargetRef.current, dataUrl);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  return (
    <div id="amulet-extension-panel" className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-5 text-neutral-100 flex flex-col gap-5">
      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <Gem className="w-4 h-4 text-amber-400" />
          <h2 className="font-semibold text-sm tracking-wide text-neutral-200">
            AMULET SHOWCASE EXTENSION (ระบบจัดแสดงพระเครื่อง 4 ทิศทาง)
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs text-neutral-400 flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={config.showAmulet}
              onChange={e => onConfigChange({ showAmulet: e.target.checked })}
              className="accent-amber-500 rounded"
            />
            เปิดการแสดงผลพระเครื่อง
          </label>
        </div>
      </div>

      {/* Amulet Selector */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-semibold text-neutral-300">
          SELECT SACRED AMULET (เลือกพระเครื่อง):
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {SAMPLE_AMULETS.map(item => {
            const isSelected = selectedAmulet.id === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectAmulet(item)}
                className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition ${
                  isSelected
                    ? 'bg-amber-950/40 border-amber-500 text-amber-200 shadow-lg shadow-amber-950/40'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <div className="font-bold text-xs text-neutral-100">{item.thaiName}</div>
                <div className="text-[11px] text-amber-400/90">{item.name}</div>
                <div className="text-[10px] text-neutral-400 truncate">{item.material}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4 View Modes (Front, Back, Edge, Base) */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-neutral-300">
            4-VIEW INSPECTION MODES (มุมมอง 4 ทิศทาง):
          </span>
          <div className="flex items-center gap-2 text-xs">
            <button
              id="btn-auto-flip"
              onClick={() => onToggleAutoFlip(!autoFlip)}
              className={`px-2.5 py-1 rounded-lg font-medium flex items-center gap-1.5 transition ${
                autoFlip
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-900/40'
                  : 'bg-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              <RotateCw className={`w-3 h-3 ${autoFlip ? 'animate-spin' : ''}`} />
              Auto-Flip (สลับมุมอัตโนมัติ)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {angles.map(ang => {
            const isSelected = amuletAngle === ang.key;
            return (
              <div
                key={ang.key}
                className={`p-3 rounded-lg border flex flex-col justify-between gap-2 transition ${
                  isSelected
                    ? 'bg-amber-900/30 border-amber-500 text-amber-200 shadow-md'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400'
                }`}
              >
                <div
                  onClick={() => onAngleChange(ang.key)}
                  className="cursor-pointer flex flex-col gap-1"
                >
                  <span className="font-bold text-xs">{ang.label}</span>
                  <span className="text-[10px] opacity-75 line-clamp-2">{ang.desc}</span>
                </div>
                <button
                  onClick={() => handleTriggerUpload(ang.key)}
                  className="text-[10px] py-1 px-2 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center justify-center gap-1 transition"
                  title="อัปโหลดรูปภาพพระเครื่องของคุณเองในมุมนี้"
                >
                  <Upload className="w-3 h-3" /> อัปโหลดรูป
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Auto-flip speed and Studio Theme */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Auto Flip Interval */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 font-medium">ความเร็วการสลับมุม (Auto-Flip Interval)</span>
            <span className="font-mono text-amber-400">{autoFlipInterval.toFixed(1)} วินาที</span>
          </div>
          <input
            type="range"
            min="1.5"
            max="6.0"
            step="0.5"
            value={autoFlipInterval}
            onChange={e => onIntervalChange(parseFloat(e.target.value))}
            className="w-full accent-amber-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
        </div>

        {/* Studio Theme Backdrop */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <span className="text-xs font-medium text-neutral-300 flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-amber-400" /> โทนสีสตูดิโอ 16:9
          </span>
          <div className="grid grid-cols-2 gap-1.5">
            {studioThemes.map(theme => (
              <button
                key={theme.key}
                onClick={() => onConfigChange({ studioTheme: theme.key })}
                className={`py-1.5 px-2 rounded text-[11px] font-medium border text-left truncate transition ${
                  config.studioTheme === theme.key
                    ? 'border-amber-500 bg-amber-950/60 text-white'
                    : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {theme.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
