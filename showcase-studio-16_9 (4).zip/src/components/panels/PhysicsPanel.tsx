import React from 'react';
import { TMJPhysicsParams, TMJState, TMJPreset } from '../../types/viseme';
import { globalTMJEngine } from '../../physics/tmj-engine';
import { Activity, Wind, Heart, Zap, Cpu } from 'lucide-react';

interface PhysicsPanelProps {
  tmjState: TMJState;
  physicsParams: TMJPhysicsParams;
  onParamsChange: (params: TMJPhysicsParams) => void;
}

export const PhysicsPanel: React.FC<PhysicsPanelProps> = ({
  tmjState,
  physicsParams,
  onParamsChange,
}) => {
  const handlePreset = (preset: TMJPreset) => {
    globalTMJEngine.setPreset(preset);
    onParamsChange(globalTMJEngine.getParams());
  };

  const updateParam = (key: keyof TMJPhysicsParams, val: number | boolean) => {
    globalTMJEngine.setParams({ [key]: val });
    onParamsChange(globalTMJEngine.getParams());
  };

  const angleDeg = (tmjState.jawAngle * (180 / Math.PI)).toFixed(1);

  return (
    <div id="tmj-physics-panel" className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-5 text-neutral-100 flex flex-col gap-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <h2 className="font-semibold text-sm tracking-wide text-neutral-200">
            120Hz TMJ BIOMECHANICS & CONDYLAR PHYSICS
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
            CLOCK: 120Hz
          </span>
        </div>
      </div>

      {/* Physics Presets */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-semibold text-neutral-300">
          PHYSICS PRESETS (ชุดค่าฟิสิกส์สำเร็จรูป):
        </label>
        <div className="grid grid-cols-3 gap-2">
          {(['soft', 'normal', 'punchy'] as TMJPreset[]).map(preset => {
            const isSelected = physicsParams.preset === preset;
            return (
              <button
                key={preset}
                id={`btn-preset-${preset}`}
                onClick={() => handlePreset(preset)}
                className={`py-2 px-3 rounded-lg text-xs font-semibold uppercase transition flex flex-col items-center gap-1 ${
                  isSelected
                    ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/40 border border-cyan-400'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700/80'
                }`}
              >
                <span>{preset}</span>
                <span className="text-[10px] font-normal opacity-80">
                  {preset === 'soft' && 'นุ่มนวล ลื่นไหล'}
                  {preset === 'normal' && 'สมดุล สมจริง'}
                  {preset === 'punchy' && 'คมชัด ฉับไว'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sliders: Mass, Stiffness, Damping, Condylar Slide */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Jaw Mass */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 font-medium">Mandibular Mass (มวลขากรรไกร m)</span>
            <span className="font-mono text-cyan-400">{physicsParams.mass.toFixed(2)} kg</span>
          </div>
          <input
            type="range"
            min="0.15"
            max="0.45"
            step="0.01"
            value={physicsParams.mass}
            onChange={e => updateParam('mass', parseFloat(e.target.value))}
            className="w-full accent-cyan-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-neutral-500">มวลเฉื่อยของกระดูกขากรรไกรล่างตามสรีระ</span>
        </div>

        {/* Tissue Recoil / Elasticity */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 font-medium">Tissue Recoil (แรงดีดเนื้อเยื่อ)</span>
            <span className="font-mono text-cyan-400">{physicsParams.tissueRecoil.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="2.0"
            step="0.05"
            value={physicsParams.tissueRecoil}
            onChange={e => updateParam('tissueRecoil', parseFloat(e.target.value))}
            className="w-full accent-cyan-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-neutral-500">ความยืดหยุ่นดีดตัวของกล้ามเนื้อ Masseter</span>
        </div>

        {/* Condylar Slide Ratio */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 font-medium">Condylar Slide (การสไลด์ของข้อต่อ)</span>
            <span className="font-mono text-cyan-400">{physicsParams.condylarSlide.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0.2"
            max="0.8"
            step="0.02"
            value={physicsParams.condylarSlide}
            onChange={e => updateParam('condylarSlide', parseFloat(e.target.value))}
            className="w-full accent-cyan-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-neutral-500">อัตราการเลื่อนลงและไปข้างหน้าของหัว Condyle</span>
        </div>

        {/* Damping */}
        <div className="bg-neutral-950/60 p-3.5 rounded-lg border border-neutral-800/80 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-neutral-300 font-medium">Viscous Damping (ความหน่วง c)</span>
            <span className="font-mono text-cyan-400">{physicsParams.damping.toFixed(1)} Ns/m</span>
          </div>
          <input
            type="range"
            min="5"
            max="25"
            step="0.5"
            value={physicsParams.damping}
            onChange={e => updateParam('damping', parseFloat(e.target.value))}
            className="w-full accent-cyan-500 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-neutral-500">ความหน่วงของของเหลวในช่องข้อต่อ Synovial</span>
        </div>
      </div>

      {/* Biological Micro-Motions (Living Human Micro-Dynamics) */}
      <div className="flex flex-col gap-2.5">
        <label className="text-xs font-semibold text-neutral-300">
          BIOLOGICAL MICRO-MOTIONS (การจำลองสัญญาณชีพมนุษย์):
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Respiration */}
          <button
            id="toggle-respiration"
            onClick={() => updateParam('respirationEnabled', !physicsParams.respirationEnabled)}
            className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition ${
              physicsParams.respirationEnabled
                ? 'bg-emerald-950/40 border-emerald-600/80 text-emerald-300'
                : 'bg-neutral-950/50 border-neutral-800 text-neutral-400'
            }`}
          >
            <div className="flex items-center gap-1.5 font-semibold text-xs">
              <Wind className="w-3.5 h-3.5" /> หายใจ 3.8s
            </div>
            <span className="text-[10px] opacity-80">การขยับของอก/ไหปลาร้า</span>
          </button>

          {/* Postural Sway */}
          <button
            id="toggle-sway"
            onClick={() => updateParam('posturalSwayEnabled', !physicsParams.posturalSwayEnabled)}
            className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition ${
              physicsParams.posturalSwayEnabled
                ? 'bg-blue-950/40 border-blue-600/80 text-blue-300'
                : 'bg-neutral-950/50 border-neutral-800 text-neutral-400'
            }`}
          >
            <div className="flex items-center gap-1.5 font-semibold text-xs">
              <Cpu className="w-3.5 h-3.5" /> Postural Sway
            </div>
            <span className="text-[10px] opacity-80">การเซสมดุล 0.2-0.5Hz</span>
          </button>

          {/* Heart Pulse */}
          <button
            id="toggle-heart"
            onClick={() => updateParam('heartPulseEnabled', !physicsParams.heartPulseEnabled)}
            className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition ${
              physicsParams.heartPulseEnabled
                ? 'bg-rose-950/40 border-rose-600/80 text-rose-300'
                : 'bg-neutral-950/50 border-neutral-800 text-neutral-400'
            }`}
          >
            <div className="flex items-center gap-1.5 font-semibold text-xs">
              <Heart className="w-3.5 h-3.5" /> ชีพจร 72 BPM
            </div>
            <span className="text-[10px] opacity-80">การเต้นของหัวใจไมโคร</span>
          </button>

          {/* Micro-tremble */}
          <button
            id="toggle-tremble"
            onClick={() => updateParam('microTrembleEnabled', !physicsParams.microTrembleEnabled)}
            className={`p-3 rounded-lg border text-left flex flex-col gap-1 transition ${
              physicsParams.microTrembleEnabled
                ? 'bg-purple-950/40 border-purple-600/80 text-purple-300'
                : 'bg-neutral-950/50 border-neutral-800 text-neutral-400'
            }`}
          >
            <div className="flex items-center gap-1.5 font-semibold text-xs">
              <Zap className="w-3.5 h-3.5" /> สั่นละเอียด 8Hz
            </div>
            <span className="text-[10px] opacity-80">Physiological Tremor</span>
          </button>
        </div>
      </div>

      {/* Live TMJ Dynamic Gauges */}
      <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div>
          <span className="text-neutral-500 block text-[10px]">JAW ROTATION θ</span>
          <span className="text-white font-bold text-sm">{angleDeg}°</span>
        </div>
        <div>
          <span className="text-neutral-500 block text-[10px]">CONDYLE TRANSLATION Y</span>
          <span className="text-cyan-400 font-bold text-sm">{tmjState.jawTranslationY.toFixed(2)} mm</span>
        </div>
        <div>
          <span className="text-neutral-500 block text-[10px]">CONDYLE TRANSLATION Z</span>
          <span className="text-cyan-400 font-bold text-sm">{tmjState.jawTranslationZ.toFixed(2)} mm</span>
        </div>
        <div>
          <span className="text-neutral-500 block text-[10px]">JAW ANGULAR VELOCITY</span>
          <span className="text-amber-400 font-bold text-sm">{tmjState.jawVelocity.toFixed(2)} rad/s</span>
        </div>
      </div>
    </div>
  );
};
