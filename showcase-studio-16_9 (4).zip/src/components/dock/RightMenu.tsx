import React, { useState, useCallback } from 'react';
import { Store, ShoppingCart, Gift, ChevronRight, ChevronLeft } from 'lucide-react';
import { sound } from '../../utils/audio/index';

interface RightMenuProps {
  giftCountdown: string;
  isGiftReady: boolean;
  onOpenShop: () => void;
  onOpenMarket: () => void;
  onOpenGift: () => void;
  onOpenFestival: () => void;
}

export const RightMenu: React.FC<RightMenuProps> = ({
  giftCountdown,
  isGiftReady,
  onOpenShop,
  onOpenMarket,
  onOpenGift,
  onOpenFestival,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // ตัด Event Propagation ป้องกันการกระตุกของแผนที่ด้านหลัง
  const handleAction = useCallback((callback: () => void) => {
    return (e: React.MouseEvent | React.PointerEvent) => {
      e.stopPropagation();
      try {
        sound.playClick();
      } catch {}
      callback();
    };
  }, []);

  const isolatePointer = (e: React.PointerEvent | React.TouchEvent) => {
    e.stopPropagation();
  };

  return (
    <aside
      onPointerDown={isolatePointer}
      onPointerMove={isolatePointer}
      onPointerUp={isolatePointer}
      onTouchStart={isolatePointer}
      onTouchMove={isolatePointer}
      onTouchEnd={isolatePointer}
      className="side-menu side-menu-right interactive-ui absolute right-1.5 sm:right-4 top-20 sm:top-24 z-20 flex items-start gap-1 pointer-events-auto select-none touch-manipulation"
      style={{ touchAction: 'manipulation' }}
    >
      {/* ปุ่มพับเก็บเมนูด้านขวา สำหรับมือถือ */}
      <button
        type="button"
        onPointerDown={isolatePointer}
        onClick={handleAction(() => setIsCollapsed((prev) => !prev))}
        className="w-6 h-9 sm:w-7 sm:h-10 bg-amber-950/90 hover:bg-amber-900 border border-amber-500/60 rounded-l-xl flex items-center justify-center text-amber-200 shadow-md active:scale-90 transition-all mt-1 touch-manipulation cursor-pointer"
        title={isCollapsed ? 'แสดงเมนู' : 'ซ่อนเมนู'}
      >
        {isCollapsed ? (
          <ChevronLeft className="w-4 h-4 pointer-events-none" />
        ) : (
          <ChevronRight className="w-4 h-4 pointer-events-none" />
        )}
      </button>

      {/* รายการปุ่มเมนูฝั่งขวา */}
      <div
        className={`flex flex-col items-end gap-1.5 sm:gap-2.5 transition-all duration-300 origin-right ${
          isCollapsed ? 'scale-0 opacity-0 pointer-events-none w-0' : 'scale-100 opacity-100'
        }`}
      >
        {/* เทศกาลเก็บเกี่ยว */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenFestival)}
          className="group relative flex items-center gap-1.5 p-1 sm:px-3 sm:py-1.5 game-wood-panel rounded-xl sm:rounded-2xl border border-amber-400 shadow-xl active:scale-90 active:brightness-95 transition-all text-left touch-manipulation cursor-pointer"
          title="เทศกาลเก็บเกี่ยว"
        >
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full overflow-hidden border border-white shadow bg-amber-400 flex items-center justify-center flex-shrink-0 pointer-events-none">
            <img
              src="/src/assets/images/cow_mascot_logo_1790916726207.jpg"
              alt="Festival"
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <span className="text-sm sm:text-xl hidden">🐮</span>
          </div>

          <div className="hidden sm:flex flex-col pr-1 pointer-events-none">
            <span className="text-xs font-black text-amber-200 group-hover:text-yellow-100 drop-shadow">
              เทศกาลเก็บเกี่ยว
            </span>
            <span className="text-[10px] font-bold text-emerald-300 drop-shadow">
              6 วัน 12 ชม.
            </span>
          </div>
          <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping pointer-events-none" />
        </button>

        {/* ร้านค้า (Shop) */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenShop)}
          className="group relative flex flex-col items-center justify-center w-11 h-11 sm:w-14 sm:h-14 game-wood-panel rounded-xl sm:rounded-2xl shadow-lg border border-emerald-400/80 active:scale-90 active:brightness-95 transition-transform touch-manipulation cursor-pointer"
          title="ร้านค้าในเกม"
        >
          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-md sm:rounded-lg bg-emerald-500/30 flex items-center justify-center text-emerald-200 group-hover:text-white transition-colors pointer-events-none">
            <Store className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-300" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold text-emerald-100 tracking-tight leading-none mt-0.5 drop-shadow pointer-events-none">
            ร้านค้า
          </span>
        </button>

        {/* ตลาด (Market) */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenMarket)}
          className="group relative flex flex-col items-center justify-center w-11 h-11 sm:w-14 sm:h-14 game-wood-panel rounded-xl sm:rounded-2xl shadow-lg border border-amber-400/80 active:scale-90 active:brightness-95 transition-transform touch-manipulation cursor-pointer"
          title="ตลาดซื้อขายและรถส่งของ"
        >
          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-md sm:rounded-lg bg-amber-500/30 flex items-center justify-center text-amber-200 group-hover:text-white transition-colors pointer-events-none">
            <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold text-amber-100 tracking-tight leading-none mt-0.5 drop-shadow pointer-events-none">
            ตลาด
          </span>
        </button>

        {/* ของขวัญ (Gift / Lucky Box with Timer) */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenGift)}
          className={`group relative flex flex-col items-center justify-center min-w-[44px] sm:min-w-[50px] p-1 sm:p-1.5 game-wood-panel rounded-xl sm:rounded-2xl shadow-lg border active:scale-90 active:brightness-95 transition-transform touch-manipulation cursor-pointer ${
            isGiftReady ? 'border-yellow-400 animate-gentle-pulse' : 'border-purple-400/80'
          }`}
          title="กล่องของขวัญนำโชค"
        >
          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-md sm:rounded-lg bg-purple-500/30 flex items-center justify-center text-purple-200 group-hover:text-white transition-colors pointer-events-none">
            <Gift className={`w-4 h-4 sm:w-5 sm:h-5 ${isGiftReady ? 'text-yellow-300' : 'text-purple-300'}`} />
          </div>
          <span className="text-[8px] sm:text-[10px] font-bold text-purple-100 tracking-tight leading-none mt-0.5 drop-shadow pointer-events-none">
            {isGiftReady ? 'เปิดฟรี!' : giftCountdown}
          </span>
          {isGiftReady && (
            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-yellow-400 border border-white text-stone-900 text-[8px] font-black flex items-center justify-center pointer-events-none">
              !
            </span>
          )}
        </button>
      </div>
    </aside>
  );
};