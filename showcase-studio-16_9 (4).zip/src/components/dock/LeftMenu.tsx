import React, { useState, useCallback } from 'react';
import { ClipboardList, Gift, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { sound } from '../../utils/audio/index';

interface LeftMenuProps {
  questCount: number;
  onOpenQuests: () => void;
  onOpenEvents: () => void;
  onOpenDaily: () => void;
}

export const LeftMenu: React.FC<LeftMenuProps> = ({
  questCount,
  onOpenQuests,
  onOpenEvents,
  onOpenDaily,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  // ตัด Event Propagation ทันที ป้องกันการแย่ง Pointer กับแผนที่ฟาร์ม
  const handleAction = useCallback((callback: () => void) => {
    return (e: React.MouseEvent | React.PointerEvent) => {
      e.stopPropagation();
      try {
        sound.playClick();
      } catch {}
      callback();
    };
  }, []);

  const isolatePointer = (e: React.PointerEvent | React.TouchEvent) => {
    e.stopPropagation();
  };

  return (
    <aside
      onPointerDown={isolatePointer}
      onPointerMove={isolatePointer}
      onPointerUp={isolatePointer}
      onTouchStart={isolatePointer}
      onTouchMove={isolatePointer}
      onTouchEnd={isolatePointer}
      className="side-menu side-menu-left interactive-ui absolute left-1.5 sm:left-4 top-20 sm:top-24 z-20 flex items-start gap-1 pointer-events-auto select-none touch-manipulation"
      style={{ touchAction: 'manipulation' }}
    >
      {/* รายการปุ่มเมนู */}
      <div
        className={`flex flex-col gap-1.5 sm:gap-3 transition-all duration-300 origin-left ${
          isCollapsed ? 'scale-0 opacity-0 pointer-events-none w-0' : 'scale-100 opacity-100'
        }`}
      >
        {/* ภารกิจ (Quests) */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenQuests)}
          className="group relative flex flex-col items-center justify-center w-11 h-11 sm:w-14 sm:h-14 game-wood-panel rounded-xl sm:rounded-2xl shadow-lg border border-amber-400/80 active:scale-90 active:brightness-95 transition-transform touch-manipulation cursor-pointer"
          title="ภารกิจประจำวัน"
        >
          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-md sm:rounded-lg bg-amber-500/30 flex items-center justify-center text-amber-200 group-hover:text-white transition-colors pointer-events-none">
            <ClipboardList className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold text-amber-100 tracking-tight leading-none mt-0.5 drop-shadow pointer-events-none">
            ภารกิจ
          </span>

          {questCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-4 h-4 sm:min-w-5 sm:h-5 px-0.5 rounded-full bg-red-600 border border-white text-white text-[9px] sm:text-[11px] font-extrabold flex items-center justify-center shadow-md animate-bounce pointer-events-none">
              {questCount}
            </span>
          )}
        </button>

        {/* กิจกรรม (Events) */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenEvents)}
          className="group relative flex flex-col items-center justify-center w-11 h-11 sm:w-14 sm:h-14 game-wood-panel rounded-xl sm:rounded-2xl shadow-lg border border-pink-400/80 active:scale-90 active:brightness-95 transition-transform touch-manipulation cursor-pointer"
          title="กิจกรรมพิเศษ"
        >
          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-md sm:rounded-lg bg-pink-500/30 flex items-center justify-center text-pink-300 group-hover:text-white transition-colors pointer-events-none">
            <Gift className="w-4 h-4 sm:w-5 sm:h-5 text-pink-300" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold text-pink-100 tracking-tight leading-none mt-0.5 drop-shadow pointer-events-none">
            กิจกรรม
          </span>
        </button>

        {/* รายวัน (Daily Rewards) */}
        <button
          type="button"
          onPointerDown={isolatePointer}
          onClick={handleAction(onOpenDaily)}
          className="group relative flex flex-col items-center justify-center w-11 h-11 sm:w-14 sm:h-14 game-wood-panel rounded-xl sm:rounded-2xl shadow-lg border border-sky-400/80 active:scale-90 active:brightness-95 transition-transform touch-manipulation cursor-pointer"
          title="รางวัลล็อกอินรายวัน"
        >
          <div className="w-5 h-5 sm:w-7 sm:h-7 rounded-md sm:rounded-lg bg-sky-500/30 flex items-center justify-center text-sky-200 group-hover:text-white transition-colors pointer-events-none">
            <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-sky-300" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold text-sky-100 tracking-tight leading-none mt-0.5 drop-shadow pointer-events-none">
            รายวัน
          </span>
        </button>
      </div>

      {/* ปุ่มพับเก็บเมนูด้านซ้าย สำหรับมือถือ */}
      <button
        type="button"
        onPointerDown={isolatePointer}
        onClick={handleAction(() => setIsCollapsed((prev) => !prev))}
        className="w-6 h-9 sm:w-7 sm:h-10 bg-amber-950/90 hover:bg-amber-900 border border-amber-500/60 rounded-r-xl flex items-center justify-center text-amber-200 shadow-md active:scale-90 transition-all mt-1 touch-manipulation cursor-pointer"
        title={isCollapsed ? 'แสดงเมนู' : 'ซ่อนเมนู'}
      >
        {isCollapsed ? (
          <ChevronRight className="w-4 h-4 pointer-events-none" />
        ) : (
          <ChevronLeft className="w-4 h-4 pointer-events-none" />
        )}
      </button>
    </aside>
  );
};