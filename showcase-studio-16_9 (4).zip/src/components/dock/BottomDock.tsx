import React, { useState, useCallback } from 'react';
import { Map, Briefcase, Hammer, PawPrint, Factory, Store, Users, MessageSquare, ChevronDown, ChevronUp } from 'lucide-react';
import { sound } from '../../utils/audio/index';
import { FarmLog } from '../../types/game';

interface BottomDockProps {
  logs: FarmLog[];
  inventoryBadge: number;
  onOpenMap: () => void;
  onOpenInventory: () => void;
  onOpenBuild: () => void;
  onOpenAnimals: () => void;
  onOpenProduction: () => void;
  onOpenMarket: () => void;
  onOpenFriends: () => void;
  onOpenLogoInfo: () => void;
}

export const BottomDock: React.FC<BottomDockProps> = ({
  logs,
  inventoryBadge,
  onOpenMap,
  onOpenInventory,
  onOpenBuild,
  onOpenAnimals,
  onOpenProduction,
  onOpenMarket,
  onOpenFriends,
  onOpenLogoInfo,
}) => {
  const [showMobileLogs, setShowMobileLogs] = useState(false);

  // Helper สำหรับปุ่ม Action: แตะครั้งเดียวติดทันที ไม่หน่วง และไม่ทะลุไปขยับแผนที่
  const fastAction = useCallback((callback: () => void) => {
    return (e: React.MouseEvent | React.PointerEvent) => {
      e.stopPropagation();
      try {
        sound.playClick();
      } catch {}
      callback();
    };
  }, []);

  return (
    <div 
      onPointerDown={(e) => e.stopPropagation()}
      className="dock-root relative z-30 flex flex-col md:flex-row items-center md:items-end justify-between px-2 pt-0 pointer-events-none gap-1 sm:gap-2 select-none pb-[calc(0.375rem+env(safe-area-inset-bottom,0px))]"
      style={{ touchAction: 'none' }}
    >
      {/* Bottom Left: Live Activity Ticker */}
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        className="dock-log pointer-events-auto self-start touch-manipulation"
      >
        {/* ปุ่มเปิด/ปิดประวัติบนมือถือ */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(() => setShowMobileLogs(!showMobileLogs))}
          className="md:hidden flex items-center gap-1.5 bg-stone-900/85 backdrop-blur-md px-3 py-1 rounded-full border border-stone-600/70 text-emerald-400 text-[10px] font-bold shadow-lg active:scale-95 transition-transform mb-1 touch-manipulation cursor-pointer"
        >
          <MessageSquare className="w-3 h-3 pointer-events-none" />
          <span className="pointer-events-none">บันทึกฟาร์ม</span>
          {showMobileLogs ? <ChevronDown className="w-3 h-3 pointer-events-none" /> : <ChevronUp className="w-3 h-3 pointer-events-none" />}
        </button>

        {/* กล่องข้อความประวัติ */}
        <div
          className={`${
            showMobileLogs ? 'flex' : 'hidden'
          } md:flex flex-col gap-1 max-w-[260px] sm:max-w-[320px] bg-stone-900/90 backdrop-blur-md rounded-2xl p-2 border border-stone-700/80 shadow-xl`}
        >
          <div className="flex items-center gap-1.5 text-stone-300 text-[10px] font-bold pb-1 border-b border-stone-800">
            <MessageSquare className="w-3 h-3 text-emerald-400 pointer-events-none" />
            <span>บันทึกความเคลื่อนไหวฟาร์ม</span>
          </div>
          <div className="flex flex-col gap-1 max-h-[64px] sm:max-h-[88px] overflow-y-auto game-scroll text-[10px] sm:text-xs">
            {logs.slice(-3).map((log) => (
              <div key={log.id} className="flex items-start gap-1 text-emerald-300 leading-tight">
                <span className="text-[9px] mt-0.5">💬</span>
                <span className="text-stone-200 line-clamp-2">{log.message}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Center: Main Action Dock (จุดสำคัญที่สุดสำหรับมือถือ) */}
      <div 
        onPointerDown={(e) => e.stopPropagation()}
        className="dock-main pointer-events-auto flex items-center justify-center gap-1 sm:gap-1.5 game-wood-board rounded-2xl sm:rounded-3xl p-1 sm:p-2 shadow-2xl border-2 border-amber-600/70 max-w-full overflow-x-auto touch-manipulation overscroll-contain"
        style={{ touchAction: 'pan-x' }}
      >
        {/* แผนที่ (Map) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenMap)}
          className="flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="แผนที่ฟาร์มและเมือง"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-sky-600 to-cyan-400 flex items-center justify-center text-white shadow pointer-events-none">
            <Map className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">แผนที่</span>
        </button>

        {/* กระเป๋า (Inventory / Barn) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenInventory)}
          className="relative flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="คลังเก็บผลผลิต"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-amber-700 to-amber-500 flex items-center justify-center text-white shadow pointer-events-none">
            <Briefcase className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">กระเป๋า</span>
          {inventoryBadge > 0 && (
            <span className="absolute -top-0.5 right-0.5 min-w-4 h-4 px-1 rounded-full bg-red-600 text-white text-[8px] sm:text-[9px] font-black flex items-center justify-center border border-white animate-pulse pointer-events-none">
              {inventoryBadge}
            </span>
          )}
        </button>

        {/* ก่อสร้าง (Build) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenBuild)}
          className="flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="ก่อสร้างและตกแต่งฟาร์ม"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-stone-600 to-stone-400 flex items-center justify-center text-white shadow pointer-events-none">
            <Hammer className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">ก่อสร้าง</span>
        </button>

        {/* สัตว์ (Animals) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenAnimals)}
          className="flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="ดูแลปศุสัตว์"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-400 flex items-center justify-center text-white shadow pointer-events-none">
            <PawPrint className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">สัตว์</span>
        </button>

        {/* ผลิต (Production) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenProduction)}
          className="flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="โรงงานแปรรูปสินค้า"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-sky-400 flex items-center justify-center text-white shadow pointer-events-none">
            <Factory className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">ผลิต</span>
        </button>

        {/* ตลาด (Market) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenMarket)}
          className="flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="ตลาดนัดและรถขนส่ง"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white shadow pointer-events-none">
            <Store className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">ตลาด</span>
        </button>

        {/* เพื่อน (Friends) */}
        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={fastAction(onOpenFriends)}
          className="flex flex-col items-center justify-center min-w-[44px] sm:min-w-[54px] py-1 px-1 rounded-xl hover:bg-white/10 active:scale-90 active:brightness-95 transition-all text-amber-100 touch-manipulation cursor-pointer"
          title="ระบบเพื่อนและของขวัญ"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow pointer-events-none">
            <Users className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span className="text-[9px] sm:text-[11px] font-bold mt-0.5 drop-shadow leading-none pointer-events-none">เพื่อน</span>
        </button>
      </div>

      {/* Bottom Right: Logo Plaque (สำหรับจอใหญ่ PC) */}
      <div
        onPointerDown={(e) => e.stopPropagation()}
        onClick={fastAction(onOpenLogoInfo)}
        className="pointer-events-auto hidden lg:flex items-center gap-2 game-wood-panel rounded-2xl p-2 pr-4 border-2 border-amber-400/90 shadow-2xl cursor-pointer hover:scale-105 active:scale-95 transition-transform touch-manipulation"
        title="Dream Farm (B.P.)"
      >
        <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white shadow bg-amber-400 flex items-center justify-center pointer-events-none">
          <img
            src="/src/assets/images/cow_mascot_logo_1790916726207.jpg"
            alt="Cow Mascot"
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.style.display = 'none';
            }}
          />
        </div>
        <div className="flex flex-col pointer-events-none">
          <span className="text-base font-black text-amber-200 tracking-wide drop-shadow">
            Dream Farm <span className="text-yellow-300 text-xs">(B.P.)</span>
          </span>
          <span className="text-[11px] font-bold text-emerald-300 drop-shadow">
            ปลูกวันนี้... สร้างอนาคตที่ดีกว่า 🌱
          </span>
        </div>
      </div>
    </div>
  );
};