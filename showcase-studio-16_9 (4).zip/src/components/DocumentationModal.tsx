import React from 'react';
import { BookOpen, X, Code, Activity, Mic, Layers, Film, Gem, CheckCircle } from 'lucide-react';

interface DocumentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DocumentationModal: React.FC<DocumentationModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-4xl w-full max-h-[85dvh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-cyan-400" />
            <h3 className="font-bold text-base text-neutral-100">
              SHOWCASE STUDIO 16:9 — ARCHITECTURE & API REFERENCE
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-neutral-300 text-xs leading-relaxed">
          {/* Overview */}
          <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800/80">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" /> 1. สถาปัตยกรรมระบบ Tri-Rate Pipeline
            </h4>
            <p className="text-neutral-400 mb-3">
              ระบบ Showcase Studio 16:9 ออกแบบมาเพื่อรันบนเบราว์เซอร์ 100% โดยแบ่งการประมวลผลออกเป็น 3 ความถี่เพื่อประสิทธิภาพสูงสุด:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-[11px]">
              <div className="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <span className="text-emerald-400 font-bold block mb-1">240Hz AUDIO DSP</span>
                <span className="text-neutral-400">ประมวลผล Biquad Formant Filters 7 ตัวกรอง และจำแนก 7 Viseme ภาษาไทยทุกๆ 4.16ms</span>
              </div>
              <div className="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <span className="text-cyan-400 font-bold block mb-1">120Hz TMJ PHYSICS</span>
                <span className="text-neutral-400">คำนวณชีวกลศาสตร์ข้อต่อขากรรไกร (Mass-Spring-Damper), Condylar Slide, Respiration และ Tremor</span>
              </div>
              <div className="bg-neutral-900 p-3 rounded-lg border border-neutral-800">
                <span className="text-pink-400 font-bold block mb-1">60Hz 1080p ENCODE</span>
                <span className="text-neutral-400">เรนเดอร์ Canvas 16:9, Three.js 3D X-Ray, Amulet PIP และบันทึกวิดีโอ MP4 Fast-Start 12 Mbps</span>
              </div>
            </div>
          </div>

          {/* Thai Visemes Engine */}
          <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800/80">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <Mic className="w-4 h-4 text-amber-400" /> 2. Thai Viseme Engine (ตารางความถี่ 7 รูปปากภาษาไทย)
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse font-sans">
                <thead>
                  <tr className="border-b border-neutral-800 text-neutral-400 font-mono text-[10px]">
                    <th className="py-2">รูปสระ/พยัญชนะ</th>
                    <th>ชื่อ Viseme</th>
                    <th>ลักษณะทางกายวิภาค</th>
                    <th>F1 (Hz)</th>
                    <th>F2 (Hz)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 text-neutral-300">
                  <tr>
                    <td className="py-2 font-bold text-rose-400">ม, บ, พ, ป, ผ, ภ</td>
                    <td>Lip Lock</td>
                    <td>ริมฝีปากบน-ล่างประกบสนิท (Bilabial Closure)</td>
                    <td>~300</td>
                    <td>~850</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold text-amber-400">อา, อะ, ั, ำ</td>
                    <td>Pharynx Open</td>
                    <td>อ้าปากกว้าง คอหอยเปิด ขากรรไกรล่างลดต่ำ</td>
                    <td>~750</td>
                    <td>~1200</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold text-emerald-400">อี, เอ, แ, ิ</td>
                    <td>Zygo Spread</td>
                    <td>มุมปากสองข้างฉีกกว้าง ลิ้นยกสูงแนบเพดาน</td>
                    <td>~350</td>
                    <td>~2300</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold text-cyan-400">อู, โอ, ุ, ู</td>
                    <td>Orbic Round</td>
                    <td>ริมฝีปากห่อยื่นเป็นวงกลม (Protrusion)</td>
                    <td>~380</td>
                    <td>~880</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold text-blue-400">ด, ต, น, ล, ร</td>
                    <td>Tip Curl</td>
                    <td>ปลายลิ้นยกแตะปุ่มเหงือกบน (Alveolar)</td>
                    <td>~450</td>
                    <td>~1800</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold text-indigo-400">ก, ข, ค, ง</td>
                    <td>Velar Dorsum</td>
                    <td>โคนลิ้นยกแตะเพดานอ่อน (Velar Arch)</td>
                    <td>~400</td>
                    <td>~1400</td>
                  </tr>
                  <tr>
                    <td className="py-2 font-bold text-purple-400">ฟ, ฝ</td>
                    <td>Dental Tuck</td>
                    <td>ฟันบนแตะขอบริมฝีปากล่าง (Labiodental)</td>
                    <td>~500</td>
                    <td>4000+</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* TMJ Biomechanics & Formulas */}
          <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800/80">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" /> 3. สมการฟิสิกส์ TMJ (Temporomandibular Biomechanics)
            </h4>
            <div className="space-y-2 font-mono text-[11px] text-neutral-400">
              <p>
                <strong className="text-neutral-200">Mass-Spring-Damper:</strong><br />
                <code>m · a(t) = -k · (θ(t) - θ_target) · recoil - c · v(t)</code>
              </p>
              <p>
                <strong className="text-neutral-200">Condylar Slide Kinematics:</strong><br />
                <code>Y_condyle = sin(2.2 · θ) · 12.0mm · slideRatio (เลื่อนต่ำลง)</code><br />
                <code>Z_condyle = sin(2.2 · θ) · 7.5mm · slideRatio (เลื่อนไปข้างหน้า)</code>
              </p>
              <p>
                <strong className="text-neutral-200">Respiration & Biological Sway:</strong><br />
                <code>T_breath = 3.8 วินาที | Sway_X = sin(0.23 · 2πt) · 3.0mm | Tremor = sin(8.0 · 2πt) · 0.4mm</code>
              </p>
            </div>
          </div>

          {/* Troubleshooting */}
          <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800/80">
            <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" /> 4. การแก้ไขปัญหา (Troubleshooting & Browser Support)
            </h4>
            <ul className="space-y-1.5 list-disc list-inside text-neutral-400">
              <li><strong>ไมโครโฟนไม่ทำงาน:</strong> ตรวจสอบสิทธิ์ไมโครโฟนในเบราว์เซอร์ หากไม่อนุญาต ระบบจะสลับไปใช้ Web Speech API TTS หรือระบบสระจำลองโดยอัตโนมัติ</li>
              <li><strong>Export MP4 จอดำหรือบันทึกไม่ติด:</strong> ระบบมี Auto-Validation และ colorSpace fallback สลับไปยัง WebM/H.264 ตามที่เบราว์เซอร์รองรับ</li>
              <li><strong>Three.js กระตุก:</strong> สามารถลดขนาดหรือปรับโหมดแสดงผลเป็น PIP เพื่อประหยัดทรัพยากร GPU</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
