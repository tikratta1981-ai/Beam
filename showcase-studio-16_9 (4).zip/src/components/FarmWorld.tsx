// src/components/FarmWorld.tsx

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Plot, AnimalPen, Factory, InventoryItem } from '../types/game';
import { CROPS } from '../data/initialData';
import { sound } from '../utils/audio';
import { Chicken3D } from './3d/Chicken3D';
import { Goat3D } from './3d/models/animals/Goat3D';
import { Sheep3D } from './3d/models/animals/Sheep3D';
import { Cow3D } from './3d/models/animals/Cow3D';
import { Pig3D } from './3d/Pig3D';
import { FarmCharacters3D } from './3d/FarmCharacters3D';
import { BakeryOven3D } from './3d/BakeryOven3D';
import { DraggableCorn3D } from './3d/DraggableCorn3D';
import { IsometricPig3D, PigEntity } from './3d/IsometricPig3D';
import { House3D } from './3d/House3D';
import { harvestSystem, HarvestSystem } from './farm/HarvestSystem';
import { HarvestTool } from './farm/HarvestTool';
import { IsometricPlot3D } from './farm/IsometricPlot3D';
import {
  STAGE_BASE_WIDTH,
  STAGE_BASE_HEIGHT,
  GRID_SIZE,
  FREE_PLOT_TYPE,
  FREE_PLOT_MIN,
  UNIQUE_FACILITY_TYPES,
  BEAUTIFUL_DEFAULT_LAYOUT,
  BUILDABLE_CATALOG,
  PlacedEntity,
  CatalogItem,
} from '../data/farmWorldData';
import { FarmControls } from './farm/FarmControls';
import { BuildableCatalogModal } from './farm/BuildableCatalogModal';
import { EntityToolbar } from './farm/EntityToolbar';
import { FreePlot } from './farm/FreePlot';
import { Fish, Sparkles, Zap, Plus } from 'lucide-react';

interface FarmWorldProps {
  plots: Plot[];
  animals: AnimalPen[];
  factories: Record<string, Factory>;
  onPlotClick: (plotId: number) => void;
  onHarvestPlot: (plotId: number) => void;
  onSpeedUpPlot: (plotId: number) => void;
  onMovePlot?: (plotId: number, x: number, y: number) => void;
  onDeletePlot?: (plotId: number) => void;
  onAddPlot?: () => void;
  onAnimalClick: (animalId: string) => void;
  onCollectAnimal: (animalId: string) => void;
  onFactoryClick: (factoryId: string) => void;
  onCollectFactory: (factoryId: string) => void;
  onOpenBarn: () => void;
  onOpenTruckOrders: () => void;
  onPickFruit: (type: 'apple' | 'orange') => void;
  onFish: () => void;
  fruitReady: { apple: boolean; orange: boolean };
  inventory?: Record<string, InventoryItem>;
  onFeedCatFish?: () => void;
  currentFarmId?: string;

  // Props สำหรับระบบหมู 3D กายวิภาคชีวภาพ
  pigs?: PigEntity[];
  onFeedPigClick?: (pigId: string) => void;
  onCollectPigClick?: (pigId: string) => void;
  onMovePig?: (pigId: string, newX: number, newY: number) => void;

  // [NEW] Props สำหรับระบบบ้านพักชาวสวน (Zone 1 Farmhouse Upgrade)
  houseLevel?: number;
  onHouseClick?: () => void;
}

const safePlaySound = (soundFn: () => void | Promise<void>) => {
  try {
    const res = soundFn();
    if (res && typeof (res as Promise<void>).catch === 'function') {
      (res as Promise<void>).catch(() => {});
    }
  } catch {}
};

export const FarmWorld: React.FC<FarmWorldProps> = ({
  plots = [],
  animals,
  factories,
  onPlotClick,
  onHarvestPlot,
  onSpeedUpPlot,
  onMovePlot,
  onDeletePlot,
  onAddPlot,
  onAnimalClick,
  onCollectAnimal,
  onFactoryClick,
  onCollectFactory,
  onOpenBarn,
  onOpenTruckOrders,
  onPickFruit,
  onFish,
  fruitReady,
  inventory = {},
  onFeedCatFish,
  currentFarmId,
  pigs = [],
  onFeedPigClick = () => {},
  onCollectPigClick = () => {},
  onMovePig = () => {},
  // ค่าเริ่มต้นสำหรับบ้านพัก
  houseLevel = 1,
  onHouseClick,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const timeoutsRef = useRef<Set<NodeJS.Timeout>>(new Set());

  // === Active Farm Map State (Farm 1 vs Farm 2 เกาะมรกต) ===
  const [internalFarmId, setInternalFarmId] = useState<string>(() => {
    try {
      return localStorage.getItem('beam_farm_active_map_id') || 'farm1';
    } catch {
      return 'farm1';
    }
  });

  useEffect(() => {
    const handleFarmChange = (e: any) => {
      if (e?.detail) setInternalFarmId(e.detail);
    };
    window.addEventListener('farmMapChanged', handleFarmChange);
    return () => window.removeEventListener('farmMapChanged', handleFarmChange);
  }, []);

  const activeFarm = currentFarmId || internalFarmId;

  // === Viewport & Scaling State ===
  const [baseScale, setBaseScale] = useState<number>(1);
  const [userZoom, setUserZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDraggingMap, setIsDraggingMap] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // === Multi-Touch Pinch Zoom Tracking ===
  const activePointersRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  const pinchInitialDistRef = useRef<number | null>(null);
  const pinchInitialZoomRef = useRef<number>(1);

  // === Game & Edit Mode State ===
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [selectedInstanceId, setSelectedInstanceId] = useState<string | null>(null);
  const [selectedPlotId, setSelectedPlotId] = useState<number | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [snapToGrid, setSnapToGrid] = useState<boolean>(true);
  const [showCharacters3D, setShowCharacters3D] = useState<boolean>(true);
  const [timeOfDay, setTimeOfDay] = useState<'day' | 'twilight' | 'night'>('day');

  // === Sickle Harvesting System State ===
  const [isSickleActive, setIsSickleActive] = useState<boolean>(false);

  // แปลงข้าวโพด 3D
  const [cornPlotsState, setCornPlotsState] = useState({
    grand200Ready: true,
    plot1Ready: true,
  });

  const [freePlotReady, setFreePlotReady] = useState<Record<string, boolean>>({});
  const resizingRef = useRef<{
    instanceId: string;
    pointerId: number;
    pointerStartX: number;
    pointerStartY: number;
    startW: number;
    startH: number;
  } | null>(null);

  // Entity Dragging
  const draggingEntityRef = useRef<{
    instanceId: string;
    pointerId: number;
    startX: number;
    startY: number;
    pointerStartX: number;
    pointerStartY: number;
  } | null>(null);

  // Plot Dragging
  const draggingPlotRef = useRef<{
    plotId: number;
    pointerId: number;
    startX: number;
    startY: number;
    pointerStartX: number;
    pointerStartY: number;
  } | null>(null);

  const [, setForceRender] = useState({});
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const [placedItems, setPlacedItems] = useState<PlacedEntity[]>(() => {
    try {
      const saved = localStorage.getItem('beam_farm_placed_items_v5');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return BEAUTIFUL_DEFAULT_LAYOUT;
  });

  const persistItems = useCallback((items: PlacedEntity[]) => {
    try {
      localStorage.setItem('beam_farm_placed_items_v5', JSON.stringify(items));
    } catch (e) {
      console.error('Failed to persist farm items:', e);
    }
  }, []);

  const handleImageError = (idKey: string) => {
    setFailedImages((prev) => ({ ...prev, [idKey]: true }));
  };

  const [floatingEffects, setFloatingEffects] = useState<
    { id: number; x: number; y: number; text: string; icon: string }[]
  >([]);

  const spawnFloatingEffect = useCallback((clientX: number, clientY: number, text: string, icon: string) => {
    const rect = containerRef.current?.getBoundingClientRect();
    const x = rect ? clientX - rect.left : clientX;
    const y = rect ? clientY - rect.top : clientY;
    const id = Date.now() + Math.random();

    setFloatingEffects((prev) => [...prev, { id, x, y, text, icon }]);
    const t = setTimeout(() => {
      setFloatingEffects((prev) => prev.filter((item) => item.id !== id));
      timeoutsRef.current.delete(t);
    }, 1200);
    timeoutsRef.current.add(t);
  }, []);

  // === Sickle Reaping FX ===
  const [reapFx, setReapFx] = useState<
    { id: number; x: number; y: number; kind: 'slash' | 'severed'; icon: string }[]
  >([]);

  const spawnReapFx = useCallback(
    (clientX: number, clientY: number, cropType: string, combo: number) => {
      const rect = containerRef.current?.getBoundingClientRect();
      const x = rect ? clientX - rect.left : clientX;
      const y = rect ? clientY - rect.top : clientY;
      const base = Date.now() + Math.random();
      const icon = CROPS[cropType]?.icon || (cropType === 'corn' ? '🌽' : cropType === 'wheat' ? '🌾' : '🥕');

      setReapFx((prev) =>
        [
          ...prev,
          { id: base, x, y, kind: 'slash' as const, icon: '' },
          { id: base + 0.1, x, y, kind: 'severed' as const, icon },
        ].slice(-40)
      );
      const t = setTimeout(() => {
        setReapFx((prev) => prev.filter((f) => f.id !== base && f.id !== base + 0.1));
        timeoutsRef.current.delete(t);
      }, 450);
      timeoutsRef.current.add(t);

      const label = HarvestSystem.comboLabel(combo);
      spawnFloatingEffect(clientX, clientY - 28, label ?? `+10 ${CROPS[cropType]?.thaiName || cropType}!`, '🌾');
    },
    [spawnFloatingEffect]
  );

  const onHarvestPlotRef = useRef(onHarvestPlot);
  useEffect(() => {
    onHarvestPlotRef.current = onHarvestPlot;
  }, [onHarvestPlot]);
  const commitHarvest = useCallback((id: number) => onHarvestPlotRef.current(id), []);

  const readyPlotCount = plots.filter((p) => p.isReady).length;

  const handleHarvestAll = useCallback(() => {
    if (isEditMode) return;
    const readyPlots = plots.filter((p) => p.isReady);
    if (readyPlots.length === 0) return;

    harvestSystem.startSwipe();
    readyPlots.forEach((plot, i) => {
      const t = setTimeout(() => {
        timeoutsRef.current.delete(t);
        const el = document.querySelector(`[data-plot-id="${plot.id}"]`);
        const r = el?.getBoundingClientRect();
        const cx = r ? r.left + r.width / 2 : window.innerWidth / 2;
        const cy = r ? r.top + r.height / 2 : window.innerHeight / 2;
        harvestSystem.checkAndHarvest(plot.id, plot, commitHarvest, (res) => {
          spawnReapFx(cx, cy, res.cropType, res.combo ?? 1);
        });
        if (i === readyPlots.length - 1) harvestSystem.endSwipe();
      }, i * 90);
      timeoutsRef.current.add(t);
    });
  }, [plots, isEditMode, commitHarvest, spawnReapFx]);

  const currentTotalScale = baseScale * userZoom;

  const clampPanCoordinates = useCallback(
    (targetPan: { x: number; y: number }, scale: number) => {
      if (!containerRef.current) return targetPan;
      const { clientWidth, clientHeight } = containerRef.current;
      const renderedWidth = STAGE_BASE_WIDTH * scale;
      const renderedHeight = STAGE_BASE_HEIGHT * scale;
      const maxX = Math.max(0, (renderedWidth - clientWidth) / 2);
      const maxY = Math.max(0, (renderedHeight - clientHeight) / 2);

      return {
        x: Math.max(-maxX, Math.min(maxX, targetPan.x)),
        y: Math.max(-maxY, Math.min(maxY, targetPan.y)),
      };
    },
    []
  );

  const updateViewportScale = useCallback(() => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    if (clientWidth === 0 || clientHeight === 0) return;

    const scaleX = clientWidth / STAGE_BASE_WIDTH;
    const scaleY = clientHeight / STAGE_BASE_HEIGHT;
    const nextBase = Math.max(scaleX, scaleY);
    setBaseScale(nextBase);
    setPan((prev) => clampPanCoordinates(prev, nextBase * userZoom));
  }, [clampPanCoordinates, userZoom]);

  useEffect(() => {
    updateViewportScale();
    const observer = new ResizeObserver(updateViewportScale);
    if (containerRef.current) observer.observe(containerRef.current);
    window.addEventListener('resize', updateViewportScale);

    const handleGlobalBlur = () => {
      activePointersRef.current.clear();
      draggingEntityRef.current = null;
      draggingPlotRef.current = null;
      setIsDraggingMap(false);
      pinchInitialDistRef.current = null;
      harvestSystem.endSwipe();
    };
    window.addEventListener('blur', handleGlobalBlur);

    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateViewportScale);
      window.removeEventListener('blur', handleGlobalBlur);
      timeoutsRef.current.forEach((t) => clearTimeout(t));
      timeoutsRef.current.clear();
    };
  }, [updateViewportScale]);

  const handleZoomChange = useCallback(
    (nextZoom: number) => {
      const clampedZoom = Math.max(1.0, Math.min(2.5, Number(nextZoom.toFixed(2))));
      setUserZoom(clampedZoom);
      setPan((prev) => clampPanCoordinates(prev, baseScale * clampedZoom));
    },
    [baseScale, clampPanCoordinates]
  );

  const isInteractiveElement = (target: EventTarget | null): boolean => {
    if (!(target instanceof HTMLElement)) return false;
    return !!target.closest(
      'button, input, select, textarea, [role="button"], .interactive-target, .interactive-ui, .modal-backdrop'
    );
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isSickleActive && !isEditMode) {
      harvestSystem.startSwipe();
      const targetElement = document.elementFromPoint(e.clientX, e.clientY);
      const plotElement = targetElement?.closest('[data-plot-id]');
      if (plotElement) {
        const plotId = Number(plotElement.getAttribute('data-plot-id'));
        const targetPlot = plots.find((p) => p.id === plotId);
        if (targetPlot && targetPlot.isReady) {
          harvestSystem.checkAndHarvest(plotId, targetPlot, commitHarvest, (res) => {
            spawnReapFx(e.clientX, e.clientY, res.cropType, res.combo ?? 1);
          });
        }
      }
      return;
    }

    if (isInteractiveElement(e.target)) return;

    activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (activePointersRef.current.size === 2) {
      const points = Array.from(activePointersRef.current.values());
      const dist = Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
      pinchInitialDistRef.current = dist;
      pinchInitialZoomRef.current = userZoom;
      setIsDraggingMap(false);
      return;
    }

    if (activePointersRef.current.size === 1) {
      setSelectedInstanceId(null);
      setSelectedPlotId(null);
      setIsDraggingMap(true);
      dragStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
      try {
        e.currentTarget.setPointerCapture(e.pointerId);
      } catch {}
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isSickleActive && harvestSystem.getIsSwiping() && !isEditMode) {
      const targetElement = document.elementFromPoint(e.clientX, e.clientY);
      const plotElement = targetElement?.closest('[data-plot-id]');
      if (plotElement) {
        const plotId = Number(plotElement.getAttribute('data-plot-id'));
        const targetPlot = plots.find((p) => p.id === plotId);
        if (targetPlot && targetPlot.isReady) {
          harvestSystem.checkAndHarvest(plotId, targetPlot, commitHarvest, (res) => {
            spawnReapFx(e.clientX, e.clientY, res.cropType, res.combo ?? 1);
          });
        }
      }
      return;
    }

    if (activePointersRef.current.has(e.pointerId)) {
      activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }

    if (activePointersRef.current.size === 2 && pinchInitialDistRef.current) {
      const points = Array.from(activePointersRef.current.values());
      const currentDist = Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
      const zoomRatio = currentDist / pinchInitialDistRef.current;
      handleZoomChange(pinchInitialZoomRef.current * zoomRatio);
      return;
    }

    // ลากย้ายแปลงผัก
    if (draggingPlotRef.current && draggingPlotRef.current.pointerId === e.pointerId) {
      const { plotId, startX, startY, pointerStartX, pointerStartY } = draggingPlotRef.current;
      const deltaX = (e.clientX - pointerStartX) / currentTotalScale;
      const deltaY = (e.clientY - pointerStartY) / currentTotalScale;

      let targetX = Math.round(startX + deltaX);
      let targetY = Math.round(startY + deltaY);

      if (snapToGrid) {
        targetX = Math.round(targetX / GRID_SIZE) * GRID_SIZE;
        targetY = Math.round(targetY / GRID_SIZE) * GRID_SIZE;
      }

      targetX = Math.max(0, Math.min(STAGE_BASE_WIDTH - 120, targetX));
      targetY = Math.max(0, Math.min(STAGE_BASE_HEIGHT - 92, targetY));

      onMovePlot?.(plotId, targetX, targetY);
      return;
    }

    // ลากย้ายสิ่งก่อสร้าง
    if (draggingEntityRef.current && draggingEntityRef.current.pointerId === e.pointerId) {
      const { instanceId, startX, startY, pointerStartX, pointerStartY } = draggingEntityRef.current;
      const deltaX = (e.clientX - pointerStartX) / currentTotalScale;
      const deltaY = (e.clientY - pointerStartY) / currentTotalScale;

      setPlacedItems((prev) =>
        prev.map((it) => {
          if (it.instanceId !== instanceId) return it;

          const isRotated90 = (it.rotation || 0) % 180 !== 0;
          const boundW = isRotated90 ? it.height : it.width;
          const boundH = isRotated90 ? it.width : it.height;

          let targetX = Math.round(startX + deltaX);
          let targetY = Math.round(startY + deltaY);

          if (snapToGrid) {
            targetX = Math.round(targetX / GRID_SIZE) * GRID_SIZE;
            targetY = Math.round(targetY / GRID_SIZE) * GRID_SIZE;
          }

          return {
            ...it,
            x: Math.max(0, Math.min(STAGE_BASE_WIDTH - boundW, targetX)),
            y: Math.max(0, Math.min(STAGE_BASE_HEIGHT - boundH, targetY)),
          };
        })
      );
      return;
    }

    // เลื่อนแผนที่
    if (isDraggingMap && activePointersRef.current.size === 1) {
      const rawPan = {
        x: e.clientX - dragStartRef.current.x,
        y: e.clientY - dragStartRef.current.y,
      };
      setPan(clampPanCoordinates(rawPan, currentTotalScale));
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    harvestSystem.endSwipe();
    activePointersRef.current.delete(e.pointerId);

    if (draggingPlotRef.current?.pointerId === e.pointerId) {
      draggingPlotRef.current = null;
      setForceRender({});
    }

    if (draggingEntityRef.current && draggingEntityRef.current.pointerId === e.pointerId) {
      draggingEntityRef.current = null;
      setForceRender({});
      setPlacedItems((latest) => {
        persistItems(latest);
        return latest;
      });
    }

    if (activePointersRef.current.size === 1) {
      const remainingPoint = Array.from(activePointersRef.current.values())[0];
      dragStartRef.current = { x: remainingPoint.x - pan.x, y: remainingPoint.y - pan.y };
      setIsDraggingMap(true);
      pinchInitialDistRef.current = null;
    } else if (activePointersRef.current.size === 0) {
      setIsDraggingMap(false);
      pinchInitialDistRef.current = null;
    }

    try {
      if (e.currentTarget.hasPointerCapture(e.pointerId)) {
        e.currentTarget.releasePointerCapture(e.pointerId);
      }
    } catch {}
  };

  const handlePointerCancel = (e: React.PointerEvent<HTMLDivElement>) => {
    harvestSystem.endSwipe();
    activePointersRef.current.delete(e.pointerId);
    if (draggingPlotRef.current?.pointerId === e.pointerId) {
      draggingPlotRef.current = null;
    }
    if (draggingEntityRef.current?.pointerId === e.pointerId) {
      draggingEntityRef.current = null;
      setForceRender({});
    }
    if (activePointersRef.current.size === 0) {
      setIsDraggingMap(false);
      pinchInitialDistRef.current = null;
    }
  };

  const handleEntityPointerDown = (e: React.PointerEvent, item: PlacedEntity) => {
    if (!isEditMode) return;
    e.stopPropagation();
    setSelectedPlotId(null);
    setSelectedInstanceId(item.instanceId);

    draggingEntityRef.current = {
      instanceId: item.instanceId,
      pointerId: e.pointerId,
      startX: item.x,
      startY: item.y,
      pointerStartX: e.clientX,
      pointerStartY: e.clientY,
    };
    setForceRender({});

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
  };

  const handlePlotPointerDown = (e: React.PointerEvent, plot: Plot) => {
    if (!isEditMode) return;
    e.stopPropagation();
    setSelectedInstanceId(null);
    setSelectedPlotId(plot.id);

    const plotIdx = plots.findIndex((p) => p.id === plot.id);
    const plotX = plot.x ?? 510 + (plotIdx >= 0 ? plotIdx % 5 : 0) * 114;
    const plotY = plot.y ?? 310 + Math.floor((plotIdx >= 0 ? plotIdx : 0) / 5) * 86;

    draggingPlotRef.current = {
      plotId: plot.id,
      pointerId: e.pointerId,
      startX: plotX,
      startY: plotY,
      pointerStartX: e.clientX,
      pointerStartY: e.clientY,
    };
    setForceRender({});

    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
  };

  const handleWheel = (e: React.WheelEvent) => {
    const delta = e.deltaY < 0 ? 0.08 : -0.08;
    handleZoomChange(userZoom + delta);
  };

  const handleAutoArrange = () => {
    safePlaySound(() => sound.playClick());
    setPlacedItems(BEAUTIFUL_DEFAULT_LAYOUT);
    persistItems(BEAUTIFUL_DEFAULT_LAYOUT);
    setSelectedInstanceId(null);
    setSelectedPlotId(null);
  };

  const handleSpawnItem = (template: CatalogItem, e?: React.MouseEvent) => {
    safePlaySound(() => sound.playClick());

    if (UNIQUE_FACILITY_TYPES.has(template.type)) {
      const alreadyExists = placedItems.some((item) => item.type === template.type);
      if (alreadyExists) {
        if (e) {
          spawnFloatingEffect(e.clientX, e.clientY, `มี ${template.name} ในฟาร์มแล้ว!`, '⚠️');
        }
        return;
      }
    }

    let spawnX = 576;
    let spawnY = 480;

    if (template.type === FREE_PLOT_TYPE) {
      const n = placedItems.filter((i) => i.type === FREE_PLOT_TYPE).length;
      spawnX += (n % 5) * GRID_SIZE;
      spawnY += (n % 5) * GRID_SIZE;
    }

    if (snapToGrid) {
      spawnX = Math.round(spawnX / GRID_SIZE) * GRID_SIZE;
      spawnY = Math.round(spawnY / GRID_SIZE) * GRID_SIZE;
    }

    const newItem: PlacedEntity = {
      instanceId: `item_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: template.type,
      name: template.name,
      icon: template.icon,
      imgSrc: template.imgSrc,
      x: spawnX,
      y: spawnY,
      width: template.width,
      height: template.height,
      rotation: 0,
      flipX: false,
    };

    setPlacedItems((prev) => {
      const next = [...prev, newItem];
      persistItems(next);
      return next;
    });
    setSelectedInstanceId(newItem.instanceId);
    setSelectedPlotId(null);
    setIsEditMode(true);
    setIsMenuOpen(false);
  };

  const handleAddFreePlot = () => {
    const template = BUILDABLE_CATALOG.find((c) => c.type === FREE_PLOT_TYPE);
    if (template) handleSpawnItem(template);
  };

  const growFreePlot = (instanceId: string) => {
    setFreePlotReady((prev) => ({ ...prev, [instanceId]: false }));
    const t = setTimeout(() => {
      setFreePlotReady((prev) => ({ ...prev, [instanceId]: true }));
      timeoutsRef.current.delete(t);
    }, 20000);
    timeoutsRef.current.add(t);
  };

  const handleResizeStart = (e: React.PointerEvent, item: PlacedEntity) => {
    e.stopPropagation();
    resizingRef.current = {
      instanceId: item.instanceId,
      pointerId: e.pointerId,
      pointerStartX: e.clientX,
      pointerStartY: e.clientY,
      startW: item.width,
      startH: item.height,
    };
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
  };

  const handleResizeMove = (e: React.PointerEvent, item: PlacedEntity) => {
    const r = resizingRef.current;
    if (!r || r.pointerId !== e.pointerId || r.instanceId !== item.instanceId) return;
    e.stopPropagation();
    const rotated90 = (item.rotation || 0) % 180 !== 0;
    const dx = (e.clientX - r.pointerStartX) / currentTotalScale;
    const dy = (e.clientY - r.pointerStartY) / currentTotalScale;
    let w = r.startW + (rotated90 ? dy : dx);
    let h = r.startH + (rotated90 ? dx : dy);
    if (snapToGrid) {
      w = Math.round(w / GRID_SIZE) * GRID_SIZE;
      h = Math.round(h / GRID_SIZE) * GRID_SIZE;
    }
    w = Math.max(FREE_PLOT_MIN, Math.min(STAGE_BASE_WIDTH - item.x, Math.round(w)));
    h = Math.max(FREE_PLOT_MIN, Math.min(STAGE_BASE_HEIGHT - item.y, Math.round(h)));
    setPlacedItems((prev) =>
      prev.map((it) => (it.instanceId === item.instanceId ? { ...it, width: w, height: h } : it))
    );
  };

  const handleResizeEnd = (e: React.PointerEvent) => {
    if (resizingRef.current?.pointerId !== e.pointerId) return;
    e.stopPropagation();
    resizingRef.current = null;
    setPlacedItems((latest) => {
      persistItems(latest);
      return latest;
    });
  };

  const handleDeleteItem = (instanceId: string) => {
    safePlaySound(() => sound.playClick());
    setPlacedItems((prev) => {
      const next = prev.filter((item) => item.instanceId !== instanceId);
      persistItems(next);
      return next;
    });
    if (selectedInstanceId === instanceId) {
      setSelectedInstanceId(null);
    }
  };

  const handleRotateItem = (instanceId: string) => {
    safePlaySound(() => sound.playClick());
    setPlacedItems((prev) => {
      const next = prev.map((item) =>
        item.instanceId === instanceId
          ? { ...item, rotation: ((item.rotation || 0) + 90) % 360 }
          : item
      );
      persistItems(next);
      return next;
    });
  };

  const handleFlipItem = (instanceId: string) => {
    safePlaySound(() => sound.playClick());
    setPlacedItems((prev) => {
      const next = prev.map((item) =>
        item.instanceId === instanceId ? { ...item, flipX: !item.flipX } : item
      );
      persistItems(next);
      return next;
    });
  };

  const getFactoryData = (type: string) => {
    const key = type.includes('bakery') ? 'bakery' : type.includes('dairy') ? 'dairy' : type.includes('jam') ? 'jam' : null;
    return key ? { key, data: factories[key] } : null;
  };

  const getAnimalPenData = (type: string) => {
    const penType = type.includes('chicken') ? 'chicken' : type.includes('cow') ? 'cow' : type.includes('pig') ? 'pig' : type.includes('sheep') ? 'sheep' : type.includes('goat') ? 'goat' : null;
    return penType ? animals.find((a) => a.type === penType) : null;
  };

  const handleEntityClick = (e: React.MouseEvent, item: PlacedEntity) => {
    if (isEditMode) {
      e.stopPropagation();
      setSelectedPlotId(null);
      setSelectedInstanceId(item.instanceId);
      return;
    }
    e.stopPropagation();

    // 🏡 บ้านพักชาวสวน (คลิกเพื่อเปิดหน้าต่างอัปเกรดบ้าน)
    if (item.type.includes('farmhouse')) {
      safePlaySound(() => sound.playClick());
      if (onHouseClick) {
        onHouseClick();
      } else {
        onOpenBarn();
      }
      return;
    }

    // 📦 โรงนาและยุ้งฉาง
    if (item.type.includes('barn_silo')) {
      safePlaySound(() => sound.playClick());
      onOpenBarn();
      return;
    }

    // 🍞 เตาอบขนมปัง
    if (item.type.includes('bakery')) {
      const factoryMeta = getFactoryData('bakery');
      if (factoryMeta?.data?.completedItems && factoryMeta.data.completedItems.length > 0) {
        onCollectFactory('bakery');
        spawnFloatingEffect(e.clientX, e.clientY, 'รับขนมปังหอมกรุ่น! 🍞', '✨');
      } else {
        onFactoryClick('bakery');
      }
      return;
    }

    // 🌽 แปลงข้าวโพด 200 ตร.ม.
    if (item.type === 'corn_3d_grand_200sqm') {
      if (cornPlotsState.grand200Ready) {
        sound.playHarvest();
        spawnFloatingEffect(e.clientX, e.clientY, '+80🪙 ข้าวโพด 200 ตร.ม. ท่อนปอง!', '🌽');
        setCornPlotsState((prev) => ({ ...prev, grand200Ready: false }));
      }
      return;
    }

    // 🌱 แปลงปลูกอิสระ
    if (item.type === FREE_PLOT_TYPE) {
      if (freePlotReady[item.instanceId] !== false) {
        sound.playHarvest();
        spawnFloatingEffect(e.clientX, e.clientY, '+30🪙 เก็บเกี่ยวจากแปลงอิสระ!', '🌽');
        growFreePlot(item.instanceId);
      }
      return;
    }

    // 🌽 แปลงข้าวโพดแปลง 1
    if (item.type === 'corn_3d_plot_1') {
      if (cornPlotsState.plot1Ready) {
        sound.playHarvest();
        spawnFloatingEffect(e.clientX, e.clientY, '+45🪙 ข้าวโพดแปลง 1 ทางเดินหลัก!', '🌽');
        setCornPlotsState((prev) => ({ ...prev, plot1Ready: false }));
      }
      return;
    }

    // 🚚 รถกระบะส่งของ
    if (item.type.includes('truck')) {
      safePlaySound(() => sound.playTruckHorn());
      onOpenTruckOrders();
      return;
    }

    // โรงงานอื่น ๆ
    const factoryMeta = getFactoryData(item.type);
    if (factoryMeta) {
      const { key, data } = factoryMeta;
      if (data?.completedItems && data.completedItems.length > 0) {
        onCollectFactory(key);
        spawnFloatingEffect(e.clientX, e.clientY, 'เก็บผลผลิตแปรรูปสำเร็จ! ✨', '📦');
      } else {
        onFactoryClick(key);
      }
      return;
    }

    // คอกสัตว์
    const pen = getAnimalPenData(item.type);
    if (pen) {
      safePlaySound(() => sound.playAnimal(pen.type));
      if (pen.isReady) {
        onCollectAnimal(pen.id);
        spawnFloatingEffect(e.clientX, e.clientY, `+${pen.produceQuantity} ${pen.produceName}`, pen.produceIcon);
      } else {
        onAnimalClick(pen.id);
      }
      return;
    }

    // ต้นผลไม้
    if (item.type.includes('tree')) {
      const isOrange = item.type.includes('orange');
      const fruitType = isOrange ? 'orange' : 'apple';
      const isReady = isOrange ? fruitReady.orange : fruitReady.apple;

      if (isReady) {
        onPickFruit(fruitType);
        spawnFloatingEffect(
          e.clientX,
          e.clientY,
          isOrange ? '+2 ส้มสดฉ่ำ!' : '+2 แอปเปิ้ลสด!',
          isOrange ? '🍊' : '🍎'
        );
      } else {
        safePlaySound(() => sound.playClick());
      }
      return;
    }

    // บ่อน้ำ
    if (item.type.includes('water_well')) {
      safePlaySound(() => sound.playWater());
      spawnFloatingEffect(e.clientX, e.clientY, 'ตักน้ำใสบริสุทธิ์ 💧', '✨');
      return;
    }

    safePlaySound(() => sound.playClick());
  };

  const isCurrentlyDragging = !!draggingEntityRef.current || !!draggingPlotRef.current;

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden select-none cursor-grab active:cursor-grabbing bg-[#4d8c28] touch-none"
      style={{ touchAction: 'none', WebkitUserSelect: 'none' }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
      onWheel={handleWheel}
    >
      <style>{`
        @keyframes gentle-breathe {
          0%, 100% { transform: scale(1) translateY(0); }
          50% { transform: scale(1.025, 0.98) translateY(-2px); }
        }
        @keyframes tree-sway {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(1.2deg); }
          75% { transform: rotate(-1.2deg); }
        }
        .anim-breathe { animation: gentle-breathe 3.5s ease-in-out infinite; }
        .anim-sway { animation: tree-sway 4s ease-in-out infinite; transform-origin: bottom center; }
      `}</style>

      {/* แถบปุ่มควบคุมและการซูม */}
      <div className="interactive-ui pointer-events-auto">
        <FarmControls
          isEditMode={isEditMode}
          onToggleEditMode={() => {
            safePlaySound(() => sound.playClick());
            setIsEditMode((prev) => {
              if (prev) {
                setSelectedInstanceId(null);
                setSelectedPlotId(null);
                persistItems(placedItems);
              }
              return !prev;
            });
            draggingEntityRef.current = null;
            draggingPlotRef.current = null;
          }}
          snapToGrid={snapToGrid}
          onToggleSnapToGrid={() => {
            safePlaySound(() => sound.playClick());
            setSnapToGrid((prev) => !prev);
          }}
          onAutoArrange={handleAutoArrange}
          onAddFreePlot={handleAddFreePlot}
          onOpenCatalog={() => {
            safePlaySound(() => sound.playClick());
            setIsMenuOpen(true);
          }}
          showCharacters3D={showCharacters3D}
          onToggleCharacters3D={() => {
            safePlaySound(() => sound.playClick());
            setShowCharacters3D((prev) => !prev);
          }}
          timeOfDay={timeOfDay}
          onToggleTimeOfDay={() => {
            safePlaySound(() => sound.playClick());
            setTimeOfDay((prev) => (prev === 'day' ? 'twilight' : prev === 'twilight' ? 'night' : 'day'));
          }}
          userZoom={userZoom}
          onZoomIn={() => {
            safePlaySound(() => sound.playClick());
            handleZoomChange(userZoom + 0.15);
          }}
          onZoomOut={() => {
            safePlaySound(() => sound.playClick());
            handleZoomChange(userZoom - 0.15);
          }}
          onResetView={() => {
            safePlaySound(() => sound.playClick());
            setUserZoom(1);
            setPan({ x: 0, y: 0 });
          }}
        />

        {/* ปุ่มลอยเพิ่มแปลงผักโดยตรงในโหมดแก้ไข */}
        {isEditMode && onAddPlot && (
          <div className="absolute top-20 left-4 z-40">
            <button
              onClick={() => {
                safePlaySound(() => sound.playClick());
                onAddPlot();
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white font-bold text-xs shadow-xl border-2 border-emerald-300 active:scale-95 transition-transform cursor-pointer"
              title="เพิ่มแปลงผักใหม่ไม่จำกัด"
            >
              <Plus className="w-4 h-4" />
              <span>เพิ่มแปลงผัก 🌱</span>
            </button>
          </div>
        )}

        {/* ปุ่มลอยเลือกโหมดเคียวเก็บเกี่ยว และปุ่มเรียกหมู */}
        {!isEditMode && (
          <div className="absolute top-20 right-4 z-40 flex items-center gap-2">
            {pigs && pigs.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  safePlaySound(() => sound.playAnimal('pig'));
                  const firstPig = pigs[0];
                  if (firstPig && onMovePig) {
                    onMovePig(firstPig.id, 640, 480);
                  }
                  spawnFloatingEffect(window.innerWidth / 2, window.innerHeight / 2, 'เรียกหมูมาแล้ว! 🐷', '🌾');
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-500 hover:from-pink-500 hover:to-rose-400 text-white font-black text-xs shadow-xl border-2 border-pink-300 active:scale-95 transition-all cursor-pointer backdrop-blur-md"
                title="เป่านกหวีดเรียกหมูมาที่หน้าจอ"
              >
                <span className="text-sm">🪈</span>
                <span>เรียกหมู 🐷</span>
              </button>
            )}
            <HarvestTool
              readyCount={readyPlotCount}
              onHarvestAll={handleHarvestAll}
              isActive={isSickleActive}
              onToggleTool={(active) => {
                safePlaySound(() => sound.playClick());
                setIsSickleActive(active);
              }}
            />
          </div>
        )}
      </div>

      {/* โมดอลเลือกสิ่งก่อสร้าง */}
      <div className="interactive-ui">
        <BuildableCatalogModal
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          placedItems={placedItems}
          failedImages={failedImages}
          onImageError={handleImageError}
          catalog={BUILDABLE_CATALOG}
          onSpawnItem={handleSpawnItem}
        />
      </div>

      {/* Floating Gain Effects */}
      <div className="absolute inset-0 pointer-events-none z-[120]">
        {floatingEffects.map((eff) => (
          <div
            key={eff.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 text-white font-black text-sm drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] animate-bounce flex items-center gap-1 bg-stone-900/90 border border-yellow-400 px-3 py-1 rounded-full shadow-2xl"
            style={{ left: `${eff.x}px`, top: `${eff.y}px` }}
          >
            <span>{eff.icon}</span>
            <span>{eff.text}</span>
          </div>
        ))}
      </div>

      {/* Sickle Reaping FX */}
      <div className="absolute inset-0 pointer-events-none z-[119]">
        {reapFx.map((f) =>
          f.kind === 'slash' ? (
            <div
              key={f.id}
              className="absolute -translate-x-1/2 -translate-y-1/2 w-20 h-1.5 rounded-full bg-gradient-to-r from-transparent via-yellow-200 to-white animate-slash-streak"
              style={{ left: `${f.x}px`, top: `${f.y}px` }}
            />
          ) : (
            <div
              key={f.id}
              className="absolute -translate-x-1/2 -translate-y-1/2 text-3xl animate-severed"
              style={{ left: `${f.x}px`, top: `${f.y}px` }}
            >
              {f.icon}
            </div>
          )
        )}
      </div>

      {/* ผืนผ้าใบฟาร์มหลัก */}
      <div
        className="absolute top-1/2 left-1/2 w-[1440px] h-[960px] origin-center will-change-transform"
        style={{
          transform: `translate3d(calc(-50% + ${pan.x}px), calc(-50% + ${pan.y}px), 0) scale(${currentTotalScale})`,
          transition: isDraggingMap || isCurrentlyDragging ? 'none' : 'transform 150ms ease-out',
        }}
      >
        <div className="absolute inset-0 overflow-hidden bg-[#4d8c28]">
          <img
            key={activeFarm}
            src={activeFarm === 'farm2' ? '/farm2_bg.jpg' : '/farm_bg.jpg'}
            alt={activeFarm === 'farm2' ? 'Emerald Island Farm 2' : 'Riverside Farm 1'}
            className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none transition-opacity duration-300"
            draggable={false}
            onError={(e) => {
              const target = e.currentTarget as HTMLImageElement;
              if (!target.src.endsWith('/farm_bg.jpg')) {
                target.src = '/farm_bg.jpg';
              }
            }}
          />

          {/* สระน้ำมรกตตกปลา */}
          <div
            onClick={(e) => {
              if (isEditMode) return;
              e.stopPropagation();
              onFish();
              spawnFloatingEffect(e.clientX, e.clientY, '+ปลาเทราต์สด!', '🐟');
            }}
            className="interactive-target absolute bottom-[40px] left-[50px] w-80 h-72 rounded-full cursor-pointer hover:ring-4 hover:ring-cyan-300 flex flex-col items-center justify-center transition-all group z-10"
            title="สระน้ำมรกต (คลิกเพื่อตกปลา)"
          >
            {!isEditMode && (
              <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-stone-900/90 text-cyan-200 text-xs font-black px-3 py-1.5 rounded-full border border-cyan-400 flex items-center gap-1 shadow-lg pointer-events-none">
                <Fish className="w-4 h-4" /> ตกปลา 🎣
              </div>
            )}
          </div>

          {/* 🏮 โคมไฟไม้สไตล์ญี่ปุ่น */}
          <div
            className="absolute top-[685px] left-[315px] pointer-events-none z-15 flex flex-col items-center"
            title="โคมไฟไม้ริมทางเดิน"
          >
            <div className="relative w-7 h-11 flex flex-col items-center">
              <div className="w-8 h-2 bg-[#451a03] rounded-t border-t border-[#78350f] shadow-md" />
              <div
                className={`w-5 h-6 rounded-sm border border-[#78350f] flex items-center justify-center transition-all duration-700 ${
                  timeOfDay !== 'day'
                    ? 'bg-amber-300 shadow-[0_0_24px_rgba(251,191,36,0.9)] animate-pulse'
                    : 'bg-amber-100/90'
                }`}
              >
                <div className={`w-2.5 h-2.5 rounded-full ${timeOfDay !== 'day' ? 'bg-amber-400' : 'bg-amber-200'}`} />
              </div>
              <div className="w-3.5 h-3.5 bg-[#57534e] rounded-b border border-[#44403c] shadow-sm" />
            </div>
          </div>

          {/* 🏮 โคมไฟไม้จุดที่ 2 */}
          <div
            className="absolute top-[750px] left-[215px] pointer-events-none z-15 flex flex-col items-center"
            title="โคมไฟไม้ริมสะพานเทียบเรือ"
          >
            <div className="relative w-7 h-11 flex flex-col items-center">
              <div className="w-8 h-2 bg-[#451a03] rounded-t border-t border-[#78350f] shadow-md" />
              <div
                className={`w-5 h-6 rounded-sm border border-[#78350f] flex items-center justify-center transition-all duration-700 ${
                  timeOfDay !== 'day'
                    ? 'bg-amber-300 shadow-[0_0_24px_rgba(251,191,36,0.9)] animate-pulse'
                    : 'bg-amber-100/90'
                }`}
              >
                <div className={`w-2.5 h-2.5 rounded-full ${timeOfDay !== 'day' ? 'bg-amber-400' : 'bg-amber-200'}`} />
              </div>
              <div className="w-3.5 h-3.5 bg-[#57534e] rounded-b border border-[#44403c] shadow-sm" />
            </div>
          </div>

          {/* 🪑 ม้านั่งไม้ริมน้ำ */}
          <div className="absolute top-[785px] left-[272px] pointer-events-none z-14 flex flex-col items-center">
            <div className="w-9 h-4 bg-[#78350f] rounded-sm border-t-2 border-[#b45309] shadow-md flex justify-between px-1">
              <div className="w-1 h-3 bg-[#451a03]" />
              <div className="w-1 h-3 bg-[#451a03]" />
            </div>
          </div>

          {/* 🌅 แสงยามเย็น / 🌙 แสงยามค่ำคืน */}
          {timeOfDay === 'twilight' && (
            <div className="absolute inset-0 pointer-events-none z-20 bg-gradient-to-br from-amber-800/25 via-orange-900/20 to-amber-950/30 mix-blend-color-burn transition-all duration-700" />
          )}
          {timeOfDay === 'night' && (
            <>
              <div className="absolute inset-0 pointer-events-none z-20 bg-gradient-to-b from-indigo-950/45 via-slate-950/50 to-indigo-950/40 mix-blend-multiply transition-all duration-700" />
              <div className="absolute top-[700px] left-[80px] w-64 h-56 bg-cyan-200/15 rounded-full blur-2xl pointer-events-none z-21 animate-pulse duration-[3000ms]" />
            </>
          )}

          {/* ========================================================
             🌾 แปลงพืชเกษตรหลัก 3D
             ======================================================== */}
          {plots.map((plot, plotIndex) => {
            const cropKey = plot.cropId || (plot as any).cropType;
            const isSelected = isEditMode && selectedPlotId === plot.id;

            const plotX = plot.x ?? 510 + (plotIndex % 5) * 114;
            const plotY = plot.y ?? 310 + Math.floor(plotIndex / 5) * 86;

            return (
              <div
                key={plot.id}
                data-plot-id={plot.id}
                onPointerDown={(e) => handlePlotPointerDown(e, plot)}
                style={{
                  left: `${plotX}px`,
                  top: `${plotY}px`,
                  zIndex: isSelected ? 9995 : Math.round(plotY + 88),
                  touchAction: 'none',
                }}
                className={`interactive-target absolute ${
                  isEditMode ? 'cursor-grab active:cursor-grabbing' : 'cursor-pointer'
                }`}
              >
                <IsometricPlot3D
                  plot={plot}
                  width={120}
                  height={92}
                  isSelected={isSelected}
                  onClick={(e) => {
                    if (isEditMode) {
                      e.stopPropagation();
                      setSelectedInstanceId(null);
                      setSelectedPlotId(plot.id);
                      return;
                    }

                    e.stopPropagation();

                    if (!cropKey) {
                      safePlaySound(() => sound.playClick());
                      onPlotClick(plot.id);
                      return;
                    }

                    if (plot.isReady) {
                      onHarvestPlot(plot.id);
                      spawnReapFx(e.clientX, e.clientY, cropKey, 1);
                      return;
                    }

                    safePlaySound(() => sound.playClick());
                    onSpeedUpPlot(plot.id);
                  }}
                />

                {isSelected && (
                  <div className="interactive-ui">
                    <EntityToolbar
                      onDelete={() => {
                        safePlaySound(() => sound.playClick());
                        onDeletePlot?.(plot.id);
                        setSelectedPlotId(null);
                      }}
                      onConfirm={() => {
                        safePlaySound(() => sound.playClick());
                        setSelectedPlotId(null);
                      }}
                    />
                  </div>
                )}
              </div>
            );
          })}

          {/* ========================================================
             🐷 เรนเดอร์หมู 3 มิติกายวิภาคสมจริง (IsometricPig3D)
             ======================================================== */}
          {pigs.map((pig) => (
            <div key={pig.id} className="interactive-target">
              <IsometricPig3D
                pig={pig}
                onFeedClick={onFeedPigClick}
                onCollectClick={onCollectPigClick}
                onMove={onMovePig}
              />
            </div>
          ))}

          {/* ========================================================
             สิ่งก่อสร้าง สัตว์ และของตกแต่ง
             ======================================================== */}
          {placedItems.map((item) => {
            const isDraggingThis = draggingEntityRef.current?.instanceId === item.instanceId;
            const isSelected = isEditMode && selectedInstanceId === item.instanceId;
            const computedZIndex = isDraggingThis ? 9999 : isSelected ? 9990 : Math.round(item.y + item.height);

            const isRotated90 = (item.rotation || 0) % 180 !== 0;
            const effectiveWidth = isRotated90 ? item.height : item.width;
            const effectiveHeight = isRotated90 ? item.width : item.height;

            const isFarmhouse = item.type.includes('farmhouse');
            const isBakery3D = item.type === 'bakery_oven';
            const isGrandCorn = item.type === 'corn_3d_grand_200sqm';
            const isPlot1Corn = item.type === 'corn_3d_plot_1';
            const isAnyCorn3D = isGrandCorn || isPlot1Corn;
            const isFreePlot = item.type === FREE_PLOT_TYPE;
            const isFreePlotReady = freePlotReady[item.instanceId] !== false;

            const animalData = getAnimalPenData(item.type);
            const factoryMeta = getFactoryData(item.type);
            const isAnimal = !!animalData;
            const isTree = item.type.includes('tree');
            const isProducing = !!factoryMeta?.data?.currentProduction;
            const isFactoryReady = !!factoryMeta?.data?.completedItems && factoryMeta.data.completedItems.length > 0;

            const isCornReady = isGrandCorn ? cornPlotsState.grand200Ready : cornPlotsState.plot1Ready;

            return (
              <div
                key={item.instanceId}
                onPointerDown={(e) => handleEntityPointerDown(e, item)}
                onClick={(e) => handleEntityClick(e, item)}
                style={{
                  left: `${item.x}px`,
                  top: `${item.y}px`,
                  width: `${effectiveWidth}px`,
                  height: `${effectiveHeight}px`,
                  zIndex: computedZIndex,
                  touchAction: 'none',
                }}
                className={`interactive-target absolute cursor-pointer flex items-center justify-center group ${
                  isSelected
                    ? 'ring-4 ring-yellow-400 rounded-3xl bg-amber-500/20 cursor-grab active:cursor-grabbing shadow-2xl'
                    : isEditMode
                    ? 'hover:ring-2 hover:ring-yellow-300/60 rounded-2xl'
                    : 'hover:scale-[1.02] transition-transform'
                }`}
              >
                {/* 🏡 [NEW] บ้านพักชาวสวน 3D พร้อมป้ายเลเวลและปุ่มอัปเกรด */}
                {isFarmhouse ? (
                  <div
                    className="w-full h-full relative flex items-center justify-center"
                    style={{
                      transform: `rotate(${item.rotation || 0}deg) scaleX(${item.flipX ? -1 : 1})`,
                    }}
                  >
                    <div className="w-full h-full drop-shadow-2xl">
                      <House3D type="farmhouse" seamless={true} className="w-full h-full" />
                    </div>

                    {!isEditMode && (
                      <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-40 pointer-events-none bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 text-amber-200 px-3 py-0.5 rounded-full font-bold text-[11px] shadow-2xl border-2 border-amber-300 flex items-center gap-1.5 whitespace-nowrap">
                        <span>🏡</span>
                        <span>บ้านพัก Lv.{houseLevel}</span>
                        <span className="bg-amber-400 text-stone-900 text-[9px] px-1 py-0.2 rounded font-black">
                          UPGRADE
                        </span>
                      </div>
                    )}
                  </div>
                ) : isBakery3D ? (
                  <div
                    className="w-full h-full relative flex items-center justify-center"
                    style={{
                      transform: `rotate(${item.rotation || 0}deg) scaleX(${item.flipX ? -1 : 1})`,
                    }}
                  >
                    <BakeryOven3D
                      isProducing={isProducing}
                      width={effectiveWidth}
                      height={effectiveHeight}
                    />

                    {!isEditMode && isFactoryReady && (
                      <div className="absolute -top-7 z-40 bg-white/95 rounded-full p-2 border-2 border-amber-400 shadow-2xl animate-bounce flex items-center justify-center pointer-events-none">
                        <span className="text-2xl drop-shadow">🍞</span>
                        <span className="text-[10px] font-black text-amber-600 ml-1">สุกแล้ว!</span>
                      </div>
                    )}
                  </div>
                ) : isFreePlot ? (
                  <div className="w-full h-full relative">
                    <FreePlot width={effectiveWidth} height={effectiveHeight} isReady={isFreePlotReady} />
                    {!isEditMode && isFreePlotReady && (
                      <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 z-40 pointer-events-none bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 text-stone-900 px-3 py-0.5 rounded-full font-black text-[11px] shadow-2xl border-2 border-white animate-bounce flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-700" />
                        <span>เก็บเกี่ยว 🌽</span>
                      </div>
                    )}
                    {!isEditMode && !isFreePlotReady && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-40 pointer-events-none bg-stone-900/90 px-2.5 py-0.5 rounded-full border border-lime-400 text-[10px] font-bold text-lime-300">
                        🌱 กำลังโต...
                      </div>
                    )}
                    {isSelected && (
                      <div
                        onPointerDown={(e) => handleResizeStart(e, item)}
                        onPointerMove={(e) => handleResizeMove(e, item)}
                        onPointerUp={handleResizeEnd}
                        onPointerCancel={handleResizeEnd}
                        style={{ touchAction: 'none' }}
                        className="absolute -bottom-3 -right-3 z-[60] w-7 h-7 rounded-full bg-lime-500 border-2 border-white shadow-lg flex items-center justify-center cursor-nwse-resize text-white text-xs font-black"
                        title="ลากเพื่อย่อ/ขยายแปลง"
                      >
                        ⤡
                      </div>
                    )}
                  </div>
                ) : isAnyCorn3D ? (
                  <div
                    className="w-full h-full relative flex items-center justify-center"
                    style={{
                      transform: `rotate(${item.rotation || 0}deg) scaleX(${item.flipX ? -1 : 1})`,
                    }}
                  >
                    <DraggableCorn3D
                      isGrand={isGrandCorn}
                      isReady={isCornReady}
                      isWatered={true}
                      width={effectiveWidth}
                      height={effectiveHeight}
                    />

                    {!isEditMode && (
                      <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 pointer-events-auto flex flex-col items-center z-40">
                        {isCornReady ? (
                          <button
                            type="button"
                            onClick={(e) => handleEntityClick(e, item)}
                            className="bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-400 text-stone-900 px-3.5 py-1 rounded-full font-black text-xs shadow-2xl border-2 border-white animate-bounce flex items-center gap-1 cursor-pointer hover:scale-105 active:scale-95"
                          >
                            <Sparkles className="w-3.5 h-3.5 text-amber-700 animate-spin" />
                            <span>เก็บเกี่ยว {isGrandCorn ? '200 ตร.ม. 🌽' : 'แปลน 1 🌽'}</span>
                          </button>
                        ) : (
                          <div className="flex items-center gap-1 bg-stone-900/90 backdrop-blur-xs px-2.5 py-0.5 rounded-full border border-amber-400 shadow">
                            <span className="text-[10px] font-mono font-bold text-yellow-300">🌽 กำลังโต...</span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                sound.playSuccessChime();
                                if (isGrandCorn) {
                                  setCornPlotsState((prev) => ({ ...prev, grand200Ready: true }));
                                } else {
                                  setCornPlotsState((prev) => ({ ...prev, plot1Ready: true }));
                                }
                              }}
                              className="text-[9px] text-cyan-300 hover:text-white font-bold flex items-center gap-0.5 ml-1"
                            >
                              <Zap className="w-2.5 h-2.5" /> 1💎
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : item.type.includes('chicken_coop') && !isEditMode ? (
                  <div className="w-full h-full relative">
                    <Chicken3D
                      seamless
                      compact
                      readyProduce={animalData?.isReady ? animalData.produceQuantity : 0}
                      isFed={!!animalData?.fedAt && !animalData?.isReady}
                      onFeed={() => {
                        if (animalData) onAnimalClick(animalData.id);
                      }}
                      onCollectEggs={() => {
                        if (animalData?.isReady) onCollectAnimal(animalData.id);
                      }}
                    />
                  </div>
                ) : (item.type.includes('goat_pen') || item.type.includes('goat')) && !isEditMode ? (
                  <div className="w-full h-full relative">
                    <Goat3D
                      seamless
                      compact
                      readyProduce={animalData?.isReady ? animalData.produceQuantity : 0}
                      isFed={!!animalData?.fedAt && !animalData?.isReady}
                      onFeed={() => {
                        if (animalData) onAnimalClick(animalData.id);
                      }}
                      onCollectMilk={() => {
                        if (animalData?.isReady) onCollectAnimal(animalData.id);
                      }}
                    />
                  </div>
                ) : (item.type.includes('sheep_pen') || item.type.includes('sheep')) && !isEditMode ? (
                  <div className="w-full h-full relative">
                    <Sheep3D
                      seamless
                      compact
                      readyProduce={animalData?.isReady ? animalData.produceQuantity : 0}
                      isFed={!!animalData?.fedAt && !animalData?.isReady}
                      onFeed={() => {
                        if (animalData) onAnimalClick(animalData.id);
                      }}
                      onCollectProduce={() => {
                        if (animalData?.isReady) onCollectAnimal(animalData.id);
                      }}
                    />
                  </div>
                ) : (item.type.includes('cow_pen') || item.type.includes('cow_pasture') || item.type.includes('cow')) && !isEditMode ? (
                  <div className="w-full h-full relative">
                    <Cow3D
                      seamless
                      compact
                      readyProduce={animalData?.isReady ? animalData.produceQuantity : 0}
                      isFed={!!animalData?.fedAt && !animalData?.isReady}
                      onFeed={() => {
                        if (animalData) onAnimalClick(animalData.id);
                      }}
                      onCollectProduce={() => {
                        if (animalData?.isReady) onCollectAnimal(animalData.id);
                      }}
                    />
                  </div>
                ) : (item.type.includes('pig_pen') || item.type.includes('pig')) && !isEditMode ? (
                  <div className="w-full h-full relative">
                    <Pig3D
                      seamless
                      compact
                      readyProduce={animalData?.isReady ? animalData.produceQuantity : 0}
                      isFed={!!animalData?.fedAt && !animalData?.isReady}
                      onFeed={() => {
                        if (animalData) onAnimalClick(animalData.id);
                      }}
                      onCollectProduce={() => {
                        if (animalData?.isReady) onCollectAnimal(animalData.id);
                      }}
                    />
                  </div>
                ) : (
                  <div
                    className={`relative w-full h-full flex items-center justify-center ${
                      isAnimal && !isEditMode ? 'anim-breathe' : ''
                    } ${isTree && !isEditMode ? 'anim-sway' : ''}`}
                  >
                    <div
                      className="flex items-center justify-center transition-transform duration-200"
                      style={{
                        width: `${item.width}px`,
                        height: `${item.height}px`,
                        transform: `rotate(${item.rotation || 0}deg) scaleX(${item.flipX ? -1 : 1})`,
                      }}
                    >
                      {item.imgSrc && !failedImages[item.instanceId] ? (
                        <img
                          src={item.imgSrc}
                          alt={item.name}
                          onError={() => handleImageError(item.instanceId)}
                          className="w-full h-full object-contain drop-shadow-[0_4px_6px_rgba(20,35,12,0.32)] select-none pointer-events-none"
                          draggable={false}
                        />
                      ) : (
                        <span className="text-5xl select-none drop-shadow-md pointer-events-none">
                          {item.icon}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {isSelected && (
                  <div className="interactive-ui">
                    <EntityToolbar
                      onRotate={() => handleRotateItem(item.instanceId)}
                      onFlip={() => handleFlipItem(item.instanceId)}
                      onDelete={() => handleDeleteItem(item.instanceId)}
                      onConfirm={() => {
                        safePlaySound(() => sound.playClick());
                        setSelectedInstanceId(null);
                      }}
                    />
                  </div>
                )}
              </div>
            );
          })}

          {showCharacters3D && (
            <FarmCharacters3D
              isEditMode={isEditMode}
              inventory={inventory}
              onOpenFishing={onFish}
              onFeedCatFish={onFeedCatFish}
              onCharacterClick={(char) => {
                spawnFloatingEffect(window.innerWidth / 2, window.innerHeight / 2, `${char.name} ทักทายคุณ!`, '💖');
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};