// src/components/FarmView.tsx
import React, { useEffect } from 'react';
import { Pig3D } from './3d/Pig3D';
import { useFarmStore } from '../store/useFarmStore';
import { GAME_ITEMS } from '../data/items';

export const FarmView: React.FC = () => {
  const {
    coins,
    inventory,
    pigPen,
    feedPig,
    collectPigProduce,
    checkProduceTimer,
    sellTruffles,
  } = useFarmStore();

  // ตรวจสถานะผลผลิตทุกๆ 2 วินาที
  useEffect(() => {
    const timer = setInterval(() => {
      checkProduceTimer();
    }, 2000);
    return () => clearInterval(timer);
  }, [checkProduceTimer]);

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-4 font-['Kanit',sans-serif]">
      {/* ส่วนหัวแสดงเงินและคลังไอเทม */}
      <header className="flex flex-wrap items-center justify-between p-3.5 bg-amber-950/80 rounded-2xl border-2 border-amber-600/50 shadow-xl backdrop-blur-md text-white">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🏡</span>
          <div>
            <h1 className="text-base font-black text-amber-200">แฮปปี้ฟาร์ม</h1>
            <p className="text-xs text-amber-300/80">เหรียญในกระเป๋า: 🪙 {coins.toLocaleString()} G</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="px-2.5 py-1 bg-black/40 rounded-xl border border-white/10 flex items-center gap-1">
            <span>🥣 {GAME_ITEMS.pig_feed?.name || 'อาหารหมู'}:</span>
            <span className="font-bold text-amber-300">{inventory.pig_feed}</span>
          </div>
          <div className="px-2.5 py-1 bg-black/40 rounded-xl border border-white/10 flex items-center gap-1">
            <span>🍄 {GAME_ITEMS.truffle?.name || 'ทรัฟเฟิล'}:</span>
            <span className="font-bold text-emerald-300">{inventory.truffle}</span>
          </div>
          {inventory.truffle > 0 && (
            <button
              onClick={sellTruffles}
              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold cursor-pointer transition-transform active:scale-95 shadow"
            >
              ขายเห็ด (+{inventory.truffle * 120} G)
            </button>
          )}
        </div>
      </header>

      {/* กล่องคอกหมู 3D Pig3D */}
      <section className="bg-gradient-to-b from-amber-950/40 to-black/60 p-4 rounded-3xl border border-amber-800/40 shadow-2xl">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl">🐷</span>
            <h2 className="font-bold text-amber-200 text-sm">คอกหมูอารมณ์ดี (Truffle Pig Pen)</h2>
          </div>
          <span className="text-xs text-amber-400/80">
            {pigPen.isFed ? '🟢 หมูกำลังกินอิ่ม & ช่วยกันคุ้ยหาเห็ด' : '⚪ หมูเริ่มหิวแล้ว โปรยอาหารเพิ่มเลย!'}
          </span>
        </div>

        {/* 🌟 เรียกใช้ Pig3D ตรงนี้ 🌟 */}
        <div className="flex items-center justify-center p-4">
          <Pig3D
            readyProduce={pigPen.produceCount}
            isFed={pigPen.isFed}
            onFeed={() => {
              const ok = feedPig();
              if (!ok && inventory.pig_feed <= 0) {
                // แจ้งเตือนเมื่ออาหารหมด
              }
            }}
            onCollectProduce={() => {
              const count = collectPigProduce();
              if (count > 0) {
                // เก็บผลผลิตสำเร็จ
              }
            }}
          />
        </div>
      </section>
    </div>
  );
};
