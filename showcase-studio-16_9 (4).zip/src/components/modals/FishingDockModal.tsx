// src/components/modals/FishingDockModal.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  ArrowLeft,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Sparkles,
  BookOpen,
  Award,
  Package,
  Check,
  Plus,
  Coins,
  Sun,
  Sunset,
  Moon,
} from 'lucide-react';
import { EmeraldLake3D } from '../3d/EmeraldLake3D';
import { sound } from '../../utils/audio';
import { InventoryItem } from '../../types/game';
import confetti from 'canvas-confetti';

interface FishingDockModalProps {
  isOpen: boolean;
  onClose: () => void;
  energy: number;
  onConsumeEnergy?: (amount: number) => boolean;
  onAddFishToInventory?: (fish: any, weight: number) => void;
  onAddRewards?: (coins: number, xp: number) => void;
  inventory?: Record<string, InventoryItem>;
  onConsumeItems?: (items: { itemId: string; count: number }[]) => boolean;
  gems?: number;
  luckyFisherBuff?: number;
  onConsumeLuckyBuff?: () => void;
  timeOfDay?: 'day' | 'twilight' | 'night';
  onToggleTimeOfDay?: () => void;
}

export interface FishSpeciesInfo {
  id: string;
  name: string;
  thaiName: string;
  icon: string;
  rarity: 'ทั่วไป' | 'หายาก' | 'แรร์' | 'ตำนาน';
  price: number;
  xp: number;
  minW: number;
  maxW: number;
  description: string;
  bestBait: string;
  dishName: string;
}

export const FISH_LIST: FishSpeciesInfo[] = [
  {
    id: 'fish_carp',
    name: 'Emerald Carp',
    thaiName: 'ปลาคาร์ปมรกต',
    icon: '🐟',
    rarity: 'ทั่วไป',
    price: 35,
    xp: 15,
    minW: 1.2,
    maxW: 3.5,
    description: 'ปลาเกล็ดเขียวมรกต พบชุกชุมริมตลิ่ง เนื้อแน่นรสหวาน นิยมนำไปต้มยำ',
    bestBait: 'เหยื่อแป้งสาลี',
    dishName: '🍲 ต้มยำปลาคาร์ปมรกต',
  },
  {
    id: 'fish_bass',
    name: 'Striped Bass',
    thaiName: 'ปลากะพงลายเสือ',
    icon: '🐠',
    rarity: 'หายาก',
    price: 65,
    xp: 30,
    minW: 2.0,
    maxW: 5.8,
    description: 'ปลานักล่าแห่งร่องน้ำลึก ปราดเปรียว ว่องไว มีแรงดึงสายเบ็ดมหาศาล',
    bestBait: 'เหยื่อแป้งสาลี / เหยื่อข้าวโพด',
    dishName: '🧈 สเต๊กปลากะพงย่างเนย',
  },
  {
    id: 'fish_trout',
    name: 'Rainbow Trout',
    thaiName: 'ปลาเทราต์สายรุ้ง',
    icon: '🐡',
    rarity: 'แรร์',
    price: 125,
    xp: 60,
    minW: 3.0,
    maxW: 7.2,
    description: 'ปลาหายากสะท้อนแสงหลากสีดั่งสายรุ้ง พ่อค้าในเมืองรับซื้อในราคาสูง',
    bestBait: 'เหยื่อข้าวโพดหวาน',
    dishName: '🥪 แซนด์วิชสเต๊กปลาเทราต์',
  },
  {
    id: 'fish_golden_catfish',
    name: 'Ancient Golden Catfish',
    thaiName: 'ปลาดุกทองคำโบราณ',
    icon: '✨',
    rarity: 'ตำนาน',
    price: 380,
    xp: 160,
    minW: 8.5,
    maxW: 19.8,
    description: 'เจ้าแห่งทะเลสาบมรกต ลำตัวเรืองแสงสีทองคำอร่าม สัญลักษณ์แห่งความอุดมสมบูรณ์',
    bestBait: 'เหยื่อประกายทอง',
    dishName: '👑 ซุปปลาดุกทองคำจักรพรรดิ',
  },
];

export interface FishBait {
  id: string;
  name: string;
  thaiName: string;
  icon: string;
  description: string;
  effectText: string;
  recipe: { itemId: string; count: number }[];
}

export const FISH_BAITS: FishBait[] = [
  {
    id: 'bait_wheat',
    name: 'Wheat Dough Bait',
    thaiName: 'เหยื่อแป้งสาลี',
    icon: '🌾',
    description: 'แป้งสาลีคลุกเคล้าสูตรพื้นบ้าน กลิ่นหอมดึงดูดปลาได้รวดเร็ว',
    effectText: '⚡ ปลากินเบ็ดไวขึ้น 30% (ลดเวลารอ)',
    recipe: [{ itemId: 'wheat', count: 2 }],
  },
  {
    id: 'bait_corn',
    name: 'Sweet Corn Bait',
    thaiName: 'เหยื่อข้าวโพดหวาน',
    icon: '🌽',
    description: 'ข้าวโพดหวานเมล็ดเต่งตึง กลิ่นหวานพิเศษที่ปลาเทราต์สายรุ้งชื่นชอบ',
    effectText: '🐡 เพิ่มโอกาสเจอปลาเทราต์สายรุ้ง +40%',
    recipe: [{ itemId: 'corn', count: 2 }],
  },
  {
    id: 'bait_golden',
    name: 'Golden Glimmer Bait',
    thaiName: 'เหยื่อประกายทอง',
    icon: '✨',
    description: 'เหยื่อผสมเนยสดหอมฟุ้งและประกายทองเรืองแสง ล่อเจ้าแห่งทะเลสาบ',
    effectText: '👑 เพิ่มโอกาสเจอปลาดุกทองคำโบราณ 25%!',
    recipe: [
      { itemId: 'bread', count: 1 },
      { itemId: 'butter', count: 1 },
    ],
  },
];

interface FishRecordData {
  count: number;
  maxWeight: number;
}

export const FishingDockModal: React.FC<FishingDockModalProps> = ({
  isOpen,
  onClose,
  energy,
  onConsumeEnergy,
  onAddFishToInventory,
  onAddRewards,
  inventory = {},
  onConsumeItems,
  gems = 0,
  luckyFisherBuff = 0,
  onConsumeLuckyBuff,
  timeOfDay = 'day',
  onToggleTimeOfDay,
}) => {
  // Tabs: 'fishing' (ตกปลา 3D) | 'encyclopedia' (สมุดพันธุ์ปลา) | 'baits' (กล่องเหยื่อ)
  const [activeTab, setActiveTab] = useState<'fishing' | 'encyclopedia' | 'baits'>('fishing');

  const [gameState, setGameState] = useState<
    'idle' | 'casting' | 'waiting' | 'nibbling' | 'hooked' | 'reeling' | 'caught' | 'escaped'
  >('idle');
  const [selectedFish, setSelectedFish] = useState<FishSpeciesInfo | null>(null);
  const [caughtWeight, setCaughtWeight] = useState<number>(0);
  const [isNewPersonalBest, setIsNewPersonalBest] = useState<boolean>(false);

  const [reelProgress, setReelProgress] = useState<number>(30);
  const [fishPosition, setFishPosition] = useState<number>(50);
  const [barPosition, setBarPosition] = useState<number>(50);
  const [isHoldingReel, setIsHoldingReel] = useState<boolean>(false);

  // Fullscreen, Zoom & Pan
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [zoom, setZoom] = useState<number>(1.9);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: -20 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [processedBgUrl, setProcessedBgUrl] = useState<string | null>(null);

  // 📖 สมุดสะสมพันธุ์ปลา (Fish Record Book)
  const [records, setRecords] = useState<Record<string, FishRecordData>>(() => {
    try {
      const saved = localStorage.getItem('farm_fish_records_v1');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      fish_carp: { count: 1, maxWeight: 2.1 },
      fish_bass: { count: 0, maxWeight: 0 },
      fish_trout: { count: 0, maxWeight: 0 },
      fish_golden_catfish: { count: 0, maxWeight: 0 },
    };
  });

  const [isMasterAnglerClaimed, setIsMasterAnglerClaimed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('farm_master_angler_claimed') === 'true';
    } catch {
      return false;
    }
  });

  // 🪱 ระบบเหยื่อตกปลา (Bait Inventory & Selection)
  const [baits, setBaits] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('farm_fish_baits_v1');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      bait_wheat: 3,
      bait_corn: 1,
      bait_golden: 0,
    };
  });
  const [activeBait, setActiveBait] = useState<string | null>(null);

  const timersRef = useRef<Set<NodeJS.Timeout>>(new Set());
  const activeIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const isRewardedRef = useRef<boolean>(false);

  const clearAllTimers = useCallback(() => {
    timersRef.current.forEach((t) => clearTimeout(t));
    timersRef.current.clear();
    if (activeIntervalRef.current) {
      clearInterval(activeIntervalRef.current);
      activeIntervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => clearAllTimers();
  }, [clearAllTimers]);

  useEffect(() => {
    if (!isOpen) {
      clearAllTimers();
      setGameState('idle');
      setSelectedFish(null);
      setZoom(1.9);
      setPan({ x: 0, y: -20 });
      setActiveTab('fishing');
    }
  }, [isOpen, clearAllTimers]);

  // Save records
  useEffect(() => {
    try {
      localStorage.setItem('farm_fish_records_v1', JSON.stringify(records));
    } catch {}
  }, [records]);

  // Save baits
  useEffect(() => {
    try {
      localStorage.setItem('farm_fish_baits_v1', JSON.stringify(baits));
    } catch {}
  }, [baits]);

  // Fullscreen state listener
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // 🌟 ประมวลผลภาพเกาะ 3D ให้โปร่งใส 100%
  useEffect(() => {
    if (!isOpen || processedBgUrl) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = '/fishing_lake_bg.jpg';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || img.width;
        canvas.height = img.naturalHeight || img.height;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) return;
        ctx.drawImage(img, 0, 0);

        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imgData.data;
        const w = canvas.width;
        const h = canvas.height;
        const visited = new Uint8Array(w * h);

        const queue: number[] = [0, w - 1, (h - 1) * w, h * w - 1];
        visited[0] = 1;
        visited[w - 1] = 1;
        visited[(h - 1) * w] = 1;
        visited[h * w - 1] = 1;

        let head = 0;
        while (head < queue.length) {
          const idx = queue[head++];
          const px = idx % w;
          const py = Math.floor(idx / w);
          const pIdx = idx * 4;
          const r = data[pIdx];
          const g = data[pIdx + 1];
          const b = data[pIdx + 2];

          if (r >= 215 && g >= 215 && b >= 215) {
            const minChannel = Math.min(r, g, b);
            if (minChannel >= 240) {
              data[pIdx + 3] = 0;
            } else {
              data[pIdx + 3] = Math.round(((240 - minChannel) / 25) * 255);
            }

            const n1 = px > 0 ? idx - 1 : -1;
            const n2 = px < w - 1 ? idx + 1 : -1;
            const n3 = py > 0 ? idx - w : -1;
            const n4 = py < h - 1 ? idx + w : -1;

            if (n1 >= 0 && !visited[n1]) { visited[n1] = 1; queue.push(n1); }
            if (n2 >= 0 && !visited[n2]) { visited[n2] = 1; queue.push(n2); }
            if (n3 >= 0 && !visited[n3]) { visited[n3] = 1; queue.push(n3); }
            if (n4 >= 0 && !visited[n4]) { visited[n4] = 1; queue.push(n4); }
          }
        }

        ctx.putImageData(imgData, 0, 0);
        setProcessedBgUrl(canvas.toDataURL('image/png'));
      } catch (err) {
        console.warn('Background cleanup error:', err);
      }
    };
  }, [isOpen, processedBgUrl]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleZoom = (delta: number) => {
    setZoom((prev) => Math.max(1.3, Math.min(3.2, +(prev + delta).toFixed(2))));
  };

  const handleResetView = () => {
    setZoom(1.9);
    setPan({ x: 0, y: -20 });
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('button') || gameState === 'reeling') return;
    setIsPanning(true);
    setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isPanning) return;
    setPan({
      x: Math.max(-250, Math.min(250, e.clientX - panStart.x)),
      y: Math.max(-250, Math.min(250, e.clientY - panStart.y)),
    });
  };

  const handlePointerUp = () => {
    setIsPanning(false);
  };

  // 🪱 ฟังก์ชันคราฟต์เหยื่อ
  const handleCraftBait = (bait: FishBait) => {
    const hasIngredients = bait.recipe.every((ing) => {
      const have = inventory[ing.itemId]?.count || 0;
      return have >= ing.count;
    });

    if (!hasIngredients) {
      sound.playClick();
      alert('วัตถุดิบในโรงนาไม่เพียงพอสำหรับการผสมเหยื่อนี้!');
      return;
    }

    if (onConsumeItems) {
      const success = onConsumeItems(bait.recipe);
      if (!success) return;
    }

    sound.playSuccessChime();
    setBaits((prev) => ({
      ...prev,
      [bait.id]: (prev[bait.id] || 0) + 1,
    }));
  };

  // 🏆 รับรางวัลนักตกปลามือทอง
  const handleClaimMasterAngler = () => {
    if (isMasterAnglerClaimed) return;
    const allSpeciesCaught = FISH_LIST.every((f) => (records[f.id]?.count || 0) > 0);
    if (!allSpeciesCaught) return;

    sound.playLevelUp();
    try {
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.5 } });
    } catch {}

    if (onAddRewards) {
      onAddRewards(5000, 500);
    }
    setIsMasterAnglerClaimed(true);
    localStorage.setItem('farm_master_angler_claimed', 'true');
  };

  // 🎣 เหวี่ยงเบ็ดตกปลา
  const handleCastRod = () => {
    if (gameState !== 'idle') return;
    isRewardedRef.current = false;
    setIsNewPersonalBest(false);

    if (energy < 2) {
      alert('พลังงานไม่เพียงพอ! ต้องการพลังงาน 2 หน่วย ⚡');
      return;
    }

    if (onConsumeEnergy && !onConsumeEnergy(2)) return;

    // ตรวจสอบและหักเหยื่อที่ติดตั้ง
    let currentBaitType = activeBait;
    if (activeBait && (baits[activeBait] || 0) > 0) {
      setBaits((prev) => ({
        ...prev,
        [activeBait]: Math.max(0, (prev[activeBait] || 0) - 1),
      }));
    } else {
      currentBaitType = null;
    }

    try { sound.playWater(); } catch {}
    setGameState('casting');

    // คำนวณอัตราสุ่มตามเหยื่อและบัฟแมวนำโชค
    let roll = Math.random() * 100;
    let fish: FishSpeciesInfo;

    const isLucky = luckyFisherBuff > 0;
    if (isLucky) {
      roll += 18; // บัฟนำโชคเพิ่มโอกาสเจอตัวหายาก
    }

    if (currentBaitType === 'bait_golden') {
      // 25% ปลาดุกทองคำ, 35% ปลาเทราต์, 25% ปลากะพง, 15% ปลาคาร์ป
      fish = roll > 75 ? FISH_LIST[3] : roll > 40 ? FISH_LIST[2] : roll > 15 ? FISH_LIST[1] : FISH_LIST[0];
    } else if (currentBaitType === 'bait_corn') {
      // เพิ่มโอกาสปลาเทราต์ +40%
      fish = roll > 88 ? FISH_LIST[3] : roll > 45 ? FISH_LIST[2] : roll > 25 ? FISH_LIST[1] : FISH_LIST[0];
    } else {
      // อัตรามาตรฐาน
      fish = roll > 92 ? FISH_LIST[3] : roll > 72 ? FISH_LIST[2] : roll > 42 ? FISH_LIST[1] : FISH_LIST[0];
    }

    setSelectedFish(fish);

    // เวลาปลากินเบ็ด (เหยื่อแป้งสาลีลดเวลารอ 30%)
    const waitMultiplier = currentBaitType === 'bait_wheat' ? 0.7 : 1.0;
    const baseWait = (1800 + Math.random() * 2000) * waitMultiplier;

    const t1 = setTimeout(() => {
      setGameState('waiting');
      const t2 = setTimeout(() => {
        setGameState('nibbling');
        const t3 = setTimeout(() => {
          setGameState('hooked');
          try { sound.playSuccessChime(); } catch {}
          const t4 = setTimeout(() => {
            setGameState((prev) => (prev === 'hooked' ? 'escaped' : prev));
          }, 2000);
          timersRef.current.add(t4);
        }, 750 * waitMultiplier);
        timersRef.current.add(t3);
      }, baseWait);
      timersRef.current.add(t2);
    }, 900);
    timersRef.current.add(t1);
  };

  const handleStrike = () => {
    if (gameState !== 'hooked') return;
    clearAllTimers();
    try { sound.playClick(); } catch {}
    setReelProgress(32);
    setBarPosition(50);
    setFishPosition(50);
    setGameState('reeling');
  };

  const handleFishCaught = (fish: FishSpeciesInfo) => {
    if (isRewardedRef.current) return;
    isRewardedRef.current = true;
    clearAllTimers();

    // คำนวณน้ำหนัก (ถ้ามีบัฟแมว จะได้น้ำหนักสถิติสูงขึ้น)
    let weightMin = fish.minW;
    if (luckyFisherBuff > 0) {
      weightMin += (fish.maxW - fish.minW) * 0.35;
    }
    const weight = +(weightMin + Math.random() * (fish.maxW - weightMin)).toFixed(2);
    setCaughtWeight(weight);

    // บันทึกลงสมุดสถิติพันธุ์ปลา (Personal Best Record)
    const prevRecord = records[fish.id] || { count: 0, maxWeight: 0 };
    const isNewRecord = weight > prevRecord.maxWeight;
    setIsNewPersonalBest(isNewRecord);

    setRecords((prev) => ({
      ...prev,
      [fish.id]: {
        count: (prev[fish.id]?.count || 0) + 1,
        maxWeight: Math.max(prev[fish.id]?.maxWeight || 0, weight),
      },
    }));

    // หักบัฟแมวนำโชค
    if (luckyFisherBuff > 0 && onConsumeLuckyBuff) {
      onConsumeLuckyBuff();
    }

    setGameState('caught');

    try { sound.playLevelUp(); } catch {}
    if (onAddFishToInventory) onAddFishToInventory(fish, weight);
    if (onAddRewards) onAddRewards(fish.price, fish.xp);
  };

  // มินิเกมประคองสายเบ็ด (Tension Gauge)
  useEffect(() => {
    if (!isOpen || gameState !== 'reeling' || !selectedFish) return;

    activeIntervalRef.current = setInterval(() => {
      setBarPosition((prev) => {
        const next = isHoldingReel ? prev + 4.2 : prev - 3.4;
        return Math.max(10, Math.min(90, next));
      });

      setFishPosition((prev) => {
        const wiggle = (Math.random() - 0.5) * 8.5;
        return Math.max(15, Math.min(85, prev + wiggle));
      });

      const isOverlap = Math.abs(barPosition - fishPosition) < 17;

      setReelProgress((prev) => {
        const next = isOverlap ? prev + 1.6 : prev - 1.3;
        if (next >= 100) {
          handleFishCaught(selectedFish);
          return 100;
        } else if (next <= 0) {
          clearAllTimers();
          setGameState('escaped');
          return 0;
        }
        return next;
      });
    }, 50);

    return () => {
      if (activeIntervalRef.current) clearInterval(activeIntervalRef.current);
    };
  }, [isOpen, gameState, isHoldingReel, barPosition, fishPosition, selectedFish]);

  if (!isOpen) return null;

  const allSpeciesCaughtCount = FISH_LIST.filter((f) => (records[f.id]?.count || 0) > 0).length;
  const isMasterAnglerEligible = allSpeciesCaughtCount === FISH_LIST.length;

  return (
    <div
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      className="fixed inset-0 z-50 w-screen h-screen overflow-hidden flex flex-col bg-[#021114] animate-fade-in select-none"
    >
      {/* 🌊 1. บรรยากาศพื้นหลังทะเลสาบ */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#062428] via-[#03191d] to-[#010e11] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_52%,rgba(20,184,166,0.22)_0%,rgba(6,95,70,0.12)_45%,transparent_75%)] pointer-events-none" />

      {/* 🏞️ 2. ฉาก 3D ทะเลสาบมรกต */}
      <div className="absolute inset-0 z-0 overflow-hidden flex items-center justify-center cursor-grab active:cursor-grabbing">
        <div
          className="relative w-full h-full flex items-center justify-center will-change-transform transition-transform duration-100 ease-out"
          style={{
            transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoom})`,
          }}
        >
          {processedBgUrl && (
            <img
              src={processedBgUrl}
              alt="Emerald Lake 3D Island"
              className="absolute pointer-events-none select-none w-auto h-auto max-w-none transform scale-[1.05]"
              style={{ zIndex: 1 }}
              draggable={false}
            />
          )}

          <EmeraldLake3D
            gameState={gameState}
            onBobberClick={gameState === 'hooked' ? handleStrike : undefined}
            timeOfDay={timeOfDay}
          />

          {/* แสงสะท้อนกลางสระ */}
          <div className="absolute top-[52%] left-[45%] w-56 h-40 bg-cyan-300/20 rounded-full blur-2xl animate-pulse pointer-events-none" />

          {/* ทุ่นลอยน้ำ */}
          {gameState !== 'idle' && (
            <div
              onClick={gameState === 'hooked' ? handleStrike : undefined}
              className={`absolute top-[53%] left-[44%] -translate-x-1/2 -translate-y-1/2 z-20 cursor-pointer transition-all ${
                gameState === 'hooked'
                  ? 'scale-150 animate-bounce'
                  : gameState === 'nibbling'
                  ? 'animate-pulse'
                  : ''
              }`}
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-b from-red-500 via-white to-red-600 border-2 border-white shadow-2xl flex items-center justify-center">
                <span className="w-2.5 h-2.5 rounded-full bg-red-600" />
              </div>
              <div className="w-14 h-14 -mt-11 -ml-3 rounded-full border-2 border-cyan-300/70 animate-ping pointer-events-none" />
            </div>
          )}
        </div>
      </div>

      {/* 🧭 3. แถบควบคุมบนสุด (Header HUD) */}
      <div className="relative z-30 flex items-center justify-between px-3 sm:px-6 py-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent pointer-events-auto">
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => {
              clearAllTimers();
              onClose();
            }}
            className="px-3.5 py-1.5 bg-slate-900/90 hover:bg-slate-800 text-teal-200 rounded-xl border border-teal-500/40 backdrop-blur shadow flex items-center gap-1.5 font-bold text-xs sm:text-sm transition active:scale-95 cursor-pointer"
          >
            <ArrowLeft size={16} /> กลับฟาร์ม
          </button>

          {/* เมนูแท็บหลัก: ตกปลา | สมุดพันธุ์ปลา | กล่องเหยื่อ */}
          <div className="flex items-center bg-black/75 rounded-2xl p-1 border border-teal-500/40 backdrop-blur">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('fishing');
              }}
              className={`px-3 py-1 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'fishing'
                  ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-slate-950 shadow'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              <span>🎣</span>
              <span>ตกปลา</span>
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('encyclopedia');
              }}
              className={`px-3 py-1 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'encyclopedia'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>สมุดพันธุ์ปลา ({allSpeciesCaughtCount}/4)</span>
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('baits');
              }}
              className={`px-3 py-1 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'baits'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                  : 'text-teal-200 hover:text-white'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>กล่องเหยื่อ</span>
            </button>
          </div>
        </div>

        {/* แถบเครื่องมือขวา: บัฟ, ช่วงเวลา, พลังงาน, ซูม, ปิด */}
        <div className="flex items-center gap-2">
          {/* บัฟแมวนำโชค (Lucky Fisher Buff) */}
          {luckyFisherBuff > 0 && (
            <div className="bg-emerald-950/90 text-emerald-300 border border-emerald-400 px-2.5 py-1 rounded-full text-xs font-black shadow-lg flex items-center gap-1 animate-pulse">
              <span>🐱🍀</span>
              <span className="hidden sm:inline">แมวนำโชค:</span>
              <span>{luckyFisherBuff} ครั้ง</span>
            </div>
          )}

          {/* ปุ่มสลับช่วงเวลา (Time of Day: Day / Twilight / Night) */}
          {onToggleTimeOfDay && (
            <button
              onClick={() => {
                sound.playClick();
                onToggleTimeOfDay();
              }}
              title={
                timeOfDay === 'day'
                  ? 'บรรยากาศ: กลางวัน ☀️'
                  : timeOfDay === 'twilight'
                  ? 'บรรยากาศ: ยามเย็น 🌅'
                  : 'บรรยากาศ: กลางคืน 🌙 (หิ่งห้อย)'
              }
              className="p-1.5 bg-black/75 hover:bg-slate-800 text-amber-300 rounded-xl border border-teal-500/40 backdrop-blur shadow transition active:scale-95 cursor-pointer"
            >
              {timeOfDay === 'day' ? (
                <Sun className="w-4 h-4 text-yellow-300" />
              ) : timeOfDay === 'twilight' ? (
                <Sunset className="w-4 h-4 text-orange-400" />
              ) : (
                <Moon className="w-4 h-4 text-cyan-300" />
              )}
            </button>
          )}

          {/* พลังงาน */}
          <div className="bg-black/70 backdrop-blur px-3 py-1 rounded-full border border-teal-500/50 flex items-center gap-1">
            <span className="text-amber-400 font-bold text-xs">⚡</span>
            <span className="font-extrabold text-white text-xs sm:text-sm">{energy}</span>
          </div>

          {/* ซูม Pan-Zoom */}
          <div className="hidden sm:flex items-center bg-black/70 backdrop-blur rounded-xl border border-teal-500/40 p-0.5 shadow">
            <button
              onClick={() => handleZoom(-0.2)}
              title="ซูมออก (-)"
              className="p-1 hover:bg-teal-500/30 text-teal-200 rounded-lg transition active:scale-95 cursor-pointer"
            >
              <ZoomOut size={15} />
            </button>
            <span className="px-1 text-xs font-black text-teal-300 min-w-[34px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => handleZoom(0.2)}
              title="ซูมเข้า (+)"
              className="p-1 hover:bg-teal-500/30 text-teal-200 rounded-lg transition active:scale-95 cursor-pointer"
            >
              <ZoomIn size={15} />
            </button>
            <button
              onClick={handleResetView}
              title="รีเซ็ตมุมมอง"
              className="p-1 hover:bg-teal-500/30 text-teal-200 rounded-lg border-l border-teal-500/30 transition active:scale-95 cursor-pointer"
            >
              <RotateCcw size={14} />
            </button>
          </div>

          {/* สลับเต็มจอ */}
          <button
            onClick={toggleFullscreen}
            className="p-1.5 bg-slate-900/90 hover:bg-slate-800 text-teal-200 rounded-xl border border-teal-500/40 backdrop-blur shadow transition active:scale-95 cursor-pointer hidden sm:block"
          >
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>

          {/* ปุ่มปิด */}
          <button
            onClick={() => {
              clearAllTimers();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-600/90 hover:bg-red-500 flex items-center justify-center text-white font-bold transition shadow-lg cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* 📖 4. หน้าต่างสมุดสะสมพันธุ์ปลา (Fish Record Book) */}
      {activeTab === 'encyclopedia' && (
        <div
          onPointerDown={(e) => e.stopPropagation()}
          className="relative z-40 flex-1 overflow-y-auto p-4 sm:p-6 max-w-4xl w-full mx-auto flex flex-col gap-4 animate-in fade-in zoom-in-95 pointer-events-auto"
        >
          {/* แบนเนอร์ฉายานักตกปลามือทอง */}
          <div className="bg-gradient-to-r from-amber-950/90 via-stone-900/90 to-amber-950/90 border-2 border-amber-400 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-3xl shadow">
                🏆
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-amber-200">
                  ฉายา: ยอดนักตกปลามือทองแห่งแม่น้ำมรกต
                </h3>
                <p className="text-xs text-amber-300/80">
                  ตกปลาให้ครบทั้ง 4 ชนิดเพื่อปลดล็อกฉายาและรางวัลใหญ่ 5,000 เหรียญ + 25 เพชร!
                </p>
                <div className="mt-1 text-xs font-mono font-bold text-teal-300">
                  ความคืบหน้า: {allSpeciesCaughtCount} / {FISH_LIST.length} ชนิด
                </div>
              </div>
            </div>

            <div>
              {isMasterAnglerClaimed ? (
                <div className="px-4 py-2 bg-emerald-950/80 border border-emerald-400 text-emerald-300 rounded-2xl font-black text-xs flex items-center gap-1.5 shadow">
                  <Check className="w-4 h-4" /> ปลดล็อกฉายาสำเร็จแล้ว
                </div>
              ) : isMasterAnglerEligible ? (
                <button
                  onClick={handleClaimMasterAngler}
                  className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black rounded-2xl shadow-xl hover:brightness-110 active:scale-95 transition flex items-center gap-2 cursor-pointer animate-bounce"
                >
                  <Award className="w-4 h-4 text-amber-900" />
                  <span>รับรางวัล 5,000🪙 + 25💎!</span>
                </button>
              ) : (
                <div className="px-4 py-2 bg-stone-900/80 border border-stone-700 text-stone-400 rounded-2xl font-bold text-xs">
                  ยังสะสมไม่ครบ ({allSpeciesCaughtCount}/4)
                </div>
              )}
            </div>
          </div>

          {/* การ์ดพันธุ์ปลาทั้ง 4 ชนิด */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {FISH_LIST.map((fish) => {
              const record = records[fish.id] || { count: 0, maxWeight: 0 };
              const isCaught = record.count > 0;

              return (
                <div
                  key={fish.id}
                  className={`rounded-3xl p-4 border-2 transition-all flex flex-col justify-between ${
                    isCaught
                      ? 'bg-slate-950/85 border-teal-500/60 shadow-xl'
                      : 'bg-stone-950/70 border-stone-800 opacity-70'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                      <div className="flex items-center gap-2.5">
                        <span className="text-3xl p-1 bg-stone-900 rounded-xl border border-stone-700">
                          {fish.icon}
                        </span>
                        <div>
                          <h4 className="font-black text-base text-white">{fish.thaiName}</h4>
                          <span className="text-[10px] text-teal-300 font-mono">{fish.name}</span>
                        </div>
                      </div>
                      <span
                        className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                          fish.rarity === 'ตำนาน'
                            ? 'bg-amber-400 text-black shadow'
                            : fish.rarity === 'แรร์'
                            ? 'bg-purple-600 text-white'
                            : fish.rarity === 'หายาก'
                            ? 'bg-blue-600 text-white'
                            : 'bg-stone-700 text-stone-200'
                        }`}
                      >
                        {fish.rarity}
                      </span>
                    </div>

                    <p className="text-xs text-stone-300 my-2 leading-relaxed">{fish.description}</p>
                  </div>

                  {/* สถิติการจับ */}
                  <div className="mt-2 pt-2 border-t border-stone-800/80 flex flex-col gap-1.5 text-xs">
                    <div className="grid grid-cols-2 gap-2 bg-black/40 rounded-xl p-2 border border-stone-800">
                      <div>
                        <span className="text-stone-400 text-[10px] block">สถิติตัวใหญ่สุด (PB):</span>
                        <span className="font-black text-amber-300 text-sm">
                          {isCaught ? `${record.maxWeight} กก.` : '— ยังไม่พบ —'}
                        </span>
                      </div>
                      <div>
                        <span className="text-stone-400 text-[10px] block">จำนวนที่เคยจับ:</span>
                        <span className="font-black text-teal-300 text-sm">
                          {record.count} ตัว
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-stone-400">
                      <span>เมนูแนะนำ: <strong className="text-amber-200">{fish.dishName}</strong></span>
                      <span>เหยื่อ: <strong className="text-cyan-300">{fish.bestBait}</strong></span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 🪱 5. หน้าต่างกล่องและคราฟต์เหยื่อตกปลา (Bait Box & Crafting) */}
      {activeTab === 'baits' && (
        <div
          onPointerDown={(e) => e.stopPropagation()}
          className="relative z-40 flex-1 overflow-y-auto p-4 sm:p-6 max-w-3xl w-full mx-auto flex flex-col gap-4 animate-in fade-in zoom-in-95 pointer-events-auto"
        >
          <div className="bg-stone-900/90 border-2 border-emerald-500/60 rounded-3xl p-4 sm:p-5 shadow-2xl flex items-center justify-between">
            <div>
              <h3 className="text-base sm:text-lg font-black text-emerald-200 flex items-center gap-2">
                <span>🪱</span> กล่องเหยื่อตกปลา (Bait Crafting Box)
              </h3>
              <p className="text-xs text-stone-300 mt-0.5">
                นำผลผลิตในฟาร์มมาผสมเป็นเหยื่อสูตรพิเศษ เพื่อดึงดูดปลาหายากและตกได้ไวยิ่งขึ้น
              </p>
            </div>
            {activeBait && (
              <button
                onClick={() => {
                  sound.playClick();
                  setActiveBait(null);
                }}
                className="px-3 py-1.5 bg-red-900/80 hover:bg-red-800 text-red-200 border border-red-500/60 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer"
              >
                ถอดเหยื่อออก
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {FISH_BAITS.map((bait) => {
              const currentBaitCount = baits[bait.id] || 0;
              const isEquipped = activeBait === bait.id;

              const canCraft = bait.recipe.every((ing) => {
                const have = inventory[ing.itemId]?.count || 0;
                return have >= ing.count;
              });

              return (
                <div
                  key={bait.id}
                  className={`rounded-3xl p-4 border-2 flex flex-col justify-between transition-all ${
                    isEquipped
                      ? 'bg-emerald-950/90 border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                      : 'bg-slate-950/80 border-stone-800'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{bait.icon}</span>
                        <div>
                          <h4 className="font-extrabold text-sm text-white">{bait.thaiName}</h4>
                          <span className="text-[10px] text-emerald-300 font-mono">มี: {currentBaitCount} ชิ้น</span>
                        </div>
                      </div>
                      {isEquipped && (
                        <span className="text-[10px] font-black bg-emerald-400 text-slate-950 px-2 py-0.5 rounded-full shadow">
                          กำลังใช้งาน
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-stone-300 my-2 leading-relaxed">{bait.description}</p>
                    <div className="bg-emerald-950/60 text-emerald-300 text-[11px] font-bold p-2 rounded-xl border border-emerald-800/80 mb-3">
                      {bait.effectText}
                    </div>

                    {/* วัตถุดิบที่ใช้ */}
                    <div className="text-[11px] text-stone-400 mb-2 font-bold">
                      วัตถุดิบคราฟต์:
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {bait.recipe.map((ing) => {
                          const have = inventory[ing.itemId]?.count || 0;
                          const isOk = have >= ing.count;
                          const itMeta = inventory[ing.itemId];
                          return (
                            <span
                              key={ing.itemId}
                              className={`px-2 py-0.5 rounded-lg border text-[10px] font-mono ${
                                isOk
                                  ? 'bg-stone-900 border-emerald-500/60 text-emerald-300'
                                  : 'bg-red-950/60 border-red-800 text-red-300'
                              }`}
                            >
                              {itMeta?.icon || '📦'} {itMeta?.thaiName || ing.itemId}: {have}/{ing.count}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 mt-3 pt-2 border-t border-stone-800">
                    <button
                      onClick={() => handleCraftBait(bait)}
                      disabled={!canCraft}
                      className={`w-full py-2 rounded-xl text-xs font-black shadow transition flex items-center justify-center gap-1 active:scale-95 cursor-pointer ${
                        canCraft
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 hover:brightness-110'
                          : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                      }`}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>คราฟต์เหยื่อ (+1)</span>
                    </button>

                    <button
                      onClick={() => {
                        sound.playClick();
                        setActiveBait(isEquipped ? null : bait.id);
                      }}
                      disabled={currentBaitCount <= 0 && !isEquipped}
                      className={`w-full py-2 rounded-xl text-xs font-black shadow transition active:scale-95 cursor-pointer ${
                        isEquipped
                          ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                          : currentBaitCount > 0
                          ? 'bg-slate-800 text-teal-200 hover:bg-slate-700 border border-teal-500/40'
                          : 'bg-stone-900 text-stone-600 border border-stone-800 cursor-not-allowed'
                      }`}
                    >
                      {isEquipped ? 'ถอดเหยื่อนี้' : currentBaitCount > 0 ? 'ติดตั้งเหยื่อนี้' : 'เหยื่อหมด (คราฟต์เพิ่ม)'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 🎣 6. แถบควบคุมการตกปลา (Interactive Fishing Controls) */}
      {activeTab === 'fishing' && (
        <div className="relative z-20 flex-1 flex flex-col items-center justify-end pb-8 px-4 pointer-events-none">
          {gameState === 'casting' && (
            <div className="mb-8 px-6 py-2.5 bg-black/85 backdrop-blur-md rounded-2xl border border-cyan-400 text-cyan-200 font-bold text-base shadow-xl animate-pulse">
              กำลังเหวี่ยงสายเบ็ดลงสู่กลางทะเลสาบมรกต...
            </div>
          )}

          {gameState === 'waiting' && (
            <div className="mb-8 px-6 py-2.5 bg-black/75 backdrop-blur-md rounded-2xl border border-teal-500/50 text-teal-100 font-medium text-sm shadow-xl flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-ping" />
              สายน้ำนิ่งสนิท... สังเกตทุ่นสีแดงกลางสระให้ดี
            </div>
          )}

          {gameState === 'nibbling' && (
            <div className="mb-8 px-6 py-2.5 bg-amber-950/85 backdrop-blur-md rounded-2xl border border-amber-400 text-amber-200 font-bold text-base shadow-xl animate-bounce">
              ระลอกคลื่นผุดขึ้น! ปลากำลังตอดเหยื่อแล้ว...
            </div>
          )}

          {gameState === 'hooked' && (
            <div className="pointer-events-auto mb-10 flex flex-col items-center animate-bounce">
              <button
                onClick={handleStrike}
                className="px-10 py-5 bg-gradient-to-r from-red-600 via-orange-500 to-amber-500 text-white font-black text-2xl rounded-3xl shadow-[0_0_40px_rgba(239,68,68,0.85)] border-4 border-yellow-300 transition-all active:scale-90 cursor-pointer"
              >
                ⚡ ปลากินแล้ว! กดตวัดเบ็ดทันที! ⚡
              </button>
            </div>
          )}

          {/* มินิเกมประคองสายเบ็ด */}
          {gameState === 'reeling' && (
            <div className="pointer-events-auto mb-6 bg-slate-950/95 backdrop-blur-xl border-2 border-cyan-400/80 p-6 rounded-3xl w-full max-w-md shadow-2xl flex flex-col items-center">
              <div className="w-full flex justify-between text-xs font-black text-cyan-300 mb-2">
                <span>ความตึงของสายเบ็ด:</span>
                <span className="text-sm font-extrabold">{Math.round(reelProgress)}%</span>
              </div>

              <div className="w-full h-3.5 bg-slate-800 rounded-full overflow-hidden border border-cyan-600/50 mb-5">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 via-emerald-400 to-cyan-400 transition-all duration-75"
                  style={{ width: `${reelProgress}%` }}
                />
              </div>

              <div className="relative w-full h-14 bg-black/80 rounded-2xl border border-teal-500/40 overflow-hidden mb-5 flex items-center">
                <div
                  className="absolute h-full bg-emerald-500/40 border-x-2 border-emerald-300 rounded-xl transition-all duration-75"
                  style={{ left: `${barPosition - 12}%`, width: '24%' }}
                />
                <div
                  className="absolute text-3xl -translate-x-1/2 transition-all duration-100"
                  style={{ left: `${fishPosition}%` }}
                >
                  {selectedFish?.icon || '🐟'}
                </div>
              </div>

              <button
                onMouseDown={() => setIsHoldingReel(true)}
                onMouseUp={() => setIsHoldingReel(false)}
                onTouchStart={() => setIsHoldingReel(true)}
                onTouchEnd={() => setIsHoldingReel(false)}
                className={`w-full py-4 rounded-2xl font-black text-xl tracking-wider select-none shadow-xl transition-all active:scale-95 cursor-pointer ${
                  isHoldingReel
                    ? 'bg-amber-400 text-amber-950 shadow-[0_0_25px_rgba(251,191,36,0.6)]'
                    : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white'
                }`}
              >
                {isHoldingReel ? '🎣 กำลังหมุนรอกดึง...!' : 'กดค้าง เพื่อหมุนรอกประคองสาย'}
              </button>
            </div>
          )}

          {/* ป๊อปอัปผลลัพธ์เมื่อได้ปลา */}
          {gameState === 'caught' && selectedFish && (
            <div className="pointer-events-auto relative z-20 bg-slate-900/95 border-2 border-cyan-400 p-6 rounded-3xl max-w-sm w-full text-center shadow-2xl animate-stamp-in backdrop-blur-2xl">
              <div className="text-7xl mb-2 animate-bounce">{selectedFish.icon}</div>
              <span className="inline-block px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-1 bg-gradient-to-r from-amber-400 to-orange-500 text-black">
                {selectedFish.rarity}
              </span>

              {isNewPersonalBest && (
                <div className="text-xs font-black text-yellow-300 bg-amber-950/80 border border-yellow-400 px-3 py-1 rounded-full mb-2 animate-pulse flex items-center justify-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                  <span>สถิติน้ำหนักใหม่ส่วนตัว! 🏆</span>
                </div>
              )}

              <h3 className="text-2xl font-black text-white">{selectedFish.thaiName}</h3>

              <div className="my-4 py-3 bg-black/50 rounded-2xl flex justify-around items-center border border-teal-500/30">
                <div>
                  <span className="text-gray-400 block text-xs">น้ำหนัก</span>
                  <span className="font-black text-white text-lg">{caughtWeight} กก.</span>
                </div>
                <div className="w-[1px] h-8 bg-teal-800/80" />
                <div>
                  <span className="text-gray-400 block text-xs">มูลค่า</span>
                  <span className="font-black text-amber-300 text-lg">+{selectedFish.price} 🪙</span>
                </div>
                <div className="w-[1px] h-8 bg-teal-800/80" />
                <div>
                  <span className="text-gray-400 block text-xs">EXP</span>
                  <span className="font-black text-cyan-300 text-lg">+{selectedFish.xp} ⭐</span>
                </div>
              </div>

              <button
                onClick={() => setGameState('idle')}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-black text-lg rounded-2xl shadow-lg transition active:scale-95 cursor-pointer"
              >
                เก็บเข้าห้องเย็น & ตกต่อ
              </button>
            </div>
          )}

          {gameState === 'escaped' && (
            <div className="pointer-events-auto relative z-20 bg-slate-900/95 border-2 border-red-500/80 p-6 rounded-3xl max-w-sm w-full text-center shadow-2xl backdrop-blur-xl">
              <div className="text-5xl mb-2">💦</div>
              <h3 className="text-2xl font-black text-red-400">ปลาหลุดมือไปแล้ว!</h3>
              <p className="text-xs text-stone-300 my-2">ลองประคองเกจความตึงให้อยู่ในโซนเขียวตลอดเวลานะ</p>
              <button
                onClick={() => setGameState('idle')}
                className="w-full mt-2 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-2xl transition active:scale-95 cursor-pointer"
              >
                ลองใหม่อีกครั้ง
              </button>
            </div>
          )}

          {gameState === 'idle' && (
            <div className="pointer-events-auto flex flex-col items-center">
              {/* แถบแจ้งเหยื่อที่ติดตั้ง */}
              <div className="mb-2 flex items-center gap-2">
                {activeBait ? (
                  <div className="bg-black/75 backdrop-blur px-3 py-1 rounded-full border border-emerald-400/80 text-emerald-200 text-xs font-bold flex items-center gap-1.5 shadow">
                    <span>🪱 เหยื่อ:</span>
                    <span className="text-white">
                      {FISH_BAITS.find((b) => b.id === activeBait)?.thaiName} (เหลือ {baits[activeBait] || 0} ชิ้น)
                    </span>
                    <button
                      onClick={() => setActiveBait(null)}
                      className="text-stone-400 hover:text-red-400 ml-1"
                      title="ถอดเหยื่อ"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setActiveTab('baits')}
                    className="bg-black/60 hover:bg-black/80 backdrop-blur px-3 py-1 rounded-full border border-teal-500/40 text-teal-300 text-xs font-bold flex items-center gap-1.5 shadow transition cursor-pointer"
                  >
                    <span>🪱 ติดตั้งเหยื่อพิเศษ</span>
                  </button>
                )}
              </div>

              <button
                onClick={handleCastRod}
                className="px-10 py-5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-amber-950 font-black text-xl sm:text-2xl rounded-3xl shadow-[0_0_35px_rgba(245,158,11,0.6)] border-2 border-yellow-200 transition-all active:scale-95 flex items-center gap-3 animate-gentle-bounce cursor-pointer"
              >
                <span className="text-3xl">🎣</span> เหวี่ยงเบ็ดลงสระ (ใช้ 2 ⚡)
              </button>
              <p className="mt-2 text-xs text-teal-200/80 bg-black/50 px-3 py-1 rounded-full backdrop-blur">
                คลิกหรือลากเพื่อเลื่อนมุมมอง • กด [📖 สมุดพันธุ์ปลา] เพื่อดูสถิติ
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
