import { AnimalCareModal } from './animal/AnimalCareModal';
export { AnimalCareModal };
export default AnimalCareModal;
