import React from 'react';
import { X, Trophy, Award, Gift, Clock, Sparkles } from 'lucide-react';
import { sound } from '../../../utils/audio/index';

interface EventsModalProps {
  isOpen: boolean;
  onClose: () => void;
  festivalPoints: number;
  onClaimMilestone: (tier: number) => void;
  claimedTiers: number[];
}

export const EventsModal: React.FC<EventsModalProps> = ({
  isOpen,
  onClose,
  festivalPoints,
  onClaimMilestone,
  claimedTiers,
}) => {
  if (!isOpen) return null;

  const milestones = [
    { tier: 1, target: 10, reward: '1,500 🪙 + 20 ⚡', claimed: claimedTiers.includes(1) },
    { tier: 2, target: 25, reward: '3,000 🪙 + 15 💎', claimed: claimedTiers.includes(2) },
    { tier: 3, target: 50, reward: '5,000 🪙 + 50 💎 + ถังทองคำ 🏆', claimed: claimedTiers.includes(3) },
    { tier: 4, target: 100, reward: 'ถ้วยวัวทองคำลิมิเต็ด + 10,000 🪙', claimed: claimedTiers.includes(4) },
  ];

  const rankings = [
    { rank: 1, name: 'พี่บีม (ฟาร์มต้นแบบ B.P.)', score: 1420, avatar: '🧑‍🌾' },
    { rank: 2, name: 'คุณ (Beam Farm)', score: festivalPoints, avatar: '🤠', isUser: true },
    { rank: 3, name: 'ลุงสมชาย ฟาร์มสุขใจ', score: 680, avatar: '👴' },
    { rank: 4, name: 'น้องพลอย สวนเบอร์รี่', score: 540, avatar: '👩‍🌾' },
    { rank: 5, name: 'กิตติ โรงสีข้าว', score: 410, avatar: '👨‍🌾' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-yellow-400 to-amber-500 flex items-center justify-center text-3xl border-2 border-white shadow-lg">
              🐮
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                  เทศกาลเก็บเกี่ยวฤดูใบไม้ร่วง (Harvest Fest)
                </h2>
              </div>
              <div className="flex items-center gap-2 text-xs text-emerald-300">
                <Clock className="w-3.5 h-3.5" />
                <span>เวลาที่เหลือ: 6 วัน 12 ชั่วโมง · กิจกรรมพิเศษประจำฤดูกาล</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content: Milestones & Leaderboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {/* Milestones / Season Pass */}
          <div className="flex flex-col gap-2.5">
            <h3 className="font-extrabold text-xs sm:text-sm text-amber-300 flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-pink-400" />
              <span>ขั้นรางวัลการเก็บเกี่ยว ({festivalPoints} แต้ม)</span>
            </h3>

            {milestones.map((m) => {
              const reached = festivalPoints >= m.target;

              return (
                <div
                  key={m.tier}
                  className={`p-3 rounded-2xl border-2 flex items-center justify-between gap-2 ${
                    m.claimed
                      ? 'bg-stone-900/50 border-stone-800 opacity-60'
                      : reached
                      ? 'bg-gradient-to-r from-amber-950/80 to-emerald-950/80 border-yellow-400 shadow'
                      : 'bg-stone-900/70 border-amber-950'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-200">
                      <span>เป้าหมาย: เก็บเกี่ยว {m.target} ผลผลิต</span>
                      {reached && !m.claimed && (
                        <span className="text-[10px] bg-emerald-500 text-stone-900 font-black px-1.5 rounded">
                          พร้อมรับ!
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-stone-300 mt-0.5">{m.reward}</div>
                  </div>

                  <button
                    disabled={!reached || m.claimed}
                    onClick={() => {
                      sound.playLevelUp();
                      onClaimMilestone(m.tier);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black shadow transition-all ${
                      m.claimed
                        ? 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                        : reached
                        ? 'game-btn-yellow text-stone-900 hover:brightness-110 active:scale-95 animate-pulse'
                        : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                    }`}
                  >
                    {m.claimed ? 'รับแล้ว' : 'รับรางวัล'}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Leaderboard */}
          <div className="flex flex-col gap-2.5 bg-stone-900/70 rounded-2xl p-3 border border-amber-900">
            <h3 className="font-extrabold text-xs sm:text-sm text-yellow-300 flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-yellow-400" />
              <span>อันดับยอดชาวไร่ประจำเซิร์ฟเวอร์</span>
            </h3>

            <div className="flex flex-col gap-1.5 mt-1">
              {rankings.map((r) => (
                <div
                  key={r.rank}
                  className={`flex items-center justify-between p-2 rounded-xl border text-xs ${
                    r.isUser
                      ? 'bg-amber-600/30 border-yellow-400 font-bold'
                      : 'bg-stone-950/60 border-stone-800 text-stone-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center font-black text-[11px] ${
                        r.rank === 1
                          ? 'bg-yellow-400 text-stone-900'
                          : r.rank === 2
                          ? 'bg-stone-300 text-stone-900'
                          : r.rank === 3
                          ? 'bg-amber-700 text-white'
                          : 'text-stone-500'
                      }`}
                    >
                      {r.rank}
                    </span>
                    <span>{r.avatar}</span>
                    <span className="truncate max-w-[130px]">{r.name}</span>
                  </div>

                  <span className="font-mono text-yellow-300 font-bold">
                    {r.score.toLocaleString()} แต้ม
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
