// src/components/modals/AiChodChatModal.tsx
import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Send, Sparkles, X } from 'lucide-react';
import { ChatMessage } from '../../types/game';
import { naiChodVoice } from '../../utils/aiSpeech';
import { askNaiChod, FarmContext } from '../../utils/aiChodBrain';
import { sanitizeChatQuery, aiChatLimiter, ttsLimiter } from '../../security';

interface AiChodChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  farmContext: FarmContext;
}

export const AiChodChatModal: React.FC<AiChodChatModalProps> = ({
  isOpen,
  onClose,
  farmContext,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-chod',
      sender: 'chod',
      text: 'ว่าไงหลานเอ๊ย! ลุงชดพร้อมช่วยดูแลฟาร์มแล้ว มีข้อสงสัยเรื่องเพาะปลูก เลี้ยงสัตว์ หรืออยากให้ตรวจสภาพฟาร์ม ถามลุงได้เลยนะ!',
      timestamp: Date.now(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(naiChodVoice.isMuted);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    '📊 ตรวจสภาพฟาร์มให้หน่อย',
    '🌾 ปลูกอะไรกำไรดีสุดตอนนี้?',
    '📦 คลังโรงนาเป็นยังไงบ้าง?',
    '🐾 ขอคำแนะนำเรื่องเลี้ยงสัตว์',
  ];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (!isOpen) {
      naiChodVoice.stop();
      setIsSpeaking(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSendMessage = (textToSend?: string) => {
    const rawText = (textToSend || inputValue).trim();
    if (!rawText) return;

    if (!aiChatLimiter.tryConsume(1)) {
      const rateLimitMsg: ChatMessage = {
        id: `chod-limit-${Date.now()}`,
        sender: 'chod',
        text: 'ใจเย็นๆ ก่อนนะหลานเอ๊ย! ถามถี่เกินไปแล้ว นั่งจิบน้ำชาพักสักครู่แล้วค่อยถามลุงใหม่นะ 🍵',
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, rateLimitMsg]);
      return;
    }

    const text = sanitizeChatQuery(rawText);

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInputValue('');

    setTimeout(() => {
      const answer = askNaiChod(text, farmContext);
      const chodMessage: ChatMessage = {
        id: `chod-${Date.now()}`,
        sender: 'chod',
        text: answer,
        timestamp: Date.now(),
      };

      setMessages((prev) => [...prev, chodMessage]);

      if (ttsLimiter.tryConsume(1)) {
        naiChodVoice.speak(
          answer,
          () => setIsSpeaking(true),
          () => setIsSpeaking(false)
        );
      }
    }, 300);
  };

  const handleToggleMute = () => {
    const muted = naiChodVoice.toggleMute();
    setIsMuted(muted);
    if (muted) setIsSpeaking(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs select-none animate-fade-in font-['Kanit',sans-serif]">
      <div className="relative w-full max-w-lg bg-amber-50 rounded-2xl shadow-2xl border-4 border-amber-800 flex flex-col max-h-[88dvh] overflow-hidden">
        {/* หัวกระดานไม้สไตล์ลุงชด */}
        <div className="bg-gradient-to-r from-amber-900 via-amber-800 to-amber-950 px-4 py-3 flex items-center justify-between border-b-2 border-amber-950 shadow-md">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div
                className={`w-12 h-12 rounded-full border-2 border-amber-300 bg-amber-100 flex items-center justify-center text-2xl shadow-inner transition-transform duration-300 ${
                  isSpeaking ? 'scale-110 ring-4 ring-emerald-400 animate-pulse' : ''
                }`}
              >
                👨‍🌾
              </div>
              {isSpeaking && (
                <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 text-[10px] text-white font-bold items-center justify-center">
                    ♪
                  </span>
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white font-bold text-lg font-kanit">นายชด ปราชญ์ชาวสวน AI</h3>
                <span className="bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded-full font-medium">
                  {isSpeaking ? 'กำลังพูด...' : 'พร้อมสนทนา'}
                </span>
              </div>
              <p className="text-amber-200/90 text-xs font-kanit">ผู้รอบรู้การเกษตรประจำฟาร์ม Beam Farm (B.P.)</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* ปุ่มเปิด-ปิดเสียงพูด */}
            <button
              onClick={handleToggleMute}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                isMuted
                  ? 'bg-red-900/70 border-red-400 text-red-200'
                  : 'bg-amber-950/70 border-amber-400 text-emerald-300 hover:bg-amber-900'
              }`}
              title={isMuted ? 'เปิดเสียงลุงชด' : 'ปิดเสียงลุงชด'}
            >
              {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>

            {/* ปุ่มปิด Modal */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-amber-950/70 border border-amber-500 text-amber-200 hover:bg-red-700 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* กล่องข้อความแชท */}
        <div className="flex-1 p-3.5 overflow-y-auto space-y-3 bg-[radial-gradient(#fed7aa_1px,transparent_1px)] [background-size:16px_16px]">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-end gap-2 ${
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'chod' && (
                <div className="w-8 h-8 rounded-full bg-amber-200 border border-amber-600 flex items-center justify-center text-sm shrink-0 mb-1">
                  👨‍🌾
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm font-kanit leading-relaxed shadow-xs ${
                  msg.sender === 'user'
                    ? 'bg-amber-600 text-white rounded-br-xs border border-amber-700'
                    : 'bg-white text-stone-800 rounded-bl-xs border border-amber-200 shadow-amber-900/5'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        {/* แถบปุ่มคำถามลัด (Quick Prompts) */}
        <div className="px-3 py-2 bg-amber-100/90 border-t border-amber-200 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <Sparkles className="w-3.5 h-3.5 text-amber-800 shrink-0 ml-1" />
          {quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="text-xs bg-white/95 hover:bg-amber-200 text-amber-900 px-3 py-1.5 rounded-full whitespace-nowrap border border-amber-300 font-kanit shadow-2xs transition-all active:scale-95 cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* ฟอร์มพิมพ์ส่งข้อความ */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-white border-t border-amber-200 flex items-center gap-2"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="พิมพ์ถามลุงชดได้เลย เช่น ปลูกอะไรดี, ตรวจฟาร์ม..."
            className="flex-1 bg-amber-50/60 border border-amber-300 rounded-xl px-4 py-2.5 text-sm text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-600 font-kanit"
          />
          <button
            type="submit"
            disabled={!inputValue.trim()}
            className="bg-emerald-600 hover:bg-emerald-700 active:scale-95 px-4 py-2.5 rounded-xl flex items-center justify-center font-bold text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
