import React from 'react';
import { X, Hammer, Coins, Sparkles } from 'lucide-react';
import { sound } from '../../utils/audio';

interface BuildModalProps {
  isOpen: boolean;
  onClose: () => void;
  coins: number;
  plotCount: number;
  onAddPlot: () => void;
  onBuildAnimalPen?: (animalType: 'chicken' | 'cow' | 'sheep') => void;
  playerLevel?: number;
  onBuildDecoration: (name: string, cost: number) => void;
}

export const BuildModal: React.FC<BuildModalProps> = ({
  isOpen,
  onClose,
  coins,
  plotCount,
  onAddPlot,
  onBuildAnimalPen,
  playerLevel = 1,
  onBuildDecoration,
}) => {
  if (!isOpen) return null;

  const buildables = [
    {
      id: 'plot',
      name: 'แปลงเกษตรแปลงใหม่ (+1 แปลง)',
      icon: '🪴',
      desc: 'ขยายพื้นที่เพาะปลูกผลผลิต เพื่อเพิ่มกำลังผลิตในฟาร์ม',
      cost: 1500,
      action: onAddPlot,
      disabled: coins < 1500 || plotCount >= 16,
    },
    ...(onBuildAnimalPen ? [
      {
        id: 'chicken_coop',
        name: 'เล้าไก่อารมณ์ดี (Chicken Coop)',
        icon: '🐔',
        desc: 'เลี้ยงไก่ไข่ ให้อาหารด้วยข้าวโพด เก็บเกี่ยวไข่ไก่สด',
        cost: 800,
        action: () => onBuildAnimalPen('chicken'),
        disabled: coins < 800,
      },
      {
        id: 'cow_pasture',
        name: 'คอกวัวนมพันธุ์ดี (Cow Pasture)',
        icon: '🐮',
        desc: 'เลี้ยงโคนม ให้อาหารด้วยข้าวโพด ผลิตนมโคสดแท้',
        cost: 2500,
        action: () => onBuildAnimalPen('cow'),
        disabled: coins < 2500 || playerLevel < 2,
      },
      {
        id: 'sheep_pasture',
        name: 'ทุ่งแกะปุยเมฆ (Sheep Pasture)',
        icon: '🐑',
        desc: 'เลี้ยงแกะขนปุย ให้อาหารด้วยข้าวสาลี ตัดขนแกะนุ่ม',
        cost: 4000,
        action: () => onBuildAnimalPen('sheep'),
        disabled: coins < 4000 || playerLevel < 4,
      },
    ] : []),
    {
      id: 'orange_tree',
      name: 'ต้นส้มสายน้ำผึ้ง',
      icon: '🍊',
      desc: 'ปลูกไม้ผล ให้ผลส้มหวานฉ่ำเก็บเกี่ยวได้ทุก 3 นาที',
      cost: 2000,
      action: () => onBuildDecoration('ต้นส้มสายน้ำผึ้ง', 2000),
      disabled: coins < 2000,
    },
    {
      id: 'flower_bed',
      name: 'แปลงกุหลาบและดอกไม้หลากสี',
      icon: '💐',
      desc: 'เพิ่มความสดใสให้รอบฟาร์ม ดึงดูดผึ้งและผีเสื้อ',
      cost: 800,
      action: () => onBuildDecoration('แปลงกุหลาบดอกไม้', 800),
      disabled: coins < 800,
    },
    {
      id: 'lantern',
      name: 'เสาไฟทางเดินสไตล์วินเทจ',
      icon: '🏮',
      desc: 'ให้แสงสว่างอบอุ่นตลอดค่ำคืนริมถนนฟาร์ม',
      cost: 500,
      action: () => onBuildDecoration('เสาไฟทางเดิน', 500),
      disabled: coins < 500,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-stone-700 flex items-center justify-center text-white shadow">
              <Hammer className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                ก่อสร้างและตกแต่ง (Build & Decor)
              </h2>
              <span className="text-xs text-amber-300">
                เพิ่มแปลงเกษตร ไม้ผล และของประดับเพื่อสร้างฟาร์มในฝัน
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Build List */}
        <div className="flex flex-col gap-3 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {buildables.map((item) => (
            <div
              key={item.id}
              className="bg-stone-900/75 rounded-2xl p-3.5 border border-amber-900 flex items-center justify-between gap-3 hover:border-amber-500 transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className="text-4xl p-1 bg-stone-950 rounded-xl border border-stone-800">
                  {item.icon}
                </span>
                <div>
                  <h3 className="font-extrabold text-sm text-amber-100">{item.name}</h3>
                  <p className="text-xs text-stone-400 mt-0.5">{item.desc}</p>
                </div>
              </div>

              <button
                disabled={item.disabled}
                onClick={() => {
                  sound.playSuccessChime();
                  item.action();
                }}
                className={`px-4 py-2 rounded-xl text-xs font-black shadow flex items-center gap-1.5 whitespace-nowrap transition-all ${
                  !item.disabled
                    ? 'game-btn-yellow text-stone-900 hover:brightness-110 active:scale-95'
                    : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                <span>{item.cost.toLocaleString()} 🪙</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
