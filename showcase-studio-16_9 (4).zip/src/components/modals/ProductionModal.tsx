import React from 'react';
import { X, Clock, Sparkles, Zap, Check } from 'lucide-react';
import { Factory, Recipe, InventoryItem } from '../../types/game';
import { RECIPES } from '../../data/initialData';
import { sound } from '../../utils/audio';

interface ProductionModalProps {
  isOpen: boolean;
  onClose: () => void;
  factoryId: string;
  factory: Factory;
  inventory: Record<string, InventoryItem>;
  onStartProduction: (recipeId: string) => void;
  onSpeedUpProduction: () => void;
  onCollectProduct: (recipeId: string) => void;
  gems: number;
}

export const ProductionModal: React.FC<ProductionModalProps> = ({
  isOpen,
  onClose,
  factoryId,
  factory,
  inventory,
  onStartProduction,
  onSpeedUpProduction,
  onCollectProduct,
  gems,
}) => {
  if (!isOpen || !factory) return null;

  // Filter recipes for this factory
  const factoryRecipes: Recipe[] = Object.values(RECIPES).filter((rec) => {
    if (factoryId === 'bakery') return ['bread', 'cornBread', 'cookie', 'troutSandwich'].includes(rec.id);
    if (factoryId === 'dairy') return ['butter', 'cheese', 'strawberryMilk', 'bassButterSteak'].includes(rec.id);
    if (factoryId === 'jam') return ['strawberryJam', 'fishTomYum', 'goldenCatfishSoup'].includes(rec.id);
    if (factoryId === 'windmill') return ['flour'].includes(rec.id);
    return false;
  });

  const currentProd = factory.currentProduction;
  const currentRecipe = currentProd ? RECIPES[currentProd.recipeId] : null;

  let progress = 0;
  let remainingSec = 0;
  if (currentProd) {
    const elapsed = (Date.now() - currentProd.startedAt) / 1000;
    remainingSec = Math.max(0, Math.ceil(currentProd.durationSec - elapsed));
    progress = Math.min(100, Math.round((elapsed / currentProd.durationSec) * 100));
  }

  const speedUpCost = 2;
  const canSpeedUp = gems >= speedUpCost;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <span className="text-3xl">{factory.icon}</span>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                {factory.thaiName}
              </h2>
              <span className="text-xs text-amber-300">เลเวล {factory.level} · ประสิทธิภาพสูง</span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Production Status Banner */}
        <div className="my-3 bg-stone-900/80 rounded-2xl p-3 border border-amber-500/50 flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-300 font-bold">สถานะการทำงานปัจจุบัน:</span>
            {currentProd ? (
              remainingSec <= 0 ? (
                <span className="text-emerald-400 font-extrabold animate-pulse">
                  ✓ เสร็จสิ้น พร้อมรับสินค้า!
                </span>
              ) : (
                <span className="text-yellow-300 font-mono font-bold">
                  กำลังผลิต... เหลือ {remainingSec} วินาที
                </span>
              )
            ) : (
              <span className="text-stone-400">ว่าง (พร้อมรับออเดอร์)</span>
            )}
          </div>

          {currentProd && currentRecipe && (
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-3xl">{currentRecipe.icon}</span>
                <div>
                  <span className="font-bold text-sm text-amber-100">{currentRecipe.thaiName}</span>
                  <div className="w-36 sm:w-56 h-2.5 bg-stone-800 rounded-full overflow-hidden mt-1 border border-stone-700">
                    <div
                      className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>

              {remainingSec <= 0 ? (
                <button
                  onClick={() => {
                    sound.playHarvest();
                    onCollectProduct(currentRecipe.id);
                  }}
                  className="px-3.5 py-1.5 game-btn-green rounded-xl text-white font-extrabold text-xs shadow-lg animate-bounce"
                >
                  เก็บผลผลิต!
                </button>
              ) : (
                <button
                  disabled={!canSpeedUp}
                  onClick={() => {
                    sound.playSuccessChime();
                    onSpeedUpProduction();
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow"
                >
                  <Zap className="w-3.5 h-3.5 text-cyan-200" />
                  <span>เร่งทันที ({speedUpCost}💎)</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Recipes Grid */}
        <h3 className="text-xs font-bold text-amber-200 mb-2">เลือกเมนูที่ต้องการผลิต:</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 overflow-y-auto game-scroll pr-1 flex-1">
          {factoryRecipes.map((recipe) => {
            // Check if player has all ingredients
            const canCraft = recipe.ingredients.every((ing) => {
              const currentCount = inventory[ing.itemId]?.count || 0;
              return currentCount >= ing.count;
            });

            return (
              <div
                key={recipe.id}
                className="bg-stone-900/70 rounded-2xl p-3 border border-amber-900 flex flex-col justify-between hover:border-amber-500 transition-colors"
              >
                <div className="flex items-start gap-2.5">
                  <div className="text-3xl p-1 bg-stone-800 rounded-xl border border-stone-700">
                    {recipe.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-extrabold text-sm text-amber-100">
                          {recipe.thaiName}
                        </span>
                        {['fishTomYum', 'troutSandwich', 'bassButterSteak', 'goldenCatfishSoup'].includes(recipe.id) && (
                          <span className="text-[9px] font-bold text-cyan-300 bg-cyan-950/90 border border-cyan-500/60 px-1.5 py-0.5 rounded-full">
                            🐟 เมนูปลาสด
                          </span>
                        )}
                      </div>
                      <span className="flex items-center gap-0.5 text-[10px] text-blue-300">
                        <Sparkles className="w-3 h-3" />
                        +{recipe.xpReward} XP
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-stone-300 mt-1">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        {recipe.durationSec} วิ
                      </span>
                      <span>·</span>
                      <span className="text-yellow-300">ขาย: +{recipe.sellPrice}🪙</span>
                    </div>
                  </div>
                </div>

                {/* Ingredients checklist */}
                <div className="my-2.5 bg-stone-950/60 rounded-xl p-2 border border-stone-800 flex flex-wrap gap-2 text-[11px]">
                  {recipe.ingredients.map((ing) => {
                    const have = inventory[ing.itemId]?.count || 0;
                    const isEnough = have >= ing.count;
                    const itemData = inventory[ing.itemId];

                    return (
                      <div
                        key={ing.itemId}
                        className={`flex items-center gap-1 px-1.5 py-0.5 rounded ${
                          isEnough
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                            : 'bg-red-950/80 text-red-300 border border-red-900'
                        }`}
                      >
                        <span>{itemData?.icon || '📦'}</span>
                        <span>{itemData?.thaiName || ing.itemId}:</span>
                        <span className="font-bold">
                          {have}/{ing.count}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Craft Button */}
                <button
                  disabled={!canCraft || !!currentProd}
                  onClick={() => {
                    sound.playClick();
                    onStartProduction(recipe.id);
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-black shadow transition-all ${
                    canCraft && !currentProd
                      ? 'game-btn-green text-white hover:brightness-110 active:scale-95'
                      : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                  }`}
                >
                  {currentProd
                    ? 'โรงงานกำลังผลิตอยู่'
                    : canCraft
                    ? 'เริ่มการผลิต ⚡'
                    : 'วัตถุดิบไม่เพียงพอ'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
