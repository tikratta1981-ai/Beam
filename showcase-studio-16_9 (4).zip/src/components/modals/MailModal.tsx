import React from 'react';
import { X, Mail, Check, Gift } from 'lucide-react';
import { sound } from '../../utils/audio';

export interface MailMessage {
  id: string;
  sender: string;
  avatar: string;
  subject: string;
  content: string;
  reward?: { coins?: number; gems?: number; energy?: number };
  read: boolean;
  claimed: boolean;
  date: string;
}

interface MailModalProps {
  isOpen: boolean;
  onClose: () => void;
  mails: MailMessage[];
  onClaimMail: (mailId: string) => void;
}

export const MailModal: React.FC<MailModalProps> = ({ isOpen, onClose, mails, onClaimMail }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-600 flex items-center justify-center text-white shadow">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                กล่องจดหมายฟาร์ม (Inbox)
              </h2>
              <span className="text-xs text-amber-300">ข่าวสาร รางวัลกิจกรรม และของขวัญจากเพื่อน</span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mail List */}
        <div className="flex flex-col gap-2.5 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {mails.length === 0 ? (
            <div className="text-center py-12 text-stone-400 text-xs">ไม่มีข้อความใหม่</div>
          ) : (
            mails.map((mail) => (
              <div
                key={mail.id}
                className={`p-3.5 rounded-2xl border-2 flex flex-col gap-2 ${
                  mail.claimed
                    ? 'bg-stone-900/50 border-stone-800 opacity-70'
                    : 'bg-stone-900/80 border-amber-900/80 hover:border-amber-500'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{mail.avatar}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-amber-100">{mail.subject}</span>
                        {!mail.read && (
                          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                        )}
                      </div>
                      <span className="text-[11px] text-stone-400">
                        จาก: {mail.sender} · {mail.date}
                      </span>
                    </div>
                  </div>

                  {mail.reward && (
                    <div className="flex items-center gap-1.5 bg-stone-950 px-2 py-1 rounded-xl text-xs font-bold border border-stone-800">
                      {mail.reward.coins && (
                        <span className="text-yellow-300">+{mail.reward.coins} 🪙</span>
                      )}
                      {mail.reward.gems && (
                        <span className="text-cyan-300">+{mail.reward.gems} 💎</span>
                      )}
                      {mail.reward.energy && (
                        <span className="text-emerald-300">+{mail.reward.energy} ⚡</span>
                      )}
                    </div>
                  )}
                </div>

                <p className="text-xs text-stone-300 bg-stone-950/40 p-2 rounded-xl border border-stone-800/80">
                  {mail.content}
                </p>

                {mail.reward && !mail.claimed && (
                  <button
                    onClick={() => {
                      sound.playLevelUp();
                      onClaimMail(mail.id);
                    }}
                    className="self-end px-4 py-1.5 game-btn-yellow text-stone-900 font-black text-xs rounded-xl shadow hover:brightness-110 active:scale-95"
                  >
                    รับของขวัญ 🎁
                  </button>
                )}
                {mail.claimed && (
                  <span className="self-end text-[11px] text-emerald-400 font-bold">
                    ✓ รับของขวัญเรียบร้อยแล้ว
                  </span>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
