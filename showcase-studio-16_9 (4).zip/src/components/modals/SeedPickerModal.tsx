import React from 'react';
import { X, Clock, Coins, Sparkles } from 'lucide-react';
import { CROPS } from '../../data/initialData';
import { CropType } from '../../types/game';
import { sound } from '../../utils/audio';

interface SeedPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCrop: (crop: CropType) => void;
  playerLevel: number;
  playerCoins: number;
}

export const SeedPickerModal: React.FC<SeedPickerModalProps> = ({
  isOpen,
  onClose,
  onSelectCrop,
  playerLevel,
  playerCoins,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg game-wood-board rounded-3xl p-4 sm:p-5 shadow-2xl border-4 border-amber-600/80 text-white">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🌱</span>
            <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
              เลือกรวงข้าวและเมล็ดพันธุ์ที่จะปลูก
            </h2>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Crop Selection Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-4 max-h-[60dvh] overflow-y-auto game-scroll pr-1">
          {Object.values(CROPS).map((crop) => {
            const isLocked = playerLevel < crop.minLevel;
            const canAfford = playerCoins >= crop.cost;

            return (
              <button
                key={crop.id}
                disabled={isLocked || !canAfford}
                onClick={() => {
                  sound.playPlant();
                  onSelectCrop(crop);
                }}
                className={`relative flex flex-col items-center justify-between p-3 rounded-2xl border-2 transition-all ${
                  isLocked
                    ? 'bg-stone-900/60 border-stone-700 opacity-60 cursor-not-allowed'
                    : !canAfford
                    ? 'bg-amber-950/40 border-amber-900/60 opacity-70 cursor-not-allowed'
                    : 'bg-gradient-to-b from-[#6b421d] to-[#45270d] border-amber-500 hover:border-yellow-300 hover:scale-105 active:scale-95 shadow-md cursor-pointer'
                }`}
              >
                {/* Crop Icon */}
                <div className="text-4xl my-1 filter drop-shadow">{crop.icon}</div>

                {/* Crop Name */}
                <span className="font-extrabold text-sm text-amber-100 text-center">
                  {crop.thaiName}
                </span>

                {/* Stats */}
                <div className="w-full flex flex-col gap-1 mt-2 text-[11px] text-stone-300 bg-stone-900/60 rounded-xl p-1.5 border border-stone-800">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-yellow-300">
                      <Coins className="w-3 h-3" />
                      <span>{crop.cost}</span>
                    </span>
                    <span className="flex items-center gap-1 text-cyan-300">
                      <Clock className="w-3 h-3" />
                      <span>{crop.growTimeSec} วิ</span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-emerald-300">
                    <span>ขาย: +{crop.sellPrice}</span>
                    <span className="flex items-center gap-0.5 text-blue-300">
                      <Sparkles className="w-3 h-3" />
                      <span>+{crop.xpReward} XP</span>
                    </span>
                  </div>
                </div>

                {/* Locked Badge */}
                {isLocked && (
                  <div className="absolute inset-0 bg-black/60 rounded-2xl flex flex-col items-center justify-center p-2 text-center">
                    <span className="text-xl">🔒</span>
                    <span className="text-xs font-bold text-amber-300 mt-1">
                      ปลดล็อกที่ Lv. {crop.minLevel}
                    </span>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer Hint */}
        <div className="pt-2 text-center text-xs text-amber-300/70 border-t border-amber-800/60">
          เคล็ดลับ: ยิ่งพืชเลเวลสูง ยิ่งให้กำไรและ XP มากขึ้น!
        </div>
      </div>
    </div>
  );
};
