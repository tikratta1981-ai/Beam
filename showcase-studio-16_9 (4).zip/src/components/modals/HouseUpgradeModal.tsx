// src/components/modals/HouseUpgradeModal.tsx
import React, { useState } from 'react';
import { House3D } from '../3d/House3D';

export interface HouseLevelInfo {
  level: number;
  name: string;
  costCoins: number;
  costWood: number;
  costDiamonds: number;
  maxEnergyBonus: number;
  storageBonus: number;
  description: string;
}

export const HOUSE_TIERS: HouseLevelInfo[] = [
  {
    level: 1,
    name: 'กระท่อมชาวสวนเริ่มต้น',
    costCoins: 0,
    costWood: 0,
    costDiamonds: 0,
    maxEnergyBonus: 50,
    storageBonus: 100,
    description: 'ที่พักผ่อนขั้นต้น กันแดดกันฝน ฟื้นฟูพลังงานพื้นฐาน',
  },
  {
    level: 2,
    name: 'บ้านไม้คลาสสิกทรงฟาร์ม',
    costCoins: 2500,
    costWood: 50,
    costDiamonds: 5,
    maxEnergyBonus: 75,
    storageBonus: 180,
    description: 'ขยายชานเรือนด้านหน้า เพิ่มพื้นที่ตากเมล็ดพันธุ์และฟื้นพลังงานไวขึ้น',
  },
  {
    level: 3,
    name: 'คฤหาสน์คันทรีเรดบาร์น',
    costCoins: 8000,
    costWood: 150,
    costDiamonds: 15,
    maxEnergyBonus: 100,
    storageBonus: 300,
    description: 'บ้านไม้สองชั้นพร้อมเตาผิงหินและห้องใต้หลังคา จุของได้มหาศาล',
  },
  {
    level: 4,
    name: 'ฟาร์มวิลล่าสไตล์โมเดิร์นคันทรี',
    costCoins: 20000,
    costWood: 350,
    costDiamonds: 30,
    maxEnergyBonus: 150,
    storageBonus: 500,
    description: 'ฟาร์มเฮ้าส์ระดับสูงสุด ปลดล็อกบัฟฟื้นพลังงานสองเท่าและรูปลักษณ์หรูหรา',
  },
];

interface HouseUpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
  playerCoins: number;
  playerWood?: number;
  playerDiamonds: number;
  onUpgrade: (nextLevel: number, costCoins: number, costWood: number, costDiamonds: number) => void;
}

export const HouseUpgradeModal: React.FC<HouseUpgradeModalProps> = ({
  isOpen,
  onClose,
  currentLevel = 1,
  playerCoins,
  playerWood = 0,
  playerDiamonds,
  onUpgrade,
}) => {
  const [previewLevel, setPreviewLevel] = useState<number>(
    Math.min(currentLevel + 1, HOUSE_TIERS.length)
  );

  if (!isOpen) return null;

  const currentTier = HOUSE_TIERS.find((t) => t.level === currentLevel) || HOUSE_TIERS[0];
  const nextTier = HOUSE_TIERS.find((t) => t.level === currentLevel + 1);
  const previewTier = HOUSE_TIERS.find((t) => t.level === previewLevel) || currentTier;
  const isMaxLevel = !nextTier;

  const canAfford =
    nextTier &&
    playerCoins >= nextTier.costCoins &&
    playerDiamonds >= nextTier.costDiamonds &&
    playerWood >= nextTier.costWood;

  const handleUpgradeClick = () => {
    if (!nextTier || !canAfford) return;
    onUpgrade(nextTier.level, nextTier.costCoins, nextTier.costWood, nextTier.costDiamonds);
    // ขยับ preview ไปยังเลเวลถัดไปหลังอัปเกรด
    if (nextTier.level < HOUSE_TIERS.length) {
      setPreviewLevel(nextTier.level + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-amber-50 to-orange-100/90 rounded-3xl shadow-2xl border-4 border-amber-800/30 overflow-hidden">
        
        {/* Header */}
        <div className="relative bg-gradient-to-r from-amber-700 via-amber-600 to-amber-700 px-6 py-4 text-white shadow-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">🏡</span>
            <div>
              <h2 className="text-xl font-bold tracking-wide drop-shadow-sm">บ้านพักชาวสวน (Farmhouse)</h2>
              <p className="text-xs text-amber-200">โซน 1: ศูนย์กลางฟาร์มและฟื้นฟูพลังงาน</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-black/20 hover:bg-black/40 text-amber-100 flex items-center justify-center text-lg font-bold transition-transform active:scale-95 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* ซีกซ้าย: 3D Preview Display + Selector */}
          <div className="flex flex-col items-center">
            <div className="relative w-full h-56 bg-gradient-to-b from-sky-200 to-emerald-100 rounded-2xl border-2 border-amber-300 shadow-inner overflow-hidden flex items-center justify-center">
              <House3D type="farmhouse" seamless={true} className="w-full h-full" />
              
              <div className="absolute top-2 left-2 bg-amber-900/80 text-amber-100 text-xs px-2.5 py-1 rounded-full backdrop-blur-sm">
                ระดับปัจจุบัน: Lv. {currentLevel}
              </div>
              <div className="absolute top-2 right-2 bg-blue-900/80 text-blue-100 text-xs px-2.5 py-1 rounded-full backdrop-blur-sm">
                กำลังดู: Lv. {previewLevel}
              </div>
            </div>

            {/* Level Preview Selector Tabs */}
            <div className="flex gap-1.5 mt-3">
              {HOUSE_TIERS.map((tier) => (
                <button
                  key={tier.level}
                  onClick={() => setPreviewLevel(tier.level)}
                  className={`px-3 py-1 text-xs rounded-lg font-bold transition-all ${
                    previewLevel === tier.level
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'bg-amber-200/70 text-amber-800 hover:bg-amber-300'
                  }`}
                >
                  Lv.{tier.level}
                </button>
              ))}
            </div>

            {/* คำอธิบายบ้าน */}
            <div className="mt-2 text-center">
              <h3 className="font-bold text-amber-900 text-sm">{previewTier.name}</h3>
              <p className="text-xs text-amber-700 mt-0.5 px-2">{previewTier.description}</p>
            </div>
          </div>

          {/* ซีกขวา: สถิติและค่าอัปเกรด */}
          <div className="flex flex-col justify-between space-y-4">
            
            {/* กล่องแสดงผลประโยชน์ (Perks) */}
            <div className="bg-amber-100/80 border border-amber-300/80 rounded-2xl p-4 shadow-sm space-y-2.5">
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                คุณสมบัติและโบนัสที่จะได้รับ
              </h4>
              
              {/* Max Energy Bonus */}
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-slate-700">
                  ⚡ ขีดจำกัดพลังงานสูงสุด:
                </span>
                <span className="font-bold text-emerald-700">
                  {currentTier.maxEnergyBonus}
                  {nextTier && (
                    <span className="text-xs text-emerald-500 font-semibold ml-1">
                      ➔ {nextTier.maxEnergyBonus} (+{nextTier.maxEnergyBonus - currentTier.maxEnergyBonus})
                    </span>
                  )}
                </span>
              </div>

              {/* Barn Capacity Bonus */}
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-1.5 text-slate-700">
                  📦 ความจุคลังเก็บผลผลิต:
                </span>
                <span className="font-bold text-amber-800">
                  {currentTier.storageBonus}
                  {nextTier && (
                    <span className="text-xs text-amber-600 font-semibold ml-1">
                      ➔ {nextTier.storageBonus} (+{nextTier.storageBonus - currentTier.storageBonus})
                    </span>
                  )}
                </span>
              </div>
            </div>

            {/* ค่าใช้จ่ายในการอัปเกรด */}
            {!isMaxLevel && nextTier ? (
              <div className="bg-white/80 border border-amber-200 rounded-2xl p-4 space-y-2">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  วัตถุดิบที่ต้องการ (ระดับถัดไป Lv.{nextTier.level})
                </h4>
                
                <div className="grid grid-cols-3 gap-2 pt-1 text-center">
                  {/* เหรียญ */}
                  <div className={`p-2 rounded-xl border ${playerCoins >= nextTier.costCoins ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-red-50 border-red-200 text-red-600'}`}>
                    <div className="text-lg">🪙</div>
                    <div className="text-xs font-bold mt-0.5">{nextTier.costCoins.toLocaleString()}</div>
                    <div className="text-[10px] text-slate-500">มี {playerCoins.toLocaleString()}</div>
                  </div>

                  {/* ไม้ */}
                  <div className={`p-2 rounded-xl border ${playerWood >= nextTier.costWood ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-red-50 border-red-200 text-red-600'}`}>
                    <div className="text-lg">🪵</div>
                    <div className="text-xs font-bold mt-0.5">{nextTier.costWood}</div>
                    <div className="text-[10px] text-slate-500">มี {playerWood}</div>
                  </div>

                  {/* เพชร */}
                  <div className={`p-2 rounded-xl border ${playerDiamonds >= nextTier.costDiamonds ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-red-50 border-red-200 text-red-600'}`}>
                    <div className="text-lg">💎</div>
                    <div className="text-xs font-bold mt-0.5">{nextTier.costDiamonds}</div>
                    <div className="text-[10px] text-slate-500">มี {playerDiamonds}</div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-emerald-100/80 border border-emerald-300 rounded-2xl text-center">
                <span className="text-2xl">🏆</span>
                <p className="text-sm font-bold text-emerald-800 mt-1">บ้านพักระดับสูงสุดแล้ว!</p>
                <p className="text-xs text-emerald-600">ฟาร์มเฮ้าส์ของคุณสมบูรณ์แบบที่สุดในเมือง</p>
              </div>
            )}

            {/* ปุ่มกดอัปเกรด */}
            {!isMaxLevel ? (
              <button
                disabled={!canAfford}
                onClick={handleUpgradeClick}
                className={`w-full py-3.5 px-6 rounded-2xl font-bold text-base shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 ${
                  canAfford
                    ? 'bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white cursor-pointer hover:shadow-emerald-500/25'
                    : 'bg-slate-300 text-slate-500 cursor-not-allowed shadow-none'
                }`}
              >
                <span>🔨</span>
                <span>{canAfford ? 'อัปเกรดบ้านทันที' : 'ทรัพยากรไม่เพียงพอ'}</span>
              </button>
            ) : (
              <button
                onClick={onClose}
                className="w-full py-3 px-6 rounded-2xl font-bold bg-amber-600 text-white hover:bg-amber-700 shadow-md transition-all active:scale-95 cursor-pointer"
              >
                ปิดหน้าต่าง
              </button>
            )}

          </div>
        </div>

      </div>
    </div>
  );
};