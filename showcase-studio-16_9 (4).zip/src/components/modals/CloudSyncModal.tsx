import React, { useState, useEffect } from 'react';
import {
  X,
  Cloud,
  CloudCheck,
  RefreshCw,
  Download,
  Upload,
  Copy,
  Check,
  Smartphone,
  ShieldCheck,
  AlertTriangle,
  GitMerge,
  Sparkles,
  User,
  Key,
  Laptop,
} from 'lucide-react';
import { sound } from '../../utils/audio';
import { cloudSyncLimiter, logSecurityEvent } from '../../security';

export interface CloudSavePayload {
  version: string;
  timestamp: number;
  deviceId: string;
  userEmail?: string;
  gameData: any;
  placedItems?: any[];
  hash?: string;
}

interface CloudSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSnapshot: any;
  placedItems: any[];
  onApplySnapshot: (snapshot: any, placedItems?: any[]) => void;
  userEmail?: string;
}

export const CloudSyncModal: React.FC<CloudSyncModalProps> = ({
  isOpen,
  onClose,
  currentSnapshot,
  placedItems,
  onApplySnapshot,
  userEmail = 'tommegood641@gmail.com',
}) => {
  const [activeTab, setActiveTab] = useState<'sync' | 'backup' | 'import'>('sync');
  const [transferCode, setTransferCode] = useState<string>('');
  const [inputCode, setInputCode] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [syncing, setSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>(() => {
    return localStorage.getItem('beam_farm_last_sync_time') || 'ยังไม่เคยซิงก์';
  });

  // สถานะบัญชีผู้ใช้
  const [accountEmail, setAccountEmail] = useState<string>(() => {
    return localStorage.getItem('beam_farm_account_email') || userEmail;
  });
  const [isEditingAccount, setIsEditingAccount] = useState<boolean>(false);
  const [inputEmail, setInputEmail] = useState<string>(accountEmail);

  // Device ID เฉพาะของเครื่องนี้
  const [deviceId] = useState<string>(() => {
    let id = localStorage.getItem('beam_farm_device_id');
    if (!id) {
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      id = `${isMobile ? 'Mobile' : 'Desktop'}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      localStorage.setItem('beam_farm_device_id', id);
    }
    return id;
  });

  // State สำหรับจัดการ Conflict เมื่อข้อมูลชนกัน
  const [conflictData, setConflictData] = useState<{
    local: CloudSavePayload;
    remote: CloudSavePayload;
  } | null>(null);

  const [notification, setNotification] = useState<string | null>(null);

  // สร้างรหัส Transfer Code จาก Save ปัจจุบัน
  const generateTransferCode = () => {
    try {
      const payload: CloudSavePayload = {
        version: '6.0',
        timestamp: Date.now(),
        deviceId,
        userEmail: accountEmail,
        gameData: currentSnapshot,
        placedItems,
      };
      const jsonStr = JSON.stringify(payload);
      const b64 = btoa(encodeURIComponent(jsonStr));
      setTransferCode(b64);
    } catch {
      setNotification('เกิดข้อผิดพลาดในการสร้างรหัส');
    }
  };

  useEffect(() => {
    if (isOpen) {
      generateTransferCode();
    }
  }, [isOpen, currentSnapshot, placedItems, accountEmail]);

  if (!isOpen) return null;

  // 1-Click ดาวน์โหลดไฟล์สำรองข้อมูล (.beamfarm)
  const handleDownloadBackup = () => {
    try {
      sound.playClick();
      if (!cloudSyncLimiter.tryConsume(1)) {
        setNotification('คำขอดาวน์โหลดสำรองถี่เกินไป กรุณารอสักครู่ (Rate limit)');
        return;
      }
      const payload: CloudSavePayload = {
        version: '6.0',
        timestamp: Date.now(),
        deviceId,
        userEmail: accountEmail,
        gameData: currentSnapshot,
        placedItems,
      };
      const jsonStr = JSON.stringify(payload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `beam_farm_save_${dateStr}_${deviceId}.beamfarm`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      sound.playHarvest();
      setNotification('ดาวน์โหลดไฟล์สำรองข้อมูลสำเร็จ! 💾');
      setTimeout(() => setNotification(null), 3500);
    } catch {
      setNotification('ดาวน์โหลดไฟล์ไม่สำเร็จ');
    }
  };

  // 1-Click คัดลอกรหัส Transfer Code
  const handleCopyTransferCode = () => {
    sound.playClick();
    if (!transferCode) generateTransferCode();
    navigator.clipboard.writeText(transferCode);
    setCopied(true);
    sound.playCoin();
    setTimeout(() => setCopied(false), 2500);
    setNotification('คัดลอกรหัสย้ายเครื่องลงคลิปบอร์ดแล้ว! 📋');
    setTimeout(() => setNotification(null), 3000);
  };

  // ตรวจสอบและเปรียบเทียบข้อมูลเมื่อจะนำเข้า (Conflict Detection)
  const processIncomingPayload = (payload: CloudSavePayload) => {
    if (!payload.gameData || typeof payload.gameData !== 'object') {
      setNotification('ไฟล์หรือรหัสสำรองข้อมูลไม่ถูกต้อง ❌');
      setTimeout(() => setNotification(null), 3000);
      return;
    }

    const localPayload: CloudSavePayload = {
      version: '6.0',
      timestamp: currentSnapshot?.lastActiveTime || Date.now(),
      deviceId,
      userEmail: accountEmail,
      gameData: currentSnapshot,
      placedItems,
    };

    // ตรวจสอบว่ามีความขัดแย้งหรือไม่ (ต่างเครื่อง หรือต่างเวลา หรือต่างเลเวล)
    const isDifferentDevice = payload.deviceId && payload.deviceId !== deviceId;
    const isDifferentLevel = (payload.gameData.level || 1) !== (currentSnapshot?.level || 1);
    const isSignificantDiff = Math.abs((payload.timestamp || 0) - (localPayload.timestamp || 0)) > 60000;

    if (isDifferentDevice || isDifferentLevel || isSignificantDiff) {
      // ตรวจพบ Conflict -> เปิดหน้าต่างเปรียบเทียบให้ผู้เล่นเลือกวิธีแก้ปัญหา
      sound.playSuccessChime();
      setConflictData({
        local: localPayload,
        remote: payload,
      });
    } else {
      // ไม่มี Conflict ทับได้ทันที
      applySnapshotAndClose(payload.gameData, payload.placedItems);
    }
  };

  // นำเข้ารหัส Transfer Code จาก Text
  const handleImportTransferCode = () => {
    sound.playClick();
    if (!inputCode.trim()) {
      setNotification('กรุณาวางรหัสย้ายเครื่องก่อนครับ ⚠️');
      setTimeout(() => setNotification(null), 3000);
      return;
    }

    try {
      const decoded = decodeURIComponent(atob(inputCode.trim()));
      const payload: CloudSavePayload = JSON.parse(decoded);
      processIncomingPayload(payload);
    } catch {
      setNotification('รหัสย้ายเครื่องไม่ถูกต้องหรือชำรุด กรุณาตรวจสอบอีกครั้ง ❌');
      setTimeout(() => setNotification(null), 3500);
    }
  };

  // นำเข้าไฟล์จากคอมพิวเตอร์/มือถือ
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const payload: CloudSavePayload = JSON.parse(text);
        processIncomingPayload(payload);
      } catch {
        setNotification('ไฟล์ข้อมูลฟาร์มไม่ถูกต้อง ❌');
        setTimeout(() => setNotification(null), 3000);
      }
    };
    reader.readAsText(file);
  };

  // ปรับใช้ข้อมูลและบันทึกลงระบบ
  const applySnapshotAndClose = (gameData: any, newPlacedItems?: any[]) => {
    onApplySnapshot(gameData, newPlacedItems);
    const nowStr = new Date().toLocaleString('th-TH');
    setLastSyncTime(nowStr);
    localStorage.setItem('beam_farm_last_sync_time', nowStr);
    sound.playHarvest();
    setNotification('ซิงก์และโหลดข้อมูลฟาร์มสำเร็จเรียบร้อย! ✨🎉');
    setTimeout(() => {
      setNotification(null);
      setConflictData(null);
      onClose();
    }, 1800);
  };

  // กลยุทธ์การแก้ไข Conflict (Conflict Resolution Strategies)
  const handleResolveConflict = (strategy: 'highest' | 'recent' | 'merge' | 'local') => {
    if (!conflictData) return;
    sound.playClick();

    const localData = conflictData.local.gameData;
    const remoteData = conflictData.remote.gameData;
    const localItems = conflictData.local.placedItems || placedItems;
    const remoteItems = conflictData.remote.placedItems || [];

    if (strategy === 'highest') {
      // ยึดเซฟที่มีเลเวลหรือ XP สูงที่สุด
      const localScore = (localData.level || 1) * 10000 + (localData.xp || 0);
      const remoteScore = (remoteData.level || 1) * 10000 + (remoteData.xp || 0);
      if (remoteScore >= localScore) {
        applySnapshotAndClose(remoteData, remoteItems.length > 0 ? remoteItems : localItems);
      } else {
        applySnapshotAndClose(localData, localItems);
      }
    } else if (strategy === 'recent') {
      // Last-Write-Wins: ยึดเวลาบันทึกล่าสุด
      if ((conflictData.remote.timestamp || 0) >= (conflictData.local.timestamp || 0)) {
        applySnapshotAndClose(remoteData, remoteItems.length > 0 ? remoteItems : localItems);
      } else {
        applySnapshotAndClose(localData, localItems);
      }
    } else if (strategy === 'merge') {
      // Smart Merge: รวมเหรียญและเพชรสูงสุด + ใช้เลเวลและฟาร์มที่ดีกว่า
      const mergedData = {
        ...((remoteData.level || 1) >= (localData.level || 1) ? remoteData : localData),
        coins: Math.max(localData.coins || 0, remoteData.coins || 0) + Math.min(localData.coins || 0, remoteData.coins || 0) * 0.1,
        gems: Math.max(localData.gems || 0, remoteData.gems || 0),
        barnCapacity: Math.max(localData.barnCapacity || 30, remoteData.barnCapacity || 30),
      };
      applySnapshotAndClose(mergedData, remoteItems.length > 0 ? remoteItems : localItems);
    } else if (strategy === 'local') {
      // คงข้อมูลเครื่องนี้ไว้
      setConflictData(null);
      setNotification('ยกเลิกการนำเข้า คงข้อมูลเครื่องนี้ตามเดิม');
      setTimeout(() => setNotification(null), 2500);
    }
  };

  // จำลองการซิงก์
  const handleSimulatedSync = () => {
    sound.playClick();
    setSyncing(true);
    setTimeout(() => {
      setSyncing(false);
      const nowStr = new Date().toLocaleString('th-TH');
      setLastSyncTime(nowStr);
      localStorage.setItem('beam_farm_last_sync_time', nowStr);
      sound.playHarvest();
      setNotification('ซิงก์ข้อมูลอุปกรณ์ปัจจุบันเรียบร้อยแล้ว! ☁️✨');
      setTimeout(() => setNotification(null), 3000);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[92dvh] game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-cyan-600/90 flex items-center justify-center text-white shadow border border-cyan-300">
              <Cloud className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow flex items-center gap-2">
                <span>Cloud Save & Cross-Device Sync</span>
                <span className="text-[10px] bg-cyan-500/30 text-cyan-200 border border-cyan-400/50 px-2 py-0.5 rounded-full font-bold">
                  v6.0
                </span>
              </h2>
              <span className="text-xs text-amber-300/90">
                ระบบเชื่อมโยงบัญชี สำรองข้อมูล และซิงก์ข้ามอุปกรณ์
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* แจ้งเตือน Toast */}
        {notification && (
          <div className="my-2 p-2.5 bg-emerald-600/90 text-white rounded-xl border border-emerald-300 text-xs font-black shadow-lg text-center animate-bounce shrink-0">
            {notification}
          </div>
        )}

        {/* หน้าต่างเมื่อตรวจพบ Conflict (Conflict Resolution View) */}
        {conflictData ? (
          <div className="my-3 flex-1 overflow-y-auto game-scroll pr-1 flex flex-col">
            <div className="bg-amber-950/80 border-2 border-amber-500 rounded-2xl p-4 mb-3">
              <div className="flex items-center gap-2 text-yellow-300 font-black text-sm mb-1">
                <AlertTriangle className="w-5 h-5 text-yellow-400" />
                <span>ตรวจพบข้อมูลขัดแย้งกัน (Save Conflict Detected)</span>
              </div>
              <p className="text-xs text-stone-300">
                ข้อมูลในเครื่องปัจจุบันและข้อมูลที่นำเข้ามีการเล่นคนละช่วงเวลาหรือระดับเลเวลไม่เท่ากัน กรุณาเลือกวิธีจัดการ:
              </p>
            </div>

            {/* Side-by-side comparison */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              {/* Local Device */}
              <div className="bg-stone-900/90 border-2 border-stone-700 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-stone-300 pb-2 border-b border-stone-800 mb-2">
                    <Smartphone className="w-4 h-4 text-cyan-400" />
                    <span>เครื่องปัจจุบัน (This Device)</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-stone-400">เลเวล:</span>
                      <span className="font-bold text-yellow-300">Lv. {conflictData.local.gameData.level || 1}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">เหรียญทอง:</span>
                      <span className="font-bold text-amber-300">{conflictData.local.gameData.coins?.toLocaleString()} 🪙</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">เพชร:</span>
                      <span className="font-bold text-emerald-300">{conflictData.local.gameData.gems || 0} 💎</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">ชื่อฟาร์ม:</span>
                      <span className="font-bold text-stone-200">{conflictData.local.gameData.farmName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">อุปกรณ์:</span>
                      <span className="text-[10px] text-stone-400 font-mono">{conflictData.local.deviceId}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-2 border-t border-stone-800 text-[10px] text-stone-400">
                  เวลา: {new Date(conflictData.local.timestamp).toLocaleTimeString('th-TH')}
                </div>
              </div>

              {/* Remote / Incoming Save */}
              <div className="bg-stone-900/90 border-2 border-cyan-500/80 rounded-2xl p-3.5 flex flex-col justify-between shadow-lg">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300 pb-2 border-b border-stone-800 mb-2">
                    <Cloud className="w-4 h-4 text-cyan-400" />
                    <span>ข้อมูลที่จะนำเข้า (Incoming Save)</span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-stone-400">เลเวล:</span>
                      <span className="font-bold text-yellow-300">Lv. {conflictData.remote.gameData.level || 1}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">เหรียญทอง:</span>
                      <span className="font-bold text-amber-300">{conflictData.remote.gameData.coins?.toLocaleString()} 🪙</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">เพชร:</span>
                      <span className="font-bold text-emerald-300">{conflictData.remote.gameData.gems || 0} 💎</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">ชื่อฟาร์ม:</span>
                      <span className="font-bold text-stone-200">{conflictData.remote.gameData.farmName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">อุปกรณ์:</span>
                      <span className="text-[10px] text-cyan-300 font-mono">{conflictData.remote.deviceId}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-2 border-t border-stone-800 text-[10px] text-cyan-300">
                  เวลา: {new Date(conflictData.remote.timestamp).toLocaleTimeString('th-TH')}
                </div>
              </div>
            </div>

            {/* Resolution Strategy Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-auto">
              <button
                type="button"
                onClick={() => handleResolveConflict('highest')}
                className="p-2.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-stone-950 font-black text-xs rounded-xl shadow-md border border-white flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-stone-950" />
                <span>1. ยึดเลเวลและ XP สูงสุด (แนะนำ ⭐)</span>
              </button>

              <button
                type="button"
                onClick={() => handleResolveConflict('recent')}
                className="p-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs rounded-xl shadow border border-cyan-300 flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>2. ยึดเวลาเล่นล่าสุด (Last-Write-Wins)</span>
              </button>

              <button
                type="button"
                onClick={() => handleResolveConflict('merge')}
                className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow border border-emerald-300 flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
              >
                <GitMerge className="w-4 h-4" />
                <span>3. รวมเหรียญและเพชร (Smart Merge)</span>
              </button>

              <button
                type="button"
                onClick={() => handleResolveConflict('local')}
                className="p-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold text-xs rounded-xl shadow border border-stone-600 flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
              >
                <X className="w-4 h-4" />
                <span>4. ยกเลิก คงข้อมูลเครื่องนี้ไว้</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Tabs */}
            <div className="flex items-center gap-2 mt-3 pb-2 border-b border-amber-900/60 shrink-0">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setActiveTab('sync');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'sync'
                    ? 'bg-cyan-600 text-white shadow-md border border-cyan-300'
                    : 'bg-stone-800/80 text-stone-300 hover:bg-stone-700'
                }`}
              >
                <CloudCheck className="w-4 h-4" />
                <span>บัญชี & ซิงก์ (Account & Sync)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setActiveTab('backup');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'backup'
                    ? 'bg-amber-600 text-white shadow-md border border-amber-300'
                    : 'bg-stone-800/80 text-stone-300 hover:bg-stone-700'
                }`}
              >
                <Download className="w-4 h-4" />
                <span>สำรองข้อมูล & รหัสย้ายเครื่อง</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setActiveTab('import');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'import'
                    ? 'bg-emerald-600 text-white shadow-md border border-emerald-300'
                    : 'bg-stone-800/80 text-stone-300 hover:bg-stone-700'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>กู้คืน & นำเข้าเซฟ</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="my-3 flex-1 overflow-y-auto game-scroll pr-1 flex flex-col gap-3">
              {activeTab === 'sync' && (
                <div className="flex flex-col gap-3">
                  {/* Account Card */}
                  <div className="bg-stone-900/85 rounded-2xl p-4 border border-stone-800 flex flex-col gap-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-full bg-cyan-700 flex items-center justify-center text-white">
                          <User className="w-5 h-5" />
                        </div>
                        <div>
                          <span className="text-[10px] text-stone-400 font-bold block">บัญชีผู้ใช้ของคุณ (User Account)</span>
                          {isEditingAccount ? (
                            <div className="flex items-center gap-2 mt-1">
                              <input
                                type="email"
                                value={inputEmail}
                                onChange={(e) => setInputEmail(e.target.value)}
                                className="bg-stone-950 border border-cyan-500 rounded-lg px-2 py-0.5 text-xs text-white"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  if (inputEmail.trim()) {
                                    setAccountEmail(inputEmail.trim());
                                    localStorage.setItem('beam_farm_account_email', inputEmail.trim());
                                  }
                                  setIsEditingAccount(false);
                                }}
                                className="px-2 py-0.5 bg-emerald-600 text-white rounded-lg text-xs"
                              >
                                บันทึก
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-black text-amber-200">{accountEmail}</span>
                              <button
                                type="button"
                                onClick={() => setIsEditingAccount(true)}
                                className="text-[10px] text-cyan-400 hover:underline"
                              >
                                เปลี่ยน
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-500/50">
                        <ShieldCheck className="w-4 h-4" />
                        <span>เชื่อมโยงแล้ว</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-800 text-xs text-stone-300">
                      <div>
                        <span className="text-stone-400 block text-[10px]">รหัสเครื่องปัจจุบัน (Device ID):</span>
                        <span className="font-mono text-cyan-300 text-xs font-bold flex items-center gap-1">
                          <Laptop className="w-3.5 h-3.5" /> {deviceId}
                        </span>
                      </div>
                      <div>
                        <span className="text-stone-400 block text-[10px]">ซิงก์ล่าสุดเมื่อ:</span>
                        <span className="text-amber-200 text-xs font-bold">{lastSyncTime}</span>
                      </div>
                    </div>
                  </div>

                  {/* Sync Action */}
                  <div className="bg-stone-900/85 rounded-2xl p-4 border border-stone-800 flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-black text-amber-200">ซิงก์สถานะฟาร์มด่วน (Manual Sync Now)</h4>
                      <p className="text-[10px] text-stone-400 mt-0.5">
                        ตรวจสอบความคืบหน้าของฟาร์ม และบันทึก Snapshot ล่าสุด
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleSimulatedSync}
                      disabled={syncing}
                      className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl font-bold text-xs shadow-md border border-cyan-300 flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
                    >
                      <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
                      <span>{syncing ? 'กำลังซิงก์...' : 'ซิงก์ทันที'}</span>
                    </button>
                  </div>

                  {/* Cross-Device Notice */}
                  <div className="bg-stone-950/80 p-3.5 rounded-2xl border border-stone-800 text-xs text-stone-300 flex items-start gap-2.5">
                    <Smartphone className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-cyan-200 block mb-0.5">เล่น 2 เครื่องพร้อมกัน (Cross-Device Protocol):</span>
                      <p className="text-[11px] leading-relaxed text-stone-400">
                        คุณสามารถใช้ <strong>รหัสย้ายเครื่อง 6 หลัก (Transfer Code)</strong> หรือ <strong>ดาวน์โหลดไฟล์ .beamfarm</strong> จากแท็บ "สำรองข้อมูล" ไปเปิดในเครื่องที่สองได้ทันที และหากมีการเล่นทั้งสองเครื่อง ระบบมี <strong>Conflict Resolution Engine</strong> ช่วยผสานข้อมูลเลเวลและเหรียญทองให้คุณโดยไม่สูญหาย
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'backup' && (
                <div className="flex flex-col gap-3">
                  {/* File Backup */}
                  <div className="bg-stone-900/85 rounded-2xl p-4 border border-stone-800 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs font-black text-amber-200">
                        <Download className="w-4 h-4 text-amber-400" />
                        <span>ดาวน์โหลดไฟล์สำรอง (.beamfarm)</span>
                      </div>
                      <p className="text-[10px] text-stone-400 mt-0.5">
                        บันทึกไฟล์ฟาร์มทั้งหมดลงเครื่อง สำหรับเก็บไว้ในคอมพิวเตอร์ แฟลชไดรฟ์ หรือส่งต่อ
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleDownloadBackup}
                      className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold text-xs shadow-md border border-amber-300 flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer whitespace-nowrap"
                    >
                      <Download className="w-4 h-4" />
                      <span>ดาวน์โหลดไฟล์</span>
                    </button>
                  </div>

                  {/* Transfer Code Generator */}
                  <div className="bg-stone-900/85 rounded-2xl p-4 border border-stone-800 flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-black text-cyan-200">
                        <Key className="w-4 h-4 text-cyan-400" />
                        <span>รหัสย้ายเครื่องฉุกเฉิน (Cross-Device Transfer Code)</span>
                      </div>
                      <button
                        type="button"
                        onClick={handleCopyTransferCode}
                        className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow transition-transform active:scale-95 cursor-pointer"
                      >
                        {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copied ? 'คัดลอกแล้ว!' : 'คัดลอกรหัส'}</span>
                      </button>
                    </div>
                    <p className="text-[10px] text-stone-400">
                      คัดลอกรหัสเข้ารหัสข้อความด้านล่างนี้ไปวางในอีกเครื่อง (แท็บเล็ต/มือถือ) เพื่อเล่นต่อได้ทันที
                    </p>
                    <textarea
                      readOnly
                      value={transferCode}
                      className="w-full h-20 bg-stone-950/90 border border-stone-700 rounded-xl p-2 text-[10px] font-mono text-cyan-200 select-all resize-none focus:outline-none"
                    />
                  </div>
                </div>
              )}

              {activeTab === 'import' && (
                <div className="flex flex-col gap-3">
                  {/* Import via Transfer Code */}
                  <div className="bg-stone-900/85 rounded-2xl p-4 border border-stone-800 flex flex-col gap-2">
                    <div className="flex items-center gap-1.5 text-xs font-black text-emerald-200">
                      <Key className="w-4 h-4 text-emerald-400" />
                      <span>วางรหัสย้ายเครื่อง (Paste Transfer Code)</span>
                    </div>
                    <textarea
                      value={inputCode}
                      onChange={(e) => setInputCode(e.target.value)}
                      placeholder="วางรหัสที่คัดลอกมาจากอีกเครื่องที่นี่..."
                      className="w-full h-20 bg-stone-950/90 border border-stone-700 rounded-xl p-2 text-xs font-mono text-emerald-200 resize-none focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={handleImportTransferCode}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md border border-emerald-300 flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>โหลดข้อมูลจากรหัสย้ายเครื่อง</span>
                    </button>
                  </div>

                  {/* Upload Backup File */}
                  <div className="bg-stone-900/85 rounded-2xl p-4 border border-stone-800 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs font-black text-amber-200">
                        <Upload className="w-4 h-4 text-amber-400" />
                        <span>นำเข้าจากไฟล์สำรอง (.beamfarm)</span>
                      </div>
                      <p className="text-[10px] text-stone-400 mt-0.5">
                        เลือกไฟล์ที่คุณเคยดาวน์โหลดไว้เพื่อกู้คืนข้อมูล
                      </p>
                    </div>
                    <label className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold text-xs shadow-md border border-amber-300 flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer whitespace-nowrap">
                      <Upload className="w-4 h-4" />
                      <span>เลือกไฟล์</span>
                      <input
                        type="file"
                        accept=".beamfarm,.json"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
