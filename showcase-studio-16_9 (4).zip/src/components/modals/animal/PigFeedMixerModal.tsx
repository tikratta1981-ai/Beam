// src/components/modals/animal/PigFeedMixerModal.tsx

import React, { useState } from 'react';
import { 
  X, 
  Award, 
  Utensils, 
  Heart, 
  Clock, 
  Sparkles, 
  ChefHat, 
  Info, 
  Scale, 
  Dna, 
  CheckCircle2,
  PackageCheck
} from 'lucide-react';
import { InventoryItem } from '../../../types/game';
import { sound } from '../../../utils/audio/index';
import { PigEntity } from '../../3d/models/animals/IsometricPig3D';

/* =========================================================================
   เสาแกนไม้ด้านข้าง (Spindle SVG)
   ========================================================================= */
const WoodenSpindle: React.FC<{ isRight?: boolean }> = ({ isRight = false }) => (
  <div className="relative w-8 sm:w-11 flex-shrink-0 flex flex-col items-center select-none py-1.5 z-10">
    {/* หัวเสาแกนไม้ด้านบน */}
    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-gradient-to-b from-[#874922] via-[#5c2e11] to-[#2b1205] border border-[#a86537] shadow-lg flex items-center justify-center">
      <div className="w-2.5 h-2.5 rounded-full bg-[#f3c88c]/60 shadow-inner" />
    </div>

    {/* ลำต้นแกนไม้หมุนม้วนกระดาษ */}
    <div className="w-4 sm:w-5.5 flex-1 my-0.5 rounded-sm bg-gradient-to-r from-[#2a1306] via-[#6e3917] to-[#1f0d04] border-x border-[#8d4b21] shadow-2xl relative">
      <div className="absolute inset-y-0 left-1 w-0.5 bg-[#fce4bd]/20" />
      <div className="absolute inset-y-0 right-1 w-0.5 bg-black/40" />
    </div>

    {/* หัวเสาแกนไม้ด้านล่าง */}
    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-gradient-to-t from-[#874922] via-[#5c2e11] to-[#2b1205] border border-[#a86537] shadow-lg flex items-center justify-center">
      <div className="w-2.5 h-2.5 rounded-full bg-[#f3c88c]/60 shadow-inner" />
    </div>

    {/* เงาทอดจากแกนไม้ลงบนแผ่นกระดาษ */}
    <div 
      className={`absolute inset-y-4 ${
        isRight ? '-left-3.5 bg-gradient-to-l' : '-right-3.5 bg-gradient-to-r'
      } w-3.5 from-black/45 to-transparent pointer-events-none`} 
    />
  </div>
);

/* =========================================================================
   PIG FEED MIXER MODAL COMPONENT
   ========================================================================= */
export interface PigFeedMixerModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory?: Record<string, InventoryItem>;
  onFeedPig: (recipeType: 'mash' | 'truffle_mix') => void;
  pig?: PigEntity;
}

export const PigFeedMixerModal: React.FC<PigFeedMixerModalProps> = ({
  isOpen,
  onClose,
  inventory = {},
  onFeedPig,
  pig,
}) => {
  const [activeTab, setActiveTab] = useState<'biofeed' | 'profile'>('biofeed');

  if (!isOpen) return null;

  // 1. ตรวจสอบวัตถุดิบในคลัง (Inventory Check)
  const wheatCount = Number(inventory?.['wheat']?.count ?? 0);
  const cornCount = Number(inventory?.['corn']?.count ?? 0);
  const appleCount = Number(inventory?.['apple']?.count ?? 0);

  // เงื่อนไขสูตรอาหาร
  const canCraftMash = cornCount >= 2 && wheatCount >= 2;
  const canCraftTruffle = wheatCount >= 3 && appleCount >= 1;

  // เงื่อนไขหมูพร้อมรับอาหาร
  const isPigReadyToEat = pig?.fedAt === null || Boolean(pig?.isReady);

  // ฟังก์ชันผสมและป้อนอาหาร
  const handleCraftAndFeed = (recipeType: 'mash' | 'truffle_mix') => {
    try {
      sound.playSuccessChime();
    } catch {}
    onFeedPig(recipeType);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200 select-none"
      onClick={onClose}
    >
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-[680px] flex items-stretch filter drop-shadow-[0_25px_30px_rgba(0,0,0,0.7)]"
      >
        {/* เสาแกนไม้ซ้าย */}
        <WoodenSpindle isRight={false} />

        {/* แผ่นกระดาษม้วนโบราณ (Parchment Paper Body) */}
        <div className="flex-1 min-w-0 relative flex flex-col rounded-sm bg-gradient-to-b from-[#f8efe0] via-[#eedab9] to-[#debfa0] border-y-2 border-[#7c481e]/40 shadow-[inset_0_0_35px_rgba(100,55,18,0.32)] px-4 sm:px-6 py-3.5 text-stone-900 font-serif">
          
          {/* ขอบม้วนกระดาษโค้งมนบน-ล่าง */}
          <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-b from-[#6b3a16]/35 to-transparent pointer-events-none" />
          <div className="absolute bottom-0 inset-x-0 h-1.5 bg-gradient-to-t from-[#4a240b]/35 to-transparent pointer-events-none" />

          {/* ปุ่มปิดม้วนกระดาษ (X) */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 w-7 h-7 rounded-full bg-[#592a10]/15 hover:bg-[#592a10]/30 text-[#421d0a] flex items-center justify-center transition active:scale-90 z-20 cursor-pointer"
            title="ปิดหน้าต่าง"
          >
            <X className="w-4 h-4 stroke-[2.8]" />
          </button>

          {/* หัวเรื่องม้วนกระดาษ */}
          <div className="text-center mb-2 pr-7 pl-7">
            <h2 className="text-base sm:text-lg font-black text-[#431d09] tracking-wide inline-flex items-center gap-1.5 border-b-2 border-[#542911]/25 pb-0.5">
              📜 สารบบปศุสัตว์ชีวภาพหลวง
            </h2>
          </div>

          {/* แถบสลับหน้า (Tabs) */}
          <div className="flex items-center justify-center gap-2 mb-2.5 pb-2 border-b border-[#5a2e12]/20">
            <button
              type="button"
              onClick={() => setActiveTab('biofeed')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition cursor-pointer shadow-sm ${
                activeTab === 'biofeed'
                  ? 'bg-[#431e0b] text-[#fbf0da] shadow-inner ring-1 ring-[#97602f]'
                  : 'bg-[#5b321a]/15 text-[#431e0b] hover:bg-[#5b321a]/25'
              }`}
            >
              <Utensils className="w-3.5 h-3.5 text-amber-500" /> หน้าที่ ๑: เครื่องผสมอาหารชีวภาพ
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition cursor-pointer shadow-sm ${
                activeTab === 'profile'
                  ? 'bg-[#431e0b] text-[#fbf0da] shadow-inner ring-1 ring-[#97602f]'
                  : 'bg-[#5b321a]/15 text-[#431e0b] hover:bg-[#5b321a]/25'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-amber-500" /> หน้าที่ ๒: ทะเบียนประวัติหมู
            </button>
          </div>

          {/* ==========================================================
              หน้าที่ ๑: เครื่องผสมอาหารชีวภาพ (Biofeed)
             ========================================================== */}
          {activeTab === 'biofeed' && (
            <div className="space-y-2.5 text-xs">
              <p className="text-[11px] text-center font-semibold text-[#542911]/85 italic -mt-1">
                "ผสมโภชนาการชีวภาพสูตรตำรับหลวง เร่งการเจริญเติบโตและผลผลิตล้ำค่า"
              </p>

              {/* สูตรที่ 1: รำข้าวโพดหวานบดละเอียด */}
              <div className="flex items-center justify-between gap-2.5 p-2.5 rounded-lg bg-[#532910]/10 border border-[#6b3819]/25 shadow-sm hover:bg-[#532910]/15 transition">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-md bg-[#542911]/15 border border-[#6f3b18]/30 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
                    🌽
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-[#381706] text-xs sm:text-sm truncate">
                        รำข้าวโพดหวานบดละเอียด
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded-full font-black bg-amber-700/25 text-[#431e0b] border border-amber-800/30">
                        มาตรฐาน
                      </span>
                    </div>
                    <div className="text-[11px] text-stone-800 flex items-center gap-1 mt-0.5">
                      <span>ผลผลิต: <strong>เบคอนเกรดพรีเมียม</strong> 🥓</span>
                      <span className="text-emerald-800 font-bold">(+120🪙, +45XP)</span>
                    </div>
                    <div className="text-[10px] text-stone-700 mt-0.5">
                      วัตถุดิบ:{' '}
                      <span className={`font-semibold ${cornCount >= 2 ? 'text-emerald-800' : 'text-rose-800'}`}>
                        ข้าวโพด {cornCount}/2
                      </span>
                      {' • '}
                      <span className={`font-semibold ${wheatCount >= 2 ? 'text-emerald-800' : 'text-rose-800'}`}>
                        ข้าวสาลี {wheatCount}/2
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={!canCraftMash || !isPigReadyToEat}
                  onClick={() => handleCraftAndFeed('mash')}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black shadow transition active:scale-95 cursor-pointer ${
                    canCraftMash && isPigReadyToEat
                      ? 'bg-gradient-to-r from-[#944a1d] to-[#5a270a] text-amber-100 hover:brightness-110 border border-[#d68545]/60'
                      : 'bg-stone-500/20 text-stone-500 cursor-not-allowed border border-stone-400/30'
                  }`}
                >
                  <ChefHat className="w-3.5 h-3.5" /> ผสมและป้อน
                </button>
              </div>

              {/* สูตรที่ 2: สลัดแอปเปิ้ลหมักกลิ่นทรัฟเฟิล */}
              <div className="flex items-center justify-between gap-2.5 p-2.5 rounded-lg bg-[#532910]/10 border border-[#6b3819]/25 shadow-sm hover:bg-[#532910]/15 transition">
                <div className="flex items-center gap-2.5 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-md bg-[#542911]/15 border border-[#6f3b18]/30 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
                    🍎
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-bold text-[#381706] text-xs sm:text-sm truncate">
                        สลัดแอปเปิ้ลหมักกลิ่นทรัฟเฟิล
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded-full font-black bg-purple-700/25 text-[#42174d] border border-purple-800/30">
                        กูร์เมต์
                      </span>
                    </div>
                    <div className="text-[11px] text-stone-800 flex items-center gap-1 mt-0.5">
                      <span>ผลผลิต: <strong>เห็ดทรัฟเฟิลดำทองคำ</strong> 🍄</span>
                      <span className="text-emerald-800 font-bold">(+350🪙, +120XP)</span>
                    </div>
                    <div className="text-[10px] text-stone-700 mt-0.5">
                      วัตถุดิบ:{' '}
                      <span className={`font-semibold ${wheatCount >= 3 ? 'text-emerald-800' : 'text-rose-800'}`}>
                        ข้าวสาลี {wheatCount}/3
                      </span>
                      {' • '}
                      <span className={`font-semibold ${appleCount >= 1 ? 'text-emerald-800' : 'text-rose-800'}`}>
                        แอปเปิ้ล {appleCount}/1
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={!canCraftTruffle || !isPigReadyToEat}
                  onClick={() => handleCraftAndFeed('truffle_mix')}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-black shadow transition active:scale-95 cursor-pointer ${
                    canCraftTruffle && isPigReadyToEat
                      ? 'bg-gradient-to-r from-[#944a1d] to-[#5a270a] text-amber-100 hover:brightness-110 border border-[#d68545]/60'
                      : 'bg-stone-500/20 text-stone-500 cursor-not-allowed border border-stone-400/30'
                  }`}
                >
                  <ChefHat className="w-3.5 h-3.5" /> ผสมและป้อน
                </button>
              </div>

              {/* สถานะคำเตือนด้านล่าง */}
              <div className="flex items-center justify-between text-[11px] text-[#4d250d] pt-1 border-t border-[#5a2e12]/20 font-bold">
                <div className="flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 text-amber-900" />
                  <span>
                    {!isPigReadyToEat 
                      ? '⏳ หมูกำลังเคี้ยวเอื้องอยู่ กรุณารอรอบถัดไป' 
                      : '✨ สัตว์เลี้ยงพร้อมรับมื้ออาหารชีวภาพ'}
                  </span>
                </div>
                <span className="flex items-center gap-1 text-[#3b1c0a]">
                  <PackageCheck className="w-3.5 h-3.5 text-emerald-800" /> ระบบผสมสำเร็จรูป
                </span>
              </div>
            </div>
          )}

          {/* ==========================================================
              หน้าที่ ๒: ทะเบียนประวัติหมู (Profile)
             ========================================================== */}
          {activeTab === 'profile' && (
            <div className="space-y-2 text-xs">
              <p className="text-[11px] text-center font-semibold text-[#542911]/85 italic -mt-1">
                "ตราประทับขึ้นทะเบียนสัตว์เลี้ยงหลวงประจำปีรัชศก"
              </p>

              <div className="space-y-1.5 bg-[#532910]/08 p-2.5 rounded-lg border border-[#6b3819]/20">
                {/* รหัสประจำตัว */}
                <div className="flex items-center justify-between border-b border-[#5a2e12]/15 pb-1">
                  <span className="font-bold flex items-center gap-1 text-stone-800">
                    <Award className="w-3.5 h-3.5 text-amber-900" /> รหัสประจำตัว:
                  </span>
                  <span className="font-black text-[#381706]">
                    {pig?.name || 'น้องหมูพิกเล็ต'} ({pig?.id || 'PIG-007'})
                  </span>
                </div>

                {/* สายพันธุ์ */}
                <div className="flex items-center justify-between border-b border-[#5a2e12]/15 pb-1">
                  <span className="font-bold flex items-center gap-1 text-stone-800">
                    <Dna className="w-3.5 h-3.5 text-amber-900" /> สายพันธุ์:
                  </span>
                  <span className="font-bold text-[#5c2d12]">
                    {pig?.breed || 'สายพันธุ์เบอร์กเชียร์แท้ (Berkshire)'}
                  </span>
                </div>

                {/* น้ำหนักตัว */}
                <div className="flex items-center justify-between border-b border-[#5a2e12]/15 pb-1">
                  <span className="font-bold flex items-center gap-1 text-stone-800">
                    <Scale className="w-3.5 h-3.5 text-amber-900" /> น้ำหนักตัว:
                  </span>
                  <span className="font-black text-stone-900">
                    {pig?.weightKg ?? 84.5} กิโลกรัม
                  </span>
                </div>

                {/* สถานะความสุข */}
                <div className="flex items-center justify-between border-b border-[#5a2e12]/15 pb-1">
                  <span className="font-bold flex items-center gap-1 text-stone-800">
                    <Heart className="w-3.5 h-3.5 text-rose-700" /> สถานะความสุข:
                  </span>
                  <span className="font-bold text-emerald-800">
                    {pig?.fedAt && !pig?.isReady
                      ? 'กำลังเคี้ยวเอื้องอย่างเอร็ดอร่อย 🥣'
                      : 'อารมณ์ดี รอกินอาหารมื้อถัดไป 🌾'}
                  </span>
                </div>

                {/* รอบเวลาการผลิต */}
                <div className="flex items-center justify-between border-b border-[#5a2e12]/15 pb-1">
                  <span className="font-bold flex items-center gap-1 text-stone-800">
                    <Clock className="w-3.5 h-3.5 text-amber-900" /> รอบเวลาการผลิต:
                  </span>
                  <span className="font-bold">{pig?.durationSec ?? 30} วินาที / รอบ</span>
                </div>

                {/* ผลผลิตที่จะได้รับ */}
                <div className="flex items-center justify-between">
                  <span className="font-bold flex items-center gap-1 text-stone-800">
                    <Sparkles className="w-3.5 h-3.5 text-amber-700" /> ผลผลิตที่จะได้รับ:
                  </span>
                  <span className="font-black text-[#381706]">
                    {pig?.produceName || 'เบคอนเกรดพรีเมียม'} {pig?.produceIcon || '🥓'}
                  </span>
                </div>
              </div>

              {/* ปุ่มสลับกลับไปหน้าผสมอาหาร */}
              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => setActiveTab('biofeed')}
                  className="px-4 py-1 rounded-full bg-[#431e0b] text-[#fbf0da] text-xs font-bold hover:bg-[#5b2a0f] transition active:scale-95 cursor-pointer shadow"
                >
                  ← สลับไปหน้าผสมอาหาร
                </button>
              </div>
            </div>
          )}
        </div>

        {/* เสาแกนไม้ขวา */}
        <WoodenSpindle isRight={true} />
      </div>
    </div>
  );
};