import React, { useState, useEffect } from 'react';
import { X, Heart, Clock, Sparkles } from 'lucide-react';
import { AnimalPen, InventoryItem } from '../../../types/game';
import { sound } from '../../../utils/audio/index';
import { Chicken3D } from '../../3d/models/animals/Chicken3D';
import { Pig3D } from '../../3d/Pig3D';

interface AnimalCareModalProps {
  isOpen: boolean;
  onClose: () => void;
  animals: AnimalPen[];
  inventory: Record<string, InventoryItem>;
  onFeedAnimal: (animalId: string) => void;
  onCollectProduce: (animalId: string) => void;
  onBuildAnimalPen?: (animalType: 'chicken' | 'cow' | 'sheep') => void;
  playerLevel?: number;
  coins?: number;
}

export const AnimalCareModal: React.FC<AnimalCareModalProps> = ({
  isOpen,
  onClose,
  animals,
  inventory,
  onFeedAnimal,
  onCollectProduce,
}) => {
  const [pettingId, setPettingId] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [selected3DType, setSelected3DType] = useState<'chicken' | 'pig'>('chicken');
  const chickenPen = animals.find((a) => a.type === 'chicken');
  const pigPen = animals.find((a) => a.type === 'pig');

  useEffect(() => {
    if (!isOpen) return;
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const handlePet = (id: string, type: AnimalPen['type']) => {
    setPettingId(id);
    try {
      sound.playAnimal(type);
    } catch {
      try { sound.playClick(); } catch {}
    }
    setTimeout(() => setPettingId(null), 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-2xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <span className="text-3xl">🐾</span>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow font-['Kanit',sans-serif]">
                การดูแลสัตว์ในฟาร์ม (Livestock Care)
              </h2>
              <span className="text-xs text-amber-300">ให้อาหาร ลูบหัว และเก็บผลผลิตพรีเมียม</span>
            </div>
          </div>
          <button
            onClick={() => {
              try { sound.playClick(); } catch {}
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* สัตว์ 3D เสมือนจริงแบบ Interactive (เล้าไก่ / คอกหมู) */}
        {(chickenPen || pigPen) && (
          <div className="mt-3 shrink-0 flex flex-col items-center">
            {chickenPen && pigPen && (
              <div className="flex gap-2 mb-1">
                <button
                  type="button"
                  onClick={() => setSelected3DType('chicken')}
                  className={`px-3 py-0.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    selected3DType === 'chicken'
                      ? 'bg-amber-500 text-stone-950 shadow scale-105'
                      : 'bg-black/40 text-amber-200/70 hover:text-white'
                  }`}
                >
                  🐔 ไก่ไข่อารมณ์ดี
                </button>
                <button
                  type="button"
                  onClick={() => setSelected3DType('pig')}
                  className={`px-3 py-0.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    selected3DType === 'pig'
                      ? 'bg-pink-500 text-white shadow scale-105'
                      : 'bg-black/40 text-amber-200/70 hover:text-white'
                  }`}
                >
                  🐷 หมูคุ้ยทรัฟเฟิล
                </button>
              </div>
            )}

            {selected3DType === 'chicken' && chickenPen ? (
              <Chicken3D
                readyProduce={chickenPen.isReady ? chickenPen.produceQuantity : 0}
                isFed={!!chickenPen.fedAt && !chickenPen.isReady}
                onFeed={() => {
                  const feedItem = inventory[chickenPen.feedCropId];
                  if ((feedItem?.count || 0) >= chickenPen.feedRequired) {
                    onFeedAnimal(chickenPen.id);
                  } else {
                    try { sound.playClick(); } catch {}
                  }
                }}
                onCollectEggs={() => onCollectProduce(chickenPen.id)}
              />
            ) : pigPen ? (
              <div className="flex justify-center w-full py-1">
                <Pig3D
                  readyProduce={pigPen.isReady ? pigPen.produceQuantity : 0}
                  isFed={!!pigPen.fedAt && !pigPen.isReady}
                  onFeed={() => {
                    const feedItem = inventory[pigPen.feedCropId];
                    if ((feedItem?.count || 0) >= pigPen.feedRequired) {
                      onFeedAnimal(pigPen.id);
                    } else {
                      try { sound.playClick(); } catch {}
                    }
                  }}
                  onCollectProduce={() => onCollectProduce(pigPen.id)}
                />
              </div>
            ) : null}
          </div>
        )}

        {/* Grid แสดงคอกสัตว์ */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {animals
            .filter((pen, idx, arr) => arr.findIndex((p) => p.id === pen.id) === idx)
            .map((pen, penIndex) => {
              const feedItem = inventory[pen.feedCropId];
              const haveFeed = (feedItem?.count || 0) >= pen.feedRequired;

              let remainingSec = 0;
              if (pen.fedAt && !pen.isReady) {
                const elapsed = (currentTime - pen.fedAt) / 1000;
                remainingSec = Math.max(0, Math.ceil(pen.durationSec - elapsed));
              }

              return (
                <div
                  key={`${pen.id}_${penIndex}`}
                className="bg-stone-900/85 rounded-2xl p-3 border-2 border-amber-900/80 flex flex-col justify-between hover:border-amber-500 transition-colors"
              >
                {/* Pen Header */}
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <div className="flex items-center gap-2">
                    <span className="text-3xl animate-bounce-gentle">{pen.icon}</span>
                    <div>
                      <h3 className="font-extrabold text-sm text-amber-100">{pen.thaiName}</h3>
                      <span className="text-[11px] text-stone-400">
                        จำนวน: {pen.count} ตัว · ให้ {pen.produceName}
                      </span>
                    </div>
                  </div>

                  {/* Pet Button */}
                  <button
                    onClick={() => handlePet(pen.id, pen.type)}
                    className="p-1.5 rounded-full bg-pink-900/60 hover:bg-pink-800 text-pink-300 border border-pink-700 active:scale-90 transition-all relative cursor-pointer"
                    title="ลูบหัวสัตว์เพื่อเพิ่มความสุข"
                  >
                    <Heart className="w-4 h-4 fill-pink-400 text-pink-400" />
                    {pettingId === pen.id && (
                      <span className="absolute -top-4 -left-2 text-base animate-bounce">💖</span>
                    )}
                  </button>
                </div>

                {/* State & Produce Info */}
                <div className="my-2.5 bg-stone-950/60 rounded-xl p-2.5 border border-stone-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{pen.produceIcon}</span>
                    <div className="text-xs">
                      <div className="font-bold text-amber-200">
                        {pen.produceQuantity}x {pen.produceName}
                      </div>
                      <div className="text-stone-400 text-[10px]">
                        อาหาร: {pen.feedRequired} {feedItem?.thaiName || pen.feedCropId}
                      </div>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  {pen.isReady ? (
                    <span className="bg-emerald-500/20 text-emerald-400 font-extrabold text-xs px-2 py-0.5 rounded-full border border-emerald-500/40 animate-pulse">
                      พร้อมเก็บ!
                    </span>
                  ) : pen.fedAt ? (
                    <span className="text-yellow-400 font-mono text-xs flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {remainingSec} วิ
                    </span>
                  ) : (
                    <span className="text-stone-500 text-xs">หิวข้าว</span>
                  )}
                </div>

                {/* Actions: Feed or Collect */}
                <div className="flex items-center gap-2">
                  {pen.isReady ? (
                    <button
                      onClick={() => {
                        try { sound.playHarvest(); } catch {}
                        onCollectProduce(pen.id);
                      }}
                      className="w-full py-2.5 game-btn-green rounded-xl text-white font-black text-xs flex items-center justify-center gap-1 shadow hover:brightness-110 active:scale-95 cursor-pointer"
                    >
                      <span>เก็บผลผลิต {pen.produceIcon} (+{pen.produceQuantity})</span>
                    </button>
                  ) : pen.fedAt ? (
                    <div className="w-full py-2 text-center text-xs text-stone-400 font-medium bg-stone-800 rounded-xl border border-stone-700/60">
                      สัตว์กำลังกินอาหาร... ({remainingSec}s)
                    </div>
                  ) : (
                    <button
                      disabled={!haveFeed}
                      onClick={() => {
                        try {
                          sound.playAnimal(pen.type);
                        } catch {}
                        onFeedAnimal(pen.id);
                      }}
                      className={`w-full py-2.5 rounded-xl font-black text-xs shadow flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        haveFeed
                          ? 'game-btn-yellow text-stone-900 hover:brightness-110 active:scale-95'
                          : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                      }`}
                    >
                      <span>ให้อาหาร ({feedItem?.count || 0}/{pen.feedRequired})</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};