export { IsometricPig3D, type PigEntity, type IsometricPig3DProps } from '../../3d/models/animals/IsometricPig3D';
export { default } from '../../3d/models/animals/IsometricPig3D';
