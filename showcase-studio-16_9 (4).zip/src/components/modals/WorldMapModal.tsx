// src/components/modals/WorldMapModal.tsx
import React from 'react';
import { X, MapPin, Navigation, Lock } from 'lucide-react';
import { WORLD_ZONES, WorldZone, switchFarmMap } from '../../data/worldMapData';

export interface WorldMapModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerLevel: number;
  currentFarmId?: string;
  onSwitchFarm?: (farmId: 'farm1' | 'farm2') => void;
  onTravelTo?: (actionId: string, zoneName: string) => void;
}

export const WorldMapModal: React.FC<WorldMapModalProps> = ({
  isOpen,
  onClose,
  playerLevel,
  currentFarmId = 'farm1',
  onSwitchFarm,
  onTravelTo,
}) => {
  if (!isOpen) return null;

  // 🚀 ระบบจัดการการเดินทาง (สลับฟาร์มได้ทันทีในตัว โดยไม่ต้องโหลดหน้าใหม่)
  const handleTravelClick = (zone: WorldZone) => {
    if (zone.actionId === 'SWITCH_TO_FARM_1') {
      if (onSwitchFarm) {
        onSwitchFarm('farm1');
      } else {
        switchFarmMap('farm1');
      }
      onClose();
      return;
    }
    if (zone.actionId === 'SWITCH_TO_FARM_2') {
      if (onSwitchFarm) {
        onSwitchFarm('farm2');
      } else {
        switchFarmMap('farm2');
      }
      onClose();
      return;
    }
    if (zone.actionId === 'CLOSE_MAP') {
      onClose();
      return;
    }
    if (zone.actionId === 'COMING_SOON') {
      alert(`🚧 ${zone.name} กำลังอยู่ในช่วงก่อสร้าง ขยายเมืองเร็วๆ นี้!`);
      return;
    }

    // หากมี callback ส่งต่อระบบภายนอก (เช่น เปิดหน้าต่างตลาด, ตกปลา)
    if (onTravelTo) {
      onTravelTo(zone.actionId, zone.name);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs animate-fade-in">
      {/* กรอบหน้าต่างไม้คันทรี่ */}
      <div className="relative w-full max-w-3xl bg-[#3e2110] border-4 border-[#8B5A2B] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90dvh]">
        
        {/* แถบหัวข้อด้านบน */}
        <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-[#5a3219] to-[#3a1d0d] border-b-2 border-[#8B5A2B]/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-cyan-600 border-2 border-white/40 flex items-center justify-center shadow">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-amber-100 tracking-wide font-['Kanit']">
                แผนที่โลกและอาณาเขต (World Map)
              </h2>
              <p className="text-xs text-amber-200/80 font-['Kanit']">
                เดินทางสู่สถานที่สำคัญเพื่อทำกิจกรรมและสำรวจพื้นที่ใหม่
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-red-600 hover:bg-red-500 border border-red-300 text-white flex items-center justify-center transition shadow cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ตารางแสดงเมืองและพื้นที่ขยาย (Grid Responsive) */}
        <div className="p-3 sm:p-4 overflow-y-auto game-scroll grid grid-cols-1 sm:grid-cols-2 gap-3">
          {WORLD_ZONES.map((zone) => {
            const isLocked = playerLevel < zone.minLevel;
            const isCurrentZone =
              (zone.id === 'beam_farm' && currentFarmId === 'farm1') ||
              (zone.id === 'beam_farm_2' && currentFarmId === 'farm2') ||
              (!['beam_farm', 'beam_farm_2'].includes(zone.id) && !!zone.isCurrent);

            return (
              <div
                key={zone.id}
                className={`relative flex flex-col justify-between p-3 rounded-xl border-2 transition-all ${
                  isCurrentZone
                    ? 'bg-amber-950/70 border-amber-400 shadow-amber-950/50 ring-1 ring-amber-400/40'
                    : isLocked
                    ? 'bg-black/40 border-stone-700/60 opacity-70'
                    : 'bg-[#2a160b] border-amber-800/80 hover:border-amber-400/80 shadow-md'
                }`}
              >
                {/* ข้อมูลด้านบน */}
                <div className="flex items-start gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0 border border-white/10 ${
                      zone.iconBgColor || 'bg-amber-900/60'
                    }`}
                  >
                    {zone.iconEmoji}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="text-sm sm:text-base font-bold text-amber-100 truncate font-['Kanit']">
                        {zone.name}
                      </h3>
                      {isCurrentZone && (
                        <span className="text-[10px] bg-amber-400 text-stone-900 font-bold px-1.5 py-0.2 rounded-full">
                          คุณอยู่ที่นี่
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-amber-300/70 block">({zone.nameEn})</span>
                    <p className="text-xs text-stone-300/90 mt-1 line-clamp-2 font-['Kanit'] leading-relaxed">
                      {zone.description}
                    </p>
                  </div>
                </div>

                {/* แถบด้านล่าง: ป้ายสถานะ & ปุ่มเดินทาง */}
                <div className="mt-3 pt-2 border-t border-amber-900/40 flex items-center justify-between gap-2">
                  {/* แสดงสถานะ / Badge / เลเวลที่ปลด */}
                  <div>
                    {isCurrentZone ? (
                      <span className="text-xs font-bold text-emerald-400">ปัจจุบัน</span>
                    ) : isLocked ? (
                      <div className="flex items-center gap-1 text-xs text-stone-400 font-bold">
                        <Lock className="w-3.5 h-3.5 text-amber-500" />
                        <span>เปิดที่ Lv. {zone.minLevel}</span>
                      </div>
                    ) : zone.badge ? (
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                          zone.badgeColor === 'cyan'
                            ? 'bg-cyan-900/60 border-cyan-400 text-cyan-200'
                            : zone.badgeColor === 'purple'
                            ? 'bg-purple-900/60 border-purple-400 text-purple-200'
                            : zone.badgeColor === 'amber'
                            ? 'bg-amber-900/60 border-amber-400 text-amber-200'
                            : 'bg-emerald-900/60 border-emerald-400 text-emerald-200'
                        }`}
                      >
                        {zone.badge}
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-emerald-400">เปิดบริการ</span>
                    )}
                  </div>

                  {/* ปุ่มกดเดินทาง */}
                  {!isCurrentZone && (
                    <button
                      disabled={isLocked}
                      onClick={() => handleTravelClick(zone)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition shadow cursor-pointer ${
                        isLocked
                          ? 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-300 active:scale-95'
                      }`}
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>เดินทาง</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};