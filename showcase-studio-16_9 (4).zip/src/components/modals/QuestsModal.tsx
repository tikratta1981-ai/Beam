import React from 'react';
import { X, ClipboardList, CheckCircle, Coins, Sparkles } from 'lucide-react';
import { Quest } from '../../types/game';
import { sound } from '../../utils/audio';
import confetti from 'canvas-confetti';

interface QuestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  quests: Quest[];
  onClaimQuest: (questId: string) => void;
}

export const QuestsModal: React.FC<QuestsModalProps> = ({
  isOpen,
  onClose,
  quests,
  onClaimQuest,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-600 flex items-center justify-center text-white shadow">
              <ClipboardList className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                ภารกิจชาวไร่ (Quests & Missions)
              </h2>
              <span className="text-xs text-amber-300">
                ทำภารกิจรายวันเพื่อรับเงินรางวัล เพชร และเลเวลอัป!
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quests List */}
        <div className="flex flex-col gap-3 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {quests.map((quest) => {
            const isFinished = quest.current >= quest.target;
            const progressPercent = Math.min(100, Math.round((quest.current / quest.target) * 100));

            return (
              <div
                key={quest.id}
                className={`p-3.5 rounded-2xl border-2 flex flex-col gap-2 transition-all ${
                  quest.claimed
                    ? 'bg-stone-900/40 border-stone-800 opacity-60'
                    : isFinished
                    ? 'bg-gradient-to-r from-amber-950/80 to-emerald-950/80 border-yellow-400 shadow-md'
                    : 'bg-stone-900/70 border-amber-900/80'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      {quest.type === 'fish' && (
                        <span className="text-sm bg-cyan-950 border border-cyan-500/50 p-1 rounded-lg">🎣</span>
                      )}
                      <span className="font-extrabold text-sm text-amber-100">
                        {quest.thaiTitle}
                      </span>
                      {quest.claimed && (
                        <span className="bg-stone-800 text-stone-400 text-[10px] px-2 py-0.5 rounded-full">
                          รับแล้ว
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-stone-300 mt-0.5">{quest.description}</p>
                  </div>

                  {/* Rewards preview */}
                  <div className="flex items-center gap-2 text-xs bg-stone-950/60 px-2 py-1 rounded-xl border border-stone-800">
                    <span className="flex items-center gap-0.5 text-yellow-300 font-bold">
                      <Coins className="w-3 h-3" />
                      +{quest.rewardCoins}
                    </span>
                    <span className="flex items-center gap-0.5 text-blue-300 font-bold">
                      <Sparkles className="w-3 h-3" />
                      +{quest.rewardXp} XP
                    </span>
                    {quest.rewardGems > 0 && (
                      <span className="text-cyan-300 font-bold">+{quest.rewardGems}💎</span>
                    )}
                  </div>
                </div>

                {/* Progress bar & Claim button */}
                <div className="flex items-center justify-between gap-3 mt-1">
                  <div className="flex-1">
                    <div className="flex justify-between text-[11px] text-stone-300 mb-1">
                      <span>ความคืบหน้า</span>
                      <span className="font-mono font-bold text-amber-300">
                        {quest.current} / {quest.target}
                      </span>
                    </div>
                    <div className="h-2 w-full bg-stone-800 rounded-full overflow-hidden border border-stone-700">
                      <div
                        className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full transition-all duration-500"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Claim Button */}
                  {!quest.claimed && (
                    <button
                      disabled={!isFinished}
                      onClick={() => {
                        sound.playLevelUp();
                        try {
                          confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
                        } catch {}
                        onClaimQuest(quest.id);
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-black shadow transition-all whitespace-nowrap ${
                        isFinished
                          ? 'game-btn-yellow text-stone-900 hover:brightness-110 active:scale-95 animate-gentle-pulse'
                          : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                      }`}
                    >
                      {isFinished ? 'รับรางวัล! 🎁' : 'ยังไม่สำเร็จ'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
