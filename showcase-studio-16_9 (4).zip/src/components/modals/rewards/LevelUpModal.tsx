import React, { useEffect } from 'react';
import { Sparkles, Trophy, Coins } from 'lucide-react';
import { sound } from '../../../utils/audio/index';
import confetti from 'canvas-confetti';

interface LevelUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  newLevel: number;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({ isOpen, onClose, newLevel }) => {
  useEffect(() => {
    if (isOpen) {
      sound.playLevelUp();
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
        });
      } catch {}
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md game-wood-board rounded-3xl p-6 shadow-2xl border-4 border-yellow-400 text-white flex flex-col items-center text-center">
        {/* Glowing badge */}
        <div className="relative mb-3">
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-yellow-400 to-amber-600 flex items-center justify-center border-4 border-white shadow-2xl animate-gentle-bounce text-5xl">
            🏆
          </div>
          <div className="absolute -bottom-2 inset-x-0 mx-auto w-max px-3 py-0.5 bg-red-600 border border-white rounded-full text-xs font-black text-white shadow">
            LEVEL UP!
          </div>
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-yellow-300 drop-shadow mt-2">
          ยินดีด้วย! ฟาร์มเลเวล {newLevel}
        </h2>
        <p className="text-xs text-amber-200 mt-1">
          คุณพัฒนาฟาร์มได้อย่างยอดเยี่ยม ได้รับรางวัลตอบแทนชาวไร่คนเก่ง!
        </p>

        {/* Unlocked rewards list */}
        <div className="w-full my-4 bg-stone-900/80 rounded-2xl p-3 border border-amber-600/60 flex flex-col gap-2">
          <div className="text-xs font-bold text-stone-300 text-left">รางวัลที่ได้รับ:</div>
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-stone-950 p-2 rounded-xl border border-stone-800 flex flex-col items-center">
              <span className="text-xl">🪙</span>
              <span className="font-black text-yellow-300">+2,500</span>
              <span className="text-[10px] text-stone-400">เหรียญทอง</span>
            </div>
            <div className="bg-stone-950 p-2 rounded-xl border border-stone-800 flex flex-col items-center">
              <span className="text-xl">💎</span>
              <span className="font-black text-cyan-300">+15</span>
              <span className="text-[10px] text-stone-400">เพชรล้ำค่า</span>
            </div>
            <div className="bg-stone-950 p-2 rounded-xl border border-stone-800 flex flex-col items-center">
              <span className="text-xl">⚡</span>
              <span className="font-black text-emerald-300">เต็มพิกัด</span>
              <span className="text-[10px] text-stone-400">เติมพลังงาน</span>
            </div>
          </div>
        </div>

        {/* Claim & Continue button */}
        <button
          onClick={() => {
            sound.playCoin();
            onClose();
          }}
          className="w-full py-3 game-btn-yellow rounded-2xl text-stone-900 font-black text-sm shadow-xl hover:brightness-110 active:scale-95 transition-all"
        >
          รับรางวัลและกลับสู่ฟาร์ม 🌾
        </button>
      </div>
    </div>
  );
};
