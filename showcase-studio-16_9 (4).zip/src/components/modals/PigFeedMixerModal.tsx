// src/components/modals/PigFeedMixerModal.tsx

import React from 'react';
import { X, Sparkles, ChefHat, Check, AlertCircle } from 'lucide-react';
import { InventoryItem } from '../../types/game';
import { sound } from '../../utils/audio';

export interface PigFeedMixerModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory?: Record<string, InventoryItem>;
  onFeedPig: (recipeType: 'mash' | 'truffle_mix') => void;
}

export const PigFeedMixerModal: React.FC<PigFeedMixerModalProps> = ({
  isOpen,
  onClose,
  inventory = {},
  onFeedPig,
}) => {
  if (!isOpen) return null;

  // ตรวจสอบจำนวนวัตถุดิบในคลัง พร้อม Fallback ป้องกัน Crash 100%
  const wheatCount = Number(inventory?.['wheat']?.count ?? 0);
  const cornCount = Number(inventory?.['corn']?.count ?? 0);
  const appleCount = Number(inventory?.['apple']?.count ?? 0);

  // ความต้องการของแต่ละสูตร
  const reqMash = { corn: 2, wheat: 2 };
  const reqTruffle = { wheat: 3, apple: 1 };

  const canCraftMash = cornCount >= reqMash.corn && wheatCount >= reqMash.wheat;
  const canCraftTruffle = wheatCount >= reqTruffle.wheat && appleCount >= reqTruffle.apple;

  const handleCraftAndFeed = (recipeType: 'mash' | 'truffle_mix') => {
    try {
      if (sound.playSuccessChime) {
        sound.playSuccessChime();
      } else {
        sound.playClick?.();
      }
    } catch {}
    onFeedPig(recipeType);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200 select-none font-['Kanit',sans-serif]"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md bg-stone-900/95 border-2 border-pink-400/80 rounded-3xl p-5 sm:p-6 shadow-[0_10px_35px_rgba(244,114,182,0.25)] text-stone-100"
      >
        {/* แถบหัวข้อ Modal */}
        <div className="flex items-center justify-between border-b border-pink-500/30 pb-3.5 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-pink-500/30 to-rose-600/30 border border-pink-400 flex items-center justify-center text-2xl shadow-inner">
              🥣
            </div>
            <div>
              <h2 className="text-lg font-black text-pink-300 tracking-wide flex items-center gap-1.5">
                <span>เครื่องผสมอาหารหมูชีวภาพ</span>
                <span className="text-[10px] bg-pink-950 text-pink-300 border border-pink-500/60 px-2 py-0.5 rounded-full font-normal">
                  Bio-Feed
                </span>
              </h2>
              <p className="text-[11px] text-pink-200/70">
                ผสมโภชนาการเข้มข้น เร่งการเจริญเติบโตและผลผลิตเกรดพรีเมียม
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              try { sound.playClick(); } catch {}
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center cursor-pointer transition-colors active:scale-95"
            aria-label="ปิดหน้าต่าง"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* รายการสูตรการผสมอาหาร */}
        <div className="space-y-3.5">
          {/* สูตร 1: รำข้าวโพดหวานบดละเอียด */}
          <div
            className={`rounded-2xl p-4 border transition-all ${
              canCraftMash
                ? 'bg-stone-800/90 border-amber-500/50 hover:border-amber-400 shadow-md'
                : 'bg-stone-800/40 border-stone-700/60 opacity-80'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-amber-200">รำข้าวโพดหวานบดละเอียด</span>
                  <span className="text-[10px] bg-amber-950/80 text-amber-300 border border-amber-600/70 px-1.5 py-0.2 rounded-full font-medium">
                    มาตรฐาน
                  </span>
                </div>
                <div className="text-xs text-stone-300 mt-1 flex items-center gap-1">
                  <span>ผลผลิต:</span>
                  <span className="font-bold text-amber-300">เบคอนเกรดพรีเมียม 🥓</span>
                  <span className="text-[11px] text-stone-400">(+120🪙, +45XP)</span>
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-2xl">
                🌽
              </div>
            </div>

            <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-stone-700/70">
              <div className="text-xs text-stone-300 flex items-center gap-2">
                <span className="text-stone-400">ใช้วัตถุดิบ:</span>
                <span className={cornCount >= reqMash.corn ? 'text-emerald-400 font-bold' : 'text-rose-400 font-medium'}>
                  ข้าวโพด {reqMash.corn}/{cornCount}
                </span>
                <span>•</span>
                <span className={wheatCount >= reqMash.wheat ? 'text-emerald-400 font-bold' : 'text-rose-400 font-medium'}>
                  ข้าวสาลี {reqMash.wheat}/{wheatCount}
                </span>
              </div>

              <button
                disabled={!canCraftMash}
                onClick={() => handleCraftAndFeed('mash')}
                className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all active:scale-95 ${
                  canCraftMash
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-stone-950 cursor-pointer shadow-amber-500/20'
                    : 'bg-stone-700 text-stone-500 cursor-not-allowed'
                }`}
              >
                <ChefHat className="w-3.5 h-3.5" />
                <span>ผสมและป้อน</span>
              </button>
            </div>
          </div>

          {/* สูตร 2: สลัดแอปเปิ้ลหมักกลิ่นทรัฟเฟิล */}
          <div
            className={`rounded-2xl p-4 border transition-all ${
              canCraftTruffle
                ? 'bg-stone-800/90 border-purple-500/50 hover:border-purple-400 shadow-md'
                : 'bg-stone-800/40 border-stone-700/60 opacity-80'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-purple-200">สลัดแอปเปิ้ลหมักกลิ่นทรัฟเฟิล</span>
                  <span className="text-[10px] bg-purple-950/80 text-purple-300 border border-purple-500/70 px-1.5 py-0.2 rounded-full font-medium">
                    กูร์เมต์
                  </span>
                </div>
                <div className="text-xs text-stone-300 mt-1 flex items-center gap-1">
                  <span>ผลผลิต:</span>
                  <span className="font-bold text-purple-300">เห็ดทรัฟเฟิลดำทองคำ 🍄✨</span>
                  <span className="text-[11px] text-stone-400">(+350🪙, +120XP)</span>
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-2xl">
                🍄
              </div>
            </div>

            <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-stone-700/70">
              <div className="text-xs text-stone-300 flex items-center gap-2">
                <span className="text-stone-400">ใช้วัตถุดิบ:</span>
                <span className={wheatCount >= reqTruffle.wheat ? 'text-emerald-400 font-bold' : 'text-rose-400 font-medium'}>
                  ข้าวสาลี {reqTruffle.wheat}/{wheatCount}
                </span>
                <span>•</span>
                <span className={appleCount >= reqTruffle.apple ? 'text-emerald-400 font-bold' : 'text-rose-400 font-medium'}>
                  แอปเปิ้ล {reqTruffle.apple}/{appleCount}
                </span>
              </div>

              <button
                disabled={!canCraftTruffle}
                onClick={() => handleCraftAndFeed('truffle_mix')}
                className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-lg transition-all active:scale-95 ${
                  canCraftTruffle
                    ? 'bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 hover:brightness-110 text-white cursor-pointer shadow-purple-500/20'
                    : 'bg-stone-700 text-stone-500 cursor-not-allowed'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>ผสมและป้อน</span>
              </button>
            </div>
          </div>
        </div>

        {/* แถบคำแนะนำด้านล่าง */}
        <div className="mt-4 pt-3 border-t border-stone-800 flex items-center justify-between text-[11px] text-stone-400">
          <div className="flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 text-pink-400" />
            <span>อาหารช่วยให้หมูย่อยและผลิตผลผลิตได้ไวขึ้น</span>
          </div>
          <span className="text-pink-300/80 font-mono">🐷 Smart Porcine</span>
        </div>
      </div>
    </div>
  );
};