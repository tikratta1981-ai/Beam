import React from 'react';
import { X, Sparkles, Heart, Award } from 'lucide-react';
import { sound } from '../../../utils/audio/index';

interface LogoInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  farmName: string;
}

export const LogoInfoModal: React.FC<LogoInfoModalProps> = ({ isOpen, onClose, farmName }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md game-wood-board rounded-3xl p-6 shadow-2xl border-4 border-amber-500/80 text-white flex flex-col items-center text-center">
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-yellow-300 via-amber-400 to-orange-500 flex items-center justify-center text-5xl border-4 border-white shadow-xl mb-3">
          🐮
        </div>

        <h2 className="text-2xl font-black text-amber-200 drop-shadow">{farmName}</h2>
        <span className="text-xs font-bold text-emerald-300 mt-1">
          "ปลูกวันนี้... สร้างอนาคตที่ดีกว่า" 🌱
        </span>

        <p className="text-xs text-stone-300 my-4 leading-relaxed bg-stone-900/70 p-3.5 rounded-2xl border border-stone-800">
          ยินดีต้อนรับสู่โลกของ <strong>Beam Farm (B.P.)</strong> ต้นแบบเกมจำลองฟาร์มแสนสุข
          ที่ผสานเสน่ห์ของการทำเกษตรอินทรีย์ การแปรรูปสินค้าคุณภาพสูง
          และการแบ่งปันความสุขให้กับเพื่อนบ้านในชุมชนชนบทอันแสนอบอุ่น
        </p>

        <div className="w-full grid grid-cols-2 gap-2 text-xs mb-4">
          <div className="bg-stone-950 p-2.5 rounded-xl border border-stone-800 flex flex-col items-center">
            <span className="text-xl">🌾</span>
            <span className="font-bold text-amber-200 mt-1">เกษตรอินทรีย์</span>
            <span className="text-[10px] text-stone-400">พืชผลหลากหลาย</span>
          </div>
          <div className="bg-stone-950 p-2.5 rounded-xl border border-stone-800 flex flex-col items-center">
            <span className="text-xl">🤝</span>
            <span className="font-bold text-emerald-300 mt-1">ชุมชนเพื่อนบ้าน</span>
            <span className="text-[10px] text-stone-400">ช่วยเหลือ & ส่งของขวัญ</span>
          </div>
        </div>

        <button
          onClick={() => {
            sound.playSuccessChime();
            onClose();
          }}
          className="w-full py-2.5 game-btn-yellow rounded-xl text-stone-900 font-black text-xs shadow-lg active:scale-95"
        >
          กลับสู่การดูแลฟาร์ม ✨
        </button>
      </div>
    </div>
  );
};
