// src/components/modals/AuthModal.tsx

import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  User,
  LogOut,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  Cloud,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { sound } from '../../../utils/audio/index';
import { UserProfile, AuthProvider } from '../../../types/auth';
import {
  loginWithGoogle,
  loginWithFacebook,
  loginAsGuest,
  logoutUser,
  getKnownAccounts,
  isValidEmail,
} from '../../../utils/auth';
import { sanitizeText } from '../../../security';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onLoginSuccess: (user: UserProfile) => void;
  onLogout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  onLogout,
}) => {
  const [googleEmail, setGoogleEmail] = useState<string>('tommegood641@gmail.com');
  const [googleName, setGoogleName] = useState<string>('Farmer Tom');
  const [facebookName, setFacebookName] = useState<string>('Farmer Beam');
  const [activeTab, setActiveTab] = useState<'quick' | 'custom_google' | 'custom_fb'>('quick');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const knownAccounts = getKnownAccounts();

  const handleGoogleLogin = async (customEmail?: string, customName?: string) => {
    sound.playClick();
    const targetEmail = (customEmail || googleEmail).trim();
    const targetName = (customName || googleName).trim();

    if (!isValidEmail(targetEmail)) {
      setStatusMessage('กรุณากรอกอีเมล Gmail ให้ถูกต้อง (เช่น user@gmail.com)');
      return;
    }

    setIsLoading(true);
    setStatusMessage('กำลังเชื่อมต่อระบบ Google Account...');

    setTimeout(async () => {
      try {
        const user = await loginWithGoogle(
          sanitizeText(targetEmail, 100),
          sanitizeText(targetName, 40)
        );
        sound.playSuccessChime();
        setStatusMessage('เข้าสู่ระบบสำเร็จ! กำลังโหลดฟาร์ม...');
        setTimeout(() => {
          setIsLoading(false);
          setStatusMessage(null);
          onLoginSuccess(user);
          onClose();
        }, 600);
      } catch (err: any) {
        setIsLoading(false);
        setStatusMessage(`เกิดข้อผิดพลาด: ${err?.message || 'ไม่สามารถเข้าสู่ระบบได้'}`);
      }
    }, 500);
  };

  const handleFacebookLogin = async (customName?: string) => {
    sound.playClick();
    const targetName = (customName || facebookName).trim();
    if (!targetName) {
      setStatusMessage('กรุณาระบุชื่อโปรไฟล์ Facebook');
      return;
    }

    setIsLoading(true);
    setStatusMessage('กำลังเชื่อมต่อระบบ Facebook...');

    setTimeout(async () => {
      try {
        const user = await loginWithFacebook(sanitizeText(targetName, 40));
        sound.playSuccessChime();
        setStatusMessage('เข้าสู่ระบบสำเร็จ! กำลังโหลดฟาร์ม...');
        setTimeout(() => {
          setIsLoading(false);
          setStatusMessage(null);
          onLoginSuccess(user);
          onClose();
        }, 600);
      } catch (err: any) {
        setIsLoading(false);
        setStatusMessage(`เกิดข้อผิดพลาด: ${err?.message || 'ไม่สามารถเข้าสู่ระบบได้'}`);
      }
    }, 500);
  };

  const handleGuestLogin = () => {
    sound.playClick();
    const guestUser = loginAsGuest();
    onLoginSuccess(guestUser);
    onClose();
  };

  const handleSwitchAccount = () => {
    sound.playClick();
    onLogout();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/90 text-white flex flex-col max-h-[92dvh] overflow-y-auto game-scroll">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-stone-900 shadow-md">
              <User className="w-6 h-6 text-stone-950 font-bold" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                เข้าสู่ระบบสมาชิกฟาร์ม
              </h2>
              <span className="text-[11px] text-amber-300/90">
                Farm Account & Cloud Sync
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current User Status Banner (เมื่อล็อกอินอยู่แล้ว) */}
        {currentUser && currentUser.provider !== 'guest' ? (
          <div className="my-4 flex flex-col gap-3">
            <div className="bg-stone-900/90 border-2 border-emerald-500/70 rounded-2xl p-3.5 flex items-center gap-3 shadow-lg">
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-emerald-400 bg-stone-800 flex items-center justify-center flex-shrink-0">
                {currentUser.provider === 'google' ? (
                  <span className="text-2xl font-bold text-red-400">G</span>
                ) : (
                  <span className="text-2xl font-bold text-blue-400">f</span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-black text-amber-100 truncate">
                    {currentUser.displayName}
                  </span>
                  <span className="text-[10px] bg-emerald-700/80 text-emerald-200 px-1.5 py-0.5 rounded-full font-bold">
                    {currentUser.provider === 'google' ? 'Google' : 'Facebook'}
                  </span>
                </div>
                <div className="text-xs text-stone-400 truncate">{currentUser.email}</div>
                <div className="flex items-center gap-1 text-[11px] text-emerald-300 mt-1 font-medium">
                  <Cloud className="w-3.5 h-3.5" />
                  <span>เซฟฟาร์มผูกกับบัญชีนี้แล้ว (Cloud Active)</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white font-bold text-sm shadow-md active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>เล่นต่อด้วยบัญชีนี้</span>
            </button>

            <button
              onClick={handleSwitchAccount}
              className="w-full py-2 rounded-xl bg-stone-800/80 hover:bg-stone-700 border border-stone-600 text-stone-200 font-bold text-xs active:scale-95 transition-all flex items-center justify-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5 text-amber-400" />
              <span>สลับบัญชี หรือเข้าสู่ระบบใหม่</span>
            </button>
          </div>
        ) : (
          /* Login Selection Section */
          <div className="my-3 flex flex-col gap-3">
            {/* Value Proposition */}
            <div className="bg-amber-950/60 border border-amber-500/40 rounded-2xl p-2.5 sm:p-3 text-xs text-amber-100 flex items-start gap-2 leading-relaxed">
              <Sparkles className="w-4 h-4 text-amber-300 mt-0.5 flex-shrink-0" />
              <div>
                <strong className="text-amber-300 block mb-0.5">ผูกบัญชีเพื่อปกป้องฟาร์มของคุณ:</strong>
                ล็อกอินด้วย Gmail หรือ Facebook เพื่อเล่นข้ามเครื่อง สลับโทรศัพท์ได้ทุกเมื่อ ฟาร์มไม่หาย 100%!
              </div>
            </div>

            {/* Quick Login Options */}
            {activeTab === 'quick' && (
              <div className="flex flex-col gap-2.5">
                {/* 1. Google (Gmail) One-Click Login Button */}
                <button
                  onClick={() => handleGoogleLogin()}
                  disabled={isLoading}
                  className="w-full relative group flex items-center justify-between p-3 rounded-2xl bg-white hover:bg-stone-100 text-stone-800 shadow-xl border-2 border-stone-200 active:scale-95 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    {/* Official Google G Logo SVG */}
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm border border-stone-100 flex-shrink-0">
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                        />
                      </svg>
                    </div>
                    <div className="text-left leading-tight">
                      <div className="text-sm font-black text-stone-900 flex items-center gap-1.5">
                        เข้าสู่ระบบด้วย Google (Gmail)
                        <span className="text-[9px] bg-red-100 text-red-600 px-1.5 py-0.2 rounded font-bold">
                          แนะนำ
                        </span>
                      </div>
                      <div className="text-[11px] text-stone-600">
                        {googleEmail} (One-Click)
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-stone-400 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* 2. Facebook One-Click Login Button */}
                <button
                  onClick={() => handleFacebookLogin()}
                  disabled={isLoading}
                  className="w-full relative group flex items-center justify-between p-3 rounded-2xl bg-[#1877F2] hover:bg-[#166fe5] text-white shadow-xl border border-blue-400/50 active:scale-95 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm flex-shrink-0">
                      <svg className="w-5 h-5 fill-[#1877F2]" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                    </div>
                    <div className="text-left leading-tight">
                      <div className="text-sm font-black text-white">
                        เข้าสู่ระบบด้วย Facebook
                      </div>
                      <div className="text-[11px] text-blue-100">
                        {facebookName}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-blue-200 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* Switch to Custom Email Input toggle */}
                <div className="flex justify-between items-center px-1 text-xs text-stone-400">
                  <button
                    onClick={() => setActiveTab('custom_google')}
                    className="hover:text-amber-300 underline underline-offset-2 transition-colors cursor-pointer"
                  >
                    ระบุอีเมล Gmail อื่น
                  </button>
                  <button
                    onClick={() => setActiveTab('custom_fb')}
                    className="hover:text-blue-300 underline underline-offset-2 transition-colors cursor-pointer"
                  >
                    ระบุชื่อ Facebook อื่น
                  </button>
                </div>

                {/* 3. Play as Guest Button */}
                <div className="pt-2 border-t border-amber-900/60 flex flex-col gap-1.5">
                  <button
                    onClick={handleGuestLogin}
                    disabled={isLoading}
                    className="w-full py-2 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-300 hover:text-white font-bold text-xs border border-stone-600/70 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>เล่นแบบไม่ผูกบัญชี (Guest Mode)</span>
                  </button>
                  <span className="text-[10px] text-stone-500 text-center">
                    *โหมด Guest จะบันทึกฟาร์มลงเครื่องนี้เท่านั้น หากล้างประวัติเบราว์เซอร์ข้อมูลอาจสูญหาย
                  </span>
                </div>
              </div>
            )}

            {/* Custom Google Email Input Tab */}
            {activeTab === 'custom_google' && (
              <div className="flex flex-col gap-2.5 bg-stone-900/80 p-3 rounded-2xl border border-stone-700">
                <div className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
                  <span>เข้าสู่ระบบด้วย Google Account ของคุณ</span>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] text-stone-400 font-bold">อีเมล Gmail:</label>
                  <input
                    type="email"
                    value={googleEmail}
                    onChange={(e) => setGoogleEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="bg-stone-950 border border-stone-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] text-stone-400 font-bold">ชื่อชาวสวน (Display Name):</label>
                  <input
                    type="text"
                    value={googleName}
                    onChange={(e) => setGoogleName(e.target.value)}
                    placeholder="เช่น ลุงสมชาย, พี่บีม"
                    className="bg-stone-950 border border-stone-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleGoogleLogin(googleEmail, googleName)}
                    disabled={isLoading}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow active:scale-95 transition-all"
                  >
                    ยืนยันเข้าสู่ระบบ
                  </button>
                  <button
                    onClick={() => setActiveTab('quick')}
                    className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs rounded-xl"
                  >
                    ย้อนกลับ
                  </button>
                </div>
              </div>
            )}

            {/* Custom Facebook Name Input Tab */}
            {activeTab === 'custom_fb' && (
              <div className="flex flex-col gap-2.5 bg-stone-900/80 p-3 rounded-2xl border border-stone-700">
                <div className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                  <span>เข้าสู่ระบบด้วย Facebook ของคุณ</span>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] text-stone-400 font-bold">ชื่อโปรไฟล์ Facebook:</label>
                  <input
                    type="text"
                    value={facebookName}
                    onChange={(e) => setFacebookName(e.target.value)}
                    placeholder="ชื่อ Facebook ของคุณ"
                    className="bg-stone-950 border border-stone-700 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-400"
                  />
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleFacebookLogin(facebookName)}
                    disabled={isLoading}
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow active:scale-95 transition-all"
                  >
                    ยืนยันเข้าสู่ระบบ
                  </button>
                  <button
                    onClick={() => setActiveTab('quick')}
                    className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs rounded-xl"
                  >
                    ย้อนกลับ
                  </button>
                </div>
              </div>
            )}

            {/* Remembered Accounts on this device */}
            {knownAccounts.length > 0 && activeTab === 'quick' && (
              <div className="flex flex-col gap-1.5 pt-2 border-t border-amber-900/50">
                <span className="text-[10px] text-stone-400 font-bold flex items-center gap-1">
                  <Layers className="w-3 h-3 text-amber-400" />
                  <span>บัญชีที่เคยล็อกอินบนเครื่องนี้:</span>
                </span>
                <div className="flex flex-col gap-1">
                  {knownAccounts.map((acc) => (
                    <button
                      key={acc.id}
                      onClick={() => {
                        if (acc.provider === 'google') {
                          handleGoogleLogin(acc.email, acc.displayName);
                        } else {
                          handleFacebookLogin(acc.displayName);
                        }
                      }}
                      className="flex items-center justify-between p-2 rounded-xl bg-stone-900/60 hover:bg-stone-800 text-left border border-stone-700/60 active:scale-95 transition-all text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black bg-stone-700">
                          {acc.provider === 'google' ? 'G' : 'f'}
                        </span>
                        <div>
                          <div className="font-bold text-amber-200 leading-tight">
                            {acc.displayName}
                          </div>
                          <div className="text-[10px] text-stone-400 leading-tight">
                            {acc.email}
                          </div>
                        </div>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-bold">สลับเข้าใช้</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Loading / Status Message */}
        {statusMessage && (
          <div className="my-2 p-2 bg-emerald-950/80 border border-emerald-500 rounded-xl text-center text-xs text-emerald-200 font-bold animate-pulse">
            {statusMessage}
          </div>
        )}

        {/* Security Footer Guarantee */}
        <div className="mt-auto pt-3 border-t border-amber-800/80 flex items-center justify-between text-[10px] text-stone-400">
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>ความปลอดภัยระดับ L3 (AES-GCM 256-bit + PBKDF2)</span>
          </div>
          <span className="text-amber-400/80 font-mono">v6.1 Secure Auth</span>
        </div>
      </div>
    </div>
  );
};
