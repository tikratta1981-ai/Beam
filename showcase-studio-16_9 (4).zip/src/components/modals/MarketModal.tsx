import React from 'react';
import { X, Truck, Coins, Sparkles, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { Order, InventoryItem } from '../../types/game';
import { sound } from '../../utils/audio';

interface MarketModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  inventory: Record<string, InventoryItem>;
  onFulfillOrder: (orderId: string) => void;
  onRefreshOrder: (orderId: string) => void;
}

export const MarketModal: React.FC<MarketModalProps> = ({
  isOpen,
  onClose,
  orders,
  inventory,
  onFulfillOrder,
  onRefreshOrder,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-600 flex items-center justify-center text-white shadow">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                ตลาดและรถขนส่งชุมชน (Order Board)
              </h2>
              <span className="text-xs text-amber-300">
                ส่งสินค้าเกษตรและเบเกอรี่เพื่อรับเหรียญทองและ XP ก้อนโต!
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Orders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {orders.map((order) => {
            const isPending = order.status === 'pending';
            const isAllSatisfied = order.items.every((it) => {
              const have = inventory[it.itemId]?.count || 0;
              return have >= it.count;
            });

            const hasFishItem = order.items.some(
              (it) => it.itemId.startsWith('fish_') || ['fishTomYum', 'troutSandwich', 'bassButterSteak', 'goldenCatfishSoup'].includes(it.itemId)
            );

            return (
              <div
                key={order.id}
                className={`bg-stone-900/85 rounded-2xl p-3.5 border-2 flex flex-col justify-between transition-colors ${
                  hasFishItem
                    ? 'border-cyan-500/80 shadow-[0_0_15px_rgba(6,182,212,0.15)] bg-gradient-to-b from-stone-900 to-cyan-950/20'
                    : 'border-amber-900 hover:border-amber-500'
                }`}
              >
                {/* Customer header */}
                <div className="flex items-center justify-between pb-2 border-b border-stone-800">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{order.customerAvatar}</span>
                    <div className="flex flex-col">
                      <span className="font-extrabold text-xs sm:text-sm text-amber-100 flex items-center gap-1">
                        {order.customerName}
                        {hasFishItem && (
                          <span className="text-[10px] font-bold text-cyan-300 bg-cyan-950/80 border border-cyan-500/60 px-1.5 py-0.5 rounded-full ml-1">
                            🐟 ภัตตาคารปลา
                          </span>
                        )}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      sound.playClick();
                      onRefreshOrder(order.id);
                    }}
                    className="text-stone-400 hover:text-amber-300 transition-colors p-1"
                    title="เปลี่ยนออเดอร์ใหม่"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Items Required List */}
                <div className="my-3 flex flex-col gap-1.5 bg-stone-950/60 rounded-xl p-2.5 border border-stone-800">
                  <span className="text-[10px] text-stone-400 font-bold">รายการสินค้าที่ต้องการ:</span>
                  {order.items.map((it) => {
                    const have = inventory[it.itemId]?.count || 0;
                    const isEnough = have >= it.count;
                    const itemData = inventory[it.itemId];

                    return (
                      <div
                        key={it.itemId}
                        className="flex items-center justify-between text-xs px-2 py-1 rounded bg-stone-900/80 border border-stone-800/80"
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="text-base">{itemData?.icon || '📦'}</span>
                          <span className="text-stone-200">{itemData?.thaiName || it.itemId}</span>
                        </div>
                        <div className="flex items-center gap-1 font-bold">
                          <span className={isEnough ? 'text-emerald-400' : 'text-red-400'}>
                            {have}/{it.count}
                          </span>
                          {isEnough ? (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Rewards & Deliver Button */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-stone-800">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="flex items-center gap-1 text-yellow-300 font-black">
                      <Coins className="w-3.5 h-3.5" />
                      +{order.rewardCoins}
                    </span>
                    <span className="flex items-center gap-1 text-blue-300 font-bold">
                      <Sparkles className="w-3.5 h-3.5" />
                      +{order.rewardXp} XP
                    </span>
                  </div>

                  <button
                    disabled={!isAllSatisfied || !isPending}
                    onClick={() => {
                      sound.playTruckHorn();
                      onFulfillOrder(order.id);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-black shadow transition-all ${
                      isAllSatisfied && isPending
                        ? 'game-btn-green text-white hover:brightness-110 active:scale-95'
                        : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                    }`}
                  >
                    {isAllSatisfied ? 'ส่งสินค้า 🚚' : 'สินค้าไม่ครบ'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
