import React, { useState } from 'react';
import { X, Gift, Sparkles, Coins } from 'lucide-react';
import { sound } from '../../../utils/audio/index';
import confetti from 'canvas-confetti';

interface GiftBoxModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimGift: (reward: { coins: number; gems: number; energy: number }) => void;
  isReady: boolean;
  countdown: string;
}

export const GiftBoxModal: React.FC<GiftBoxModalProps> = ({
  isOpen,
  onClose,
  onClaimGift,
  isReady,
  countdown,
}) => {
  const [opened, setOpened] = useState(false);
  const [reward, setReward] = useState<{ coins: number; gems: number; energy: number } | null>(null);

  if (!isOpen) return null;

  const handleOpenBox = () => {
    sound.playLevelUp();
    const won = {
      coins: Math.floor(Math.random() * 2000) + 1500,
      gems: Math.floor(Math.random() * 10) + 5,
      energy: 15,
    };
    setReward(won);
    setOpened(true);
    try {
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
    } catch {}
    onClaimGift(won);
  };

  const handleFinish = () => {
    setOpened(false);
    setReward(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-sm game-wood-board rounded-3xl p-5 sm:p-6 shadow-2xl border-4 border-purple-500/80 text-white flex flex-col items-center text-center">
        <button
          onClick={() => {
            sound.playClick();
            handleFinish();
          }}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-black text-amber-200 drop-shadow mb-1">
          กล่องของขวัญนำโชค (Lucky Gift)
        </h2>
        <p className="text-xs text-stone-300 mb-4">เปิดฟรีรับของรางวัลสุดพิเศษทุกรอบเวลา!</p>

        {opened && reward ? (
          <div className="flex flex-col items-center gap-3 my-2 w-full animate-fade-in">
            <div className="text-6xl animate-bounce">🎉</div>
            <div className="text-base font-black text-yellow-300">คุณได้รับของขวัญนำโชค!</div>

            <div className="grid grid-cols-3 gap-2 w-full text-xs">
              <div className="bg-stone-900/90 p-2.5 rounded-xl border border-yellow-500/50 flex flex-col items-center">
                <span className="text-xl">🪙</span>
                <span className="font-extrabold text-yellow-300">+{reward.coins}</span>
                <span className="text-[10px] text-stone-400">เหรียญทอง</span>
              </div>
              <div className="bg-stone-900/90 p-2.5 rounded-xl border border-cyan-500/50 flex flex-col items-center">
                <span className="text-xl">💎</span>
                <span className="font-extrabold text-cyan-300">+{reward.gems}</span>
                <span className="text-[10px] text-stone-400">เพชร</span>
              </div>
              <div className="bg-stone-900/90 p-2.5 rounded-xl border border-emerald-500/50 flex flex-col items-center">
                <span className="text-xl">⚡</span>
                <span className="font-extrabold text-emerald-300">+{reward.energy}</span>
                <span className="text-[10px] text-stone-400">พลังงาน</span>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playCoin();
                handleFinish();
              }}
              className="w-full mt-2 py-2.5 game-btn-green rounded-xl text-white font-black text-xs shadow-lg active:scale-95"
            >
              รับรางวัลเข้ากระเป๋า ✓
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 my-2">
            <div
              className={`w-28 h-28 rounded-3xl bg-gradient-to-tr from-purple-700 via-pink-600 to-amber-400 flex items-center justify-center text-6xl shadow-2xl border-4 border-white ${
                isReady ? 'animate-gentle-bounce cursor-pointer' : 'opacity-80'
              }`}
              onClick={isReady ? handleOpenBox : undefined}
            >
              🎁
            </div>

            {isReady ? (
              <button
                onClick={handleOpenBox}
                className="px-6 py-2.5 game-btn-yellow rounded-2xl text-stone-900 font-black text-sm shadow-xl animate-gentle-pulse hover:brightness-110 active:scale-95"
              >
                เปิดกล่องตอนนี้ฟรี! 🎁
              </button>
            ) : (
              <div className="flex flex-col items-center">
                <span className="text-xs text-stone-400">ของขวัญรอบถัดไปจะพร้อมในอีก:</span>
                <span className="text-lg font-mono font-black text-yellow-300 mt-1">
                  {countdown}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
