import React, { useState } from 'react';
import { X, Droplet, Heart, ArrowLeft, Sparkles, MessageCircle } from 'lucide-react';
import { Friend } from '../../../types/game';
import { sound } from '../../../utils/audio/index';

interface VisitFriendModalProps {
  isOpen: boolean;
  onClose: () => void;
  friend: Friend | null;
  onHelpFriend: (friendId: string) => void;
}

export const VisitFriendModal: React.FC<VisitFriendModalProps> = ({
  isOpen,
  onClose,
  friend,
  onHelpFriend,
}) => {
  const [helped, setHelped] = useState(false);
  const [chatSent, setChatSent] = useState(false);

  if (!isOpen || !friend) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header with Friend details */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-1.5 bg-stone-800 rounded-xl hover:bg-stone-700 text-amber-200 border border-stone-600"
              title="กลับฟาร์มของคุณ"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="text-3xl">{friend.avatar}</div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-amber-200">
                  {friend.farmName} ({friend.name})
                </h2>
                <span className="bg-amber-500 text-stone-900 text-[10px] font-black px-1.5 rounded-full">
                  Lv. {friend.level}
                </span>
              </div>
              <span className="text-xs text-stone-300">
                คุณกำลังเยี่ยมชมฟาร์มของเพื่อนบ้าน ร่วมส่งกำลังใจและช่วยเหลืองาน
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Friend Farm Simulation Preview */}
        <div className="relative w-full h-72 sm:h-80 my-3 rounded-2xl overflow-hidden bg-gradient-to-b from-[#6bb43d] to-[#4e8b2b] border-2 border-amber-800 flex items-center justify-center">
          {/* Decorative trees & buildings */}
          <div className="absolute top-4 left-6 text-4xl">🏡</div>
          <div className="absolute top-4 right-10 text-4xl">🐄🌾</div>
          <div className="absolute bottom-4 left-10 text-4xl">🌻🪻</div>
          <div className="absolute bottom-6 right-12 text-4xl">🚜</div>

          {/* Center Friend Interactive Plots */}
          <div className="relative bg-[#5a3617]/90 p-4 rounded-2xl border-2 border-amber-700 flex flex-col items-center gap-2">
            <span className="text-xs font-bold text-amber-200">
              {friend.needsHelp && !helped ? '⚠️ มีแปลงที่ต้องการความช่วยเหลือ!' : '🌱 แปลงเกษตรของเพื่อน'}
            </span>
            <div className="grid grid-cols-3 gap-2 text-2xl">
              <span className="p-2 bg-stone-900/60 rounded-xl">🌽</span>
              <span className="p-2 bg-stone-900/60 rounded-xl">🍅</span>
              <span className="p-2 bg-stone-900/60 rounded-xl">🍓</span>
            </div>

            {friend.needsHelp && !helped ? (
              <button
                onClick={() => {
                  sound.playHarvest();
                  onHelpFriend(friend.id);
                  setHelped(true);
                }}
                className="mt-2 px-4 py-2 game-btn-green rounded-xl text-xs font-black text-white shadow flex items-center gap-1.5 animate-bounce"
              >
                <Droplet className="w-4 h-4 text-cyan-200" />
                <span>ช่วยรดน้ำแปลงเพื่อน (+50 XP / +100 🪙)</span>
              </button>
            ) : (
              <span className="text-xs text-emerald-300 font-bold bg-stone-900/80 px-2 py-1 rounded">
                ✓ รดน้ำและดูแลแปลงนี้แล้ว
              </span>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-amber-800/80">
          <button
            onClick={() => {
              sound.playClick();
              setChatSent(true);
              setTimeout(() => setChatSent(false), 2500);
            }}
            className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-amber-200 rounded-xl text-xs font-bold border border-stone-600 flex items-center gap-1.5"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{chatSent ? 'ส่งข้อความทักทายแล้ว!' : 'ทักทาย "ฟาร์มสวยจัง!"'}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="px-4 py-1.5 game-btn-yellow text-stone-900 font-black text-xs rounded-xl shadow active:scale-95"
          >
            กลับสู่ฟาร์มของฉัน
          </button>
        </div>
      </div>
    </div>
  );
};
