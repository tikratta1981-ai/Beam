import React, { useState } from 'react';
import { X, Users, Gift, Droplet, UserPlus, Check, Sparkles, ExternalLink } from 'lucide-react';
import { Friend } from '../../../types/game';
import { sound } from '../../../utils/audio/index';

interface FriendsModalProps {
  isOpen: boolean;
  onClose: () => void;
  friends: Friend[];
  onSendGift: (friendId: string) => void;
  onHelpFriend: (friendId: string) => void;
  onVisitFriend: (friend: Friend) => void;
  onAddFriend: (code: string) => void;
}

export const FriendsModal: React.FC<FriendsModalProps> = ({
  isOpen,
  onClose,
  friends,
  onSendGift,
  onHelpFriend,
  onVisitFriend,
  onAddFriend,
}) => {
  const [friendCode, setFriendCode] = useState('');
  const [addSuccess, setAddSuccess] = useState(false);

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendCode.trim()) return;
    sound.playSuccessChime();
    onAddFriend(friendCode.trim());
    setFriendCode('');
    setAddSuccess(true);
    setTimeout(() => setAddSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                เพื่อนบ้านและชุมชน (Friends & Neighbors)
              </h2>
              <span className="text-xs text-amber-300">
                ส่งของขวัญ ช่วยเหลืองานในฟาร์ม และเยี่ยมชมไร่เพื่อน!
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add Friend Form */}
        <form onSubmit={handleAdd} className="flex gap-2 my-3">
          <input
            type="text"
            value={friendCode}
            onChange={(e) => setFriendCode(e.target.value)}
            placeholder="ใส่รหัสเพื่อน (เช่น BEAM-2026, FARM-88)"
            className="flex-1 bg-stone-900/80 border border-amber-800 rounded-xl px-3 py-2 text-xs text-white placeholder-stone-400 focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            className="px-4 py-2 game-btn-green rounded-xl text-xs font-black text-white flex items-center gap-1.5 shadow hover:brightness-110 active:scale-95"
          >
            <UserPlus className="w-4 h-4" />
            <span>เพิ่มเพื่อน</span>
          </button>
        </form>
        {addSuccess && (
          <div className="text-xs text-emerald-400 font-bold -mt-1 mb-2">
            ✓ เพิ่มเพื่อนสำเร็จแล้ว!
          </div>
        )}

        {/* Friends List */}
        <div className="flex flex-col gap-2.5 overflow-y-auto game-scroll pr-1 flex-1">
          {friends.map((friend) => (
            <div
              key={friend.id}
              className="bg-stone-900/75 rounded-2xl p-3 border border-amber-900/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-amber-500 transition-colors"
            >
              {/* Friend Info */}
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-full bg-stone-800 border-2 border-amber-400 flex items-center justify-center text-2xl shadow">
                    {friend.avatar}
                  </div>
                  <span className="absolute -bottom-1 -right-1 bg-amber-500 text-stone-900 text-[10px] font-black px-1 rounded-full border border-white">
                    Lv.{friend.level}
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-amber-100">{friend.name}</span>
                    <span
                      className={`w-2 h-2 rounded-full ${
                        friend.isOnline ? 'bg-emerald-400' : 'bg-stone-500'
                      }`}
                      title={friend.isOnline ? 'ออนไลน์' : 'ออฟไลน์'}
                    />
                  </div>
                  <span className="text-xs text-stone-400">{friend.farmName}</span>

                  {friend.needsHelp && (
                    <div className="flex items-center gap-1 text-[11px] text-yellow-300 font-medium mt-0.5">
                      <Droplet className="w-3 h-3 text-cyan-400" />
                      <span>{friend.helpType}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 self-end sm:self-center">
                {/* Help Friend Button */}
                {friend.needsHelp && (
                  <button
                    onClick={() => {
                      sound.playHarvest();
                      onHelpFriend(friend.id);
                    }}
                    className="px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold shadow flex items-center gap-1 active:scale-95"
                  >
                    <Droplet className="w-3.5 h-3.5 text-cyan-200" />
                    <span>ช่วยงาน (+50XP)</span>
                  </button>
                )}

                {/* Send Gift Button */}
                <button
                  disabled={friend.giftSentToday}
                  onClick={() => {
                    sound.playCoin();
                    onSendGift(friend.id);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shadow flex items-center gap-1 transition-all ${
                    friend.giftSentToday
                      ? 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                      : 'game-btn-yellow text-stone-900 hover:brightness-110 active:scale-95'
                  }`}
                >
                  <Gift className="w-3.5 h-3.5" />
                  <span>{friend.giftSentToday ? 'ส่งแล้ววันนี้' : 'ส่งของขวัญ'}</span>
                </button>

                {/* Visit Farm Button */}
                <button
                  onClick={() => {
                    sound.playClick();
                    onVisitFriend(friend);
                  }}
                  className="px-2.5 py-1.5 bg-stone-800 hover:bg-stone-700 text-amber-200 rounded-xl text-xs font-bold border border-stone-700 flex items-center gap-1 active:scale-95"
                  title="ไปเยี่ยมชมฟาร์ม"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>เยี่ยมชม</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
