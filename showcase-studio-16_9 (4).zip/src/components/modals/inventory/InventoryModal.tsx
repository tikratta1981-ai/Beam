import React, { useState } from 'react';
import { X, Briefcase, Coins, ArrowUpCircle } from 'lucide-react';
import { InventoryItem } from '../../../types/game';
import { sound } from '../../../utils/audio/index';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: Record<string, InventoryItem>;
  capacity: number;
  upgradeCost: number; // รับราคาจาก App.tsx โดยตรง (Single Source of Truth)
  onSellItem: (itemId: string, count: number) => void;
  onUpgradeCapacity: () => void;
  coins: number;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  inventory,
  capacity,
  upgradeCost,
  onSellItem,
  onUpgradeCapacity,
  coins,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'crops' | 'animal' | 'factory' | 'special'>('all');
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [sellCount, setSellCount] = useState<number>(1);

  if (!isOpen) return null;

  // กรองเฉพาะไอเทมที่ count > 0 เท่านั้น (ถ้าขายหมดจะหายทันที)
  const itemsList = Object.values(inventory).filter((item) => item.count > 0);
  const totalCount = itemsList.reduce((sum, item) => sum + item.count, 0);

  const filteredItems = itemsList.filter((item) => {
    if (selectedCategory === 'all') return true;
    return item.category === selectedCategory;
  });

  // ซิงก์ข้อมูลชิ้นที่เลือกกับ inventory แบบ Real-time
  const currentSelectedItem = selectedItemId ? inventory[selectedItemId] : null;
  const activeItem = currentSelectedItem && currentSelectedItem.count > 0 ? currentSelectedItem : null;

  const canUpgrade = coins >= upgradeCost;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        
        {/* Header with Title & Capacity Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-600 flex items-center justify-center text-white shadow">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                โรงนา & ไซโลเก็บสินค้า (Storage)
              </h2>
              <div className="flex items-center gap-2 text-xs text-amber-300">
                <span>ความจุรวม:</span>
                <span className="font-bold text-white">
                  {totalCount} / {capacity} ชิ้น
                </span>
                <div className="w-24 h-2 bg-stone-800 rounded-full overflow-hidden border border-stone-600">
                  <div
                    className="h-full bg-amber-400 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (totalCount / capacity) * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Upgrade Capacity Button */}
            <button
              onClick={() => {
                if (canUpgrade) {
                  sound.playSuccessChime();
                  onUpgradeCapacity();
                }
              }}
              disabled={!canUpgrade}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold shadow transition-all ${
                canUpgrade
                  ? 'game-btn-green text-white hover:brightness-110 active:scale-95'
                  : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
              }`}
              title="เพิ่มความจุ +15 ช่อง"
            >
              <ArrowUpCircle className="w-4 h-4 text-emerald-200" />
              <span>อัปเกรด ({upgradeCost}🪙)</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 my-3 overflow-x-auto pb-1">
          {[
            { id: 'all', label: 'ทั้งหมด' },
            { id: 'crops', label: '🌾 พืชผล' },
            { id: 'animal', label: '🥛 สัตว์เลี้ยง' },
            { id: 'factory', label: '🍞 แปรรูป' },
            { id: 'special', label: '✨ พิเศษ' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                sound.playClick();
                setSelectedCategory(cat.id as typeof selectedCategory);
                setSelectedItemId(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-stone-900 shadow-md font-extrabold scale-105'
                  : 'bg-stone-900/60 text-amber-200 hover:bg-stone-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Items Grid & Detail Pane */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 overflow-y-auto game-scroll pr-1 flex-1">
          
          {/* Items Grid: แสดงรูปเฉพาะสินค้าที่มีเหลืออยู่จริง */}
          <div className="md:col-span-2 grid grid-cols-3 sm:grid-cols-4 gap-2.5 content-start">
            {filteredItems.length === 0 ? (
              <div className="col-span-full py-12 text-center text-amber-300/60 font-medium">
                ไม่มีไอเทมในหมวดนี้
              </div>
            ) : (
              filteredItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    sound.playClick();
                    setSelectedItemId(item.id);
                    setSellCount(1);
                  }}
                  className={`relative flex flex-col items-center justify-between p-2 rounded-2xl border-2 transition-all ${
                    activeItem?.id === item.id
                      ? 'bg-amber-600/40 border-yellow-300 scale-105 shadow-lg'
                      : 'bg-stone-900/70 border-amber-900/80 hover:border-amber-600'
                  }`}
                >
                  <div className="text-3xl my-1">{item.icon}</div>
                  <span className="text-[11px] font-bold text-amber-100 text-center truncate w-full">
                    {item.thaiName}
                  </span>
                  <div className="w-full flex items-center justify-between mt-1 pt-1 border-t border-stone-800 text-[10px]">
                    <span className="text-yellow-400 font-extrabold tabular-nums">
                      {item.count} ชิ้น
                    </span>
                    <span className="text-amber-300/80">{item.sellPrice}🪙</span>
                  </div>
                </button>
              ))
            )}
          </div>

          {/* Selected Item Detail & Sell Action */}
          <div className="game-wood-panel rounded-2xl p-3 border-2 border-amber-500/70 flex flex-col justify-between">
            {activeItem ? (
              <>
                <div className="flex flex-col items-center text-center relative">
                  {/* ปุ่มกดยกเลิกการเลือก */}
                  <button
                    onClick={() => setSelectedItemId(null)}
                    className="absolute top-0 right-0 p-1 text-stone-400 hover:text-white"
                    title="ปิดรายละเอียด"
                  >
                    <X className="w-4 h-4" />
                  </button>

                  <div className="text-5xl my-2">{activeItem.icon}</div>
                  <h3 className="font-black text-amber-200 text-base">{activeItem.thaiName}</h3>
                  <span className="text-xs text-stone-300 mt-0.5">{activeItem.name}</span>

                  <div className="w-full bg-stone-900/70 rounded-xl p-2.5 my-3 text-xs flex flex-col gap-1 border border-stone-800">
                    <div className="flex justify-between">
                      <span className="text-stone-400">จำนวนที่มี:</span>
                      <span className="font-bold text-yellow-300">{activeItem.count} ชิ้น</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-400">ราคาขายต่อชิ้น:</span>
                      <span className="font-bold text-yellow-300">{activeItem.sellPrice} เหรียญ</span>
                    </div>
                  </div>

                  {/* Quantity selector */}
                  <div className="w-full flex items-center justify-between gap-1 mb-2">
                    <button
                      onClick={() => setSellCount((c) => Math.max(1, c - 1))}
                      className="px-2 py-1 bg-stone-800 rounded-lg text-amber-200 font-bold border border-stone-700 hover:bg-stone-700 active:scale-95"
                    >
                      -1
                    </button>
                    <span className="font-bold text-sm text-white px-2">
                      ขาย: {Math.min(sellCount, activeItem.count)}
                    </span>
                    <button
                      onClick={() => setSellCount((c) => Math.min(activeItem.count, c + 1))}
                      className="px-2 py-1 bg-stone-800 rounded-lg text-amber-200 font-bold border border-stone-700 hover:bg-stone-700 active:scale-95"
                    >
                      +1
                    </button>
                    <button
                      onClick={() => setSellCount(activeItem.count)}
                      className="px-2 py-1 bg-amber-800/80 rounded-lg text-amber-200 text-[10px] font-bold border border-amber-600 hover:bg-amber-700 active:scale-95"
                    >
                      ทั้งหมด
                    </button>
                  </div>
                </div>

                {/* ปุ่มยืนยันการขาย */}
                <button
                  onClick={() => {
                    const actualSell = Math.min(sellCount, activeItem.count);
                    onSellItem(activeItem.id, actualSell);

                    if (activeItem.count - actualSell <= 0) {
                      setSelectedItemId(null);
                    } else {
                      setSellCount(1);
                    }
                  }}
                  className="w-full py-2.5 game-btn-yellow rounded-xl text-stone-900 font-black text-sm flex items-center justify-center gap-1.5 shadow-lg hover:brightness-110 active:scale-95 transition-all"
                >
                  <Coins className="w-4 h-4 text-stone-900" />
                  <span>ขายเพื่อรับ {Math.min(sellCount, activeItem.count) * activeItem.sellPrice} เหรียญ</span>
                </button>
              </>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center text-stone-400 text-xs p-4">
                <Briefcase className="w-10 h-10 text-stone-600 mb-2" />
                <span>คลิกเลือกไอเทมเพื่อดูรายละเอียดและขายเป็นเงิน</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};