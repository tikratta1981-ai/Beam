import React, { useState } from 'react';
import { X, Settings, Volume2, VolumeX, Music, RotateCcw, Edit2, Check, Cloud, ShieldCheck, ScrollText, Trash2, Download, User } from 'lucide-react';
import { sound } from '../../utils/audio';
import { getSecurityLog, clearSecurityLog, secureStorage, SecurityEvent } from '../../security';
import { UserProfile } from '../../types/auth';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  farmName: string;
  onUpdateFarmName: (name: string) => void;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onResetGame: () => void;
  onReplayLoading?: () => void;
  onOpenCloudSync?: () => void;
  onOpenAuth?: () => void;
  currentUser?: UserProfile | null;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  farmName,
  onUpdateFarmName,
  soundEnabled,
  musicEnabled,
  onToggleSound,
  onToggleMusic,
  onResetGame,
  onReplayLoading,
  onOpenCloudSync,
  onOpenAuth,
  currentUser,
}) => {
  const [nameInput, setNameInput] = useState(farmName);
  const [isEditingName, setIsEditingName] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [showSecurityLog, setShowSecurityLog] = useState(false);
  const [securityLogs, setSecurityLogs] = useState<SecurityEvent[]>([]);

  const handleOpenSecurityLog = () => {
    sound.playClick();
    setSecurityLogs(getSecurityLog());
    setShowSecurityLog(true);
  };

  const handleClearLogs = () => {
    sound.playClick();
    clearSecurityLog();
    setSecurityLogs([]);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-stone-700 flex items-center justify-center text-white shadow">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                การตั้งค่าฟาร์ม (Settings)
              </h2>
              <span className="text-xs text-amber-300">Beam Farm (B.P.) System</span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Options list */}
        <div className="flex flex-col gap-3 my-4">
          {/* Farm Name setting */}
          <div className="bg-stone-900/75 p-3 rounded-2xl border border-stone-800 flex flex-col gap-1.5">
            <span className="text-xs text-stone-400 font-bold">ชื่อฟาร์มของคุณ:</span>
            <div className="flex items-center gap-2">
              {isEditingName ? (
                <>
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="flex-1 bg-stone-950 border border-amber-600 rounded-xl px-2.5 py-1 text-sm text-amber-100 font-bold focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      if (nameInput.trim()) {
                        onUpdateFarmName(nameInput.trim());
                      }
                      setIsEditingName(false);
                    }}
                    className="p-1.5 bg-emerald-600 rounded-xl text-white hover:bg-emerald-500"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  <span className="flex-1 text-sm font-black text-amber-200">{farmName}</span>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="p-1.5 text-stone-400 hover:text-amber-300"
                    title="แก้ไขชื่อฟาร์ม"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Sound FX Toggle */}
          <div className="bg-stone-900/75 p-3 rounded-2xl border border-stone-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {soundEnabled ? (
                <Volume2 className="w-5 h-5 text-amber-400" />
              ) : (
                <VolumeX className="w-5 h-5 text-stone-500" />
              )}
              <div>
                <div className="text-xs font-bold text-amber-100">เสียงเอฟเฟกต์ (Sound Effects)</div>
                <div className="text-[10px] text-stone-400">เสียงเก็บเกี่ยว รดน้ำ และสัตว์ร้อง</div>
              </div>
            </div>
            <button
              onClick={onToggleSound}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                soundEnabled ? 'bg-emerald-600' : 'bg-stone-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Music Toggle */}
          <div className="bg-stone-900/75 p-3 rounded-2xl border border-stone-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Music
                className={`w-5 h-5 ${musicEnabled ? 'text-emerald-400 animate-pulse' : 'text-stone-500'}`}
              />
              <div>
                <div className="text-xs font-bold text-amber-100">เพลงพื้นหลัง (Country Melody)</div>
                <div className="text-[10px] text-stone-400">เสียงสังเคราะห์เมโลดี้ฟาร์มสุขใจ</div>
              </div>
            </div>
            <button
              onClick={onToggleMusic}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                musicEnabled ? 'bg-emerald-600' : 'bg-stone-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  musicEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Farm Account & Login */}
          {onOpenAuth && (
            <div className="bg-stone-900/85 p-3 rounded-2xl border border-amber-500/50 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-amber-400" />
                  <span>บัญชีผู้เล่น (Farmer Account)</span>
                </div>
                <div className="text-[10px] text-stone-300">
                  {currentUser && currentUser.provider !== 'guest' ? (
                    <span className="text-emerald-300 font-bold">
                      ผูกกับ: {currentUser.displayName} ({currentUser.provider === 'google' ? 'Google' : 'Facebook'})
                    </span>
                  ) : (
                    <span className="text-stone-400">ยังไม่ได้ผูกบัญชี (Guest Mode)</span>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  onClose();
                  onOpenAuth();
                }}
                className={`px-3 py-1.5 text-xs font-black rounded-xl shadow active:scale-95 cursor-pointer transition-all border ${
                  currentUser && currentUser.provider !== 'guest'
                    ? 'bg-stone-800 text-emerald-300 border-emerald-400/60 hover:bg-stone-700'
                    : 'bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white border-amber-300'
                }`}
              >
                {currentUser && currentUser.provider !== 'guest' ? 'จัดการบัญชี 👤' : 'ล็อกอิน Gmail/FB 🔑'}
              </button>
            </div>
          )}

          {/* Cloud Save & Sync */}
          {onOpenCloudSync && (
            <div className="bg-stone-900/85 p-3 rounded-2xl border border-cyan-800/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-cyan-200 flex items-center gap-1.5">
                  <Cloud className="w-4 h-4 text-cyan-400" />
                  <span>Cloud Save & Cross-Device Sync</span>
                </div>
                <div className="text-[10px] text-stone-400">สำรองข้อมูล, รหัสย้ายเครื่อง, ซิงก์ 2 เครื่อง</div>
              </div>
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  onClose();
                  onOpenCloudSync();
                }}
                className="px-3 py-1.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-black text-xs rounded-xl shadow border border-cyan-300 active:scale-95 cursor-pointer transition-all"
              >
                เปิดคลาวด์ ☁️
              </button>
            </div>
          )}

          {/* Replay Loading Screen */}
          {onReplayLoading && (
            <div className="bg-stone-900/75 p-3 rounded-2xl border border-amber-900/60 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-amber-200">หน้าจอเริ่มเกม (Loading Screen)</div>
                <div className="text-[10px] text-stone-400">ดูหน้าโหลดเข้าเกม 100% พร้อมเสียงบรรเลง</div>
              </div>
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  onClose();
                  onReplayLoading();
                }}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-xs rounded-xl shadow border border-amber-200 active:scale-95 cursor-pointer transition-all"
              >
                เล่นซ้ำ 🎬
              </button>
            </div>
          )}

          {/* Security System & Audit Log */}
          <div className="bg-stone-900/85 p-3 rounded-2xl border border-emerald-900/70 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>ระบบความปลอดภัย (Security v6.1)</span>
              </div>
              <div className="text-[10px] text-stone-400">AES-GCM, SHA-256 Checksum, Rate Limiter</div>
            </div>
            <button
              type="button"
              onClick={handleOpenSecurityLog}
              className="px-3 py-1.5 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white font-black text-xs rounded-xl shadow border border-emerald-400 active:scale-95 cursor-pointer transition-all flex items-center gap-1"
            >
              <ScrollText className="w-3.5 h-3.5" />
              <span>ประวัติ 🛡️</span>
            </button>
          </div>

          {/* Reset Progress */}
          <div className="bg-stone-900/75 p-3 rounded-2xl border border-red-950 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-red-300">เริ่มเล่นใหม่ (Reset Progress)</div>
              <div className="text-[10px] text-stone-400">คืนค่าสถานะฟาร์มและเงินเริ่มต้น</div>
            </div>
            {confirmReset ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onResetGame()}
                  className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-xl border border-red-400"
                >
                  ยืนยัน
                </button>
                <button
                  onClick={() => setConfirmReset(false)}
                  className="px-2 py-1 bg-stone-700 hover:bg-stone-600 text-stone-300 text-xs rounded-xl"
                >
                  ยกเลิก
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="px-3 py-1.5 bg-red-900/80 hover:bg-red-800 text-red-200 text-xs font-bold rounded-xl border border-red-700 flex items-center gap-1 active:scale-95"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>รีเซ็ต</span>
              </button>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="text-center text-[10px] text-stone-500 pt-2 border-t border-stone-800">
          Dream Farm (B.P.) Prototype Version 1.0 · เล่นฟรีทุกแพลตฟอร์ม
        </div>
      </div>
    </div>
  );
};
