import React from 'react';
import { X, Calendar, CheckCircle2, Coins, Sparkles } from 'lucide-react';
import { DailyReward } from '../../types/game';
import { sound } from '../../utils/audio';

interface DailyRewardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  rewards: DailyReward[];
  onClaimDaily: (day: number) => void;
  currentDay: number;
}

export const DailyRewardsModal: React.FC<DailyRewardsModalProps> = ({
  isOpen,
  onClose,
  rewards,
  onClaimDaily,
  currentDay,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/65 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[90dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-sky-600 flex items-center justify-center text-white shadow">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                ของขวัญเช็คอินรายวัน (7-Day Check-in)
              </h2>
              <span className="text-xs text-amber-300">
                เข้าเกมทุกวันเพื่อรับเหรียญ เพชร และไอเทมสุดพิเศษ!
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/80 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 7 Days Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 my-4 overflow-y-auto game-scroll pr-1 flex-1">
          {rewards.map((rew) => {
            const isToday = rew.day === currentDay;
            const canClaim = isToday && !rew.claimed;

            return (
              <div
                key={rew.day}
                className={`relative rounded-2xl p-3 border-2 flex flex-col items-center justify-between text-center transition-all ${
                  rew.claimed
                    ? 'bg-stone-900/50 border-stone-800 opacity-70'
                    : canClaim
                    ? 'bg-gradient-to-b from-amber-800 to-amber-950 border-yellow-400 shadow-[0_0_12px_rgba(250,204,21,0.5)] scale-105'
                    : 'bg-stone-900/75 border-amber-900'
                }`}
              >
                <span className="text-xs font-black text-amber-300">วันที่ {rew.day}</span>

                <div className="my-2 flex flex-col items-center">
                  <div className="text-3xl my-1">
                    {rew.day === 7 ? '🏆' : rew.items ? rew.items.icon : '🎁'}
                  </div>
                  <div className="flex flex-col text-[11px] text-yellow-300 font-bold">
                    <span>+{rew.coins.toLocaleString()} 🪙</span>
                    <span className="text-cyan-300">+{rew.gems} 💎</span>
                    {rew.items && (
                      <span className="text-emerald-300 text-[10px]">
                        +{rew.items.count} {rew.items.name}
                      </span>
                    )}
                  </div>
                </div>

                {rew.claimed ? (
                  <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>รับแล้ว</span>
                  </div>
                ) : canClaim ? (
                  <button
                    onClick={() => {
                      sound.playLevelUp();
                      onClaimDaily(rew.day);
                    }}
                    className="w-full py-1.5 game-btn-yellow text-stone-900 font-black text-xs rounded-xl shadow animate-gentle-pulse hover:brightness-110 active:scale-95"
                  >
                    รับรางวัล!
                  </button>
                ) : (
                  <span className="text-[10px] text-stone-500 font-medium">ยังไม่ถึงวัน</span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
