// src/components/modals/AppModals.tsx
import React from 'react';
import { SeedPickerModal } from './seed/SeedPickerModal';
import { InventoryModal } from './inventory/InventoryModal';
import { ProductionModal } from './production/ProductionModal';
import { AnimalCareModal } from './animal/AnimalCareModal';
import { MarketModal } from './market/MarketModal';
import { QuestsModal } from './quests/QuestsModal';
import { EventsModal } from './events/EventsModal';
import { DailyRewardsModal } from './rewards/DailyRewardsModal';
import { FriendsModal } from './social/FriendsModal';
import { ShopModal } from './shop/ShopModal';
import { MailModal, MailMessage } from './social/MailModal';
import { WorldMapModal } from './world/WorldMapModal';
import { SettingsModal } from './settings/SettingsModal';
import { LevelUpModal } from './rewards/LevelUpModal';
import { GiftBoxModal } from './social/GiftBoxModal';
import { VisitFriendModal } from './social/VisitFriendModal';
import { BuildModal } from './system/BuildModal';
import { LogoInfoModal } from './system/LogoInfoModal';
import { CloudSyncModal } from './system/CloudSyncModal';
import { LoadingScreen } from '../LoadingScreen';

// 🎣 นำเข้า FishingDockModal
import { FishingDockModal } from './fishing/FishingDockModal';

import {
  Plot,
  AnimalPen,
  Factory,
  Quest,
  Order,
  Friend,
  DailyReward,
  CropType,
  FarmLog,
  InventoryItem,
} from '../../types/game';
import { GameSnapshot } from '../../data/gameConstants';

export interface AppModalsProps {
  activeModal: string | null;
  onCloseModal: () => void;
  setActiveModal: (modal: string | null) => void;

  level: number;
  coins: number;
  gems: number;
  energy: number;
  maxEnergy: number;
  xp: number;
  maxXp: number;
  farmName: string;
  setFarmName: (name: string) => void;
  barnCapacity: number;
  currentUpgradeCost: number;

  inventory: Record<string, InventoryItem>;
  factories: Record<string, Factory>;
  selectedFactoryId: string;
  animals: AnimalPen[];
  orders: Order[];
  quests: Quest[];
  festivalPoints: number;
  claimedTiers: number[];
  dailyRewards: DailyReward[];
  friends: Friend[];
  visitingFriend: Friend | null;
  setVisitingFriend: (friend: Friend | null) => void;
  shopInitialTab: string;
  mails: MailMessage[];
  plots: Plot[];
  farmLogs: FarmLog[];

  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onResetGame: () => void;
  isGiftReady: boolean;
  giftCountdownDisplay: string;
  levelUpData: { show: boolean; level: number };
  setLevelUpData: React.Dispatch<React.SetStateAction<{ show: boolean; level: number }>>;
  showLoadingScreen: boolean;
  setShowLoadingScreen: (show: boolean) => void;
  onFinishLoading: () => void;

  onSelectCrop: (crop: CropType) => void;
  onSellItem: (itemId: string, count: number) => void;
  onUpgradeCapacity: () => void;
  onStartProduction: (factoryId: string, recipeId: string) => void;
  onSpeedUpProduction: (factoryId: string) => void;
  onCollectProduct: (factoryId: string) => void;
  onFeedAnimal: (penId: string) => void;
  onCollectAnimal: (penId: string) => void;
  onBuildAnimalPen: (type: 'chicken' | 'cow' | 'sheep') => void;
  onFulfillOrder: (orderId: string) => void;
  onRefreshOrder: (orderId: string) => void;
  onClaimQuest: (questId: string) => void;
  onClaimMilestone: (tier: number) => void;
  onClaimDaily: (day: number) => void;
  onSendGift: (friendId: string) => void;
  onHelpFriend: (friendId: string) => void;
  onAddFriend: (code: string) => void;
  onBuySeeds: (cropId: string, count: number, cost: number) => void;
  onBuyPlot: () => void;
  onRefillEnergy: () => void;
  onExchangeGemsForCoins: (costGems: number, gainCoins: number) => void;
  onClaimMail: (mailId: string) => void;
  onTravel: (locationName: string) => void;
  onBuildDecoration: (name: string, cost: number) => void;
  onApplySnapshot: (snapshot: GameSnapshot) => void;
  onClaimGift: (reward: { coins: number; gems: number; energy: number }) => void;
  onUpdateFarmName: (name: string) => void;
  onOpenAuth?: () => void;
  currentUser?: any;

  onConsumeEnergy?: (amount: number) => boolean;
  onAddFishToInventory?: (fish: any, weight: number) => void;
  onAddRewards?: (coins: number, xp: number) => void;
  onConsumeItems?: (items: { itemId: string; count: number }[]) => boolean;
  luckyFisherBuff?: number;
  onConsumeLuckyBuff?: () => void;
  timeOfDay?: 'day' | 'twilight' | 'night';
  onToggleTimeOfDay?: () => void;
  currentFarmId?: string;
  onSwitchFarm?: (farmId: 'farm1' | 'farm2') => void;
}

export const AppModals: React.FC<AppModalsProps> = ({
  activeModal,
  onCloseModal,
  setActiveModal,

  level,
  coins,
  gems,
  energy,
  maxEnergy,
  xp,
  maxXp,
  farmName,
  barnCapacity,
  currentUpgradeCost,

  inventory,
  factories,
  selectedFactoryId,
  animals,
  orders,
  quests,
  festivalPoints,
  claimedTiers,
  dailyRewards,
  friends,
  visitingFriend,
  setVisitingFriend,
  shopInitialTab,
  mails,
  plots,
  farmLogs,

  soundEnabled,
  musicEnabled,
  onToggleSound,
  onToggleMusic,
  onResetGame,
  isGiftReady,
  giftCountdownDisplay,
  levelUpData,
  setLevelUpData,
  showLoadingScreen,
  setShowLoadingScreen,
  onFinishLoading,

  onSelectCrop,
  onSellItem,
  onUpgradeCapacity,
  onStartProduction,
  onSpeedUpProduction,
  onCollectProduct,
  onFeedAnimal,
  onCollectAnimal,
  onBuildAnimalPen,
  onFulfillOrder,
  onRefreshOrder,
  onClaimQuest,
  onClaimMilestone,
  onClaimDaily,
  onSendGift,
  onHelpFriend,
  onAddFriend,
  onBuySeeds,
  onBuyPlot,
  onRefillEnergy,
  onExchangeGemsForCoins,
  onClaimMail,
  onTravel,
  onBuildDecoration,
  onApplySnapshot,
  onClaimGift,
  onUpdateFarmName,
  onOpenAuth,
  currentUser,

  onConsumeEnergy,
  onAddFishToInventory,
  onAddRewards,
  onConsumeItems,
  luckyFisherBuff,
  onConsumeLuckyBuff,
  timeOfDay,
  onToggleTimeOfDay,
  currentFarmId = 'farm1',
  onSwitchFarm,
}) => {
  return (
    <>
      <SeedPickerModal
        isOpen={activeModal === 'seedPicker'}
        onClose={onCloseModal}
        onSelectCrop={onSelectCrop}
        playerLevel={level}
        playerCoins={coins}
      />

      <InventoryModal
        isOpen={activeModal === 'inventory'}
        onClose={onCloseModal}
        inventory={inventory}
        capacity={barnCapacity}
        upgradeCost={currentUpgradeCost}
        onSellItem={onSellItem}
        onUpgradeCapacity={onUpgradeCapacity}
        coins={coins}
      />

      <ProductionModal
        isOpen={activeModal === 'production'}
        onClose={onCloseModal}
        factoryId={selectedFactoryId}
        factory={factories[selectedFactoryId]}
        inventory={inventory}
        onStartProduction={(recipeId) => onStartProduction(selectedFactoryId, recipeId)}
        onSpeedUpProduction={() => onSpeedUpProduction(selectedFactoryId)}
        onCollectProduct={(recipeId) => onCollectProduct(selectedFactoryId)}
        gems={gems}
      />

      <AnimalCareModal
        isOpen={activeModal === 'animals'}
        onClose={onCloseModal}
        animals={animals}
        inventory={inventory}
        onFeedAnimal={onFeedAnimal}
        onCollectProduce={onCollectAnimal}
        onBuildAnimalPen={onBuildAnimalPen}
        playerLevel={level}
        coins={coins}
      />

      <MarketModal
        isOpen={activeModal === 'market'}
        onClose={onCloseModal}
        orders={orders}
        inventory={inventory}
        onFulfillOrder={onFulfillOrder}
        onRefreshOrder={onRefreshOrder}
      />

      <QuestsModal
        isOpen={activeModal === 'quests'}
        onClose={onCloseModal}
        quests={quests}
        onClaimQuest={onClaimQuest}
      />

      <EventsModal
        isOpen={activeModal === 'events'}
        onClose={onCloseModal}
        festivalPoints={festivalPoints}
        onClaimMilestone={onClaimMilestone}
        claimedTiers={claimedTiers}
      />

      <DailyRewardsModal
        isOpen={activeModal === 'daily'}
        onClose={onCloseModal}
        rewards={dailyRewards}
        onClaimDaily={onClaimDaily}
        currentDay={dailyRewards.find((d) => !d.claimed)?.day || 7}
      />

      <FriendsModal
        isOpen={activeModal === 'friends'}
        onClose={onCloseModal}
        friends={friends}
        onSendGift={onSendGift}
        onHelpFriend={onHelpFriend}
        onVisitFriend={(f) => {
          setVisitingFriend(f);
          setActiveModal('visitFriend');
        }}
        onAddFriend={onAddFriend}
      />

      <VisitFriendModal
        isOpen={activeModal === 'visitFriend'}
        onClose={() => setActiveModal('friends')}
        friend={visitingFriend}
        onHelpFriend={onHelpFriend}
      />

      <ShopModal
        isOpen={activeModal === 'shop'}
        onClose={onCloseModal}
        initialTab={shopInitialTab}
        coins={coins}
        gems={gems}
        energy={energy}
        maxEnergy={maxEnergy}
        onBuySeeds={onBuySeeds}
        onBuyPlot={onBuyPlot}
        onRefillEnergy={onRefillEnergy}
        onExchangeGemsForCoins={onExchangeGemsForCoins}
        plotCount={plots.length}
      />

      <MailModal
        isOpen={activeModal === 'mail'}
        onClose={onCloseModal}
        mails={mails}
        onClaimMail={onClaimMail}
      />

      {/* World Map: เมื่อเดินทางสู่บ่อตกปลา จะเปิด FishingDockModal ทันที และสลับฟาร์มแบบไม่ต้องรีโหลด */}
      <WorldMapModal
        isOpen={activeModal === 'map'}
        onClose={onCloseModal}
        playerLevel={level}
        currentFarmId={currentFarmId}
        onSwitchFarm={onSwitchFarm}
        onTravelTo={(actionId, zoneName) => {
          if (
            actionId === 'FISHING_LAKE' ||
            actionId === 'fishing' ||
            zoneName.includes('fishing') ||
            zoneName.includes('ท่าน้ำ') ||
            zoneName.includes('ตกปลา')
          ) {
            setActiveModal('fishing');
          } else if (actionId === 'OPEN_MARKET') {
            setActiveModal('market');
          } else {
            onTravel(zoneName);
          }
        }}
      />

      {/* 🎣 หน้าต่างฉากตกปลา 3D ระดับ 4K ทะเลสาบมรกต */}
      <FishingDockModal
        isOpen={activeModal === 'fishing'}
        onClose={onCloseModal}
        energy={energy}
        onConsumeEnergy={
          onConsumeEnergy ||
          ((cost) => {
            return energy >= cost;
          })
        }
        onAddFishToInventory={onAddFishToInventory}
        onAddRewards={onAddRewards}
        inventory={inventory}
        onConsumeItems={onConsumeItems}
        gems={gems}
        luckyFisherBuff={luckyFisherBuff}
        onConsumeLuckyBuff={onConsumeLuckyBuff}
        timeOfDay={timeOfDay}
        onToggleTimeOfDay={onToggleTimeOfDay}
      />

      <BuildModal
        isOpen={activeModal === 'build'}
        onClose={onCloseModal}
        coins={coins}
        plotCount={plots.length}
        onAddPlot={onBuyPlot}
        onBuildAnimalPen={onBuildAnimalPen}
        playerLevel={level}
        onBuildDecoration={onBuildDecoration}
      />

      <SettingsModal
        isOpen={activeModal === 'settings'}
        onClose={onCloseModal}
        farmName={farmName}
        onUpdateFarmName={onUpdateFarmName}
        soundEnabled={soundEnabled}
        musicEnabled={musicEnabled}
        onToggleSound={onToggleSound}
        onToggleMusic={onToggleMusic}
        onResetGame={onResetGame}
        onReplayLoading={() => setShowLoadingScreen(true)}
        onOpenCloudSync={() => setActiveModal('cloud_sync')}
        onOpenAuth={onOpenAuth}
        currentUser={currentUser}
      />

      <CloudSyncModal
        isOpen={activeModal === 'cloud_sync'}
        onClose={onCloseModal}
        currentSnapshot={{
          coins,
          gems,
          energy,
          maxEnergy,
          level,
          xp,
          maxXp,
          farmName,
          plots,
          animals,
          factories,
          inventory,
          barnCapacity,
          quests,
          orders,
          friends,
          dailyRewards,
          festivalPoints,
          claimedTiers,
          farmLogs,
          mails,
          lastActiveTime: Date.now(),
        }}
        placedItems={(() => {
          try {
            const saved = localStorage.getItem('beam_farm_placed_items_v5');
            return saved ? JSON.parse(saved) : [];
          } catch {
            return [];
          }
        })()}
        onApplySnapshot={onApplySnapshot}
      />

      <GiftBoxModal
        isOpen={activeModal === 'gift'}
        onClose={onCloseModal}
        isReady={isGiftReady}
        countdown={giftCountdownDisplay}
        onClaimGift={onClaimGift}
      />

      <LevelUpModal
        isOpen={levelUpData.show}
        onClose={() => setLevelUpData({ show: false, level })}
        newLevel={levelUpData.level}
      />

      <LogoInfoModal
        isOpen={activeModal === 'logoInfo'}
        onClose={onCloseModal}
        farmName={farmName}
      />

      {/* Loading Screen */}
      <LoadingScreen
        isOpen={showLoadingScreen}
        onFinish={onFinishLoading}
      />
    </>
  );
};