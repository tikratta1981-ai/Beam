// src/components/modals/ShopModal.tsx

import React, { useState } from 'react';
import { X, Store, Coins, Sparkles, Plus, Check } from 'lucide-react';
import { CROPS } from '../../../data/initialData';
import { sound } from '../../../utils/audio/index';
import { AnimatedCrop3D } from '../../3d/models/props/AnimatedCrop3D';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: string;
  coins: number;
  gems: number;
  energy: number;
  maxEnergy: number;
  onBuySeeds: (cropId: string, count: number, cost: number) => void;
  onBuyPlot: () => void;
  onRefillEnergy: () => void;
  onExchangeGemsForCoins: (gemsCost: number, coinsGain: number) => void;
  plotCount: number;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'seeds',
  coins,
  gems,
  energy,
  maxEnergy,
  onBuySeeds,
  onBuyPlot,
  onRefillEnergy,
  onExchangeGemsForCoins,
  plotCount,
}) => {
  const [activeTab, setActiveTab] = useState(initialTab);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl game-wood-board rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-600/80 text-white flex flex-col max-h-[92dvh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-white shadow-lg border border-emerald-300/40">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-amber-200 drop-shadow">
                ร้านค้าฟาร์ม (Farm Store)
              </h2>
              <span className="text-xs text-amber-300/90 font-medium">
                ซื้อเมล็ดพันธุ์ ขยายแปลงเพาะปลูก และเติมพลังงาน
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-red-800/90 hover:bg-red-700 flex items-center justify-center text-white border border-red-400 active:scale-90 transition-all cursor-pointer shadow-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 my-3 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'seeds', label: '🌱 เมล็ดพันธุ์ 3D' },
            { id: 'farm', label: '🏡 แปลง & ก่อสร้าง' },
            { id: 'energy', label: '⚡ พลังงาน' },
            { id: 'coins', label: '🪙 แลกเปลี่ยนเหรียญ' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sound.playClick();
                setActiveTab(tab.id);
              }}
              className={`px-3.5 py-1.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 shadow-lg font-black scale-105 border border-white'
                  : 'bg-stone-900/70 text-amber-200/90 hover:bg-stone-800 border border-amber-900/40'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content by Tab */}
        <div className="overflow-y-auto game-scroll pr-1 flex-1">
          {/* 1. Seeds Tab (การ์ด 3D เคลื่อนไหวได้สมจริง) */}
          {activeTab === 'seeds' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-1">
              {Object.values(CROPS).map((crop) => {
                const bundleCount = 5;
                const unitCost = (crop as any).seedCost ?? (crop as any).cost ?? crop.sellPrice ?? 10;
                const bundleCost = unitCost * bundleCount;
                const canAfford = coins >= bundleCost;

                return (
                  <div
                    key={crop.id}
                    className="relative bg-gradient-to-b from-[#3a1d0d] via-[#291307] to-[#1e0d04] rounded-3xl p-3 border-2 border-[#7a421a] shadow-[0_6px_16px_rgba(0,0,0,0.55)] flex flex-col justify-between items-center text-center transition-all duration-200 hover:-translate-y-1 hover:border-amber-400 hover:shadow-[0_10px_20px_rgba(245,158,11,0.25)] group"
                  >
                    {/* แท่นวาง 3D พร้อมสปอตไลต์นุ่มนวล */}
                    <div className="relative w-full flex items-center justify-center my-1.5 min-h-[74px]">
                      {/* แสงสปอตไลต์ */}
                      <div className="absolute w-20 h-20 rounded-full bg-amber-400/15 blur-md pointer-events-none group-hover:bg-amber-300/25 transition-colors" />

                      {/* โมเดล 3D เวกเตอร์เคลื่อนไหวได้ (แก้ปัญหากล่องสี่เหลี่ยม ▯ ดอกลาเวนเดอร์ 100%) */}
                      <AnimatedCrop3D cropId={crop.id} size={72} />
                    </div>

                    {/* ชื่อพืชและระยะเวลาการเติบโต */}
                    <div className="my-1 z-10 w-full">
                      <span className="font-black text-xs sm:text-sm text-amber-100 drop-shadow block truncate">
                        {crop.thaiName}
                      </span>
                      <span className="text-[10px] text-amber-300/80 font-medium block">
                        ชุด {bundleCount} เมล็ด • โต {crop.growTimeSec} วิ
                      </span>
                    </div>

                    {/* ปุ่มซื้อสีทองนูน 3D */}
                    <button
                      disabled={!canAfford}
                      onClick={() => {
                        sound.playCoin();
                        onBuySeeds(crop.id, bundleCount, bundleCost);
                      }}
                      className={`w-full mt-2 py-2 px-3 rounded-2xl text-xs font-black shadow-lg flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer ${
                        canAfford
                          ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-400 text-stone-950 border-2 border-white'
                          : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5 text-stone-900" />
                      <span>{bundleCost.toLocaleString()}</span>
                      <span className="text-[10px] text-stone-900/80 font-bold">🪙 ซื้อ</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* 2. Farm expansion Tab (ปลดล็อกเพิ่มแปลงผักได้ไม่จำกัด) */}
          {activeTab === 'farm' && (
            <div className="flex flex-col gap-3 p-1">
              <div className="bg-gradient-to-r from-[#3a1d0d] to-[#251206] rounded-3xl p-4 border-2 border-amber-800/80 shadow-lg flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-900/60 border border-amber-500/50 flex items-center justify-center text-3xl shadow-inner">
                    🪴
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-amber-200">
                      เพิ่มแปลงเพาะปลูก 3D ใหม่ (+1 แปลง)
                    </h3>
                    <p className="text-xs text-stone-300 font-medium">
                      ปัจจุบันมี {plotCount} แปลง <span className="text-emerald-400 font-bold">(ขยายได้ไม่จำกัดจำนวน 🌱)</span>
                    </p>
                  </div>
                </div>

                <button
                  disabled={coins < 1500}
                  onClick={() => {
                    sound.playSuccessChime();
                    onBuyPlot();
                  }}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-black shadow-xl flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer ${
                    coins >= 1500
                      ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 text-stone-950 border-2 border-white'
                      : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                  }`}
                >
                  <Coins className="w-4 h-4 text-stone-900" />
                  <span>1,500 🪙</span>
                </button>
              </div>

              <div className="bg-gradient-to-r from-[#3a1d0d] to-[#251206] rounded-3xl p-4 border-2 border-amber-800/80 shadow-lg flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-900/60 border border-amber-500/50 flex items-center justify-center text-3xl shadow-inner">
                    🪵
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-amber-200">
                      รั้วคาวบอยตกแต่งฟาร์ม
                    </h3>
                    <p className="text-xs text-stone-300 font-medium">เพิ่มบรรยากาศความสวยงามให้ฟาร์มสุขใจ</p>
                  </div>
                </div>
                <span className="text-xs text-emerald-400 font-bold bg-stone-900 px-3.5 py-1.5 rounded-xl border border-emerald-500/40">
                  ติดตั้งแล้ว ✓
                </span>
              </div>
            </div>
          )}

          {/* 3. Energy Tab */}
          {activeTab === 'energy' && (
            <div className="flex flex-col gap-3 p-1">
              <div className="bg-gradient-to-r from-[#3a1d0d] to-[#251206] rounded-3xl p-4 border-2 border-amber-800/80 shadow-lg flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-900/60 border border-amber-500/50 flex items-center justify-center text-3xl shadow-inner">
                    ⚡
                  </div>
                  <div>
                    <h3 className="font-black text-sm text-amber-200">
                      ฟื้นฟูพลังงานเต็มพิกัด (+{Math.max(0, maxEnergy - energy)} ⚡)
                    </h3>
                    <p className="text-xs text-stone-300 font-medium">
                      พลังงานปัจจุบัน: {energy}/{maxEnergy}
                    </p>
                  </div>
                </div>

                <button
                  disabled={gems < 5 || energy >= maxEnergy}
                  onClick={() => {
                    sound.playSuccessChime();
                    onRefillEnergy();
                  }}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-black shadow-xl flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer ${
                    gems >= 5 && energy < maxEnergy
                      ? 'bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-white border-2 border-white'
                      : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                  }`}
                >
                  <span>5 💎 เติมทันที</span>
                </button>
              </div>
            </div>
          )}

          {/* 4. Coins / Gems Exchange Tab */}
          {activeTab === 'coins' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-1">
              <div className="bg-gradient-to-b from-[#3a1d0d] to-[#251206] rounded-3xl p-4 border-2 border-amber-800/80 shadow-lg flex items-center justify-between">
                <div>
                  <div className="text-lg font-black text-yellow-300 flex items-center gap-1">
                    <span>10,000</span> <span className="text-base">🪙</span>
                  </div>
                  <div className="text-xs text-stone-300 font-medium">หีบเหรียญทองขนาดเล็ก</div>
                </div>
                <button
                  disabled={gems < 10}
                  onClick={() => {
                    sound.playCoin();
                    onExchangeGemsForCoins(10, 10000);
                  }}
                  className="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-stone-950 font-black text-xs rounded-2xl shadow-lg border border-white active:scale-95 cursor-pointer"
                >
                  แลกด้วย 10 💎
                </button>
              </div>

              <div className="bg-gradient-to-b from-[#3a1d0d] to-[#251206] rounded-3xl p-4 border-2 border-amber-800/80 shadow-lg flex items-center justify-between">
                <div>
                  <div className="text-lg font-black text-yellow-300 flex items-center gap-1">
                    <span>50,000</span> <span className="text-base">🪙</span>
                  </div>
                  <div className="text-xs text-stone-300 font-medium">หีบเหรียญทองขนาดยักษ์</div>
                </div>
                <button
                  disabled={gems < 45}
                  onClick={() => {
                    sound.playCoin();
                    onExchangeGemsForCoins(45, 50000);
                  }}
                  className="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-stone-950 font-black text-xs rounded-2xl shadow-lg border border-white active:scale-95 cursor-pointer"
                >
                  แลกด้วย 45 💎
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};