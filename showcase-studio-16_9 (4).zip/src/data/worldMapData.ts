// src/data/worldMapData.ts

export interface WorldZone {
  id: string;
  name: string;              // ชื่อภาษาไทย
  nameEn: string;            // ชื่อภาษาอังกฤษ
  description: string;       // คำอธิบายสถานที่
  iconEmoji: string;         // ไอคอนแสดงผล
  iconBgColor?: string;      // สีพื้นหลังไอคอน
  badge?: string;            // ป้ายข้อความ เช่น "3D 4K", "เปิดบริการ", "กิจกรรม"
  badgeColor?: 'cyan' | 'green' | 'amber' | 'purple' | 'red';
  minLevel: number;          // เลเวลขั้นต่ำที่ปลดล็อก (0 = เข้าได้ทันที)
  isCurrent?: boolean;       // เป็นจุดที่ผู้เล่นอยู่ปัจจุบันหรือไม่
  actionId: string;          // รหัสคำสั่งเมื่อกด "เดินทาง" (เปิด modal หรือ แสดงข้อความ)
}

// 🔑 คีย์จำฟาร์มที่กำลังเปิดอยู่ (farm1 หรือ farm2)
export const ACTIVE_FARM_STORAGE_KEY = 'beam_farm_active_map_id';

// 🔄 ฟังก์ชันอ่านว่าผู้เล่นอยู่ฟาร์มไหน
export const getCurrentFarmId = (): string => {
  return localStorage.getItem(ACTIVE_FARM_STORAGE_KEY) || 'farm1';
};

// 🚀 ฟังก์ชันสั่งสลับฟาร์มทันทีโดยไม่ต้องโหลดหน้าใหม่ (Reactive State Sync)
export const switchFarmMap = (farmId: 'farm1' | 'farm2') => {
  localStorage.setItem(ACTIVE_FARM_STORAGE_KEY, farmId);

  // แจ้งเตือนทุกส่วนของ React UI ผ่าน CustomEvent
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('farmMapChanged', { detail: farmId }));
  }

  // 3. ปรับสถานะจุดที่อยู่ปัจจุบันในลิสต์แผนที่
  WORLD_ZONES.forEach((zone) => {
    if (zone.id === 'beam_farm') zone.isCurrent = farmId === 'farm1';
    if (zone.id === 'beam_farm_2') zone.isCurrent = farmId === 'farm2';
  });
};

const currentFarm = getCurrentFarmId();

export const WORLD_ZONES: WorldZone[] = [
  // 🏡 1. ฟาร์มหลักริมสายน้ำ (รูป farm_bg.jpg เดิม)
  {
    id: 'beam_farm',
    name: 'ฟาร์มหลักริมสายน้ำ (Farm 1)',
    nameEn: 'Beam Riverside Farm',
    description: 'ศูนย์กลางฟาร์มสุขใจ แปลงเกษตรกรรม โรงงานแปรรูป และบ้านพักชาวสวน',
    iconEmoji: '🏡',
    iconBgColor: 'bg-emerald-900/60',
    minLevel: 1,
    isCurrent: currentFarm === 'farm1',
    actionId: 'SWITCH_TO_FARM_1',
  },

  // 🏝️ 2. อาณาจักรฟาร์มเกาะมรกตแห่งใหม่ (รูป farm2_bg.jpg ใหม่)
  {
    id: 'beam_farm_2',
    name: 'อาณาเขตฟาร์มเกาะมรกต (Farm 2)',
    nameEn: 'Emerald Island Farm',
    description: 'ขยายอาณาเขตใหม่ ลานหญ้ากว้างขวาง ร่องดินธรรมชาติ และลำธารน้ำตก 3D',
    iconEmoji: '🏝️',
    iconBgColor: 'bg-teal-900/60',
    badge: 'โซนใหม่',
    badgeColor: 'amber',
    minLevel: 1,
    isCurrent: currentFarm === 'farm2',
    actionId: 'SWITCH_TO_FARM_2',
  },

  // 🏪 3. ตลาดใหญ่ใจกลางเมือง
  {
    id: 'town_square',
    name: 'ตลาดใหญ่ใจกลางเมือง',
    nameEn: 'Town Square',
    description: 'แหล่งซื้อขายผลผลิตราคาสูงและการประมูลสินค้าฟาร์ม',
    iconEmoji: '🏪',
    iconBgColor: 'bg-blue-900/60',
    badge: 'เปิดบริการ',
    badgeColor: 'green',
    minLevel: 1,
    actionId: 'OPEN_MARKET',
  },

  // 🎣 4. ท่าน้ำทะเลสาบมรกต
  {
    id: 'fishing_dock',
    name: 'ท่าน้ำทะเลสาบมรกต',
    nameEn: 'Fishing Dock',
    description: 'ตกปลาหายากและนั่งเรือชมธรรมชาติริมสายน้ำ 3D',
    iconEmoji: '🎣',
    iconBgColor: 'bg-cyan-950/60',
    badge: '3D 4K',
    badgeColor: 'cyan',
    minLevel: 1,
    actionId: 'OPEN_FISHING',
  },

  // ⛏️ 5. เหมืองแร่ภูเขาทองคำ
  {
    id: 'mountain_mine',
    name: 'เหมืองแร่ภูเขาทองคำ',
    nameEn: 'Mountain Mine',
    description: 'ขุดหาแร่ทองคำ เพชรพลอย และวัตถุดิบบวกอุปกรณ์',
    iconEmoji: '⛏️',
    iconBgColor: 'bg-amber-950/60',
    minLevel: 18,
    actionId: 'OPEN_MINE',
  },

  // 🌾 6. หุบเขาเพื่อนบ้าน
  {
    id: 'neighbor_valley',
    name: 'หุบเขาเพื่อนบ้าน',
    nameEn: 'Neighbor Valley',
    description: 'เยี่ยมชมไร่ของเพื่อน ส่งของขวัญ และช่วยเหลือฟาร์ม',
    iconEmoji: '🌾',
    iconBgColor: 'bg-orange-950/60',
    badge: 'เปิดบริการ',
    badgeColor: 'green',
    minLevel: 1,
    actionId: 'OPEN_FRIENDS',
  },

  // 🏝️ 7. หาดทรายมะพร้าวหวาน
  {
    id: 'coconut_beach',
    name: 'หาดทรายมะพร้าวหวาน',
    nameEn: 'Coconut Beach',
    description: 'สำรวจชายฝั่งทะเลเขตร้อน เก็บไข่มุก และตกปลาทะเลน้ำลึก',
    iconEmoji: '🥥',
    iconBgColor: 'bg-teal-950/60',
    badge: 'เร็วๆ นี้',
    badgeColor: 'purple',
    minLevel: 12,
    actionId: 'COMING_SOON',
  },

  // 🛶 8. ตลาดน้ำคลองบางแค
  {
    id: 'floating_market',
    name: 'ตลาดน้ำคลองบางแค',
    nameEn: 'Floating Market',
    description: 'แลกเปลี่ยนเมล็ดพันธุ์หายากและสูตรทำอาหารพื้นบ้านกับพ่อค้าเรือแจว',
    iconEmoji: '🛶',
    iconBgColor: 'bg-sky-950/60',
    badge: 'กิจกรรม',
    badgeColor: 'purple',
    minLevel: 8,
    actionId: 'COMING_SOON',
  },

  // 🍄 9. ป่าพฤกษาลึกลับ
  {
    id: 'secret_forest',
    name: 'ป่าพฤกษาลึกลับ',
    nameEn: 'Mystic Forest',
    description: 'ตามหาเห็ดทรัฟเฟิล ผลเบอร์รี่โบราณ และผึ้งป่าธรรมชาติ',
    iconEmoji: '🍄',
    iconBgColor: 'bg-green-950/60',
    minLevel: 25,
    actionId: 'COMING_SOON',
  }
];