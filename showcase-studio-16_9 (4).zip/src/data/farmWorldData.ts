// src/data/farmWorldData.ts
import { getCurrentFarmId } from './worldMapData';

export const STAGE_BASE_WIDTH = 1440;
export const STAGE_BASE_HEIGHT = 960;
export const GRID_SIZE = 32;
export const FREE_PLOT_TYPE = 'crop_plot_free';
export const FREE_PLOT_MIN = 64;

// 🔄 สลับรูปภาพพื้นหลังตามฟาร์มที่เลือกจาก WorldMap อัตโนมัติ
const activeFarmId = getCurrentFarmId();
export const FARM_BACKGROUND_IMAGE = activeFarmId === 'farm2' ? '/farm2_bg.jpg' : '/farm_bg.jpg';

export interface PlacedEntity {
  instanceId: string;
  type: string;
  name: string;
  icon: string;
  imgSrc: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation?: number;
  flipX?: boolean;
}

export const UNIQUE_FACILITY_TYPES = new Set([
  'farmhouse',
  'barn_silo',
  'truck_blue',
  'bakery_oven',
  'dairy_stall',
  'jam_house',
  'chicken_coop',
  'cow_pen',
  'pig_pen',
  'sheep',
  'goat_pen',
  'corn_3d_grand_200sqm',
  'corn_3d_plot_1',
]);

// 📍 พิกัดตั้งต้นสำหรับฟาร์ม 1 (ปรับตำแหน่งแกะและแพะให้อยู่กลางจอ มองเห็นชัดเจน)
const LAYOUT_FARM_1: PlacedEntity[] = [
  { instanceId: 'init_house', type: 'farmhouse', name: 'บ้านพักชาวสวน', icon: '🏡', imgSrc: '/buildings/farmhouse.png', x: 96, y: 64, width: 176, height: 160, rotation: 0, flipX: false },
  { instanceId: 'init_barn', type: 'barn_silo', name: 'โรงนาและยุ้งฉาง', icon: '📦', imgSrc: '/buildings/barn_silo.png', x: 288, y: 64, width: 160, height: 160, rotation: 0, flipX: false },
  { instanceId: 'init_truck', type: 'truck_blue', name: 'รถกระบะส่งของ', icon: '🚙', imgSrc: '/buildings/truck_blue.png', x: 64, y: 256, width: 112, height: 80, rotation: 0, flipX: false },
  { instanceId: 'init_well', type: 'water_well', name: 'บ่อน้ำโบราณ', icon: '⛲', imgSrc: '/buildings/water_well.png', x: 192, y: 384, width: 96, height: 96, rotation: 0, flipX: false },
  { instanceId: 'init_flower', type: 'flower_bed', name: 'แปลงดอกไม้ประดับ', icon: '🌸', imgSrc: '/buildings/flower_bed.png', x: 320, y: 400, width: 96, height: 64, rotation: 0, flipX: false },
  { instanceId: 'init_bakery', type: 'bakery_oven', name: 'เตาอบขนมปัง 3D', icon: '🍞', imgSrc: '', x: 512, y: 192, width: 120, height: 120, rotation: 0, flipX: false },
  { instanceId: 'init_dairy', type: 'dairy_stall', name: 'โรงงานนมเนย', icon: '🥛', imgSrc: '/buildings/dairy_stall.png', x: 656, y: 192, width: 112, height: 112, rotation: 0, flipX: false },
  { instanceId: 'init_jam', type: 'jam_house', name: 'ร้านแยมผลไม้', icon: '🍯', imgSrc: '/buildings/jam_house.png', x: 576, y: 336, width: 112, height: 112, rotation: 0, flipX: false },
  { instanceId: 'init_tree_apple', type: 'tree_apple', name: 'ต้นแอปเปิลผลดก', icon: '🍎', imgSrc: '/buildings/tree_apple.png', x: 736, y: 64, width: 120, height: 144, rotation: 0, flipX: false },
  { instanceId: 'init_tree_orange', type: 'tree_orange', name: 'ต้นส้มสายน้ำผึ้ง', icon: '🍊', imgSrc: '/buildings/tree_orange.png', x: 864, y: 64, width: 120, height: 144, rotation: 0, flipX: false },
  { instanceId: 'init_coop', type: 'chicken_coop', name: 'ลานไก่อารมณ์ดี 3D', icon: '🐔', imgSrc: '/buildings/chicken_coop.png', x: 1024, y: 96, width: 288, height: 192, rotation: 0, flipX: false },
  { instanceId: 'init_cow', type: 'cow_pen', name: 'คอกโคนมฮอลสไตน์', icon: '🐮', imgSrc: '/buildings/cow_pen.png', x: 1024, y: 320, width: 144, height: 144, rotation: 0, flipX: false },
  
  // 🐑 ทุ่งแกะขนปุย (ขยับมาตำแหน่ง x: 880, y: 360 เพื่อให้อยู่ในหน้าจอ มองเห็นทันที)
  { instanceId: 'init_sheep', type: 'sheep', name: 'ทุ่งแกะขนปุย', icon: '🐑', imgSrc: '/buildings/sheep.png', x: 880, y: 360, width: 144, height: 144, rotation: 0, flipX: false },
  
  // 🐐 ฟาร์มแพะนม 3D (เพิ่มใหม่ อยู่บริเวณสนามหญ้าฝั่งซ้ายข้างสระน้ำ)
  { instanceId: 'init_goat', type: 'goat_pen', name: 'ฟาร์มแพะนม 3D (ฝูง 6 ตัว)', icon: '🐐', imgSrc: '', x: 220, y: 480, width: 240, height: 180, rotation: 0, flipX: false },

  { instanceId: 'init_boat', type: 'wooden_boat', name: 'เรือพายไม้ริมตลิ่ง', icon: '🛶', imgSrc: '/buildings/wooden_boat.png', x: 64, y: 640, width: 96, height: 64, rotation: 15, flipX: false },
  { instanceId: 'corn_grand_200', type: 'corn_3d_grand_200sqm', name: 'แปลนเพาะปลูก #1 (200 ตร.ม. ท่อนปอง 3D)', icon: '🌽', imgSrc: '', x: 460, y: 560, width: 290, height: 200, rotation: 0, flipX: false },
  { instanceId: 'corn_plot_1', type: 'corn_3d_plot_1', name: 'แปลนเพาะปลูก 1 (ทางเดินหลัก 3D)', icon: '🌽', imgSrc: '', x: 520, y: 380, width: 190, height: 140, rotation: 0, flipX: false },
];

// 📍 พิกัดตั้งต้นสำหรับฟาร์ม 2
const LAYOUT_FARM_2: PlacedEntity[] = [
  { instanceId: 'init_house', type: 'farmhouse', name: 'บ้านพักชาวสวน', icon: '🏡', imgSrc: '/buildings/farmhouse.png', x: 576, y: 192, width: 176, height: 160, rotation: 0, flipX: false },
  { instanceId: 'init_barn', type: 'barn_silo', name: 'โรงนาและยุ้งฉาง', icon: '📦', imgSrc: '/buildings/barn_silo.png', x: 768, y: 192, width: 160, height: 160, rotation: 0, flipX: false },
  { instanceId: 'init_truck', type: 'truck_blue', name: 'รถกระบะส่งของ', icon: '🚙', imgSrc: '/buildings/truck_blue.png', x: 928, y: 672, width: 112, height: 80, rotation: 0, flipX: false },
  { instanceId: 'init_boat', type: 'wooden_boat', name: 'เรือพายไม้ริมตลิ่ง', icon: '🛶', imgSrc: '/buildings/wooden_boat.png', x: 384, y: 224, width: 96, height: 64, rotation: -10, flipX: false },
  { instanceId: 'init_well', type: 'water_well', name: 'บ่อน้ำโบราณ', icon: '⛲', imgSrc: '/buildings/water_well.png', x: 448, y: 288, width: 96, height: 96, rotation: 0, flipX: false },
  { instanceId: 'corn_plot_1', type: 'corn_3d_plot_1', name: 'แปลงเกษตรแปลงบน (3D)', icon: '🌽', imgSrc: '', x: 160, y: 384, width: 280, height: 190, rotation: 0, flipX: false },
  { instanceId: 'corn_grand_200', type: 'corn_3d_grand_200sqm', name: 'แปลงเกษตรแปลงล่าง (200 ตร.ม. 3D)', icon: '🌽', imgSrc: '', x: 224, y: 576, width: 320, height: 210, rotation: 0, flipX: false },
  { instanceId: 'init_coop', type: 'chicken_coop', name: 'ลานไก่อารมณ์ดี 3D', icon: '🐔', imgSrc: '/buildings/chicken_coop.png', x: 416, y: 320, width: 224, height: 160, rotation: 0, flipX: false },
  { instanceId: 'init_cow', type: 'cow_pen', name: 'คอกโคนมฮอลสไตน์', icon: '🐮', imgSrc: '/buildings/cow_pen.png', x: 448, y: 448, width: 160, height: 144, rotation: 0, flipX: false },
  { instanceId: 'init_sheep', type: 'sheep', name: 'ทุ่งแกะขนปุย', icon: '🐑', imgSrc: '/buildings/sheep.png', x: 640, y: 512, width: 160, height: 144, rotation: 0, flipX: false },
  { instanceId: 'init_goat', type: 'goat_pen', name: 'ฟาร์มแพะนม 3D (ฝูง 6 ตัว)', icon: '🐐', imgSrc: '', x: 980, y: 320, width: 240, height: 180, rotation: 0, flipX: false },
  { instanceId: 'init_bakery', type: 'bakery_oven', name: 'เตาอบขนมปัง 3D', icon: '🍞', imgSrc: '', x: 736, y: 416, width: 120, height: 120, rotation: 0, flipX: false },
  { instanceId: 'init_dairy', type: 'dairy_stall', name: 'โรงงานนมเนย', icon: '🥛', imgSrc: '/buildings/dairy_stall.png', x: 864, y: 448, width: 112, height: 112, rotation: 0, flipX: false },
  { instanceId: 'init_jam', type: 'jam_house', name: 'ร้านแยมผลไม้', icon: '🍯', imgSrc: '/buildings/jam_house.png', x: 768, y: 544, width: 112, height: 112, rotation: 0, flipX: false },
  { instanceId: 'init_flower', type: 'flower_bed', name: 'แปลงดอกไม้ประดับ', icon: '🌸', imgSrc: '/buildings/flower_bed.png', x: 672, y: 320, width: 96, height: 64, rotation: 0, flipX: false },
  { instanceId: 'init_tree_apple', type: 'tree_apple', name: 'ต้นแอปเปิลผลดก', icon: '🍎', imgSrc: '/buildings/tree_apple.png', x: 384, y: 96, width: 120, height: 144, rotation: 0, flipX: false },
  { instanceId: 'init_tree_orange', type: 'tree_orange', name: 'ต้นส้มสายน้ำผึ้ง', icon: '🍊', imgSrc: '/buildings/tree_orange.png', x: 512, y: 96, width: 120, height: 144, rotation: 0, flipX: false },
];

// เลือกส่งออก Layout ตามฟาร์มที่เลือก
export const BEAUTIFUL_DEFAULT_LAYOUT: PlacedEntity[] = activeFarmId === 'farm2' ? LAYOUT_FARM_2 : LAYOUT_FARM_1;

export interface CatalogItem {
  type: string;
  name: string;
  icon: string;
  imgSrc: string;
  width: number;
  height: number;
}

export const BUILDABLE_CATALOG: CatalogItem[] = [
  { type: 'goat_pen', name: 'ฟาร์มแพะนม 3D (ฝูง 6 ตัว)', icon: '🐐', imgSrc: '', width: 240, height: 180 },
  { type: 'sheep', name: 'ทุ่งแกะขนปุย', icon: '🐑', imgSrc: '/buildings/sheep.png', width: 144, height: 144 },
  { type: 'chicken_coop', name: 'ลานไก่อารมณ์ดี 3D', icon: '🐔', imgSrc: '/buildings/chicken_coop.png', width: 288, height: 192 },
  { type: 'cow_pen', name: 'คอกโคนมฮอลสไตน์', icon: '🐮', imgSrc: '/buildings/cow_pen.png', width: 144, height: 144 },
  { type: 'pig_pen', name: 'คอกหมูน้อยร่าเริง', icon: '🐷', imgSrc: '/buildings/pig_pen.png', width: 144, height: 144 },
  { type: 'bakery_oven', name: 'เตาอบขนมปัง 3D (มีควัน)', icon: '🍞', imgSrc: '', width: 120, height: 120 },
  { type: 'corn_3d_grand_200sqm', name: 'แปลนเพาะปลูก #1 (200 ตร.ม. ท่อนปอง 3D)', icon: '🌽', imgSrc: '', width: 290, height: 200 },
  { type: 'corn_3d_plot_1', name: 'แปลนเพาะปลูก 1 (ทางเดินหลัก 3D)', icon: '🌽', imgSrc: '', width: 190, height: 140 },
  { type: 'crop_plot_free', name: 'แปลงปลูกอิสระ (ย่อ/ขยายได้)', icon: '🌱', imgSrc: '', width: 192, height: 128 },
  { type: 'farmhouse', name: 'บ้านพักชาวสวน', icon: '🏡', imgSrc: '/buildings/farmhouse.png', width: 176, height: 160 },
  { type: 'barn_silo', name: 'โรงนาและยุ้งฉาง', icon: '📦', imgSrc: '/buildings/barn_silo.png', width: 160, height: 160 },
  { type: 'truck_blue', name: 'รถกระบะส่งของ', icon: '🚙', imgSrc: '/buildings/truck_blue.png', width: 112, height: 80 },
  { type: 'dairy_stall', name: 'โรงแปรรูปนมเนย', icon: '🥛', imgSrc: '/buildings/dairy_stall.png', width: 112, height: 112 },
  { type: 'jam_house', name: 'โรงงานแยมผลไม้', icon: '🍯', imgSrc: '/buildings/jam_house.png', width: 112, height: 112 },
  { type: 'tree_apple', name: 'ต้นแอปเปิลผลดก', icon: '🍎', imgSrc: '/buildings/tree_apple.png', width: 120, height: 144 },
  { type: 'tree_orange', name: 'ต้นส้มสายน้ำผึ้ง', icon: '🍊', imgSrc: '/buildings/tree_orange.png', width: 120, height: 144 },
  { type: 'water_well', name: 'บ่อน้ำโบราณลึกลับ', icon: '⛲', imgSrc: '/buildings/water_well.png', width: 96, height: 96 },
  { type: 'flower_bed', name: 'แปลงดอกไม้ประดับ', icon: '🌸', imgSrc: '/buildings/flower_bed.png', width: 96, height: 64 },
  { type: 'wood_bridge', name: 'สะพานไม้ข้ามคลอง', icon: '🌉', imgSrc: '/buildings/wood_bridge.png', width: 128, height: 80 },
  { type: 'wooden_boat', name: 'เรือพายไม้ริมตลิ่ง', icon: '🛶', imgSrc: '/buildings/wooden_boat.png', width: 96, height: 64 },
];