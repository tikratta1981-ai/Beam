// src/data/fishingData.ts
import { FishSpecies } from '../types/fishing';

export const LAKE_FISH_CATALOG: FishSpecies[] = [
  {
    id: 'fish_carp',
    name: 'Emerald Carp',
    thaiName: 'ปลาคาร์ปมรกต',
    icon: '🐟',
    rarity: 'common',
    minWeightKg: 1.2,
    maxWeightKg: 3.5,
    sellPrice: 35,
    xpReward: 15,
    description: 'ปลาเกล็ดเขียวประกายมรกต พบได้ชุกชุมตามริมตลิ่ง เนื้อแน่นรสหวาน นิยมนำไปต้มยำ',
    shadowSpeed: 1.2,
  },
  {
    id: 'fish_bass',
    name: 'Striped Bass',
    thaiName: 'ปลากะพงลายเสือ',
    icon: '🐠',
    rarity: 'uncommon',
    minWeightKg: 2.0,
    maxWeightKg: 5.8,
    sellPrice: 65,
    xpReward: 30,
    description: 'ปลานักล่าแห่งร่องน้ำลึก ปราดเปรียว ว่องไว และมีแรงดึงสายเบ็ดมหาศาล',
    shadowSpeed: 1.8,
  },
  {
    id: 'fish_trout',
    name: 'Rainbow Trout',
    thaiName: 'ปลาเทราต์สายรุ้ง',
    icon: '🐡',
    rarity: 'rare',
    minWeightKg: 3.0,
    maxWeightKg: 7.2,
    sellPrice: 125,
    xpReward: 60,
    description: 'ปลาหายากที่สะท้อนแสงหลากสีเมื่อต้องแสงแดด พ่อค้าในเมืองให้ราคาสูงเพื่อทำสเต๊ก',
    shadowSpeed: 2.2,
  },
  {
    id: 'fish_golden_catfish',
    name: 'Ancient Golden Catfish',
    thaiName: 'ปลาดุกทองคำโบราณ',
    icon: '✨',
    rarity: 'legendary',
    minWeightKg: 8.5,
    maxWeightKg: 19.8,
    sellPrice: 380,
    xpReward: 160,
    description: 'เจ้าแห่งทะเลสาบมรกต ลำตัวเรืองแสงสีทองคำอร่าม เชื่อกันว่าเป็นสัญลักษณ์แห่งความอุดมสมบูรณ์',
    shadowSpeed: 2.8,
  },
];

/**
 * สุ่มเลือกปลาตามสัดส่วนความน่าจะเป็น (Drop Rates)
 * Common: 45% | Uncommon: 35% | Rare: 14% | Legendary: 6%
 */
export const rollRandomFish = (): FishSpecies => {
  const roll = Math.random() * 100;
  if (roll > 94) return LAKE_FISH_CATALOG[3];      // 6% Legendary
  if (roll > 80) return LAKE_FISH_CATALOG[2];      // 14% Rare
  if (roll > 45) return LAKE_FISH_CATALOG[1];      // 35% Uncommon
  return LAKE_FISH_CATALOG[0];                     // 45% Common
};