import { AnimalPen, Plot, Factory, InventoryItem, Quest, Order, Friend, DailyReward, FarmLog } from '../types/game';
import { MailMessage } from '../components/modals/social/MailModal';

export const STORAGE_KEY = 'beam_farm_save_data_v6';
export const LEGACY_STORAGE_KEY = 'beam_farm_save_data_v5';

export const CROP_UNLOCK_LEVELS: Record<string, number> = {
  wheat: 1,
  corn: 2,
  carrot: 3,
  tomato: 5,
  strawberry: 7,
  lavender: 9,
};

export const ANIMAL_TEMPLATES: Record<string, Omit<AnimalPen, 'id'>> = {
  chicken: {
    type: 'chicken',
    name: 'Chicken Coop',
    thaiName: 'เล้าไก่อารมณ์ดี',
    icon: '🐔',
    count: 3,
    maxCount: 6,
    feedCropId: 'wheat',
    feedRequired: 2,
    produceItem: 'egg',
    produceName: 'ไข่ไก่สด',
    produceIcon: '🥚',
    produceQuantity: 3,
    durationSec: 30,
    fedAt: null,
    isReady: false,
  },
  sheep: {
    type: 'sheep',
    name: 'Sheep Pasture',
    thaiName: 'ทุ่งแกะปุยเมฆ',
    icon: '🐑',
    count: 2,
    maxCount: 4,
    feedCropId: 'wheat',
    feedRequired: 3,
    produceItem: 'wool',
    produceName: 'ขนแกะนุ่ม',
    produceIcon: '🧶',
    produceQuantity: 2,
    durationSec: 60,
    fedAt: null,
    isReady: false,
  },
  cow: {
    type: 'cow',
    name: 'Cow Pasture',
    thaiName: 'คอกวัวนมพันธุ์ดี',
    icon: '🐮',
    count: 2,
    maxCount: 4,
    feedCropId: 'corn',
    feedRequired: 2,
    produceItem: 'milk',
    produceName: 'นมโคสดแท้',
    produceIcon: '🥛',
    produceQuantity: 2,
    durationSec: 90,
    fedAt: null,
    isReady: false,
  },
};

export interface GameSnapshot {
  coins: number;
  gems: number;
  energy: number;
  maxEnergy: number;
  level: number;
  xp: number;
  maxXp: number;
  farmName: string;
  plots: Plot[];
  animals: AnimalPen[];
  factories: Record<string, Factory>;
  inventory: Record<string, InventoryItem>;
  barnCapacity: number;
  quests: Quest[];
  orders: Order[];
  friends: Friend[];
  dailyRewards: DailyReward[];
  festivalPoints: number;
  claimedTiers: number[];
  farmLogs: FarmLog[];
  mails: MailMessage[];
  nextEnergyTimestamp?: number;
  nextGiftTimestamp?: number;
  lastActiveTime?: number;
}
