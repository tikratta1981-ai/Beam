export interface GameItem {
  id: string;
  name: string;
  price: number;
  category: 'feed' | 'crop' | 'product';
  icon: string;
}

export const GAME_ITEMS: Record<string, GameItem> = {
  pig_feed: {
    id: 'pig_feed',
    name: 'อาหารหมูบดพิเศษ',
    price: 35,
    category: 'feed',
    icon: '🥣',
  },
  truffle: {
    id: 'truffle',
    name: 'เห็ดทรัฟเฟิลดำทรงคุณค่า',
    price: 120,
    category: 'product',
    icon: '🍄',
  },
};
