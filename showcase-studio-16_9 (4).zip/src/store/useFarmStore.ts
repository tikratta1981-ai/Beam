import { useSyncExternalStore } from 'react';
import { sound } from '../utils/audio';

export interface FarmState {
  coins: number;
  inventory: {
    pig_feed: number;
    truffle: number;
    [key: string]: number;
  };
  pigPen: {
    isFed: boolean;
    fedAt: number | null;
    produceCount: number;
    lastProduceAt: number | null;
  };
}

export interface FarmStore extends FarmState {
  feedPig: () => boolean;
  collectPigProduce: () => number;
  checkProduceTimer: () => void;
  sellTruffles: () => void;
}

let state: FarmState = {
  coins: 500,
  inventory: {
    pig_feed: 5,
    truffle: 0,
  },
  pigPen: {
    isFed: true,
    fedAt: Date.now(),
    produceCount: 1,
    lastProduceAt: Date.now(),
  },
};

const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((listener) => listener());
}

function updateState(partial: Partial<FarmState> | ((prev: FarmState) => Partial<FarmState>)) {
  const next = typeof partial === 'function' ? partial(state) : partial;
  state = { ...state, ...next };
  notify();
}

const actions = {
  feedPig: (): boolean => {
    if (state.inventory.pig_feed <= 0) return false;
    updateState((prev) => ({
      inventory: {
        ...prev.inventory,
        pig_feed: prev.inventory.pig_feed - 1,
      },
      pigPen: {
        ...prev.pigPen,
        isFed: true,
        fedAt: Date.now(),
      },
    }));
    try {
      sound.playAnimal('pig');
    } catch {}
    return true;
  },

  collectPigProduce: (): number => {
    const count = state.pigPen.produceCount;
    if (count <= 0) return 0;

    updateState((prev) => ({
      inventory: {
        ...prev.inventory,
        truffle: (prev.inventory.truffle || 0) + count,
      },
      pigPen: {
        ...prev.pigPen,
        produceCount: 0,
      },
    }));
    try {
      sound.playHarvest();
    } catch {}
    return count;
  },

  checkProduceTimer: () => {
    const { isFed, fedAt, produceCount } = state.pigPen;
    if (!isFed || !fedAt) return;

    // ถ้ากินอิ่มและผ่านไป 10 วินาที เพิ่มผลผลิตทรัฟเฟิล (สูงสุด 3 ชิ้น)
    const elapsed = Date.now() - fedAt;
    if (elapsed > 10000 && produceCount < 3) {
      updateState((prev) => ({
        pigPen: {
          ...prev.pigPen,
          produceCount: Math.min(3, prev.pigPen.produceCount + 1),
        },
      }));
    }
  },

  sellTruffles: () => {
    const count = state.inventory.truffle;
    if (count <= 0) return;
    const earnings = count * 120;

    updateState((prev) => ({
      coins: prev.coins + earnings,
      inventory: {
        ...prev.inventory,
        truffle: 0,
      },
    }));
    try {
      sound.playCoin();
    } catch {}
  },
};

export function useFarmStore(): FarmStore {
  const currentSnapshot = useSyncExternalStore(
    (onStoreChange) => {
      listeners.add(onStoreChange);
      return () => listeners.delete(onStoreChange);
    },
    () => state
  );

  return {
    ...currentSnapshot,
    ...actions,
  };
}
