// src/main.tsx
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
import { initSecurity } from './security';

// เริ่มต้นระบบความปลอดภัย (Web Crypto, Anti-Tamper, Rate Limiters)
initSecurity();

createRoot(document.getElementById('root')!).render(<App />);

// PWA: ลงทะเบียน service worker เฉพาะ build จริง (ไม่ทำงานตอน npm run dev)
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(console.error);
  });
}
