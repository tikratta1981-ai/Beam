// src/security/securityLog.ts

export type SecurityEventType =
  | 'hash_mismatch'
  | 'rate_limit'
  | 'invalid_input'
  | 'cheat_detected'
  | 'clock_tamper'
  | 'decrypt_fail'
  | 'cloud_sync'
  | 'reset_farm';

export interface SecurityEvent {
  id: string;
  type: SecurityEventType;
  detail: string;
  timestamp: number;
  timeStr: string;
}

const MAX_LOG_SIZE = 200;
const memoryLogs: SecurityEvent[] = [];

export function logSecurityEvent(type: SecurityEventType, detail: string): void {
  const now = Date.now();
  const event: SecurityEvent = {
    id: `sec_${now}_${Math.random().toString(36).substring(2, 7)}`,
    type,
    detail,
    timestamp: now,
    timeStr: new Date(now).toLocaleTimeString('th-TH', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }),
  };

  memoryLogs.unshift(event);
  if (memoryLogs.length > MAX_LOG_SIZE) {
    memoryLogs.pop();
  }

  // Also log in dev console for observability
  if (process.env.NODE_ENV !== 'production') {
    console.warn(`[SECURITY ${type}] ${detail}`);
  }
}

export function getSecurityLog(): SecurityEvent[] {
  return [...memoryLogs];
}

export function clearSecurityLog(): void {
  memoryLogs.length = 0;
}
