// src/security/index.ts

export * from './log/securityLog';
export * from './anti-cheat/timeGuard';
export * from './runtime/rateLimiter';
export * from './runtime/sanitizer';
export * from './runtime/integrity';
export * from './storage/crypto';
export * from './anti-cheat/antiCheat';
export * from './storage/secureStorage';

import { logSecurityEvent } from './log/securityLog';
import { monotonicClock } from './anti-cheat/timeGuard';

/**
 * กำหนดค่าและตรวจสอบสภาพแวดล้อมความปลอดภัยเริ่มต้นของแอปพลิเคชัน
 */
export function initSecurity(): void {
  // 1. ตรวจสอบ Web Crypto API
  if (typeof window !== 'undefined' && (!window.crypto || !window.crypto.subtle)) {
    console.error('[SECURITY CRITICAL] Browser does not support Web Crypto API');
    logSecurityEvent('invalid_input', 'เบราว์เซอร์ไม่รองรับ Web Crypto API');
  }

  // 2. เริ่มต้น Monotonic Clock
  monotonicClock.now();

  // 3. ตรวจสอบการหมุนเวลา
  if (monotonicClock.isTampered()) {
    logSecurityEvent('clock_tamper', 'ตรวจพบเวลาระบบถูกปรับเปลี่ยนขณะเริ่มต้นระบบ');
  }

  // 4. บันทึกเหตุการณ์เริ่มต้นระบบ
  logSecurityEvent('cloud_sync', 'ระบบความปลอดภัยระดับสถาปัตยกรรม (v6.1 Security System) เริ่มต้นทำงานสมบูรณ์');
}
