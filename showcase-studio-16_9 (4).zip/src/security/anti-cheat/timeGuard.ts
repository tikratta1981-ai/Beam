// src/security/timeGuard.ts
import { logSecurityEvent } from '../log/securityLog';

/**
 * MonotonicClock ป้องกันการปั๊มเวลาหรือหมุนนาฬิกาเครื่อง (Clock Tampering / Time Skip)
 * ใช้ performance.now() ที่เดินไปข้างหน้าอย่างเดียว ร่วมกับ boot reference time
 */
export class MonotonicClock {
  private static instance: MonotonicClock;
  private readonly bootWallTime: number;
  private readonly bootPerfTime: number;
  private lastCheckedPerfTime: number;

  constructor() {
    this.bootWallTime = Date.now();
    this.bootPerfTime = typeof performance !== 'undefined' ? performance.now() : 0;
    this.lastCheckedPerfTime = this.bootPerfTime;
  }

  public static getInstance(): MonotonicClock {
    if (!MonotonicClock.instance) {
      MonotonicClock.instance = new MonotonicClock();
    }
    return MonotonicClock.instance;
  }

  /**
   * คำนวณเวลาปัจจุบันที่ปลอดภัยจากการเปลี่ยนเวลาเครื่อง (Monotonic Timestamp)
   */
  public now(): number {
    if (typeof performance === 'undefined') {
      return Date.now();
    }
    const currentPerf = performance.now();
    // ถ้า perf ถอยหลัง (เกือบเป็นไปไม่ได้) ให้ clamp ไว้
    if (currentPerf < this.lastCheckedPerfTime) {
      logSecurityEvent('clock_tamper', 'ตรวจพบ performance.now() เดินถอยหลัง');
    } else {
      this.lastCheckedPerfTime = currentPerf;
    }

    const elapsedMs = currentPerf - this.bootPerfTime;
    return this.bootWallTime + elapsedMs;
  }

  /**
   * วัดค่าความต่าง (Drift) ระหว่างเวลาของระบบปัจจุบัน (Date.now()) เทียบกับ Monotonic Time
   */
  public drift(): number {
    const monotonicNow = this.now();
    const systemNow = Date.now();
    return Math.abs(systemNow - monotonicNow);
  }

  /**
   * ตรวจสอบว่าเวลาระบบถูกหมุนเปลี่ยนเกิน 5 นาที (300,000 ms) หรือไม่
   */
  public isTampered(): boolean {
    const maxAllowedDrift = 300000; // 5 นาที
    const d = this.drift();
    if (d > maxAllowedDrift) {
      logSecurityEvent(
        'clock_tamper',
        `ตรวจพบการหมุนเวลาเครื่องผิดปกติ (${Math.round(d / 1000)} วินาที)`
      );
      return true;
    }
    return false;
  }
}

export const monotonicClock = MonotonicClock.getInstance();
