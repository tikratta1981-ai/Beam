// src/security/crypto.ts
import { logSecurityEvent } from './securityLog';

const DEVICE_KEY_STORAGE = 'beam_farm_device_entropy_v1';
const PBKDF2_ITERATIONS = 100000;
const FIXED_SALT = new Uint8Array([
  0x62, 0x65, 0x61, 0x6d, 0x5f, 0x66, 0x61, 0x72,
  0x6d, 0x5f, 0x73, 0x65, 0x63, 0x75, 0x72, 0x65,
]);

/**
 * ดึงหรือสร้าง Device Key สุ่มผูกกับเครื่อง
 */
export function getOrCreateDeviceKey(): string {
  try {
    let key = localStorage.getItem(DEVICE_KEY_STORAGE);
    if (!key) {
      const bytes = new Uint8Array(24);
      crypto.getRandomValues(bytes);
      key = Array.from(bytes)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
      localStorage.setItem(DEVICE_KEY_STORAGE, key);
    }
    return key;
  } catch {
    return 'fallback_device_key_beam_farm_2026';
  }
}

/**
 * แปลง Passphrase เป็น AES-GCM CryptoKey ผ่าน PBKDF2 (100,000 รอบ)
 */
export async function deriveKey(passphrase?: string, salt = FIXED_SALT): Promise<CryptoKey> {
  const secret = passphrase || getOrCreateDeviceKey();
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    'PBKDF2',
    false,
    ['deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * เข้ารหัสข้อมูลด้วย AES-GCM 256-bit พร้อม IV สุ่ม 12 bytes
 */
export async function encryptSave(plain: unknown, key?: CryptoKey): Promise<string> {
  const activeKey = key || (await deriveKey());
  const enc = new TextEncoder();
  const plainText = typeof plain === 'string' ? plain : JSON.stringify(plain);

  const iv = new Uint8Array(12);
  crypto.getRandomValues(iv);

  const cipherBuffer = await crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv,
    },
    activeKey,
    enc.encode(plainText)
  );

  const cipherBytes = new Uint8Array(cipherBuffer);

  // รวม IV (12 bytes) + Ciphertext เข้าด้วยกัน
  const payload = new Uint8Array(iv.length + cipherBytes.length);
  payload.set(iv, 0);
  payload.set(cipherBytes, iv.length);

  // แปลงเป็น Base64
  let binary = '';
  for (let i = 0; i < payload.length; i++) {
    binary += String.fromCharCode(payload[i]);
  }
  return btoa(binary);
}

/**
 * ถอดรหัสข้อมูลที่เข้ารหัสด้วย AES-GCM
 */
export async function decryptSave<T = unknown>(cipherBase64: string, key?: CryptoKey): Promise<T> {
  try {
    const activeKey = key || (await deriveKey());
    const binary = atob(cipherBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    if (bytes.length < 13) {
      throw new Error('Ciphertext สั้นเกินไปหรือไม่ถูกต้อง');
    }

    const iv = bytes.slice(0, 12);
    const ciphertext = bytes.slice(12);

    const decryptedBuffer = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv,
      },
      activeKey,
      ciphertext
    );

    const dec = new TextDecoder();
    const jsonString = dec.decode(decryptedBuffer);
    return JSON.parse(jsonString) as T;
  } catch (err: any) {
    logSecurityEvent('decrypt_fail', `การถอดรหัสล้มเหลว: ${err?.message || 'Invalid key or corrupted data'}`);
    throw err;
  }
}
