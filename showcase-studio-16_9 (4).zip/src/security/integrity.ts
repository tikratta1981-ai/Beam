// src/security/integrity.ts
import { logSecurityEvent } from './securityLog';

const INTEGRITY_SALT = 'beam_farm_integrity_hmac_secret_2026';

/**
 * คำนวณ SHA-256 Checksum ของข้อมูล
 */
export async function computeChecksum(data: string | object): Promise<string> {
  const enc = new TextEncoder();
  const rawText = typeof data === 'string' ? data : JSON.stringify(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', enc.encode(rawText));
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * คำนวณ HMAC-SHA256 ลงนามข้อมูลป้องกันการปลอมแปลง
 */
export async function computeHMAC(data: string | object, secret = INTEGRITY_SALT): Promise<string> {
  const enc = new TextEncoder();
  const rawText = typeof data === 'string' ? data : JSON.stringify(data);

  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const sigBuffer = await crypto.subtle.sign('HMAC', key, enc.encode(rawText));
  const sigArray = Array.from(new Uint8Array(sigBuffer));
  return sigArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * ตรวจสอบความสมบูรณ์ของ Snapshot ว่าตรงกับ Hash และ HMAC หรือไม่
 */
export async function verifySnapshot(
  data: string | object,
  expectedHash: string,
  expectedHMAC?: string
): Promise<boolean> {
  try {
    const actualHash = await computeChecksum(data);
    if (actualHash !== expectedHash) {
      logSecurityEvent('hash_mismatch', `SHA-256 ไม่ตรงกัน (Expected: ${expectedHash.slice(0, 8)}..., Actual: ${actualHash.slice(0, 8)}...)`);
      return false;
    }

    if (expectedHMAC) {
      const actualHMAC = await computeHMAC(data);
      if (actualHMAC !== expectedHMAC) {
        logSecurityEvent('hash_mismatch', 'HMAC Signature ไม่ตรงกัน ตรวจพบการดัดแปลงข้อมูล');
        return false;
      }
    }

    return true;
  } catch (err: any) {
    logSecurityEvent('hash_mismatch', `ข้อผิดพลาดในการตรวจสอบ Integrity: ${err?.message}`);
    return false;
  }
}
