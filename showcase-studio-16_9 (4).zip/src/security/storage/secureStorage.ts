// src/security/secureStorage.ts
import { encryptSave, decryptSave } from './crypto';
import { computeChecksum, computeHMAC, verifySnapshot } from '../runtime/integrity';
import { logSecurityEvent } from '../log/securityLog';

export interface StoredEnvelope {
  version: string;
  cipher: string;
  hash: string;
  hmac: string;
  timestamp: number;
}

export interface SecureGetResult<T> {
  data: T;
  restoredFromBackup: boolean;
  reason?: string;
}

const BACKUP_COUNT = 3;

/**
 * ฟังก์ชันสร้างคีย์สำหรับเก็บ Envelope ที่เข้ารหัส แยกจากคีย์ Fast-Cache ปกติ
 */
function getEnvelopeKey(key: string): string {
  return `${key}_secure_v61`;
}

export const secureStorage = {
  /**
   * บันทึกข้อมูลแบบเข้ารหัส AES-GCM 256-bit พร้อม SHA-256 Checksum, HMAC และ Rolling Auto-Backup 3 ชุด
   */
  async set(key: string, value: any): Promise<void> {
    try {
      const envelopeKey = getEnvelopeKey(key);
      const rawJson = JSON.stringify(value);
      const hash = await computeChecksum(rawJson);
      const hmac = await computeHMAC(rawJson);
      const cipher = await encryptSave(rawJson);

      const envelope: StoredEnvelope = {
        version: '6.1',
        cipher,
        hash,
        hmac,
        timestamp: Date.now(),
      };

      const envelopeJson = JSON.stringify(envelope);

      // Rolling Backup: เลื่อน backup ชุดก่อนหน้า
      try {
        const currentData = localStorage.getItem(envelopeKey);
        if (currentData) {
          for (let i = BACKUP_COUNT - 1; i >= 1; i--) {
            const prev = localStorage.getItem(`${envelopeKey}_backup_${i - 1}`);
            if (prev) {
              localStorage.setItem(`${envelopeKey}_backup_${i}`, prev);
            }
          }
          localStorage.setItem(`${envelopeKey}_backup_0`, currentData);
        }
      } catch (err) {
        console.warn('Auto-backup rotation warning:', err);
      }

      localStorage.setItem(envelopeKey, envelopeJson);
    } catch (err: any) {
      logSecurityEvent('invalid_input', `เกิดข้อผิดพลาดในการบันทึก secureStorage: ${err?.message}`);
      throw err;
    }
  },

  /**
   * ดึงข้อมูลพร้อมถอดรหัสและตรวจสอบ Integrity หากตรวจพบข้อมูลถูกแก้ จะดึงจาก Backup อัตโนมัติ
   */
  async get<T>(key: string): Promise<SecureGetResult<T> | null> {
    const envelopeKey = getEnvelopeKey(key);
    // ตรวจสอบทั้ง envelopeKey เฉพาะ และ fallback สู่ key เดิม
    const rawStored = localStorage.getItem(envelopeKey) || localStorage.getItem(key);

    // 1. ตรวจสอบ Envelope ปกติ
    if (rawStored) {
      try {
        const parsed = JSON.parse(rawStored);
        if (parsed && parsed.cipher && parsed.hash) {
          const envelope = parsed as StoredEnvelope;
          const decryptedJson = await decryptSave<string>(envelope.cipher);

          const isValid = await verifySnapshot(decryptedJson, envelope.hash, envelope.hmac);
          if (isValid) {
            const data = typeof decryptedJson === 'string' ? JSON.parse(decryptedJson) : decryptedJson;
            return {
              data: data as T,
              restoredFromBackup: false,
            };
          } else {
            logSecurityEvent('hash_mismatch', 'Checksum หรือ HMAC ของข้อมูลบันทึกไม่ตรงกับความจริง');
          }
        }
      } catch (err: any) {
        logSecurityEvent('decrypt_fail', `ไม่สามารถถอดรหัสเซฟหลักได้: ${err?.message}`);
      }
    }

    // 2. หากข้อมูลหลักเสียหาย หรือตรวจไม่ผ่าน ให้พยายามกู้คืนจาก Rolling Backup 3 ชุด
    for (let i = 0; i < BACKUP_COUNT; i++) {
      const backupRaw =
        localStorage.getItem(`${envelopeKey}_backup_${i}`) ||
        localStorage.getItem(`${key}_backup_${i}`);
      if (backupRaw) {
        try {
          const envelope: StoredEnvelope = JSON.parse(backupRaw);
          const decryptedJson = await decryptSave<string>(envelope.cipher);
          const isValid = await verifySnapshot(decryptedJson, envelope.hash, envelope.hmac);

          if (isValid) {
            const data = typeof decryptedJson === 'string' ? JSON.parse(decryptedJson) : decryptedJson;
            logSecurityEvent('cheat_detected', `กู้คืนข้อมูลสำเร็จจาก Auto-Backup #${i + 1}`);

            // กู้คืนทับตำแหน่งหลัก
            localStorage.setItem(envelopeKey, backupRaw);

            return {
              data: data as T,
              restoredFromBackup: true,
              reason: `พบข้อมูลเสียหาย กู้คืนอัตโนมัติจากชุดสำรอง #${i + 1}`,
            };
          }
        } catch {}
      }
    }

    // 3. Fallback สำหรับ Save เก่า (Plain JSON ที่ยังไม่ได้เข้ารหัส)
    const plainStored = localStorage.getItem(key);
    if (plainStored) {
      try {
        const plainData = JSON.parse(plainStored);
        if (plainData && typeof plainData === 'object' && !plainData.cipher) {
          // แปลงและเก็บเข้า secure envelope ทันทีในพื้นหลัง
          this.set(key, plainData).catch(() => {});
          return {
            data: plainData as T,
            restoredFromBackup: false,
          };
        }
      } catch {}
    }

    return null;
  },

  /**
   * ลบข้อมูลและชุด Backup ทั้งหมด
   */
  async remove(key: string): Promise<void> {
    const envelopeKey = getEnvelopeKey(key);
    localStorage.removeItem(key);
    localStorage.removeItem(envelopeKey);
    for (let i = 0; i < BACKUP_COUNT; i++) {
      localStorage.removeItem(`${envelopeKey}_backup_${i}`);
      localStorage.removeItem(`${key}_backup_${i}`);
    }
  },

  /**
   * ส่งออก Save ที่เข้ารหัสเป็น Blob สำหรับ Cloud Backup
   */
  async exportEncrypted(key: string): Promise<Blob> {
    const envelopeKey = getEnvelopeKey(key);
    const raw = localStorage.getItem(envelopeKey) || localStorage.getItem(key) || '';
    return new Blob([raw], { type: 'application/json' });
  },
};
