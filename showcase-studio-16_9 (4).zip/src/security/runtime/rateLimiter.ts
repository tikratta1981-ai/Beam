// src/security/rateLimiter.ts
import { logSecurityEvent } from '../log/securityLog';

/**
 * Token Bucket Rate Limiter
 * ควบคุมความถี่การเรียกใช้งานทรัพยากรที่อาจถูกโจมตีด้วย Replay / Spam เช่น AI Chat, TTS, Cloud Sync
 */
export class RateLimiter {
  private tokens: number;
  private readonly maxTokens: number;
  private readonly refillPerMs: number;
  private lastRefill: number;
  private readonly name: string;

  constructor(maxTokens: number, refillPerSec: number, name = 'rate_limiter') {
    this.maxTokens = maxTokens;
    this.tokens = maxTokens;
    this.refillPerMs = refillPerSec / 1000;
    this.lastRefill = Date.now();
    this.name = name;
  }

  private refill(): void {
    const now = Date.now();
    const elapsed = now - this.lastRefill;
    if (elapsed > 0) {
      this.tokens = Math.min(this.maxTokens, this.tokens + elapsed * this.refillPerMs);
      this.lastRefill = now;
    }
  }

  public tryConsume(cost = 1): boolean {
    this.refill();
    if (this.tokens >= cost) {
      this.tokens -= cost;
      return true;
    }

    logSecurityEvent('rate_limit', `คำขอเกินโควตาสำหรับ [${this.name}] (${this.tokens.toFixed(1)}/${this.maxTokens})`);
    return false;
  }

  public getRemaining(): number {
    this.refill();
    return Math.floor(this.tokens);
  }
}

// 1. AI Chat Limiter: สูงสุด 10 โทเคน, คืนโทเคน 1 ครั้งทุก 3 วินาที (1/3 ต่อวิ)
export const aiChatLimiter = new RateLimiter(10, 1 / 3, 'ai_chat');

// 2. TTS Voice Limiter: สูงสุด 6 ครั้ง, คืนโทเคน 1 ครั้งทุก 2 วินาที (1/2 ต่อวิ)
export const ttsLimiter = new RateLimiter(6, 1 / 2, 'tts_voice');

// 3. Cloud Sync Limiter: สูงสุด 3 ครั้ง, คืนโทเคน 1 ครั้งทุก 60 วินาที (1/60 ต่อวิ)
export const cloudSyncLimiter = new RateLimiter(3, 1 / 60, 'cloud_sync');
