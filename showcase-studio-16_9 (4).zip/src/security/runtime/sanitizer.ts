// src/security/sanitizer.ts
import { logSecurityEvent } from '../log/securityLog';

const FORBIDDEN_PROMPT_PATTERNS = [
  /ignore\s+(all\s+)?previous/i,
  /system\s*:/i,
  /คุณคือ\s*ai\s*อื่น/i,
  /jailbreak/i,
  /\{\{.*\}\}/, // Template injection
  /<script[\s\S]*?>[\s\S]*?<\/script>/gi,
  /javascript\s*:/i,
  /onerror\s*=/i,
  /onload\s*=/i,
  /eval\s*\(/i,
  /function\s*\(/i,
];

/**
 * แปลง HTML entity ป้องกัน Cross-Site Scripting (XSS)
 */
export function escapeHTML(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * กรองข้อความทั่วไป ลบอักขระควบคุม (Control Characters) และ Zero-Width Space
 */
export function sanitizeText(input: string, maxLen = 200): string {
  if (typeof input !== 'string') return '';

  // ตัด Zero-width, Control characters, และแท็กอันตราย
  let cleaned = input
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // Zero-width spaces
    .replace(/[\x00-\x1F\x7F]/g, '') // Control characters
    .trim();

  // จำกัดการใส่อีโมจิรัวเกินไป (Emoji Flood: ติดกันเกิน 5 ตัว -> ยุบเหลือ 1)
  cleaned = cleaned.replace(
    /([\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1FA00}-\u{1FAFF}]){5,}/gu,
    '$1'
  );

  return cleaned.substring(0, maxLen);
}

/**
 * กรองชื่อฟาร์ม อนุญาตเฉพาะภาษาไทย อังกฤษ ตัวเลข ช่องว่าง และเครื่องหมายพื้นฐาน
 * ความยาวไม่เกิน 20 ตัวอักษร
 */
export function sanitizeFarmName(name: string): string {
  if (typeof name !== 'string') return 'My Cozy Farm';

  const sanitized = sanitizeText(name, 20)
    .replace(/[<>'";\\/`$={}]/g, '')
    .trim();

  if (sanitized.length === 0) {
    return 'My Cozy Farm';
  }

  return sanitized;
}

/**
 * ตรวจและกรองคำถามที่จะส่งไปยัง AI นายชด ป้องกัน Prompt Injection
 */
export function sanitizeChatQuery(query: string): string {
  if (typeof query !== 'string') return '';

  const cleaned = sanitizeText(query, 500);

  // ตรวจสอบ Forbidden Patterns
  for (const pattern of FORBIDDEN_PROMPT_PATTERNS) {
    if (pattern.test(cleaned)) {
      logSecurityEvent('invalid_input', `ตรวจพบคำถาม AI ผิดปกติ (Prompt Injection Guard): ${cleaned.substring(0, 30)}...`);
      return 'ลุงชดอยากชวนคุยเรื่องฟาร์ม พืชผัก สัตว์เลี้ยง และการทำสวนมากกว่านะหลานเอ๊ย!';
    }
  }

  return cleaned;
}
