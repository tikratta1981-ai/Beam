// src/security/antiCheat.ts
import { GameSnapshot } from '../data/gameConstants';
import { logSecurityEvent } from './securityLog';

export interface ValidationResult {
  valid: boolean;
  reason?: string;
  sanitized: GameSnapshot;
}

const LIMITS = {
  MAX_COINS: 999_999_999,
  MAX_GEMS: 999_999,
  MAX_LEVEL: 99,
  MAX_BARN_CAPACITY: 10_000,
  MIN_BARN_CAPACITY: 30,
  MAX_ITEM_COUNT: 99_999,
  MAX_PLOTS: 100,
  MAX_ANIMALS: 50,
  MAX_FACTORIES: 20,
  MAX_ORDERS: 20,
  MAX_OFFLINE_SECONDS: 43_200, // 12 ชั่วโมง สูงสุด
};

function getMaxXpForLevel(lvl: number): number {
  return Math.round(100 * Math.pow(1.35, Math.max(0, lvl - 1)));
}

/**
 * แปลงค่าให้เป็น Safe Integer ภายในช่วงที่กำหนด
 */
function clampInt(val: any, min: number, max: number, defaultVal: number): { value: number; tampered: boolean } {
  const num = Math.floor(Number(val));
  if (isNaN(num)) return { value: defaultVal, tampered: true };
  if (num < min) return { value: min, tampered: true };
  if (num > max) return { value: max, tampered: true };
  return { value: num, tampered: false };
}

export function validateSnapshot(raw: any): ValidationResult {
  let wasTampered = false;
  const reasons: string[] = [];

  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      valid: false,
      reason: 'ข้อมูล Snapshot เสียหายหรือไม่ถูกต้อง',
      sanitized: {} as GameSnapshot,
    };
  }

  // 1. Coins Check
  const coinsCheck = clampInt(raw.coins, 0, LIMITS.MAX_COINS, 500);
  if (coinsCheck.tampered) {
    wasTampered = true;
    reasons.push('เหรียญทองอยู่นอกช่วงที่กำหนด');
  }
  const coins = coinsCheck.value;

  // 2. Gems Check
  const gemsCheck = clampInt(raw.gems, 0, LIMITS.MAX_GEMS, 10);
  if (gemsCheck.tampered) {
    wasTampered = true;
    reasons.push('เพชรอยู่นอกช่วงที่กำหนด');
  }
  const gems = gemsCheck.value;

  // 3. Level & XP Check
  const levelCheck = clampInt(raw.level, 1, LIMITS.MAX_LEVEL, 1);
  if (levelCheck.tampered) {
    wasTampered = true;
    reasons.push('เลเวลไม่ถูกต้อง');
  }
  const level = levelCheck.value;

  // Strict Max XP (ต้องคำนวณตามสูตรของเกมเท่านั้น ป้องกันการดัดแปลง)
  const expectedMaxXp = getMaxXpForLevel(level);
  const maxXp = expectedMaxXp;
  if (Number(raw.maxXp) !== expectedMaxXp) {
    wasTampered = true;
  }

  const xpCheck = clampInt(raw.xp, 0, maxXp - 1, 0);
  if (xpCheck.tampered) {
    wasTampered = true;
    reasons.push('ค่า XP ไม่ถูกต้องสำหรับเลเวลปัจจุบัน');
  }
  const xp = xpCheck.value;

  // 4. Energy Check
  const expectedMaxEnergy = 30 + (level - 1) * 2;
  const maxEnergy = expectedMaxEnergy;
  const energyCheck = clampInt(raw.energy, 0, maxEnergy * 2, maxEnergy);
  if (energyCheck.tampered || Number(raw.maxEnergy) !== expectedMaxEnergy) {
    wasTampered = true;
    reasons.push('ค่าพลังงานผิดปกติ');
  }
  const energy = energyCheck.value;

  // 5. Barn Capacity Check
  const barnCheck = clampInt(raw.barnCapacity, LIMITS.MIN_BARN_CAPACITY, LIMITS.MAX_BARN_CAPACITY, 250);
  if (barnCheck.tampered) {
    wasTampered = true;
    reasons.push('ความจุโรงนาไม่ถูกต้อง');
  }
  const barnCapacity = barnCheck.value;

  // 6. Inventory Clamping & Barn Limit Check
  const inventory: Record<string, { count: number; [key: string]: any }> = {};
  let totalItemCount = 0;

  if (raw.inventory && typeof raw.inventory === 'object') {
    for (const key of Object.keys(raw.inventory)) {
      if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
        wasTampered = true;
        continue;
      }

      const it = raw.inventory[key];
      if (it && typeof it === 'object') {
        const cCheck = clampInt(it.count, 0, LIMITS.MAX_ITEM_COUNT, 0);
        if (cCheck.tampered) wasTampered = true;

        inventory[key] = {
          ...it,
          count: cCheck.value,
        };
        totalItemCount += cCheck.value;
      }
    }
  }

  // ป้องกันการโกงไอเทมรวมล้นโรงนา
  if (totalItemCount > barnCapacity) {
    wasTampered = true;
    reasons.push(`จำนวนไอเทมรวม (${totalItemCount}) เกินความจุโรงนา (${barnCapacity})`);
  }

  // 7. Array Validation & Clamping
  const now = Date.now();

  // Plots
  if (Array.isArray(raw.plots) && raw.plots.length > LIMITS.MAX_PLOTS) wasTampered = true;
  const rawPlots = Array.isArray(raw.plots) ? raw.plots.slice(0, LIMITS.MAX_PLOTS) : [];
  const plots = rawPlots.map((p: any, idx: number) => {
    const plantedAt = typeof p.plantedAt === 'number' && p.plantedAt <= now + 60000 ? p.plantedAt : null;
    if (p.plantedAt && p.plantedAt > now + 60000) wasTampered = true;

    return {
      id: typeof p.id === 'number' ? p.id : idx,
      cropId: typeof p.cropId === 'string' ? p.cropId : null,
      plantedAt,
      isReady: Boolean(p.isReady),
      watered: Boolean(p.watered),
      x: typeof p.x === 'number' ? Math.max(0, Math.min(1440, Math.round(p.x))) : undefined,
      y: typeof p.y === 'number' ? Math.max(0, Math.min(960, Math.round(p.y))) : undefined,
      width: typeof p.width === 'number' ? p.width : undefined,
      height: typeof p.height === 'number' ? p.height : undefined,
    };
  });

  // Animals
  if (Array.isArray(raw.animals) && raw.animals.length > LIMITS.MAX_ANIMALS) wasTampered = true;
  const rawAnimals = Array.isArray(raw.animals) ? raw.animals.slice(0, LIMITS.MAX_ANIMALS) : [];
  const seenAnimalIds = new Set<string>();
  const animals: any[] = [];

  rawAnimals.forEach((a: any, idx: number) => {
    if (!a) return;
    const penType = a.type || a.animalType || 'chicken';
    const validPenType = ['cow', 'chicken', 'pig', 'sheep', 'goat'].includes(penType) ? penType : 'chicken';
    let penId = typeof a.id === 'string' && a.id.trim() ? a.id.trim() : `pen_${validPenType}_${idx}`;
    if (seenAnimalIds.has(penId)) {
      // ป้องกัน duplicate id ถ้าพบ id ซ้ำ
      penId = `${penId}_${idx}`;
    }
    seenAnimalIds.add(penId);

    const fedAt = typeof a.fedAt === 'number' && a.fedAt <= now + 60000 ? a.fedAt : null;
    if (a.fedAt && a.fedAt > now + 60000) wasTampered = true;

    animals.push({
      id: penId,
      type: validPenType,
      name: typeof a.name === 'string' ? a.name : `${validPenType} Pen`,
      thaiName: typeof a.thaiName === 'string' ? a.thaiName : `คอก${validPenType}`,
      icon: typeof a.icon === 'string' ? a.icon : '🐾',
      count: clampInt(a.count, 1, 20, 2).value,
      maxCount: clampInt(a.maxCount, 2, 50, 4).value,
      fedAt,
      durationSec: Math.max(5, Number(a.durationSec || a.produceIntervalSec) || 30),
      produceItem: typeof a.produceItem === 'string' ? a.produceItem : (a.produceItemId || 'produce'),
      produceName: typeof a.produceName === 'string' ? a.produceName : 'ผลผลิต',
      produceIcon: typeof a.produceIcon === 'string' ? a.produceIcon : '📦',
      produceQuantity: clampInt(a.produceQuantity, 1, 10, 2).value,
      feedCropId: typeof a.feedCropId === 'string' ? a.feedCropId : 'wheat',
      feedRequired: clampInt(a.feedRequired, 1, 10, 2).value,
      isReady: typeof a.isReady === 'boolean' ? a.isReady : false,
    });
  });

  // Orders
  if (Array.isArray(raw.orders) && raw.orders.length > LIMITS.MAX_ORDERS) wasTampered = true;
  const orders = Array.isArray(raw.orders) ? raw.orders.slice(0, LIMITS.MAX_ORDERS) : [];

  // Factories
  if (Array.isArray(raw.factories) && raw.factories.length > LIMITS.MAX_FACTORIES) wasTampered = true;
  const factories = Array.isArray(raw.factories) ? raw.factories.slice(0, LIMITS.MAX_FACTORIES) : [];

  // 8. Time-Skip Guard (ทั้งอนาคตและอดีต)
  const minAllowedTime = now - LIMITS.MAX_OFFLINE_SECONDS * 1000;
  const maxAllowedTime = now + 60_000; // อนุญาตให้ Clock drift ได้ 1 นาที
  let lastActiveTime = Number(raw.lastActiveTime ?? now);

  if (isNaN(lastActiveTime) || lastActiveTime > maxAllowedTime) {
    lastActiveTime = now;
    wasTampered = true;
    reasons.push('เวลาเซฟล่วงหน้าเกินเวลาจริง');
  } else if (lastActiveTime < minAllowedTime) {
    // ป้องกันการโกงเร่งเวลา Offline ย้อนหลังเกินกำหนด
    lastActiveTime = minAllowedTime;
    wasTampered = true;
    reasons.push('เวลาเซฟย้อนหลังเกินโควตาออฟไลน์สูงสุด');
  }

  // สร้าง Sanitized Snapshot ด้วย Whitelist เท่านั้น (ตัดฟิลด์แปลกปลอมออก 100%)
  const sanitizedSnapshot: GameSnapshot = {
    coins,
    gems,
    level,
    xp,
    maxXp,
    energy,
    maxEnergy,
    barnCapacity,
    inventory,
    plots,
    animals,
    factories,
    orders,
    lastActiveTime,
  } as GameSnapshot;

  if (wasTampered) {
    const reasonText = reasons.length > 0 ? reasons.join(', ') : 'โครงสร้างข้อมูลถูกดัดแปลง';
    logSecurityEvent('cheat_detected', `ปรับค่าข้อมูลที่ผิดปกติ: ${reasonText}`);
    return {
      valid: false,
      reason: reasonText,
      sanitized: sanitizedSnapshot,
    };
  }

  return {
    valid: true,
    sanitized: sanitizedSnapshot,
  };
}