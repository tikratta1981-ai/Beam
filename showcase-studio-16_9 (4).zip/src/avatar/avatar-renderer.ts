import { ThaiVisemes, TMJState, RigPin } from '../types/viseme';
import { HairAndRigEngine } from '../physics/hair-rig';

export const DEFAULT_RIG_PINS: RigPin[] = [
  { id: 'upper-lip', name: 'Upper Lip', thaiLabel: 'ริมฝีปากบน', normX: 0.5, normY: 0.63, color: '#ffd700' },
  { id: 'lower-lip', name: 'Lower Lip', thaiLabel: 'ริมฝีปากล่าง', normX: 0.5, normY: 0.69, color: '#ffd700' },
  { id: 'left-corner', name: 'Left Corner', thaiLabel: 'มุมปากซ้าย', normX: 0.42, normY: 0.66, color: '#ffea75' },
  { id: 'right-corner', name: 'Right Corner', thaiLabel: 'มุมปากขวา', normX: 0.58, normY: 0.66, color: '#ffea75' },
  { id: 'chin-tip', name: 'Chin Tip', thaiLabel: 'ปลายคาง', normX: 0.5, normY: 0.82, color: '#f3ba2f' },
  { id: 'philtrum', name: 'Philtrum', thaiLabel: 'ร่องริมฝีปาก', normX: 0.5, normY: 0.57, color: '#e6c342' },
];

export class AvatarRenderer {
  private blinkTimer: number = 0;
  private isBlinking: boolean = false;
  private blinkProgress: number = 0; // 0 = open, 1 = fully closed
  private nextBlinkTime: number = 2.5;

  public update(dt: number) {
    this.blinkTimer += dt;
    if (!this.isBlinking && this.blinkTimer >= this.nextBlinkTime) {
      this.isBlinking = true;
      this.blinkProgress = 0;
      this.blinkTimer = 0;
      this.nextBlinkTime = 2.2 + Math.random() * 2.8; // Blink every 2.2-5.0s
    }

    if (this.isBlinking) {
      this.blinkProgress += dt * 8.0; // Rapid blink (~120ms)
      if (this.blinkProgress >= 1.0) {
        this.blinkProgress = 0;
        this.isBlinking = false;
      }
    }
  }

  public triggerBlink() {
    this.isBlinking = true;
    this.blinkProgress = 0;
  }

  public render(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    tmj: TMJState,
    visemes: ThaiVisemes,
    pins: RigPin[],
    hairRig: HairAndRigEngine,
    mode: 'biomechanical' | 'realistic' | 'anime',
    showPins: boolean
  ) {
    ctx.save();

    // Studio Center Reference coordinates
    const cx = width * 0.48 + tmj.swayX * 1.8;
    const cy = height * 0.48 + tmj.swayY * 1.5;
    const scale = Math.min(width, height) * 0.0028;

    ctx.translate(cx, cy);
    ctx.rotate(tmj.swayZ * 0.03);

    // 1. Cybernetic Neck & Armature
    this.renderNeckAndShoulders(ctx, scale, tmj, mode);

    // 2. Hair physics (behind head layer)
    hairRig.update(tmj, 0, -20 * scale, 0.016);
    this.renderHairStrands(ctx, hairRig, scale, mode);

    // 3. Head Contour & Biomechanical Plates
    this.renderCranialStructure(ctx, scale, tmj, mode);

    // 4. Eyes & Eyelids (Blink mechanics)
    this.renderEyes(ctx, scale, tmj, mode);

    // 5. Thai Viseme Lip & Jaw Articulation
    this.renderMouthAndLips(ctx, scale, tmj, visemes, pins);

    // 6. 6 Golden Draggable Pins (if enabled)
    if (showPins) {
      this.renderCalibrationPins(ctx, scale, pins);
    }

    ctx.restore();
  }

  private renderNeckAndShoulders(
    ctx: CanvasRenderingContext2D,
    scale: number,
    tmj: TMJState,
    mode: string
  ) {
    const breath = Math.sin(tmj.respirationPhase) * 4 * scale;

    // Trapezius and Shoulder contours
    ctx.beginPath();
    ctx.moveTo(-140 * scale, (140 + breath) * scale);
    ctx.quadraticCurveTo(-70 * scale, 90 * scale, -38 * scale, 50 * scale);
    ctx.lineTo(38 * scale, 50 * scale);
    ctx.quadraticCurveTo(70 * scale, 90 * scale, 140 * scale, (140 + breath) * scale);
    ctx.lineTo(150 * scale, 240 * scale);
    ctx.lineTo(-150 * scale, 240 * scale);
    ctx.closePath();

    const grad = ctx.createLinearGradient(0, 50 * scale, 0, 240 * scale);
    if (mode === 'biomechanical') {
      grad.addColorStop(0, '#102230');
      grad.addColorStop(0.5, '#0b1620');
      grad.addColorStop(1, '#050c12');
    } else {
      grad.addColorStop(0, '#2a201c');
      grad.addColorStop(1, '#15100e');
    }
    ctx.fillStyle = grad;
    ctx.fill();

    // Metallic Cervical Spine Armor Plates
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, 45 * scale);
    ctx.lineTo(0, 130 * scale);
    ctx.stroke();

    [-25, -10, 5, 20].forEach(y => {
      ctx.beginPath();
      ctx.arc(0, (70 + y) * scale, 16 * scale, 0, Math.PI);
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.35)';
      ctx.stroke();
    });
  }

  private renderHairStrands(
    ctx: CanvasRenderingContext2D,
    hairRig: HairAndRigEngine,
    scale: number,
    mode: string
  ) {
    ctx.save();
    ctx.lineWidth = 4 * scale;
    ctx.lineCap = 'round';

    hairRig.hairStrands.forEach((strand, idx) => {
      ctx.beginPath();
      ctx.moveTo(strand[0].x * scale * 0.05, strand[0].y * scale * 0.05);
      for (let i = 1; i < strand.length; i++) {
        const p0 = strand[i - 1];
        const p1 = strand[i];
        const midX = ((p0.x + p1.x) / 2) * scale * 0.05;
        const midY = ((p0.y + p1.y) / 2) * scale * 0.05;
        ctx.quadraticCurveTo(p0.x * scale * 0.05, p0.y * scale * 0.05, midX, midY);
      }

      ctx.strokeStyle = mode === 'biomechanical'
        ? `rgba(0, ${180 + idx * 15}, ${230 + idx * 5}, 0.75)`
        : '#1c1512';
      ctx.stroke();
    });
    ctx.restore();
  }

  private renderCranialStructure(
    ctx: CanvasRenderingContext2D,
    scale: number,
    tmj: TMJState,
    mode: string
  ) {
    // Cranial Dome & Face Contour
    ctx.save();
    ctx.beginPath();
    // Top of skull
    ctx.arc(0, -50 * scale, 68 * scale, Math.PI, 0);
    // Right temple down to right cheekbone (Zygomatic)
    ctx.quadraticCurveTo(72 * scale, 0, 58 * scale, 35 * scale);
    // Right jawline to chin (displaced by TMJ jaw rotation)
    const chinY = (75 + tmj.jawAngle * 55 + tmj.jawTranslationY * 1.8) * scale;
    ctx.quadraticCurveTo(42 * scale, chinY - 10 * scale, 0, chinY);
    // Left jawline from chin to left cheekbone
    ctx.quadraticCurveTo(-42 * scale, chinY - 10 * scale, -58 * scale, 35 * scale);
    // Left cheekbone to temple
    ctx.quadraticCurveTo(-72 * scale, 0, -68 * scale, -50 * scale);
    ctx.closePath();

    // Shading
    const faceGrad = ctx.createRadialGradient(0, -10 * scale, 20 * scale, 0, 0, 95 * scale);
    if (mode === 'biomechanical') {
      faceGrad.addColorStop(0, '#1c3344');
      faceGrad.addColorStop(0.65, '#12222e');
      faceGrad.addColorStop(1, '#0b1620');
      ctx.fillStyle = faceGrad;
      ctx.fill();

      // Cybernetic Circuit Traces & Biometric Markings
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.45)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-52 * scale, -30 * scale);
      ctx.lineTo(-42 * scale, -20 * scale);
      ctx.lineTo(-42 * scale, 15 * scale);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(52 * scale, -30 * scale);
      ctx.lineTo(42 * scale, -20 * scale);
      ctx.lineTo(42 * scale, 15 * scale);
      ctx.stroke();
    } else {
      // Warm realistic tone
      faceGrad.addColorStop(0, '#f2d6c1');
      faceGrad.addColorStop(0.7, '#dfb99c');
      faceGrad.addColorStop(1, '#b8896a');
      ctx.fillStyle = faceGrad;
      ctx.fill();
    }

    // Border
    ctx.strokeStyle = mode === 'biomechanical' ? 'rgba(0, 240, 255, 0.8)' : '#8c6348';
    ctx.lineWidth = 2 * scale;
    ctx.stroke();
    ctx.restore();
  }

  private renderEyes(
    ctx: CanvasRenderingContext2D,
    scale: number,
    tmj: TMJState,
    mode: string
  ) {
    const blink = this.isBlinking ? Math.sin(this.blinkProgress * Math.PI) : 0;
    const eyeY = -12 * scale;
    const eyeSpacing = 30 * scale;

    [-eyeSpacing, eyeSpacing].forEach(eyeX => {
      ctx.save();
      ctx.translate(eyeX, eyeY);

      // Eyebrow
      ctx.beginPath();
      ctx.moveTo(-16 * scale, -14 * scale);
      ctx.quadraticCurveTo(0, -22 * scale, 18 * scale, -15 * scale);
      ctx.strokeStyle = mode === 'biomechanical' ? '#00f0ff' : '#452a1a';
      ctx.lineWidth = 3 * scale;
      ctx.lineCap = 'round';
      ctx.stroke();

      // Eye socket & sclera
      ctx.beginPath();
      const openHeight = 11 * scale * (1 - blink * 0.95);
      ctx.ellipse(0, 0, 16 * scale, Math.max(1, openHeight), 0, 0, Math.PI * 2);
      ctx.fillStyle = mode === 'biomechanical' ? '#0a1e2a' : '#fafafa';
      ctx.fill();
      ctx.strokeStyle = mode === 'biomechanical' ? '#00d4ff' : '#6a4e3d';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Iris & Pupil (only if eye isn't closed)
      if (blink < 0.85) {
        ctx.beginPath();
        const pupilX = tmj.swayX * 0.25 * scale;
        ctx.arc(pupilX, 0, 7 * scale, 0, Math.PI * 2);
        ctx.fillStyle = mode === 'biomechanical' ? '#00f0ff' : '#402919';
        ctx.fill();

        // High-tech pupil reticle or pupil center
        ctx.beginPath();
        ctx.arc(pupilX, 0, 3 * scale, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
      }

      ctx.restore();
    });
  }

  private renderMouthAndLips(
    ctx: CanvasRenderingContext2D,
    scale: number,
    tmj: TMJState,
    visemes: ThaiVisemes,
    pins: RigPin[]
  ) {
    ctx.save();

    // Base Mouth origin
    const baseMouthY = 44 * scale;
    // Jaw rotation and translation pushes the lower lip & chin down
    const jawDrop = (tmj.jawAngle * 70 + tmj.jawTranslationY * 2.2) * scale;

    // Viseme modifiers:
    // - pharynxOpen (อา/อะ): wide vertical opening
    const pharynxOpenFactor = visemes.pharynxOpen * 28 * scale;
    // - zygoSpread (อี/เอ): wide horizontal stretching of corners
    const zygoWidth = visemes.zygoSpread * 22 * scale;
    // - orbicRound (อู/โอ): narrows corners and rounds opening
    const orbicNarrow = visemes.orbicRound * 14 * scale;
    // - lipLock (ม/บ/พ): tight seal, flat horizontal line
    const lockTightness = visemes.lipLock;

    const cornerX = (28 * scale + zygoWidth - orbicNarrow);
    const topLipY = baseMouthY - 2 * scale;
    const bottomLipY = baseMouthY + 5 * scale + (jawDrop + pharynxOpenFactor) * (1 - lockTightness * 0.85);

    // Mouth Cavity & Oral Pharynx (Inside)
    if (bottomLipY - topLipY > 4 * scale && lockTightness < 0.6) {
      ctx.beginPath();
      ctx.moveTo(-cornerX, baseMouthY);
      ctx.quadraticCurveTo(0, topLipY + 2 * scale, cornerX, baseMouthY);
      ctx.quadraticCurveTo(0, bottomLipY + 2 * scale, -cornerX, baseMouthY);
      ctx.fillStyle = '#26060c';
      ctx.fill();

      // Tongue Tip Curl (ด/ต/น/ล/ร)
      if (visemes.tipCurl > 0.25) {
        ctx.beginPath();
        const tongueElevation = visemes.tipCurl * 14 * scale;
        ctx.arc(0, bottomLipY - tongueElevation, 10 * scale, 0, Math.PI);
        ctx.fillStyle = '#b53d4c';
        ctx.fill();
      }

      // Upper & Lower Teeth row
      ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.fillRect(-14 * scale, topLipY + 1 * scale, 28 * scale, 3 * scale);
      if (bottomLipY - topLipY > 12 * scale) {
        ctx.fillRect(-12 * scale, bottomLipY - 4 * scale, 24 * scale, 3 * scale);
      }
    }

    // Upper Lip
    ctx.beginPath();
    ctx.moveTo(-cornerX, baseMouthY);
    // Cupid's bow
    ctx.quadraticCurveTo(-cornerX * 0.5, topLipY - 3 * scale, 0, topLipY - 1 * scale);
    ctx.quadraticCurveTo(cornerX * 0.5, topLipY - 3 * scale, cornerX, baseMouthY);
    ctx.quadraticCurveTo(0, topLipY + 2 * scale, -cornerX, baseMouthY);
    ctx.fillStyle = '#b34958';
    ctx.fill();
    ctx.strokeStyle = '#6e1d29';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Lower Lip
    ctx.beginPath();
    ctx.moveTo(-cornerX, baseMouthY);
    ctx.quadraticCurveTo(0, bottomLipY + 6 * scale, cornerX, baseMouthY);
    ctx.quadraticCurveTo(0, bottomLipY, -cornerX, baseMouthY);
    ctx.fillStyle = '#cc5667';
    ctx.fill();
    ctx.strokeStyle = '#6e1d29';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Dental Tuck (ฟ/ฝ - lower lip tucked slightly behind upper teeth)
    if (visemes.dentalTuck > 0.3) {
      ctx.beginPath();
      ctx.ellipse(0, topLipY + 3 * scale, 12 * scale, 2 * scale, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.fill();
    }

    ctx.restore();
  }

  private renderCalibrationPins(
    ctx: CanvasRenderingContext2D,
    scale: number,
    pins: RigPin[]
  ) {
    ctx.save();
    pins.forEach(pin => {
      // Convert pin norm (0-1) to head coordinates
      const px = (pin.normX - 0.5) * 120 * scale;
      const py = (pin.normY - 0.5) * 160 * scale;

      // Glow halo
      ctx.beginPath();
      ctx.arc(px, py, 9 * scale, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 215, 0, 0.25)';
      ctx.fill();

      // Golden pin head
      ctx.beginPath();
      ctx.arc(px, py, 4.5 * scale, 0, Math.PI * 2);
      ctx.fillStyle = pin.color;
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Thai Pin Label
      ctx.font = `bold ${Math.round(8 * scale)}px sans-serif`;
      ctx.fillStyle = '#ffd700';
      ctx.fillText(pin.thaiLabel, px + 8 * scale, py + 3 * scale);
    });
    ctx.restore();
  }
}
