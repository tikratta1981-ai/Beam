export interface ThaiVisemes {
  lipLock: number;      // ม/บ/พ/ป - Bilabial closure (0-1)
  pharynxOpen: number;  // อา/อะ - Wide pharyngeal opening (0-1)
  zygoSpread: number;   // อี/เอ - Zygomaticus smile spread (0-1)
  orbicRound: number;   // อู/โอ - Orbicularis oris rounding / protrusion (0-1)
  tipCurl: number;      // ด/ต/น/ล/ร - Alveolar tongue tip elevation (0-1)
  velarDorsum: number;  // ก/ข/ค/ง - Velar tongue arch (0-1)
  dentalTuck: number;   // ฟ/ฝ - Labiodental lower lip tuck (0-1)
}

export interface AudioTierState {
  isListening: boolean;
  inputMode: 'mic' | 'tts' | 'sample';
  volume: number;
  pitch: number;
  noiseGate: number;
  autoGain: boolean;
  formants: {
    f1: number;
    f2: number;
  };
  visemes: ThaiVisemes;
  spectrumData: Uint8Array;
}

export type TMJPreset = 'soft' | 'normal' | 'punchy';

export interface TMJPhysicsParams {
  mass: number;          // kg
  stiffness: number;     // N/m
  damping: number;       // Ns/m
  condylarSlide: number; // Ratio of translation vs rotation
  tissueRecoil: number;  // Tissue rebound elasticity
  preset: TMJPreset;
  respirationEnabled: boolean;
  posturalSwayEnabled: boolean;
  heartPulseEnabled: boolean;
  microTrembleEnabled: boolean;
}

export interface TMJState {
  jawAngle: number;       // Radians rotation around condyle
  jawTranslationY: number;// Condylar slide downwards (mm)
  jawTranslationZ: number;// Condylar slide forwards (mm)
  jawVelocity: number;
  respirationPhase: number;// 0 to 2pi (3.8s period)
  swayX: number;          // Head lateral sway
  swayY: number;          // Head vertical breath
  swayZ: number;          // Pitch sway
  heartBeatPulse: number; // 0 to 1 pulse
  tremorOffset: number;   // 8Hz micro-jitter
}

export interface RigPin {
  id: string;
  name: string;
  thaiLabel: string;
  normX: number; // 0 to 1 relative to head box
  normY: number;
  color: string;
}

export type CameraPreset = 'FRONT' | 'PROFILE' | 'TOP' | 'TMJ' | 'WIDE';

export type AmuletViewMode = 'front' | 'back' | 'edge' | 'base';

export interface AmuletData {
  id: string;
  name: string;
  thaiName: string;
  origin: string;
  era: string;
  material: string;
  description: string;
  views: {
    front: string;
    back: string;
    edge: string;
    base: string;
  };
}

export interface StudioConfig {
  studioTheme: 'velvet-red' | 'deep-obsidian' | 'gold-sanctuary' | 'cyber-cyan';
  avatarMode: 'biomechanical' | 'realistic' | 'anime';
  showSkeleton3D: boolean;
  skeletonOpacity: number;
  skeletonPosition: 'pip' | 'overlay' | 'split';
  showAmulet: boolean;
  amuletMode: 'floating' | 'pip' | 'side-by-side';
  showHUD: boolean;
  showPins: boolean;
  cameraPreset: CameraPreset;
}
