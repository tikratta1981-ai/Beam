import { AmuletData, AmuletViewMode } from '../types/viseme';

// Procedural high-detail rendered SVGs for the 4 angles of famous Thai Amulets
function createAmuletSvg(type: 'somdej' | 'rod' | 'nangphaya', angle: AmuletViewMode): string {
  const isFront = angle === 'front';
  const isBack = angle === 'back';
  const isEdge = angle === 'edge';
  const isBase = angle === 'base';

  if (type === 'somdej') {
    // Phra Somdej Wat Rakang Pim Yai
    if (isEdge) {
      return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 280">
        <defs>
          <linearGradient id="edgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="%23d8c49e" />
            <stop offset="40%" stop-color="%23c2ab83" />
            <stop offset="80%" stop-color="%23a9926c" />
            <stop offset="100%" stop-color="%238d7653" />
          </linearGradient>
          <filter id="grain"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="3" result="noise"/><feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.18 0" in="noise" result="coloredNoise"/><feComposite operator="in" in2="SourceGraphic"/></filter>
        </defs>
        <rect x="25" y="15" width="50" height="250" rx="6" fill="url(%23edgeGrad)" stroke="%235a4629" stroke-width="2" />
        <path d="M 27 50 Q 50 55 73 50 M 27 100 Q 50 105 73 100 M 27 160 Q 50 165 73 160 M 27 220 Q 50 225 73 220" stroke="%237b6343" stroke-width="2" fill="none" opacity="0.6"/>
        <text x="50" y="272" font-size="10" font-family="sans-serif" fill="%23e2d1b3" text-anchor="middle" font-weight="bold">EDGE ขอบข้าง</text>
      </svg>`;
    }
    if (isBase) {
      return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 120">
        <defs>
          <linearGradient id="baseGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="%23d8c49e" />
            <stop offset="50%" stop-color="%23be9f74" />
            <stop offset="100%" stop-color="%238f7146" />
          </linearGradient>
        </defs>
        <rect x="20" y="20" width="160" height="80" rx="10" fill="url(%23baseGrad)" stroke="%235a4629" stroke-width="3" />
        <ellipse cx="60" cy="60" rx="8" ry="12" fill="%23725530" opacity="0.5"/>
        <ellipse cx="140" cy="60" rx="10" ry="8" fill="%23725530" opacity="0.5"/>
        <line x1="35" y1="60" x2="165" y2="60" stroke="%23483216" stroke-width="2" stroke-dasharray="4,4" opacity="0.7"/>
        <text x="100" y="114" font-size="11" font-family="sans-serif" fill="%23e2d1b3" text-anchor="middle" font-weight="bold">BASE ก้นฐาน</text>
      </svg>`;
    }
    if (isBack) {
      return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 280">
        <defs>
          <linearGradient id="backGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="%23e5d7ba" />
            <stop offset="45%" stop-color="%23cfbd98" />
            <stop offset="85%" stop-color="%23b89e72" />
            <stop offset="100%" stop-color="%23967d54" />
          </linearGradient>
        </defs>
        <rect x="20" y="15" width="160" height="250" rx="12" fill="url(%23backGrad)" stroke="%235a4629" stroke-width="4" />
        <rect x="32" y="27" width="136" height="226" rx="8" fill="none" stroke="%239e8055" stroke-width="2" stroke-dasharray="6,4" opacity="0.6"/>
        <!-- Traces of sacred stamp & chalk powder marks -->
        <circle cx="100" cy="130" r="35" fill="%23a43825" opacity="0.15"/>
        <path d="M 60 70 Q 100 85 140 70 M 50 180 Q 100 200 150 180" stroke="%237a6039" stroke-width="2" fill="none" opacity="0.4"/>
        <text x="100" y="274" font-size="10" font-family="sans-serif" fill="%23e2d1b3" text-anchor="middle" font-weight="bold">BACK หลังเรียบ</text>
      </svg>`;
    }
    // Front: Pim Yai Masterpiece with arch & tiered lotus throne
    return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 280">
      <defs>
        <linearGradient id="somdejGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="%23f0e5cb" />
          <stop offset="35%" stop-color="%23d8c49e" />
          <stop offset="70%" stop-color="%23be9f74" />
          <stop offset="100%" stop-color="%238d7249" />
        </linearGradient>
        <linearGradient id="goldGlow" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="%23ffd700" stop-opacity="0.8"/>
          <stop offset="100%" stop-color="%23ff9900" stop-opacity="0.8"/>
        </linearGradient>
      </defs>
      <!-- Tablet body -->
      <rect x="20" y="15" width="160" height="250" rx="12" fill="url(%23somdejGrad)" stroke="%23684e27" stroke-width="4" />
      <!-- Outer Border Frame -->
      <rect x="30" y="25" width="140" height="230" rx="8" fill="none" stroke="%23a4875b" stroke-width="3" />
      <!-- Arch (Sum) -->
      <path d="M 46 220 L 46 95 Q 46 45 100 45 Q 154 45 154 95 L 154 220" fill="none" stroke="%23937449" stroke-width="6" stroke-linecap="round"/>
      <!-- Halo & Usnisha -->
      <ellipse cx="100" cy="85" rx="14" ry="18" fill="%2384663b" />
      <path d="M 100 66 L 100 55" stroke="%2384663b" stroke-width="4" stroke-linecap="round"/>
      <!-- Torso & Arms (Meditation posture Dhyana Mudra) -->
      <path d="M 85 102 Q 100 98 115 102 L 120 135 Q 100 142 80 135 Z" fill="%2384663b" />
      <!-- Curved Meditation Arms -->
      <path d="M 85 104 C 65 125, 75 148, 100 150 C 125 148, 135 125, 115 104" fill="none" stroke="%2384663b" stroke-width="7" stroke-linecap="round"/>
      <!-- Crossed Legs (Padmasana) -->
      <ellipse cx="100" cy="154" rx="28" ry="8" fill="%2384663b" />
      <!-- 3 Tiered Throne (Tharn Sam Chan) -->
      <rect x="62" y="166" width="76" height="8" rx="3" fill="%2384663b" />
      <rect x="54" y="180" width="92" height="10" rx="4" fill="%2384663b" />
      <rect x="46" y="196" width="108" height="13" rx="5" fill="%2384663b" />
      <text x="100" y="273" font-size="10" font-family="sans-serif" fill="%23e2d1b3" text-anchor="middle" font-weight="bold">FRONT ด้านหน้า พิมพ์ใหญ่</text>
    </svg>`;
  }

  // Phra Rod Mahawan (Hariphunchai)
  return `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 280">
    <defs>
      <linearGradient id="rodGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="%23d68065" />
        <stop offset="50%" stop-color="%23b05b42" />
        <stop offset="100%" stop-color="%237e3522" />
      </linearGradient>
    </defs>
    <!-- Pointed arch terracotta shape -->
    <path d="M 45 250 L 45 130 Q 45 30 100 20 Q 155 30 155 130 L 155 250 Z" fill="url(%23rodGrad)" stroke="%23531b0c" stroke-width="4" />
    <circle cx="100" cy="90" r="16" fill="%235c2415" />
    <path d="M 85 110 L 115 110 L 120 155 L 80 155 Z" fill="%235c2415" />
    <ellipse cx="100" cy="170" rx="32" ry="12" fill="%235c2415" />
    <text x="100" y="272" font-size="10" font-family="sans-serif" fill="%23ffcca8" text-anchor="middle" font-weight="bold">${angle.toUpperCase()}</text>
  </svg>`;
}

export const SAMPLE_AMULETS: AmuletData[] = [
  {
    id: 'somdej-wat-rakang',
    name: 'Phra Somdej Wat Rakang (Pim Yai)',
    thaiName: 'พระสมเด็จวัดระฆังโฆสิตาราม พิมพ์ใหญ่',
    origin: 'Wat Rakang Kositaram, Bangkok',
    era: 'Rattanakosin Era (Somdej Toh B.E. 2409-2415)',
    material: 'Sacred Itthije Powders & Limelight',
    description: 'The King of Thai Amulets (Benjapakee). Masterpiece molded by Somdej Phra Buddhachan (Toh Promrangsi).',
    views: {
      front: createAmuletSvg('somdej', 'front'),
      back: createAmuletSvg('somdej', 'back'),
      edge: createAmuletSvg('somdej', 'edge'),
      base: createAmuletSvg('somdej', 'base'),
    },
  },
  {
    id: 'phra-rod-mahawan',
    name: 'Phra Rod Wat Mahawan (Pim Yai)',
    thaiName: 'พระรอด วัดมหาวัน ลำพูน พิมพ์ใหญ่',
    origin: 'Wat Mahawan, Lamphun',
    era: 'Hariphunchai Era (Over 1,200 Years Old)',
    material: 'Sacred Baked Clay & Ancient Earth Minerals',
    description: 'Renowned for supreme protection (Kong Krapan & Klaew Klaad). One of the top 5 Benjapakee treasures.',
    views: {
      front: createAmuletSvg('rod', 'front'),
      back: createAmuletSvg('rod', 'back'),
      edge: createAmuletSvg('rod', 'edge'),
      base: createAmuletSvg('rod', 'base'),
    },
  },
];
