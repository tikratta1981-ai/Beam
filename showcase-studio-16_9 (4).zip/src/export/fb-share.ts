export interface ShareMeta {
  title: string;
  description: string;
  hashtags: string[];
}

export function capturePosterFrame(canvas: HTMLCanvasElement): string {
  try {
    return canvas.toDataURL('image/jpeg', 0.92);
  } catch (err) {
    console.warn('Could not capture frame:', err);
    return '';
  }
}

export function generateFacebookShareUrl(appUrl: string, quote?: string): string {
  const url = encodeURIComponent(appUrl || window.location.href);
  const q = quote ? `&quote=${encodeURIComponent(quote)}` : '';
  return `https://www.facebook.com/sharer/sharer.php?u=${url}${q}`;
}

export const DEFAULT_SHARE_META: ShareMeta = {
  title: 'Showcase Studio 16:9 - Biomechanical Avatar & Thai Amulet Studio',
  description: 'ระบบสร้างวิดีโออวตาร 16:9 บนเบราว์เซอร์ 100% พร้อม 240Hz Thai Audio DSP, 120Hz TMJ Physics, 3D X-Ray Skeleton และ Amulet Showcase',
  hashtags: ['#ShowcaseStudio', '#BiomechanicalAvatar', '#ThaiPhonetics', '#ThreeJS', '#AmuletShowcase'],
};
