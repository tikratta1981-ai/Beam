export interface ExportOptions {
  width: number;
  height: number;
  fps: number;
  bitrate: number; // bps, e.g. 12_000_000 for 12 Mbps
  audioEnabled: boolean;
}

export class VideoExporter {
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private isRecording: boolean = false;
  private startTime: number = 0;
  private durationSeconds: number = 0;
  private timerId: number | null = null;
  private onTimeUpdate?: (seconds: number) => void;

  public get recording(): boolean {
    return this.isRecording;
  }

  public get duration(): number {
    return this.durationSeconds;
  }

  public async startRecording(
    canvas: HTMLCanvasElement,
    audioStream?: MediaStream,
    options: Partial<ExportOptions> = {},
    onTimeUpdate?: (seconds: number) => void
  ): Promise<boolean> {
    this.onTimeUpdate = onTimeUpdate;
    this.recordedChunks = [];
    const fps = options.fps || 60;
    const bitrate = options.bitrate || 12_000_000; // 12 Mbps

    try {
      // Capture 60 FPS stream from 16:9 canvas
      const canvasStream = canvas.captureStream(fps);
      const combinedTracks: MediaStreamTrack[] = [...canvasStream.getVideoTracks()];

      if (audioStream && options.audioEnabled !== false) {
        audioStream.getAudioTracks().forEach(track => combinedTracks.push(track));
      }

      const combinedStream = new MediaStream(combinedTracks);

      // Determine best supported MIME type: prefer MP4 / H.264, fallback to WebM
      let mimeType = 'video/mp4; codecs="avc1.42E01E, mp4a.40.2"';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/mp4';
      }
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm; codecs=vp9,opus';
      }
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm';
      }

      this.mediaRecorder = new MediaRecorder(combinedStream, {
        mimeType,
        videoBitsPerSecond: bitrate,
      });

      this.mediaRecorder.ondataavailable = event => {
        if (event.data && event.data.size > 0) {
          this.recordedChunks.push(event.data);
        }
      };

      this.mediaRecorder.start(250); // Emit chunk every 250ms for Fast-Start buffer
      this.isRecording = true;
      this.startTime = Date.now();
      this.durationSeconds = 0;

      this.timerId = window.setInterval(() => {
        this.durationSeconds = Math.floor((Date.now() - this.startTime) / 1000);
        if (this.onTimeUpdate) {
          this.onTimeUpdate(this.durationSeconds);
        }
      }, 500);

      return true;
    } catch (err) {
      console.error('Failed to start recording:', err);
      this.isRecording = false;
      return false;
    }
  }

  public stopRecording(): Promise<{ blob: Blob; url: string; mimeType: string }> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder || !this.isRecording) {
        reject(new Error('Recorder not active'));
        return;
      }

      if (this.timerId) {
        clearInterval(this.timerId);
        this.timerId = null;
      }

      this.mediaRecorder.onstop = () => {
        this.isRecording = false;
        const mimeType = this.mediaRecorder?.mimeType || 'video/mp4';
        const blob = new Blob(this.recordedChunks, { type: mimeType });
        const url = URL.createObjectURL(blob);
        resolve({ blob, url, mimeType });
      };

      this.mediaRecorder.stop();
    });
  }

  public downloadVideo(url: string, filename: string = 'showcase-studio-16-9.mp4') {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
}

export const globalVideoExporter = new VideoExporter();
