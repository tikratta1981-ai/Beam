import { ThaiVisemes, AudioTierState } from '../types';

export class AudioTier {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private oscillatorNode: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private dspTimer: number | null = null;

  // Formant biquad filter bank
  private formantFilters: BiquadFilterNode[] = [];
  private formantAnalysers: AnalyserNode[] = [];

  private state: AudioTierState = {
    isListening: false,
    inputMode: 'sample',
    volume: 0,
    pitch: 180,
    noiseGate: 0.02,
    autoGain: true,
    formants: { f1: 500, f2: 1500 },
    visemes: {
      lipLock: 0,
      pharynxOpen: 0,
      zygoSpread: 0,
      orbicRound: 0,
      tipCurl: 0,
      velarDorsum: 0,
      dentalTuck: 0,
    },
    spectrumData: new Uint8Array(64),
  };

  private listeners: ((state: AudioTierState) => void)[] = [];
  private peakVolume: number = 0.01;

  constructor() {
    // Lazy initialized on first user gesture
  }

  public subscribe(cb: (state: AudioTierState) => void) {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter(l => l !== cb);
    };
  }

  public getState(): AudioTierState {
    return this.state;
  }

  public setNoiseGate(val: number) {
    this.state.noiseGate = Math.max(0.005, Math.min(0.08, val));
  }

  public setAutoGain(enabled: boolean) {
    this.state.autoGain = enabled;
  }

  private async ensureAudioContext() {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  public async startMicrophone(): Promise<boolean> {
    try {
      const ctx = await this.ensureAudioContext();
      if (this.micStream) {
        this.stopMicrophone();
      }

      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.sourceNode = ctx.createMediaStreamSource(this.micStream);
      this.setupDSPNodes(ctx, this.sourceNode);

      this.state.isListening = true;
      this.state.inputMode = 'mic';
      this.startDSPClock();
      return true;
    } catch (err) {
      console.warn('Microphone permission denied or unavailable, falling back to synthesis:', err);
      this.startSyntheticPreset('pharynxOpen');
      return false;
    }
  }

  public stopMicrophone() {
    if (this.micStream) {
      this.micStream.getTracks().forEach(t => t.stop());
      this.micStream = null;
    }
    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }
    this.state.isListening = false;
  }

  private setupDSPNodes(ctx: AudioContext, source: AudioNode) {
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.smoothingTimeConstant = 0.5;

    this.gainNode = ctx.createGain();
    this.gainNode.gain.value = 1.0;

    source.connect(this.gainNode);
    this.gainNode.connect(this.analyser);

    // Setup 7 Formant Biquad Filters for Thai Phonetics:
    // F1 band 1: 300Hz (ม/บ/พ - Bilabial closed resonance)
    // F1 band 2: 750Hz (อา/อะ - Open Pharynx)
    // F2 band 1: 2200Hz (อี/เอ - Front High Spread)
    // F2 band 2: 900Hz (อู/โอ - Back Round Protrusion)
    // F3 band 1: 1800Hz (ด/ต/น/ล/ร - Alveolar Tip)
    // F3 band 2: 1400Hz (ก/ข/ค/ง - Velar Arch)
    // High-pass band: 4500Hz (ฟ/ฝ - Labiodental Fricative)
    const centerFreqs = [300, 750, 2200, 900, 1800, 1400, 4500];
    this.formantFilters = [];
    this.formantAnalysers = [];

    centerFreqs.forEach((freq, idx) => {
      const filter = ctx.createBiquadFilter();
      if (idx === 6) {
        filter.type = 'highpass';
        filter.frequency.value = freq;
        filter.Q.value = 1.5;
      } else {
        filter.type = 'bandpass';
        filter.frequency.value = freq;
        filter.Q.value = 3.0;
      }
      const fa = ctx.createAnalyser();
      fa.fftSize = 64;
      fa.smoothingTimeConstant = 0.4;

      source.connect(filter);
      filter.connect(fa);

      this.formantFilters.push(filter);
      this.formantAnalysers.push(fa);
    });
  }

  // 240Hz DSP Loop (~4.166 ms interval)
  private startDSPClock() {
    if (this.dspTimer) {
      clearInterval(this.dspTimer);
    }
    // 240Hz = 1000 / 240 = 4.166 ms
    this.dspTimer = window.setInterval(() => {
      this.processDSPFrame();
    }, 4);
  }

  public stopDSPClock() {
    if (this.dspTimer) {
      clearInterval(this.dspTimer);
      this.dspTimer = null;
    }
  }

  private processDSPFrame() {
    if (!this.analyser) {
      this.notifyListeners();
      return;
    }

    const bufferLength = this.analyser.frequencyBinCount;
    const freqData = new Uint8Array(bufferLength);
    this.analyser.getByteFrequencyData(freqData);

    const timeData = new Uint8Array(bufferLength);
    this.analyser.getByteTimeDomainData(timeData);

    // Calculate RMS volume
    let sumSquares = 0;
    for (let i = 0; i < bufferLength; i++) {
      const norm = (timeData[i] - 128) / 128;
      sumSquares += norm * norm;
    }
    let rms = Math.sqrt(sumSquares / bufferLength);

    // Auto-Gain dynamic normalization
    if (this.state.autoGain) {
      this.peakVolume = Math.max(0.05, this.peakVolume * 0.995, rms);
      rms = Math.min(1.0, rms / this.peakVolume);
    }

    // Noise Gate evaluation
    if (rms < this.state.noiseGate) {
      rms = 0;
    }

    this.state.volume = rms;

    if (rms > 0) {
      // Evaluate Formant Analysers
      const energies = this.formantAnalysers.map(fa => {
        const d = new Uint8Array(fa.frequencyBinCount);
        fa.getByteFrequencyData(d);
        let s = 0;
        for (let i = 0; i < d.length; i++) s += d[i];
        return s / (d.length * 255);
      });

      const eLipLock = energies[0] || 0;
      const ePharynx = energies[1] || 0;
      const eZygo = energies[2] || 0;
      const eOrbic = energies[3] || 0;
      const eTip = energies[4] || 0;
      const eVelar = energies[5] || 0;
      const eDental = energies[6] || 0;

      // Classify into 7 Thai Visemes with smoothing
      const alpha = 0.35; // Smoothing rate at 240Hz
      const rawLipLock = Math.min(1.0, (eLipLock * 2.2 + (rms < 0.1 ? 0.3 : 0)) * rms);
      const rawPharynx = Math.min(1.0, ePharynx * 2.5 * rms);
      const rawZygo = Math.min(1.0, eZygo * 2.2 * rms);
      const rawOrbic = Math.min(1.0, eOrbic * 2.1 * rms);
      const rawTip = Math.min(1.0, eTip * 2.0 * rms);
      const rawVelar = Math.min(1.0, eVelar * 1.8 * rms);
      const rawDental = Math.min(1.0, eDental * 2.8 * rms);

      this.state.visemes.lipLock = this.lerp(this.state.visemes.lipLock, rawLipLock, alpha);
      this.state.visemes.pharynxOpen = this.lerp(this.state.visemes.pharynxOpen, rawPharynx, alpha);
      this.state.visemes.zygoSpread = this.lerp(this.state.visemes.zygoSpread, rawZygo, alpha);
      this.state.visemes.orbicRound = this.lerp(this.state.visemes.orbicRound, rawOrbic, alpha);
      this.state.visemes.tipCurl = this.lerp(this.state.visemes.tipCurl, rawTip, alpha);
      this.state.visemes.velarDorsum = this.lerp(this.state.visemes.velarDorsum, rawVelar, alpha);
      this.state.visemes.dentalTuck = this.lerp(this.state.visemes.dentalTuck, rawDental, alpha);

      // Estimate dominant F1 & F2
      this.state.formants.f1 = Math.round(300 + ePharynx * 550);
      this.state.formants.f2 = Math.round(900 + eZygo * 1400);
    } else {
      // Natural decay when silent
      const decay = 0.2;
      this.state.visemes.lipLock = this.lerp(this.state.visemes.lipLock, 0, decay);
      this.state.visemes.pharynxOpen = this.lerp(this.state.visemes.pharynxOpen, 0, decay);
      this.state.visemes.zygoSpread = this.lerp(this.state.visemes.zygoSpread, 0, decay);
      this.state.visemes.orbicRound = this.lerp(this.state.visemes.orbicRound, 0, decay);
      this.state.visemes.tipCurl = this.lerp(this.state.visemes.tipCurl, 0, decay);
      this.state.visemes.velarDorsum = this.lerp(this.state.visemes.velarDorsum, 0, decay);
      this.state.visemes.dentalTuck = this.lerp(this.state.visemes.dentalTuck, 0, decay);
    }

    this.state.spectrumData = freqData.slice(0, 64);
    this.notifyListeners();
  }

  private lerp(start: number, end: number, t: number): number {
    return start * (1 - t) + end * t;
  }

  private notifyListeners() {
    this.listeners.forEach(cb => cb(this.state));
  }

  // Text-To-Speech Fallback (Web Speech API) with phonetic synchronization
  public speakThaiTTS(text: string): Promise<void> {
    return new Promise(resolve => {
      this.state.inputMode = 'tts';
      if (!('speechSynthesis' in window)) {
        console.warn('SpeechSynthesis not supported');
        resolve();
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'th-TH';
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      // Animate synthetic visemes matched with Thai phonetic script
      let activeIndex = 0;
      const chars = Array.from(text);
      const intervalMs = Math.max(30, Math.min(90, Math.floor(text.length > 0 ? 3000 / text.length : 60)));

      const timer = setInterval(() => {
        if (activeIndex >= chars.length) {
          clearInterval(timer);
          return;
        }
        const ch = chars[activeIndex];
        activeIndex++;
        this.mapThaiCharToViseme(ch);
      }, intervalMs);

      utterance.onend = () => {
        clearInterval(timer);
        this.resetVisemes();
        resolve();
      };

      utterance.onerror = () => {
        clearInterval(timer);
        this.resetVisemes();
        resolve();
      };

      window.speechSynthesis.speak(utterance);
    });
  }

  public mapThaiCharToViseme(ch: string) {
    const isVowelAh = /[าาะัำ]/.test(ch);
    const isVowelEe = /[ิีเแ]/.test(ch);
    const isVowelOo = /[ุูโ]/.test(ch);
    const isBilabial = /[มบพปผภ]/.test(ch);
    const isAlveolar = /[ดตนลรทธตฐถ]/.test(ch);
    const isVelar = /[กขคงคฆ]/.test(ch);
    const isDental = /[ฟฝ]/.test(ch);

    this.state.volume = 0.75;
    if (isBilabial) {
      this.state.visemes.lipLock = 0.95;
      this.state.visemes.pharynxOpen = 0.1;
    } else if (isVowelAh) {
      this.state.visemes.pharynxOpen = 0.9;
      this.state.visemes.lipLock = 0;
    } else if (isVowelEe) {
      this.state.visemes.zygoSpread = 0.85;
      this.state.visemes.pharynxOpen = 0.35;
    } else if (isVowelOo) {
      this.state.visemes.orbicRound = 0.9;
      this.state.visemes.pharynxOpen = 0.3;
    } else if (isAlveolar) {
      this.state.visemes.tipCurl = 0.8;
      this.state.visemes.pharynxOpen = 0.2;
    } else if (isVelar) {
      this.state.visemes.velarDorsum = 0.85;
      this.state.visemes.pharynxOpen = 0.3;
    } else if (isDental) {
      this.state.visemes.dentalTuck = 0.9;
    } else {
      this.state.visemes.pharynxOpen = 0.4;
    }
    this.notifyListeners();
  }

  // Interactive audition for testing the 7 Thai visemes directly
  public triggerVisemePreset(visemeKey: keyof ThaiVisemes, intensity: number = 0.85) {
    this.resetVisemes();
    this.state.volume = intensity;
    this.state.visemes[visemeKey] = intensity;
    this.notifyListeners();
  }

  public resetVisemes() {
    this.state.volume = 0;
    this.state.visemes = {
      lipLock: 0,
      pharynxOpen: 0,
      zygoSpread: 0,
      orbicRound: 0,
      tipCurl: 0,
      velarDorsum: 0,
      dentalTuck: 0,
    };
    this.notifyListeners();
  }

  public startSyntheticPreset(presetName: string) {
    this.state.inputMode = 'sample';
    this.startDSPClock();
    // Synthetic modulation loop for demo
    let phase = 0;
    const interval = setInterval(() => {
      if (this.state.inputMode !== 'sample') {
        clearInterval(interval);
        return;
      }
      phase += 0.08;
      const v = Math.sin(phase);
      if (v > 0) {
        this.state.volume = 0.5 + 0.4 * Math.sin(phase * 2);
        this.state.visemes.pharynxOpen = Math.max(0, Math.sin(phase * 1.5));
        this.state.visemes.zygoSpread = Math.max(0, Math.sin(phase * 0.8));
        this.state.visemes.lipLock = Math.max(0, Math.cos(phase * 2.3) * 0.6);
        this.state.visemes.orbicRound = Math.max(0, Math.sin(phase * 1.2) * 0.7);
      } else {
        this.resetVisemes();
      }
      this.notifyListeners();
    }, 50);
  }
}

export const globalAudioTier = new AudioTier();
