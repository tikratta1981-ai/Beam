// src/types/auth.ts

export type AuthProvider = 'google' | 'facebook' | 'guest';

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  provider: AuthProvider;
  createdAt: number;
  lastLoginAt: number;
  token?: string;
}

export interface AuthState {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}
