// src/types/game.ts

export interface CropType {
  id: string;
  name: string;
  thaiName: string;
  icon: string;
  growTimeSec: number;
  cost: number;
  sellPrice: number;
  xpReward: number;
  minLevel: number;
  description: string;
}

export interface Plot {
  id: number;
  cropId: string | null;
  cropType?: string | null;
  plantedAt: number | null; // timestamp ms
  isReady: boolean;
  watered: boolean;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
}

export interface AnimalPen {
  id: string;
  type: 'cow' | 'chicken' | 'pig' | 'sheep' | 'goat';
  name: string;
  thaiName: string;
  icon: string;
  count: number;
  maxCount: number;
  fedAt: number | null;
  durationSec: number;
  produceItem: string;
  produceName: string;
  produceIcon: string;
  produceQuantity: number;
  feedCropId: string;
  feedRequired: number;
  isReady: boolean;
}

export interface Recipe {
  id: string;
  name: string;
  thaiName: string;
  icon: string;
  durationSec: number;
  ingredients: { itemId: string; count: number }[];
  outputCount: number;
  xpReward: number;
  sellPrice: number;
  minLevel: number;
}

export interface Factory {
  id: string;
  name: string;
  thaiName: string;
  icon: string;
  level: number;
  currentProduction: {
    recipeId: string;
    startedAt: number;
    durationSec: number;
  } | null;
  queue: string[]; // recipeIds
  completedItems: string[];
}

export interface InventoryItem {
  id: string;
  name: string;
  thaiName: string;
  category: 'crops' | 'animal' | 'factory' | 'tools' | 'special';
  count: number;
  icon: string;
  sellPrice: number;
}

export interface Quest {
  id: string;
  title: string;
  thaiTitle: string;
  description: string;
  type: 'harvest' | 'produce' | 'feed' | 'order' | 'level' | 'fish';
  targetType?: string;
  current: number;
  target: number;
  rewardCoins: number;
  rewardXp: number;
  rewardGems: number;
  completed: boolean;
  claimed: boolean;
}

export interface FishRecord {
  caughtCount: number;
  maxWeightKg: number;
  firstCaughtAt: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerAvatar: string;
  items: { itemId: string; count: number }[];
  rewardCoins: number;
  rewardXp: number;
  expiresInSec: number;
  status: 'pending' | 'shipping' | 'completed';
}

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  level: number;
  farmName: string;
  giftSentToday: boolean;
  needsHelp: boolean;
  helpType?: string;
  isOnline: boolean;
}

export interface DailyReward {
  day: number;
  coins: number;
  gems: number;
  items?: { itemId: string; count: number; name: string; icon: string };
  claimed: boolean;
}

export interface FarmLog {
  id: string;
  message: string;
  time: string;
  type: 'info' | 'harvest' | 'coin' | 'upgrade' | 'order';
}

// 🌾 ข้อมูลสำหรับระบบแชท AI นายชด (Nai Chod)
export interface ChatMessage {
  id: string;
  sender: 'user' | 'chod';
  text: string;
  timestamp: number;
}