// src/types/fishing.ts

export type FishRarity = 'common' | 'uncommon' | 'rare' | 'legendary';

export interface FishSpecies {
  id: string;
  name: string;
  thaiName: string;
  icon: string;
  rarity: FishRarity;
  minWeightKg: number;
  maxWeightKg: number;
  sellPrice: number;
  xpReward: number;
  description: string;
  shadowSpeed: number; // ความเร็วการเคลื่อนที่ของเงาปลาในน้ำ 3D
}

export type FishingState =
  | 'idle'       // ยืนเตรียมตัวริมท่าเรือ
  | 'casting'    // กำลังเหวี่ยงสายเบ็ด 3D ลงน้ำ
  | 'waiting'    // ทุ่นลอยอยู่ในน้ำ รอปลากินเหยื่อ
  | 'nibbling'   // ปลาตอดเหยื่อ (ระลอกคลื่นผุด)
  | 'hooked'     // ปลากินเบ็ดเต็มตัว (มีเวลาจำกัดในการกดตวัดคัน)
  | 'reeling'    // มินิเกมประคองสายเบ็ด (Tension Gauge Minigame)
  | 'caught'     // ตกปลาสำเร็จ แสดงการ์ดรางวัล 4K
  | 'escaped';   // ปลาหลุดมือ

export interface FishingRewardRecord {
  fish: FishSpecies;
  weightKg: number;
  coinsEarned: number;
  xpEarned: number;
  timestamp: number;
}