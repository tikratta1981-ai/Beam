import { TMJPhysicsParams, TMJState, TMJPreset, ThaiVisemes } from '../types/viseme';

export class TMJEngine {
  private params: TMJPhysicsParams = {
    mass: 0.28,           // Adult mandible average mass ~280g
    stiffness: 85,        // N/m tissue tension
    damping: 12,          // Ns/m viscous friction
    condylarSlide: 0.45,  // Ratio of forward/downward condyle translation
    tissueRecoil: 1.2,    // Rebound multiplier
    preset: 'normal',
    respirationEnabled: true,
    posturalSwayEnabled: true,
    heartPulseEnabled: true,
    microTrembleEnabled: true,
  };

  private state: TMJState = {
    jawAngle: 0,
    jawTranslationY: 0,
    jawTranslationZ: 0,
    jawVelocity: 0,
    respirationPhase: 0,
    swayX: 0,
    swayY: 0,
    swayZ: 0,
    heartBeatPulse: 0,
    tremorOffset: 0,
  };

  private targetJawAngle: number = 0;
  private timer: number | null = null;
  private listeners: ((state: TMJState) => void)[] = [];
  private timeSeconds: number = 0;

  constructor() {
    this.start120HzLoop();
  }

  public subscribe(cb: (state: TMJState) => void) {
    this.listeners.push(cb);
    return () => {
      this.listeners = this.listeners.filter(l => l !== cb);
    };
  }

  public getState(): TMJState {
    return this.state;
  }

  public getParams(): TMJPhysicsParams {
    return this.params;
  }

  public setParams(newParams: Partial<TMJPhysicsParams>) {
    this.params = { ...this.params, ...newParams };
  }

  public setPreset(preset: TMJPreset) {
    this.params.preset = preset;
    if (preset === 'soft') {
      this.params.mass = 0.35;
      this.params.stiffness = 45;
      this.params.damping = 9;
      this.params.tissueRecoil = 0.8;
      this.params.condylarSlide = 0.55;
    } else if (preset === 'normal') {
      this.params.mass = 0.28;
      this.params.stiffness = 85;
      this.params.damping = 12;
      this.params.tissueRecoil = 1.2;
      this.params.condylarSlide = 0.45;
    } else if (preset === 'punchy') {
      this.params.mass = 0.20;
      this.params.stiffness = 160;
      this.params.damping = 16;
      this.params.tissueRecoil = 1.6;
      this.params.condylarSlide = 0.38;
    }
  }

  // Update target jaw opening based on Thai Visemes & Audio
  public updateVisemeTarget(visemes: ThaiVisemes, volume: number) {
    // Bilabial closure (Lip Lock) pulls jaw shut
    if (visemes.lipLock > 0.4) {
      this.targetJawAngle = 0.02 * (1 - visemes.lipLock);
      return;
    }

    // Wide pharyngeal opening (อา/อะ) opens jaw wide (up to 0.45 rad ~ 25 degrees)
    const pharynxDrive = visemes.pharynxOpen * 0.42;
    // Zygo spread (อี/เอ) opens slightly with wider lateral mouth (up to 0.20 rad)
    const zygoDrive = visemes.zygoSpread * 0.18;
    // Orbic round (อู/โอ) opens medium with forward protrusion (0.28 rad)
    const orbicDrive = visemes.orbicRound * 0.26;
    // Tip curl (ด/ต) opens moderate
    const tipDrive = visemes.tipCurl * 0.15;
    // Dental tuck (ฟ/ฝ) opens narrow for lower lip contact
    const dentalDrive = visemes.dentalTuck * 0.12;

    const combinedDrive = Math.max(pharynxDrive, zygoDrive, orbicDrive, tipDrive, dentalDrive);
    this.targetJawAngle = Math.min(0.48, combinedDrive + volume * 0.08);
  }

  // 120Hz Loop (~8.33ms)
  private start120HzLoop() {
    const dt = 1 / 120; // 0.008333s
    this.timer = window.setInterval(() => {
      this.stepPhysics(dt);
    }, 8);
  }

  public stopLoop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private stepPhysics(dt: number) {
    this.timeSeconds += dt;

    // 1. TMJ Mass-Spring-Damper Integration
    // F_spring = -k * (x - target)
    // F_damping = -c * v
    // a = (F_spring + F_damping) / mass
    const displacement = this.state.jawAngle - this.targetJawAngle;
    const springForce = -this.params.stiffness * displacement * this.params.tissueRecoil;
    const dampingForce = -this.params.damping * this.state.jawVelocity;
    const acceleration = (springForce + dampingForce) / this.params.mass;

    this.state.jawVelocity += acceleration * dt;
    this.state.jawAngle += this.state.jawVelocity * dt;

    // Clamp jaw rotation within physical anatomical limits (0 to 0.52 rad ~ 30 deg)
    if (this.state.jawAngle < 0) {
      this.state.jawAngle = 0;
      this.state.jawVelocity = 0;
    } else if (this.state.jawAngle > 0.52) {
      this.state.jawAngle = 0.52;
      this.state.jawVelocity = 0;
    }

    // 2. Condylar Slide (Anatomical translation along articular eminence)
    // As the jaw opens past the initial 12 degrees, condyle glides down and forward
    const slideFactor = Math.sin(this.state.jawAngle * 2.2);
    this.state.jawTranslationY = slideFactor * 12.0 * this.params.condylarSlide; // mm downwards
    this.state.jawTranslationZ = slideFactor * 7.5 * this.params.condylarSlide;  // mm forwards

    // 3. Respiration (3.8 seconds per breath cycle)
    if (this.params.respirationEnabled) {
      const breathPeriod = 3.8;
      this.state.respirationPhase = (this.timeSeconds % breathPeriod) / breathPeriod * (Math.PI * 2);
      // Smooth sinusoidal inhalation/exhalation
      const breathCurve = Math.sin(this.state.respirationPhase);
      this.state.swayY = breathCurve * 2.5; // mm chest/chin breathing lift
    } else {
      this.state.swayY = 0;
    }

    // 4. Postural Sway (Living body micro-sway Lissajous trajectory)
    if (this.params.posturalSwayEnabled) {
      // 0.23Hz lateral & 0.41Hz sagittal
      this.state.swayX = Math.sin(this.timeSeconds * 0.23 * 2 * Math.PI) * 3.0 +
                         Math.sin(this.timeSeconds * 0.11 * 2 * Math.PI) * 1.5;
      this.state.swayZ = Math.cos(this.timeSeconds * 0.18 * 2 * Math.PI) * 2.0;
    } else {
      this.state.swayX = 0;
      this.state.swayZ = 0;
    }

    // 5. Heart Pulse (~72 BPM = 1.2 Hz)
    if (this.params.heartPulseEnabled) {
      const heartFreq = 1.2;
      const beatCycle = (this.timeSeconds * heartFreq) % 1.0;
      // Sharp systolic contraction then slow diastolic decay
      this.state.heartBeatPulse = Math.pow(Math.max(0, Math.sin(beatCycle * Math.PI)), 6);
    } else {
      this.state.heartBeatPulse = 0;
    }

    // 6. Micro-tremble (8 Hz physiological tremor)
    if (this.params.microTrembleEnabled) {
      this.state.tremorOffset = Math.sin(this.timeSeconds * 8.0 * 2 * Math.PI) * 0.4 +
                                (Math.random() - 0.5) * 0.25;
    } else {
      this.state.tremorOffset = 0;
    }

    this.notify();
  }

  private notify() {
    this.listeners.forEach(cb => cb(this.state));
  }
}

export const globalTMJEngine = new TMJEngine();
