import { TMJState } from '../types/viseme';

export interface BoneNode {
  name: string;
  parent: string | null;
  length: number;
  rotation: number; // local angle
  worldX: number;
  worldY: number;
}

export interface HairPoint {
  x: number;
  y: number;
  vx: number;
  vy: number;
  pinned: boolean;
}

export class HairAndRigEngine {
  public hairStrands: HairPoint[][] = [];
  private numStrands = 5;
  private pointsPerStrand = 6;
  private segmentLength = 18;

  constructor() {
    this.initHair();
  }

  private initHair() {
    this.hairStrands = [];
    for (let s = 0; s < this.numStrands; s++) {
      const strand: HairPoint[] = [];
      const rootX = -40 + s * 20;
      const rootY = -90;
      for (let p = 0; p < this.pointsPerStrand; p++) {
        strand.push({
          x: rootX,
          y: rootY + p * this.segmentLength,
          vx: 0,
          vy: 0,
          pinned: p === 0,
        });
      }
      this.hairStrands.push(strand);
    }
  }

  public update(tmj: TMJState, headCenterX: number, headCenterY: number, dt: number = 0.016) {
    const gravity = 180;
    const damping = 0.88;
    const headRot = tmj.swayZ * 0.02;

    this.hairStrands.forEach((strand, sIdx) => {
      const offsetSpread = (sIdx - (this.numStrands - 1) / 2) * 22;
      const baseRootX = headCenterX + offsetSpread + tmj.swayX * 0.5;
      const baseRootY = headCenterY - 110 + tmj.swayY * 0.4;

      strand[0].x = baseRootX;
      strand[0].y = baseRootY;

      for (let i = 1; i < strand.length; i++) {
        const pt = strand[i];
        const prev = strand[i - 1];

        // Apply forces
        pt.vy += gravity * dt;
        // Inertia from head sway and breathing
        pt.vx += (-tmj.swayX * 12 + tmj.tremorOffset * 5) * dt;

        pt.x += pt.vx * dt;
        pt.y += pt.vy * dt;

        // Spring constraint to maintain distance
        const dx = pt.x - prev.x;
        const dy = pt.y - prev.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const diff = dist - this.segmentLength;
        const nx = dx / dist;
        const ny = dy / dist;

        pt.x -= nx * diff * 0.7;
        pt.y -= ny * diff * 0.7;

        pt.vx = (pt.vx + (prev.vx - pt.vx) * 0.1) * damping;
        pt.vy = (pt.vy + (prev.vy - pt.vy) * 0.1) * damping;
      }
    });
  }
}

export const globalHairRig = new HairAndRigEngine();
