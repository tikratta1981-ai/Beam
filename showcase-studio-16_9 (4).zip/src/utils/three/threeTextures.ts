import * as THREE from 'three';

// แคชสำหรับเก็บ Texture ที่สร้างแล้ว ป้องกันการสร้างซ้ำ
const textureCache: Record<string, THREE.CanvasTexture> = {};

/**
 * สร้าง Texture ฟางข้าวสีทองธรรมชาติ (Golden Farm Straw)
 */
export function getStrawTexture(): THREE.CanvasTexture {
  if (textureCache['straw']) return textureCache['straw'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#ca8a04';
  ctx.fillRect(0, 0, 256, 256);

  // เส้นฟางสีทองซ้อนกัน
  for (let i = 0; i < 350; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const len = Math.random() * 24 + 10;
    const angle = (Math.random() - 0.5) * 1.5;
    ctx.strokeStyle = Math.random() > 0.5 ? '#fde047' : Math.random() > 0.5 ? '#eab308' : '#a16207';
    ctx.lineWidth = Math.random() * 2 + 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['straw'] = tex;
  return tex;
}


/**
 * สร้าง Texture ผืนดินและกรวดหินที่มีมิติและความลึก (Realistic Soil & Gravel)
 */
export function getSoilPBRTexture(): THREE.CanvasTexture {
  if (textureCache['soil']) return textureCache['soil'];

  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d')!;

  // พื้นดินสีน้ำตาลเข้มธรรมชาติ
  ctx.fillStyle = '#4a2810';
  ctx.fillRect(0, 0, 512, 512);

  // เลเยอร์ชั้นดินและทราย
  const grad = ctx.createRadialGradient(256, 256, 60, 256, 256, 250);
  grad.addColorStop(0, 'rgba(92, 52, 22, 1)');
  grad.addColorStop(0.6, 'rgba(68, 36, 14, 0.98)');
  grad.addColorStop(0.85, 'rgba(53, 28, 10, 0.85)');
  grad.addColorStop(1, 'rgba(53, 28, 10, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // เมล็ดทราย ดินร่วน และเศษฮิวมัส
  const imgData = ctx.getImageData(0, 0, 512, 512);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const noise = (Math.random() - 0.5) * 35;
    data[i] = Math.min(255, Math.max(0, data[i] + noise));
    data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise * 0.7));
    data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise * 0.5));
  }
  ctx.putImageData(imgData, 0, 0);

  // เม็ดกรวดหินและเศษฟางธรรมชาติ
  for (let i = 0; i < 350; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    const dist = Math.hypot(rx - 256, ry - 256);
    if (dist < 235) {
      const stoneColor = Math.random() > 0.5 ? 'rgba(35, 20, 12, 0.6)' : 'rgba(120, 95, 65, 0.4)';
      ctx.fillStyle = stoneColor;
      ctx.beginPath();
      ctx.arc(rx, ry, Math.random() * 2.5 + 0.8, 0, Math.PI * 2);
      ctx.fill();

      // เส้นฟางสีทองประปราย
      if (i % 6 === 0) {
        ctx.strokeStyle = 'rgba(217, 160, 55, 0.5)';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx + (Math.random() - 0.5) * 12, ry + (Math.random() - 0.5) * 12);
        ctx.stroke();
      }
    }
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache['soil'] = tex;
  return tex;
}

/**
 * สร้าง Texture ลายไม้ธรรมชาติพร้อมตาไม้และเสี้ยนไม้ (Realistic Wood Planks)
 */
export function getWoodPBRTexture(): THREE.CanvasTexture {
  if (textureCache['wood']) return textureCache['wood'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#854d0e';
  ctx.fillRect(0, 0, 256, 256);

  // เสี้ยนไม้แนวยาว
  for (let y = 0; y < 256; y += 3) {
    const alpha = Math.random() * 0.25 + 0.05;
    ctx.strokeStyle = Math.random() > 0.5 ? `rgba(60, 30, 8, ${alpha})` : `rgba(180, 120, 50, ${alpha})`;
    ctx.lineWidth = Math.random() * 2 + 1;
    ctx.beginPath();
    ctx.moveTo(0, y + (Math.random() - 0.5) * 2);
    ctx.bezierCurveTo(80, y + (Math.random() - 0.5) * 6, 170, y + (Math.random() - 0.5) * 6, 256, y);
    ctx.stroke();
  }

  // ตาไม้
  for (let k = 0; k < 3; k++) {
    const kx = Math.random() * 200 + 28;
    const ky = Math.random() * 200 + 28;
    ctx.fillStyle = 'rgba(50, 25, 5, 0.4)';
    ctx.beginPath();
    ctx.ellipse(kx, ky, 10, 6, 0.2, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['wood'] = tex;
  return tex;
}

/**
 * สร้าง Texture อิฐมอญโบราณพร้อมร่องปูน (Realistic Brick Mortar)
 */
export function getBrickPBRTexture(): THREE.CanvasTexture {
  if (textureCache['brick']) return textureCache['brick'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#44403c'; // สีปูน
  ctx.fillRect(0, 0, 256, 256);

  const rows = 8;
  const cols = 4;
  const h = 256 / rows;
  const w = 256 / cols;

  for (let r = 0; r < rows; r++) {
    const offset = (r % 2) * (w / 2);
    for (let cCol = -1; cCol <= cols; cCol++) {
      const bx = cCol * w + offset + 2;
      const by = r * h + 2;
      const bw = w - 4;
      const bh = h - 4;

      const brickColors = ['#b91c1c', '#991b1b', '#c2410c', '#a16207', '#b45309'];
      ctx.fillStyle = brickColors[Math.floor(Math.random() * brickColors.length)];
      ctx.fillRect(bx, by, bw, bh);

      // เงานูนขอบอิฐ
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
      ctx.fillRect(bx, by + bh - 2, bw, 2);
      ctx.fillRect(bx + bw - 2, by, 2, bh);
    }
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['brick'] = tex;
  return tex;
}

/**
 * สร้าง Texture รอยด่างวัวฮอลสไตน์ (Realistic Cow Hide)
 */
export function getCowHideTexture(): THREE.CanvasTexture {
  if (textureCache['cow_hide']) return textureCache['cow_hide'];

  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#fafaf9';
  ctx.fillRect(0, 0, 512, 512);

  // รอยด่างดำธรรมชาติ
  ctx.fillStyle = '#18181b';
  const patches = [
    { x: 120, y: 150, r: 85 },
    { x: 380, y: 200, r: 95 },
    { x: 260, y: 360, r: 110 },
    { x: 80, y: 380, r: 65 },
    { x: 420, y: 410, r: 70 },
  ];

  patches.forEach((p) => {
    ctx.beginPath();
    for (let a = 0; a < Math.PI * 2; a += 0.2) {
      const radius = p.r * (0.8 + Math.sin(a * 4) * 0.2 + (Math.random() - 0.5) * 0.15);
      const px = p.x + Math.cos(a) * radius;
      const py = p.y + Math.sin(a) * radius;
      if (a === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  });

  const tex = new THREE.CanvasTexture(c);
  textureCache['cow_hide'] = tex;
  return tex;
}

/**
 * สร้าง Texture ขนแม่ไก่ลายละเอียดสมจริง (Realistic Hen Plumage)
 * มีลวดลายเกล็ดขนเรียงซ้อน (Layered Barred Feathers) สีน้ำตาลทองอบอุ่น
 */
export function getHenFeatherTexture(): THREE.CanvasTexture {
  if (textureCache['hen_feather']) return textureCache['hen_feather'];

  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d')!;

  // สีขนพื้นฐาน น้ำตาลทองแดงประกาย (Warm Auburn-Gold)
  const bgGrad = ctx.createLinearGradient(0, 0, 0, 512);
  bgGrad.addColorStop(0, '#b45309');
  bgGrad.addColorStop(0.5, '#92400e');
  bgGrad.addColorStop(1, '#78350f');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 512, 512);

  // วาดเกล็ดขนซ้อนทับกัน (Layered feather scallops)
  const rows = 16;
  const cols = 12;
  const stepY = 512 / rows;
  const stepX = 512 / cols;

  for (let r = 0; r < rows; r++) {
    const y = r * stepY;
    const offsetX = (r % 2) * (stepX * 0.5);
    for (let col = -1; col <= cols + 1; col++) {
      const x = col * stepX + offsetX;
      const fWidth = stepX * 1.1;
      const fHeight = stepY * 1.5;

      // ตัวเส้นขน (Feather vane)
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(x, y, fWidth * 0.48, fHeight * 0.55, 0, 0, Math.PI * 2);
      ctx.fillStyle = (r + col) % 3 === 0 ? '#d97706' : (r + col) % 3 === 1 ? '#b45309' : '#78350f';
      ctx.fill();

      // เส้นขอบขนสีทองนวล (Feather lace highlight)
      ctx.lineWidth = 1.8;
      ctx.strokeStyle = 'rgba(254, 240, 138, 0.45)';
      ctx.stroke();

      // ก้านขนกลาง (Shaft / Rachis)
      ctx.strokeStyle = 'rgba(255, 237, 213, 0.6)';
      ctx.lineWidth = 1.0;
      ctx.beginPath();
      ctx.moveTo(x, y - fHeight * 0.4);
      ctx.lineTo(x, y + fHeight * 0.4);
      ctx.stroke();
      ctx.restore();
    }
  }

  // เติม Micro-noise สำหรับเส้นใยขนละเอียด (Down feather fluff)
  const imgData = ctx.getImageData(0, 0, 512, 512);
  const data = imgData.data;
  for (let i = 0; i < data.length; i += 4) {
    const noise = (Math.random() - 0.5) * 22;
    data[i] = Math.min(255, Math.max(0, data[i] + noise));
    data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise * 0.8));
    data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise * 0.5));
  }
  ctx.putImageData(imgData, 0, 0);

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache['hen_feather'] = tex;
  return tex;
}

/**
 * สร้าง Texture ขนพ่อไก่โต้งสง่างาม (Realistic Rooster Plumage)
 * ปีกและหางมีเหลือบมรกตดำ-น้ำเงินเข้ม (Iridescent Beetle-Green Sheen)
 */
export function getRoosterFeatherTexture(): THREE.CanvasTexture {
  if (textureCache['rooster_feather']) return textureCache['rooster_feather'];

  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d')!;

  // พื้นหลังเหลือบเขียวเข้ม-น้ำเงินมิดไนท์
  const bgGrad = ctx.createLinearGradient(0, 0, 512, 512);
  bgGrad.addColorStop(0, '#064e3b'); // มรกตเข้ม
  bgGrad.addColorStop(0.35, '#065f46');
  bgGrad.addColorStop(0.7, '#0f172a'); // มิดไนท์บลู
  bgGrad.addColorStop(1, '#022c22');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 512, 512);

  // แถบสะท้อนแสงสีเขียวปีกแมลงทับ (Iridescence bands)
  for (let i = 0; i < 40; i++) {
    const y = Math.random() * 512;
    ctx.strokeStyle = Math.random() > 0.5 ? 'rgba(52, 211, 153, 0.22)' : 'rgba(56, 189, 248, 0.18)';
    ctx.lineWidth = Math.random() * 12 + 4;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(150, y + 20, 350, y - 20, 512, y + 10);
    ctx.stroke();
  }

  // เส้นก้านขนนกยาวโค้ง
  for (let j = 0; j < 25; j++) {
    const x = Math.random() * 512;
    ctx.strokeStyle = 'rgba(167, 243, 208, 0.4)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x + (Math.random() - 0.5) * 40, 512);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache['rooster_feather'] = tex;
  return tex;
}

/**
 * สร้าง Texture ขนลูกเจี๊ยบนุ่มฟู (Fluffy Chick Down Feather)
 */
export function getChickDownTexture(): THREE.CanvasTexture {
  if (textureCache['chick_down']) return textureCache['chick_down'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#fde047';
  ctx.fillRect(0, 0, 256, 256);

  // ไล่เฉดสีเหลืองทองอ่อนโยน
  const grad = ctx.createRadialGradient(128, 128, 20, 128, 128, 128);
  grad.addColorStop(0, '#fef08a');
  grad.addColorStop(0.7, '#facc15');
  grad.addColorStop(1, '#eab308');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  // ขนปุกปุยจิ๋ว
  for (let i = 0; i < 600; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.strokeStyle = Math.random() > 0.4 ? 'rgba(254, 249, 195, 0.6)' : 'rgba(234, 179, 8, 0.35)';
    ctx.lineWidth = 0.9;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + (Math.random() - 0.5) * 6, y + (Math.random() - 0.5) * 6);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['chick_down'] = tex;
  return tex;
}

/**
 * สร้าง Texture หงอนและเหนียงไก่เนื้อนุ่มชุ่มชื้น (Organic Fleshy Comb & Wattles)
 */
export function getCombTexture(): THREE.CanvasTexture {
  if (textureCache['comb']) return textureCache['comb'];

  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#dc2626';
  ctx.fillRect(0, 0, 128, 128);

  // ปุ่มเนื้อผิวหนังไก่ (Papillae bumps)
  for (let i = 0; i < 180; i++) {
    const x = Math.random() * 128;
    const y = Math.random() * 128;
    const r = Math.random() * 2.2 + 0.8;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(239, 68, 68, 0.6)' : 'rgba(153, 27, 27, 0.5)';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['comb'] = tex;
  return tex;
}

/**
 * สร้าง Texture เกล็ดขาไก่ธรรมชาติ (Scaly Bird Legs)
 */
export function getLegScalesTexture(): THREE.CanvasTexture {
  if (textureCache['leg_scales']) return textureCache['leg_scales'];

  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(0, 0, 128, 256);

  // รอยต่อเกล็ดขาแนวนอน
  for (let y = 0; y < 256; y += 8) {
    ctx.strokeStyle = 'rgba(146, 64, 14, 0.55)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(128, y);
    ctx.stroke();

    ctx.fillStyle = 'rgba(254, 240, 138, 0.4)';
    ctx.fillRect(0, y + 2, 128, 2);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache['leg_scales'] = tex;
  return tex;
}

/**
 * สร้าง Texture ผิวเปลือกไข่ธรรมชาติ มีจุดประเล็กน้อย (Realistic Eggshell)
 */
export function getEggshellTexture(): THREE.CanvasTexture {
  if (textureCache['eggshell']) return textureCache['eggshell'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  // สีเปลือกไข่ไก่บ้านสีนวลครีมอมชมพู-น้ำตาลอ่อน
  ctx.fillStyle = '#fef3c7';
  ctx.fillRect(0, 0, 256, 256);

  const grad = ctx.createLinearGradient(0, 0, 256, 256);
  grad.addColorStop(0, 'rgba(251, 191, 36, 0.15)');
  grad.addColorStop(0.5, 'rgba(217, 119, 6, 0.1)');
  grad.addColorStop(1, 'rgba(180, 83, 9, 0.18)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);

  // จุดประสีน้ำตาลธรรมชาติของไข่ไก่อินทรีย์ (Country farm speckles)
  for (let i = 0; i < 90; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = 'rgba(146, 64, 14, 0.28)';
    ctx.beginPath();
    ctx.arc(x, y, Math.random() * 1.5 + 0.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['eggshell'] = tex;
  return tex;
}

/**
 * สร้าง Texture สังกะสีเคลือบ/โลหะถังน้ำไก่ (Galvanized Metal)
 */
export function getGalvanizedMetalTexture(): THREE.CanvasTexture {
  if (textureCache['galvanized']) return textureCache['galvanized'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(0, 0, 256, 256);

  // ลายเกล็ดสังกะสี (Zinc spangles)
  for (let i = 0; i < 80; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const size = Math.random() * 18 + 8;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(241, 245, 249, 0.35)' : 'rgba(51, 65, 85, 0.25)';
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x + size, y);
    ctx.lineTo(x, y + size);
    ctx.lineTo(x - size, y);
    ctx.closePath();
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['galvanized'] = tex;
  return tex;
}

/**
 * ตั้งค่า Cinematic Lighting & ACES Filmic ToneMapping เพื่อความสมจริงสูงสุด
 */
export function setupRealisticLighting(scene: THREE.Scene, renderer: THREE.WebGLRenderer) {
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.15;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  // แสง Hemisphere ท้องฟ้าและแสงสะท้อนจากพื้นดิน
  const hemiLight = new THREE.HemisphereLight(0xffedd5, 0x5c3317, 0.95);
  scene.add(hemiLight);

  // แสงแดดธรรมชาติตอนกลางวัน (Golden Warm Sunlight)
  const dirLight = new THREE.DirectionalLight(0xfffae6, 2.0);
  dirLight.position.set(6, 14, 7);
  dirLight.castShadow = true;
  dirLight.shadow.mapSize.width = 1024;
  dirLight.shadow.mapSize.height = 1024;
  dirLight.shadow.camera.near = 0.5;
  dirLight.shadow.camera.far = 25;
  dirLight.shadow.bias = -0.0008;
  scene.add(dirLight);

  // แสงสะท้อนรอง (Rim light) สร้างมิติมุมขอบโมเดล
  const rimLight = new THREE.DirectionalLight(0xbae6fd, 0.65);
  rimLight.position.set(-6, 8, -5);
  scene.add(rimLight);
}

// Aliases เพื่อความสะดวกในการเรียกใช้
export const getChickenCombTexture = getCombTexture;
export const getChickenLegTexture = getLegScalesTexture;
export const getEggTexture = getEggshellTexture;

/**
 * สร้าง Texture ผ้ายีนส์เอี๊ยมชาวสวน (Denim Overalls Fabric)
 */
export function getFabricDenimTexture(): THREE.CanvasTexture {
  if (textureCache['denim']) return textureCache['denim'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#1e3a8a'; // สีครามยีนส์เข้ม
  ctx.fillRect(0, 0, 256, 256);

  // ลายทแยงเส้นใยผ้ายีนส์ (Twill weave)
  ctx.strokeStyle = 'rgba(147, 197, 253, 0.28)';
  ctx.lineWidth = 1.2;
  for (let i = -256; i < 512; i += 4) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + 256, 256);
    ctx.stroke();
  }

  // เส้นด้ายด่างตามธรรมชาติ
  for (let i = 0; i < 400; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(219, 234, 254, 0.3)' : 'rgba(30, 58, 138, 0.4)';
    ctx.fillRect(x, y, 2, 2);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache['denim'] = tex;
  return tex;
}

/**
 * สร้าง Texture เสื้อเชิ้ตลายสก็อตชาวสวน (Farmer Plaid Flannel)
 */
export function getFabricPlaidTexture(primaryColor = '#dc2626', secondaryColor = '#facc15'): THREE.CanvasTexture {
  const cacheKey = `plaid_${primaryColor}`;
  if (textureCache[cacheKey]) return textureCache[cacheKey];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#fafafa';
  ctx.fillRect(0, 0, 256, 256);

  // แถบสีหลักแนวนอนและแนวตั้ง
  ctx.fillStyle = primaryColor;
  for (let i = 0; i < 256; i += 64) {
    ctx.fillRect(i, 0, 32, 256);
    ctx.fillRect(0, i, 256, 32);
  }

  // แถบสีรองเส้นบาง
  ctx.fillStyle = secondaryColor;
  for (let i = 16; i < 256; i += 64) {
    ctx.fillRect(i, 0, 6, 256);
    ctx.fillRect(0, i, 256, 6);
  }

  // เส้นเงาตัดลาย
  ctx.strokeStyle = 'rgba(0,0,0,0.15)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 256; i += 16) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 256);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(256, i);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache[cacheKey] = tex;
  return tex;
}

/**
 * สร้าง Texture ลายหมวกฟางถัก (Woven Straw Sunhat)
 */
export function getStrawHatTexture(): THREE.CanvasTexture {
  if (textureCache['straw_hat']) return textureCache['straw_hat'];

  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#eab308';
  ctx.fillRect(0, 0, 256, 256);

  // ลายถักวงกลมและแนวขวาง
  for (let y = 0; y < 256; y += 8) {
    ctx.strokeStyle = y % 16 === 0 ? 'rgba(113, 63, 18, 0.45)' : 'rgba(254, 240, 138, 0.5)';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
  }

  for (let x = 0; x < 256; x += 8) {
    ctx.strokeStyle = x % 16 === 0 ? 'rgba(113, 63, 18, 0.35)' : 'rgba(254, 240, 138, 0.4)';
    ctx.lineWidth = 2.0;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 256);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  textureCache['straw_hat'] = tex;
  return tex;
}

/**
 * สร้าง Texture หนังรองเท้าบูทสีน้ำตาลวินเทจ (Leather Boots)
 */
export function getLeatherBootTexture(): THREE.CanvasTexture {
  if (textureCache['leather_boot']) return textureCache['leather_boot'];

  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = '#451a03';
  ctx.fillRect(0, 0, 128, 128);

  // รอยยับและไฮไลต์หนัง
  for (let i = 0; i < 40; i++) {
    const y = Math.random() * 128;
    ctx.strokeStyle = Math.random() > 0.5 ? 'rgba(180, 83, 9, 0.35)' : 'rgba(20, 10, 5, 0.4)';
    ctx.lineWidth = Math.random() * 2 + 1;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(128, y + (Math.random() - 0.5) * 8);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  textureCache['leather_boot'] = tex;
  return tex;
}


