// src/utils/aiSpeech.ts

class NaiChodVoiceEngine {
  private synth: SpeechSynthesis | null = null;
  private thaiVoice: SpeechSynthesisVoice | null = null;
  public isSpeaking: boolean = false;
  public isMuted: boolean = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.initVoice();
      if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = () => this.initVoice();
      }
    }
  }

  private initVoice() {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    // ค้นหาเสียงภาษาไทย (th-TH หรือขึ้นต้นด้วย th)
    this.thaiVoice = voices.find((v) => v.lang === 'th-TH' || v.lang.startsWith('th')) || null;
  }

  public speak(text: string, onStart?: () => void, onEnd?: () => void) {
    if (!this.synth || this.isMuted) return;

    // หยุดเสียงเดิมที่กำลังเล่นอยู่
    this.stop();

    // กรองอีโมจิและสัญลักษณ์พิเศษออก เพื่อให้การออกเสียงภาษาไทยลื่นไหล ไม่สะดุด
    const cleanText = text
      .replace(
        /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu,
        ''
      )
      .replace(/[*#_~`]/g, '')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'th-TH';
    if (this.thaiVoice) {
      utterance.voice = this.thaiVoice;
    }

    // โทนเสียงนายชด: ทุ้ม อบอุ่น มีจังหวะแบบผู้เฒ่าใจดี
    utterance.pitch = 0.88;
    utterance.rate = 0.95;
    utterance.volume = 1.0;

    utterance.onstart = () => {
      this.isSpeaking = true;
      if (onStart) onStart();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      if (onEnd) onEnd();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      if (onEnd) onEnd();
    };

    this.synth.speak(utterance);
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.isMuted) {
      this.stop();
    }
    return this.isMuted;
  }
}

export const naiChodVoice = new NaiChodVoiceEngine();