// src/utils/aiChodBrain.ts
import { Plot, AnimalPen, Factory, InventoryItem, Order } from '../../types/game';

export interface FarmContext {
  coins: number;
  gems: number;
  level: number;
  energy: number;
  maxEnergy: number;
  barnCapacity: number;
  inventory: Record<string, InventoryItem>;
  plots: Plot[];
  animals: AnimalPen[];
  factories: Record<string, Factory>;
  orders: Order[];
}

export function askNaiChod(queryText: string, ctx: FarmContext): string {
  const query = queryText.toLowerCase().trim();
  const totalItems = Object.values(ctx.inventory).reduce((acc, item) => acc + item.count, 0);
  const barnPercent = Math.round((totalItems / ctx.barnCapacity) * 100);

  // 1. ตรวจสภาพฟาร์มโดยรวม
  if (query.includes('ตรวจ') || query.includes('สภาพ') || query.includes('ฟาร์มเป็นไง') || query.includes('เช็กฟาร์ม')) {
    const readyPlots = ctx.plots.filter((p) => p.isReady).length;
    const unwateredPlots = ctx.plots.filter((p) => p.cropId && !p.watered && !p.isReady).length;
    const hungryAnimals = ctx.animals.filter((a) => a.fedAt === null).length;
    const readyFactories = Object.values(ctx.factories).filter((f) => f.completedItems && f.completedItems.length > 0).length;

    let report = `ลุงชดตรวจดูให้แล้วนะหลาน! ตอนนี้เลเวล ${ctx.level} มีเงินในกระเป๋า ${ctx.coins.toLocaleString()} เหรียญ `;

    if (readyPlots > 0) {
      report += `🌾 มีพืชพร้อมเก็บเกี่ยวแล้ว ${readyPlots} แปลง `;
    }
    if (unwateredPlots > 0) {
      report += `💧 มีแปลงที่ยังไม่ได้รดน้ำ ${unwateredPlots} แปลง รีบไปรดนะเดี๋ยวโตช้า `;
    }
    if (hungryAnimals > 0) {
      report += `🐾 สัตว์ในคอกกำลังหิวอยู่ ${hungryAnimals} คอก อย่าลืมเอาพืชไปเลี้ยงล่ะ `;
    }
    if (readyFactories > 0) {
      report += `🍞 มีของที่โรงงานผลิตเสร็จแล้ว ${readyFactories} แห่งแวะไปเก็บได้เลย `;
    }
    if (barnPercent >= 85) {
      report += `⚠️ อ้อ! โรงนาแน่นถึง ${barnPercent}% แล้ว ระวังเก็บของเพิ่มไม่ได้นะหลาน`;
    }

    if (readyPlots === 0 && unwateredPlots === 0 && hungryAnimals === 0 && readyFactories === 0) {
      report += `สภาพฟาร์มเรียบร้อยสะอาดสะอ้าน ยอดเยี่ยมมากหลานเอ๊ย!`;
    }

    return report;
  }

  // 2. ปลูกอะไรดี / กำไรดีสุด
  if (query.includes('ปลูกอะไร') || query.includes('กำไร') || query.includes('รวย') || query.includes('แนะนำพืช') || query.includes('เมล็ด')) {
    if (ctx.level <= 2) {
      return 'ช่วงตั้งตัวแบบนี้ ปลูก "ข้าวสาลี" ดีที่สุดหลาน โตไวใน 15 วินาที เก็บเกี่ยวขายหรือเอาไปทำแป้งต่อได้ไว เงินหมุนทันใจ!';
    } else if (ctx.level <= 5) {
      return 'ลุงแนะนำปลูก "ข้าวโพดหวาน" ควบคู่กับ "ข้าวสาลี" เอาผลผลิตไปป้อนให้เตาอบทำขนมปังข้าวโพด กำไรเนื้อๆ เลยหลาน!';
    } else if (ctx.level <= 9) {
      return 'ระดับหลานตอนนี้ "มะเขือเทศ" กับ "แตงกวากรอบ" คุ้มค่าน่าปลูกที่สุด ส่งรถกระบะชาวเมืองบางแคได้ราคาแพงมาก!';
    } else {
      return 'ถ้าอยากรวยไว ต้อง "ลาเวนเดอร์" กับ "สตรอว์เบอร์รี่" เลยหลาน เอาไปกวนทำแยมสตรอว์เบอร์รี่ขาย กำไรพุ่งเป็นกอบเป็นกำแน่นอน!';
    }
  }

  // 3. โรงนา หรือคลังสินค้า
  if (query.includes('โรงนา') || query.includes('คลัง') || query.includes('กระเป๋าเต็ม') || query.includes('ที่เก็บ')) {
    return `ตอนนี้โรงนาจุของอยู่ ${totalItems}/${ctx.barnCapacity} ชิ้น (${barnPercent}%) ถ้าพื้นที่เริ่มแน่น ลุงแนะนำให้เอาผลผลิตไปส่งออร์เดอร์รถกระบะ หรือกดเข้าโรงนาแล้วขายไอเทมบางส่วน หรือกดปุ่มอัปเกรดขยายขนาดโรงนานะหลาน`;
  }

  // 4. สัตว์เลี้ยง
  if (query.includes('สัตว์') || query.includes('ไก่') || query.includes('วัว') || query.includes('หมู') || query.includes('แกะ')) {
    return 'การดูแลสัตว์ไม่ยากเลยหลาน! ไก่กินข้าวสาลีเพื่อให้ไข่สด, โคนมกินข้าวโพดเพื่อให้ได้น้ำนมบริสุทธิ์ นำไปแปรรูปเป็นเนยและชีสได้ราคาดีมาก หมั่นให้อาหารอย่าให้ขาดนะสัตว์จะได้อารมณ์ดี!';
  }

  // 5. รถกระบะและออร์เดอร์
  if (query.includes('รถกระบะ') || query.includes('ออร์เดอร์') || query.includes('ส่งของ') || query.includes('ตลาด')) {
    const pendingOrders = ctx.orders.filter((o) => o.status === 'pending');
    return `กระดานส่งของตอนนี้มีคนสั่งสินค้าอยู่ ${pendingOrders.length} เจ้าหลานเอ๊ย การส่งรถกระบะเป็นวิธีหาเหรียญทองและ EXP ที่ไวที่สุดในฟาร์มแล้ว ขยันส่งบ่อยๆ จะได้เลเวลอัปไวๆ นะ`;
  }

  // 6. พลังงาน
  if (query.includes('พลังงาน') || query.includes('เหนื่อย') || query.includes('สายฟ้า')) {
    return `ตอนนี้พลังงานหลานมีอยู่ ${ctx.energy}/${ctx.maxEnergy} ขีด พลังงานจะฟื้นฟูเอง 1 หน่วยทุกๆ 3 นาที หรือเมื่อเลเวลอัปพลังงานจะเต็มหลอดทันที ระหว่างรอก็นั่งคุยกับลุงชดไปพลางๆ ก่อนได้นะหลาน`;
  }

  // 7. คำทักทาย
  if (query.includes('สวัสดี') || query.includes('หวัดดี') || query.includes('ชื่อ') || query.includes('ใคร')) {
    return 'สวัสดีหลานรัก! ลุงชื่อนายชด เป็นปราชญ์ชาวสวนอาวุโสแห่ง Beam Farm มีปัญหาติดขัดเรื่องเพาะปลูก แปรรูป เลี้ยงสัตว์ หรืออยากรู้วิธีหาเหรียญ ถามลุงได้ตลอดเวลาเลยนะ!';
  }

  // Fallback คติชาวบ้าน
  const wiseWords = [
    'ดินดี น้ำพอ พืชพรรณก็งอกงามหลานเอ๊ย ทำสวนต้องใจเย็นและหมั่นสังเกตนะ',
    'อย่าปล่อยให้โรงงานแปรรูปว่างนาน วัตถุดิบแปรรูปแล้วมูลค่าจะสูงขึ้นเป็นเท่าตัวเลยนะหลาน',
    'หมั่นเช็คกระดานภารกิจประจำวันด้วยนะหลาน ทำครบมีทั้งเหรียญและเพชรแจกเพียบเลย!',
    'หากเหนื่อยนักก็แวะพักตกปลาที่สระมรกต หรือแวะทักทายเพื่อนบ้านดูบ้างนะหลานชดเอาใจช่วย!'
  ];

  return wiseWords[Math.floor(Math.random() * wiseWords.length)];
}