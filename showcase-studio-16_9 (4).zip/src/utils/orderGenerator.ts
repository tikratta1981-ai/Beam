import { Order } from '../types/game';

export const generateLevelAppropriateOrder = (playerLvl: number, orderId: string): Order => {
  const availableItems: string[] = ['wheat'];
  if (playerLvl >= 2) availableItems.push('corn', 'fish_carp');
  if (playerLvl >= 3) availableItems.push('egg', 'fishTomYum');
  if (playerLvl >= 4) availableItems.push('carrot', 'bread', 'fish_bass');
  if (playerLvl >= 5) availableItems.push('wool', 'troutSandwich');
  if (playerLvl >= 6) availableItems.push('milk', 'butter', 'fish_trout', 'bassButterSteak');
  if (playerLvl >= 7) availableItems.push('strawberry', 'strawberryJam');
  if (playerLvl >= 8) availableItems.push('fish_golden_catfish', 'goldenCatfishSoup');

  const numItems = Math.min(availableItems.length, playerLvl > 3 ? 2 : 1);
  const chosenItems: { itemId: string; count: number }[] = [];
  const shuffled = [...availableItems].sort(() => 0.5 - Math.random());

  for (let i = 0; i < numItems; i++) {
    chosenItems.push({
      itemId: shuffled[i],
      count: Math.floor(Math.random() * 2) + 1,
    });
  }

  // Calculate realistic rewards with bonus for fish & gourmet dishes
  const rewardCoins = chosenItems.reduce((acc, it) => {
    let basePrice = 60;
    if (it.itemId.startsWith('fish_')) basePrice = 110;
    if (['fishTomYum', 'troutSandwich', 'bassButterSteak'].includes(it.itemId)) basePrice = 240;
    if (it.itemId === 'goldenCatfishSoup') basePrice = 600;
    return acc + it.count * basePrice;
  }, 0) + playerLvl * 45;

  const rewardXp = chosenItems.reduce((acc, it) => acc + it.count * 25, 0) + playerLvl * 15;

  const hasFish = chosenItems.some(
    (it) => it.itemId.startsWith('fish_') || ['fishTomYum', 'troutSandwich', 'bassButterSteak', 'goldenCatfishSoup'].includes(it.itemId)
  );

  const restaurantCustomers = [
    { name: 'ภัตตาคารริเวอร์ไซด์ (ริมน้ำ)', avatar: '🏮' },
    { name: 'ร้านซูชิลุงเค็น (Sushi Master)', avatar: '🍣' },
    { name: 'เชฟใหญ่อองตวน (Grand Hotel)', avatar: '👨‍🍳' },
    { name: 'ร้านสเต๊กฮาร์เบอร์ริมอ่าว', avatar: '🥩' },
  ];

  const generalCustomers = [
    { name: 'ลุงสมชาย', avatar: '👨‍🌾' },
    { name: 'ป้าพรพิมล', avatar: '👵' },
    { name: 'ร้านเบเกอรี่คุณกานต์', avatar: '👩‍🍳' },
    { name: 'น้องมะลิ', avatar: '👧' },
  ];

  const chosenCustomer = hasFish
    ? restaurantCustomers[Math.floor(Math.random() * restaurantCustomers.length)]
    : [...restaurantCustomers, ...generalCustomers][Math.floor(Math.random() * (restaurantCustomers.length + generalCustomers.length))];

  // Bonus for restaurant fish order
  const finalRewardCoins = hasFish ? Math.round(rewardCoins * 1.3) : rewardCoins;
  const finalRewardXp = hasFish ? Math.round(rewardXp * 1.5) : rewardXp;

  return {
    id: orderId,
    customerName: chosenCustomer.name,
    customerAvatar: chosenCustomer.avatar,
    items: chosenItems,
    rewardCoins: finalRewardCoins,
    rewardXp: finalRewardXp,
    expiresInSec: 360,
    status: 'pending' as const,
  };
};
