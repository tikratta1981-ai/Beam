// src/utils/firebase.ts
import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  User 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc 
} from 'firebase/firestore';

// คอนฟิกของคุณที่ได้จาก Firebase Console
const firebaseConfig = {
  apiKey: "วาง API_KEY ของคุณที่ได้มา",
  authDomain: "beam-farm-game.firebaseapp.com",
  projectId: "beam-farm-game",
  storageBucket: "beam-farm-game.firebasestorage.app",
  messagingSenderId: "วาง SENDER_ID ของคุณที่ได้มา",
  appId: "1:วาง APP_ID ของคุณที่ได้มา",
  measurementId: "วาง MEASUREMENT_ID ของคุณที่ได้มา"
};

const isConfigured = Boolean(
  firebaseConfig.apiKey && 
  !firebaseConfig.apiKey.includes('วาง') && 
  firebaseConfig.projectId &&
  !firebaseConfig.projectId.includes('วาง')
);

let app: any = null;
if (isConfigured) {
  try {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  } catch (err) {
    console.warn('Firebase init warning:', err);
  }
}

export const auth = app ? getAuth(app) : null;
export const db = app ? getFirestore(app) : null;
export const googleProvider = new GoogleAuthProvider();

// 2. ฟังก์ชันล็อกอินด้วย Google (Gmail จริง)
export const loginWithGoogle = async (): Promise<User | null> => {
  if (!auth) {
    console.warn("Firebase ยังไม่ได้ตั้งค่า API Key จริง");
    return null;
  }
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    console.error("Google Sign-In Error:", error);
    throw error;
  }
};

// 3. ฟังก์ชันออกจากระบบ
export const logoutUser = async () => {
  if (!auth) return;
  try {
    await signOut(auth);
  } catch (error: any) {
    console.error("Logout Error:", error);
  }
};

// 4. ฟังก์ชันบันทึกข้อมูลฟาร์มขึ้น Cloud (ผูกกับ UID ของ Gmail แต่ละคน)
export const saveGameToCloud = async (userId: string, farmData: any) => {
  if (!db) {
    console.warn("Firebase Firestore ยังไม่ได้เชื่อมต่อ");
    return false;
  }
  try {
    const userDocRef = doc(db, 'farm_saves', userId);
    await setDoc(userDocRef, {
      ...farmData,
      lastUpdated: new Date().toISOString()
    }, { merge: true });
    return true;
  } catch (error: any) {
    console.error("Save to Cloud Error:", error);
    return false;
  }
};

// 5. ฟังก์ชันดึงข้อมูลฟาร์มเก่าลงมาเล่นต่อ
export const loadGameFromCloud = async (userId: string) => {
  if (!db) return null;
  try {
    const userDocRef = doc(db, 'farm_saves', userId);
    const docSnap = await getDoc(userDocRef);
    if (docSnap.exists()) {
      return docSnap.data();
    }
    return null;
  } catch (error: any) {
    console.error("Load Cloud Error:", error);
    return null;
  }
};
