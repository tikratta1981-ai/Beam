// src/utils/auth.ts

import { UserProfile, AuthProvider } from '../types/auth';
import { STORAGE_KEY, GameSnapshot } from '../data/gameConstants';
import { secureStorage, logSecurityEvent, sanitizeText } from '../security';

const CURRENT_USER_KEY = 'beam_farm_current_user_v1';
const KNOWN_ACCOUNTS_KEY = 'beam_farm_known_accounts_v1';

/**
 * สร้าง Cryptographically Secure Random String
 */
function generateSecureRandomHex(length = 16): string {
  try {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  } catch {
    return Math.random().toString(36).substring(2, 10);
  }
}

/**
 * ดึงคีย์เซฟเฉพาะของบัญชีผู้ใช้
 */
export function getAccountSaveKey(userId?: string): string {
  if (!userId || userId.startsWith('guest_')) {
    return STORAGE_KEY;
  }
  // Sanitize userId ให้เหลือเฉพาะตัวอักษรปลอดภัย ป้องกัน Key Injection / Path Traversal
  const safeId = userId.replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 80);
  return `${STORAGE_KEY}_${safeId}`;
}

/**
 * ดึงข้อมูลผู้ใช้ปัจจุบันที่ล็อกอินอยู่
 */
export function getCurrentUser(): UserProfile | null {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as UserProfile;
  } catch {
    return null;
  }
}

/**
 * บันทึกผู้ใช้ปัจจุบันลงใน LocalStorage
 */
export function setCurrentUser(user: UserProfile | null): void {
  try {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
      addKnownAccount(user);
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  } catch (err) {
    console.error('Failed to set current user:', err);
  }
}

/**
 * ดึงรายการบัญชีที่เคยล็อกอินในเครื่องนี้
 */
export function getKnownAccounts(): UserProfile[] {
  try {
    const raw = localStorage.getItem(KNOWN_ACCOUNTS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as UserProfile[];
  } catch {
    return [];
  }
}

/**
 * เพิ่มบัญชีลงในรายการที่จำไว้
 */
function addKnownAccount(user: UserProfile): void {
  try {
    const accounts = getKnownAccounts().filter((acc) => acc.id !== user.id);
    accounts.unshift(user);
    // เก็บสูงสุด 5 บัญชี
    localStorage.setItem(KNOWN_ACCOUNTS_KEY, JSON.stringify(accounts.slice(0, 5)));
  } catch (err) {
    console.warn('Failed to add known account:', err);
  }
}

/**
 * ตรวจสอบความถูกต้องของรูปแบบอีเมล
 */
export function isValidEmail(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

/**
 * ล็อกอินด้วย Google (Gmail)
 */
export async function loginWithGoogle(
  email = 'tommegood641@gmail.com',
  displayName = 'Farmer Tom'
): Promise<UserProfile> {
  const trimmedEmail = email.trim().toLowerCase();
  if (!isValidEmail(trimmedEmail)) {
    throw new Error('รูปแบบอีเมล Gmail ไม่ถูกต้อง');
  }

  const cleanEmail = sanitizeText(trimmedEmail, 100);
  const cleanName = sanitizeText(displayName.trim(), 40) || cleanEmail.split('@')[0];
  const safeEmailId = cleanEmail.replace(/[^a-z0-9]/g, '_');
  const userId = `google_${safeEmailId}`;

  const profile: UserProfile = {
    id: userId,
    email: cleanEmail,
    displayName: cleanName,
    provider: 'google',
    photoURL: 'https://lh3.googleusercontent.com/a/default-user',
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    token: `g_tok_${generateSecureRandomHex(16)}`,
  };

  setCurrentUser(profile);
  logSecurityEvent('cloud_sync', `เข้าสู่ระบบสำเร็จผ่าน Google Account: ${cleanEmail}`);
  return profile;
}

/**
 * ล็อกอินด้วย Facebook
 */
export async function loginWithFacebook(
  displayName = 'Farmer Friend'
): Promise<UserProfile> {
  const cleanName = sanitizeText(displayName.trim(), 40) || 'Facebook Farmer';
  const cleanId = cleanName.toLowerCase().replace(/[^a-z0-9_]/g, '_') || 'user';
  const randomSuffix = generateSecureRandomHex(4);
  const userId = `fb_${cleanId}_${randomSuffix}`;
  const fakeEmail = `${cleanId}@facebook.user`;

  const profile: UserProfile = {
    id: userId,
    email: fakeEmail,
    displayName: cleanName,
    provider: 'facebook',
    photoURL: 'https://graph.facebook.com/default/picture',
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    token: `fb_tok_${generateSecureRandomHex(16)}`,
  };

  setCurrentUser(profile);
  logSecurityEvent('cloud_sync', `เข้าสู่ระบบสำเร็จผ่าน Facebook Account: ${cleanName}`);
  return profile;
}

/**
 * เข้าสู่ระบบแบบ Guest (ผู้มาเยือน)
 */
export function loginAsGuest(): UserProfile {
  const guestId = `guest_${generateSecureRandomHex(6)}`;
  const profile: UserProfile = {
    id: guestId,
    email: 'guest@beamfarm.local',
    displayName: 'ชาวสวนผู้มาเยือน (Guest)',
    provider: 'guest',
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
  };

  setCurrentUser(profile);
  return profile;
}

/**
 * ออกจากระบบ
 */
export function logoutUser(): void {
  const current = getCurrentUser();
  if (current) {
    logSecurityEvent('cloud_sync', `ออกจากระบบบัญชี: ${current.displayName} (${current.provider})`);
  }
  setCurrentUser(null);
}

/**
 * ตรวจสอบและดึงเซฟข้อมูลฟาร์มของบัญชีผู้ใช้ (ป้องกัน Account Pollution / ข้อมูลรั่วไหล)
 */
export function loadUserSaveData(userId?: string): Partial<GameSnapshot> | null {
  try {
    const key = getAccountSaveKey(userId);
    const raw = localStorage.getItem(key);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
    // หากบัญชียังไม่มีเซฟ ให้ส่งกลับ null เพื่อให้ระบบตัดสินใจสร้างใหม่หรือผูกจาก Guest
    return null;
  } catch {
    return null;
  }
}

/**
 * บันทึกข้อมูลฟาร์มเฉพาะบัญชีผู้ใช้
 */
export function saveUserSaveData(userId: string | undefined, snapshot: any): void {
  try {
    const key = getAccountSaveKey(userId);
    const rawJson = JSON.stringify(snapshot);
    localStorage.setItem(key, rawJson);

    // เซฟลง default key เฉพาะกรณีเป็น Guest เพื่อไม่ให้เขียนทับเซฟของ Guest ด้วยบัญชีอื่น
    if (!userId || userId.startsWith('guest_')) {
      localStorage.setItem(STORAGE_KEY, rawJson);
    }

    // บันทึกผ่าน secureStorage
    secureStorage.set(key, snapshot).catch(() => {});
  } catch (err) {
    console.error('Failed to save user farm data:', err);
  }
}
