/**
 * Web Audio API synthesizer for Beam Farm (B.P.)
 * High-Volume & Punchy Sound with Master Compressor
 */

export class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;

  public soundEnabled = true;
  public musicEnabled = false;

  private _masterVolume = 1.0;
  private _sfxVolume = 1.0;
  private _musicVolume = 0.7; // ปรับเพลงพื้นหลังให้ชัดขึ้น

  private musicInterval: number | null = null;
  private sfxTimestamps: number[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      const unlock = () => {
        this.ensureContext();
        window.removeEventListener('pointerdown', unlock);
        window.removeEventListener('keydown', unlock);
      };
      window.addEventListener('pointerdown', unlock, { once: true });
      window.addEventListener('keydown', unlock, { once: true });
    }
  }

  // --- Core & Bus Architecture ---

  private ensureContext(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();

      // Master Compressor: ป้องกันเสียงแตกเวลาเสียงซ้อนกัน ช่วยให้ดัน Volume ได้ดังและแน่นขึ้น
      this.compressor = this.ctx.createDynamicsCompressor();
      this.compressor.threshold.setValueAtTime(-12, this.ctx.currentTime);
      this.compressor.knee.setValueAtTime(24, this.ctx.currentTime);
      this.compressor.ratio.setValueAtTime(10, this.ctx.currentTime);
      this.compressor.attack.setValueAtTime(0.003, this.ctx.currentTime);
      this.compressor.release.setValueAtTime(0.2, this.ctx.currentTime);

      this.masterGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();

      this.updateVolumes();

      // Routing: SFX/Music -> Compressor -> MasterGain -> Destination
      this.sfxGain.connect(this.compressor);
      this.musicGain.connect(this.compressor);
      this.compressor.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    return this.ctx;
  }

  private updateVolumes() {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    if (this.masterGain) this.masterGain.gain.setValueAtTime(this._masterVolume, now);
    if (this.sfxGain) this.sfxGain.gain.setValueAtTime(this.soundEnabled ? this._sfxVolume : 0, now);
    if (this.musicGain) this.musicGain.gain.setValueAtTime(this.musicEnabled ? this._musicVolume : 0, now);
  }

  setMasterVolume(val: number) {
    this._masterVolume = Math.max(0, Math.min(1.5, val)); // อนุญาตให้เร่งได้สูงสุด 1.5
    this.updateVolumes();
  }

  setSfxVolume(val: number) {
    this._sfxVolume = Math.max(0, Math.min(1.5, val));
    this.updateVolumes();
  }

  setMusicVolume(val: number) {
    this._musicVolume = Math.max(0, Math.min(1.5, val));
    this.updateVolumes();
  }

  private checkSfxRateLimit(): boolean {
    const now = Date.now();
    this.sfxTimestamps = this.sfxTimestamps.filter((t) => now - t < 1000);
    if (this.sfxTimestamps.length >= 30) {
      return false;
    }
    this.sfxTimestamps.push(now);
    return true;
  }

  // --- Sound Effects (เร่ง Gain ให้ดังขึ้นชัดเจน) ---

  // ปุ่มกดไม้ (Click)
  playClick() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(450, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.55, ctx.currentTime); // เดิม 0.2 -> 0.55
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch {}
  }

  // ปลูกพืช (Planting)
  playPlant() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(200, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(360, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.65, ctx.currentTime); // เดิม 0.25 -> 0.65
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch {}
  }

  // เก็บเกี่ยวผลผลิต (Harvest Pop)
  playHarvest() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;

      [523.25, 659.25, 783.99].forEach((freq, i) => {
        if (!ctx || !this.sfxGain) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.05);

        gain.gain.setValueAtTime(0.5, now + i * 0.05); // เดิม 0.18 -> 0.5
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.16);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now + i * 0.05);
        osc.stop(now + i * 0.05 + 0.17);
      });
    } catch {}
  }

  // เหรียญทอง (Coin Jingle)
  // เสียงเฉือนเคียว: กวาดความถี่ 2600Hz -> 180Hz ภายใน 120ms
  playSickleSlice() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(2600, now);
      osc.frequency.exponentialRampToValueAtTime(180, now + 0.12);
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.13);
    } catch {}
  }

  // เสียงคอมโบไต่บันไดเสียง (ยิ่งคอมโบสูง โน้ตยิ่งสูง)
  playComboSound(comboCount: number) {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      const scale = [1, 1.122, 1.259, 1.498, 1.681, 2.0];
      const idx = Math.max(0, Math.min(comboCount - 1, scale.length - 1));
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440 * scale[idx], now);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.26);
    } catch {}
  }

  playCoin() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;

      [987.77, 1318.51].forEach((freq, idx) => {
        if (!ctx || !this.sfxGain) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.06);

        gain.gain.setValueAtTime(0.45, now + idx * 0.06); // เดิม 0.15 -> 0.45
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.22);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now + idx * 0.06);
        osc.stop(now + idx * 0.06 + 0.24);
      });
    } catch {}
  }

  // เลเวลอัป (Level Up Fanfare)
  playLevelUp() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const notes = [440, 554.37, 659.25, 880, 1108.73];
      const now = ctx.currentTime;

      notes.forEach((freq, i) => {
        if (!ctx || !this.sfxGain) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + i * 0.09);

        const duration = i === notes.length - 1 ? 0.65 : 0.2;
        gain.gain.setValueAtTime(0.6, now + i * 0.09); // เดิม 0.22 -> 0.6
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.09 + duration);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now + i * 0.09);
        osc.stop(now + i * 0.09 + duration);
      });
    } catch {}
  }

  // เสียงสำเร็จ (Success Chime)
  playSuccessChime() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      [587.33, 880].forEach((freq, i) => {
        if (!ctx || !this.sfxGain) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.08);

        gain.gain.setValueAtTime(0.5, now + i * 0.08); // เดิม 0.18 -> 0.5
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.24);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.26);
      });
    } catch {}
  }

  // เสียงสัตว์ (Animals)
  playAnimal(type: 'cow' | 'chicken' | 'pig' | 'sheep' | 'goat') {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      if (type === 'cow') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(145, now);
        osc.frequency.linearRampToValueAtTime(125, now + 0.2);
        osc.frequency.linearRampToValueAtTime(110, now + 0.45);

        gain.gain.setValueAtTime(0.45, now); // เดิม 0.12 -> 0.45
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.5);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.5);
      } else if (type === 'goat') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(340, now);
        osc.frequency.linearRampToValueAtTime(290, now + 0.15);
        osc.frequency.linearRampToValueAtTime(310, now + 0.3);

        gain.gain.setValueAtTime(0.45, now);
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.35);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'chicken') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(480, now);
        osc.frequency.exponentialRampToValueAtTime(650, now + 0.06);
        osc.frequency.exponentialRampToValueAtTime(390, now + 0.12);

        gain.gain.setValueAtTime(0.55, now); // เดิม 0.15 -> 0.55
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.14);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.14);
      } else if (type === 'pig') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(230, now);
        osc.frequency.linearRampToValueAtTime(160, now + 0.15);

        gain.gain.setValueAtTime(0.45, now); // เดิม 0.12 -> 0.45
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.18);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (type === 'sheep') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(290, now);
        osc.frequency.linearRampToValueAtTime(240, now + 0.25);

        gain.gain.setValueAtTime(0.45, now); // เดิม 0.12 -> 0.45
        gain.gain.exponentialRampToValueAtTime(0.005, now + 0.28);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(now);
        osc.stop(now + 0.28);
      }
    } catch {}
  }

  // รดน้ำ (Watering)
  playWater() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(850, now);
      osc.frequency.exponentialRampToValueAtTime(280, now + 0.12);

      gain.gain.setValueAtTime(0.6, now); // เดิม 0.2 -> 0.6
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now);
      osc.stop(now + 0.13);
    } catch {}
  }

  // แตรรถบรรทุกส่งของ (Truck Horn)
  playTruckHorn() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      [349.23, 440].forEach((freq) => {
        if (!ctx || !this.sfxGain) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'square';
        osc.frequency.setValueAtTime(freq, now);

        gain.gain.setValueAtTime(0.28, now); // เดิม 0.08 -> 0.28
        gain.gain.linearRampToValueAtTime(0.28, now + 0.25);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.35);
      });
    } catch {}
  }

  // เสียงดาวน์โหลด / โหลดดิ้ง (Loading Tick)
  playLoadingTick(progressPercent: number) {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      const baseFreq = 261.63 + (progressPercent / 100) * 440;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.05, now + 0.08);

      gain.gain.setValueAtTime(0.35, now); // เดิม 0.09 -> 0.35
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(now);
      osc.stop(now + 0.09);
    } catch {}
  }

  // เสียงโหลดเสร็จ (Loading Complete)
  playLoadingComplete() {
    if (!this.soundEnabled || !this.checkSfxRateLimit()) return;
    try {
      const ctx = this.ensureContext();
      if (!ctx || !this.sfxGain) return;
      const now = ctx.currentTime;
      const chordNotes = [523.25, 659.25, 783.99, 1046.5];

      chordNotes.forEach((freq, idx) => {
        if (!ctx || !this.sfxGain) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);

        gain.gain.setValueAtTime(0.48, now + idx * 0.07); // เดิม 0.16 -> 0.48
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.5);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now + idx * 0.07);
        osc.stop(now + idx * 0.07 + 0.52);
      });
    } catch {}
  }

  // --- ดนตรีประกอบพื้นหลัง (BGM) ---

  toggleMusic(enabled: boolean) {
    this.musicEnabled = enabled;
    this.updateVolumes();

    if (this.musicInterval) {
      window.clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    if (enabled) {
      this.startCountryTune();
    }
  }

  startBGM() {
    this.toggleMusic(true);
  }

  stopBGM() {
    this.toggleMusic(false);
  }

  private startCountryTune() {
    const tuneNotes = [261.63, 329.63, 392.0, 523.25, 392.0, 329.63];
    let noteIdx = 0;

    const playNextNote = () => {
      if (!this.musicEnabled) return;
      try {
        const ctx = this.ensureContext();
        if (!ctx || !this.musicGain) return;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(tuneNotes[noteIdx % tuneNotes.length], now);

        // ปรับเสียง BGM ขึ้นจาก 0.02 -> 0.18 ให้ได้ยินชัดเจนแต่ไม่กลบ SFX
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);

        osc.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        osc.stop(now + 0.58);
        noteIdx++;
      } catch {}
    };

    playNextNote();
    this.musicInterval = window.setInterval(playNextNote, 600);
  }

  dispose() {
    this.stopBGM();
    if (this.ctx && this.ctx.state !== 'closed') {
      this.ctx.close();
      this.ctx = null;
    }
  }
}

export const sound = new SoundEngine();