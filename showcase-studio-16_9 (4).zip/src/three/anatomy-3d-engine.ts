import * as THREE from 'three';
import { TMJState, CameraPreset } from '../types';

export class Anatomy3DEngine {
  private container: HTMLElement | null = null;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer | null = null;
  private animFrameId: number | null = null;

  // 3D Skeletal Mesh groups
  private rootGroup: THREE.Group;
  private skullGroup: THREE.Group;
  private mandibleGroup: THREE.Group;
  private spineGroup: THREE.Group;
  private ribCageGroup: THREE.Group;
  private leftClavicle: THREE.Mesh | null = null;
  private rightClavicle: THREE.Mesh | null = null;

  // Materials
  private boneMaterial: THREE.MeshPhysicalMaterial;
  private xRayWireMaterial: THREE.LineBasicMaterial;
  private jointDiscMaterial: THREE.MeshBasicMaterial;

  // Camera animation target
  private currentCameraPreset: CameraPreset = 'FRONT';
  private targetCameraPos = new THREE.Vector3(0, 0, 4.5);
  private targetLookAt = new THREE.Vector3(0, 0, 0);

  // Interaction
  private isMouseDown = false;
  private mousePrevX = 0;
  private mousePrevY = 0;
  private orbitYaw = 0;
  private orbitPitch = 0;
  private orbitDistance = 4.5;

  constructor() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(45, 16 / 9, 0.1, 100);
    this.camera.position.set(0, 0, 4.5);

    this.rootGroup = new THREE.Group();
    this.skullGroup = new THREE.Group();
    this.mandibleGroup = new THREE.Group();
    this.spineGroup = new THREE.Group();
    this.ribCageGroup = new THREE.Group();

    this.scene.add(this.rootGroup);
    this.rootGroup.add(this.skullGroup);
    this.rootGroup.add(this.spineGroup);
    this.rootGroup.add(this.ribCageGroup);

    // Soft-XRay Cyan gradient glow material
    this.boneMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x00f0ff,
      emissive: 0x004866,
      emissiveIntensity: 0.65,
      roughness: 0.25,
      metalness: 0.15,
      transparent: true,
      opacity: 0.82,
      transmission: 0.45,
      ior: 1.35,
      wireframe: false,
    });

    this.xRayWireMaterial = new THREE.LineBasicMaterial({
      color: 0x5df2ff,
      transparent: true,
      opacity: 0.4,
    });

    this.jointDiscMaterial = new THREE.MeshBasicMaterial({
      color: 0xffd700,
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });

    this.setupLighting();
    this.buildSkeletalGeometry();
  }

  private setupLighting() {
    const ambientLight = new THREE.AmbientLight(0x061826, 2.5);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x00f0ff, 3.0);
    keyLight.position.set(4, 5, 5);
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x00ffff, 4.0);
    rimLight.position.set(-5, 3, -4);
    this.scene.add(rimLight);

    const fillLight = new THREE.PointLight(0x0088cc, 2.0, 10);
    fillLight.position.set(0, -2, 2);
    this.scene.add(fillLight);
  }

  private buildSkeletalGeometry() {
    // 1. Cranium (Cranial Vault, Orbits, Zygomatic arch, Maxilla)
    const craniumGeom = new THREE.SphereGeometry(0.78, 32, 24);
    craniumGeom.scale(0.95, 1.15, 1.05);
    const craniumMesh = new THREE.Mesh(craniumGeom, this.boneMaterial);
    craniumMesh.position.set(0, 0.35, -0.05);
    this.skullGroup.add(craniumMesh);

    // Brow ridge & frontal bone
    const browGeom = new THREE.CylinderGeometry(0.55, 0.65, 0.2, 16);
    browGeom.scale(1.2, 1.0, 0.6);
    const browMesh = new THREE.Mesh(browGeom, this.boneMaterial);
    browMesh.position.set(0, 0.42, 0.52);
    browMesh.rotation.x = Math.PI * 0.1;
    this.skullGroup.add(browMesh);

    // Eye Orbits (Left and Right cutout impression)
    [-0.32, 0.32].forEach(x => {
      const orbitGeom = new THREE.TorusGeometry(0.18, 0.04, 12, 24);
      const orbitMesh = new THREE.Mesh(orbitGeom, this.boneMaterial);
      orbitMesh.position.set(x, 0.32, 0.65);
      this.skullGroup.add(orbitMesh);
    });

    // Nasal bone & aperture
    const nasalGeom = new THREE.ConeGeometry(0.12, 0.32, 8);
    const nasalMesh = new THREE.Mesh(nasalGeom, this.boneMaterial);
    nasalMesh.position.set(0, 0.2, 0.72);
    nasalMesh.rotation.x = -Math.PI * 0.15;
    this.skullGroup.add(nasalMesh);

    // Maxilla (Upper Jaw & Upper Dental Arch)
    const maxillaGeom = new THREE.BoxGeometry(0.58, 0.3, 0.42);
    const maxillaMesh = new THREE.Mesh(maxillaGeom, this.boneMaterial);
    maxillaMesh.position.set(0, 0.02, 0.54);
    this.skullGroup.add(maxillaMesh);

    // Upper Teeth row
    const upperTeethGeom = new THREE.TorusGeometry(0.24, 0.035, 8, 16, Math.PI);
    const upperTeeth = new THREE.Mesh(upperTeethGeom, this.boneMaterial);
    upperTeeth.position.set(0, -0.12, 0.52);
    upperTeeth.rotation.x = Math.PI * 0.5;
    this.skullGroup.add(upperTeeth);

    // Zygomatic arches (Cheekbones to TMJ fossa)
    [-0.62, 0.62].forEach(x => {
      const zygGeom = new THREE.CylinderGeometry(0.04, 0.04, 0.6, 8);
      const zygMesh = new THREE.Mesh(zygGeom, this.boneMaterial);
      zygMesh.position.set(x, 0.15, 0.25);
      zygMesh.rotation.x = Math.PI * 0.5;
      zygMesh.rotation.z = x > 0 ? -0.2 : 0.2;
      this.skullGroup.add(zygMesh);

      // Articular eminence & TMJ Glenoid Fossa
      const fossaGeom = new THREE.SphereGeometry(0.08, 8, 8);
      const fossaMesh = new THREE.Mesh(fossaGeom, this.jointDiscMaterial);
      fossaMesh.position.set(x, 0.16, -0.05);
      this.skullGroup.add(fossaMesh);
    });

    // 2. Mandible (Lower Jaw with TMJ Condyles and Chin)
    // Pivot origin is at the TMJ condyles: (0, 0.16, -0.05)
    this.mandibleGroup.position.set(0, 0.16, -0.05);
    this.skullGroup.add(this.mandibleGroup);

    // Left and right condylar processes & rami
    [-0.6, 0.6].forEach(x => {
      // Condyle head
      const condyleGeom = new THREE.SphereGeometry(0.065, 12, 8);
      condyleGeom.scale(1.2, 0.8, 0.8);
      const condyleMesh = new THREE.Mesh(condyleGeom, this.boneMaterial);
      condyleMesh.position.set(x, 0, 0);
      this.mandibleGroup.add(condyleMesh);

      // Mandibular Ramus descending to Gonial angle
      const ramusGeom = new THREE.CylinderGeometry(0.06, 0.07, 0.45, 8);
      const ramusMesh = new THREE.Mesh(ramusGeom, this.boneMaterial);
      ramusMesh.position.set(x * 0.95, -0.22, 0.08);
      ramusMesh.rotation.x = -0.3;
      this.mandibleGroup.add(ramusMesh);
    });

    // Mandibular body curve (Horse-shoe shape curving forward to chin)
    const jawBodyGeom = new THREE.TorusGeometry(0.38, 0.065, 8, 24, Math.PI);
    const jawBody = new THREE.Mesh(jawBodyGeom, this.boneMaterial);
    jawBody.position.set(0, -0.38, 0.42);
    jawBody.rotation.x = -Math.PI * 0.45;
    this.mandibleGroup.add(jawBody);

    // Lower Dental Arch
    const lowerTeethGeom = new THREE.TorusGeometry(0.23, 0.03, 8, 16, Math.PI);
    const lowerTeeth = new THREE.Mesh(lowerTeethGeom, this.boneMaterial);
    lowerTeeth.position.set(0, -0.26, 0.54);
    lowerTeeth.rotation.x = Math.PI * 0.5;
    this.mandibleGroup.add(lowerTeeth);

    // Chin Mental Protuberance
    const chinGeom = new THREE.BoxGeometry(0.24, 0.15, 0.14);
    const chinMesh = new THREE.Mesh(chinGeom, this.boneMaterial);
    chinMesh.position.set(0, -0.42, 0.64);
    this.mandibleGroup.add(chinMesh);

    // 3. Cervical Spine (C1-C7)
    for (let c = 1; c <= 7; c++) {
      const vertGeom = new THREE.CylinderGeometry(0.12 - c * 0.005, 0.14 - c * 0.005, 0.08, 12);
      const vertMesh = new THREE.Mesh(vertGeom, this.boneMaterial);
      vertMesh.position.set(0, -0.1 - c * 0.11, -0.15 + c * 0.02);
      this.spineGroup.add(vertMesh);

      // Spinous process (posterior spine spike)
      const spinousGeom = new THREE.ConeGeometry(0.04, 0.16, 6);
      const spinous = new THREE.Mesh(spinousGeom, this.boneMaterial);
      spinous.position.set(0, -0.1 - c * 0.11, -0.26 + c * 0.02);
      spinous.rotation.x = -Math.PI * 0.4;
      this.spineGroup.add(spinous);
    }

    // 4. Clavicles (Left & Right)
    const clavGeom = new THREE.CylinderGeometry(0.045, 0.04, 0.85, 8);
    clavGeom.scale(1.0, 1.0, 0.7);

    this.leftClavicle = new THREE.Mesh(clavGeom, this.boneMaterial);
    this.leftClavicle.position.set(-0.55, -0.92, 0.22);
    this.leftClavicle.rotation.z = 0.22;
    this.leftClavicle.rotation.y = 0.35;
    this.ribCageGroup.add(this.leftClavicle);

    this.rightClavicle = new THREE.Mesh(clavGeom, this.boneMaterial);
    this.rightClavicle.position.set(0.55, -0.92, 0.22);
    this.rightClavicle.rotation.z = -0.22;
    this.rightClavicle.rotation.y = -0.35;
    this.ribCageGroup.add(this.rightClavicle);

    // 5. Sternum & Rib Cage
    const sternumGeom = new THREE.BoxGeometry(0.14, 0.75, 0.05);
    const sternumMesh = new THREE.Mesh(sternumGeom, this.boneMaterial);
    sternumMesh.position.set(0, -1.35, 0.45);
    this.ribCageGroup.add(sternumMesh);

    // 7 True Ribs pairs
    for (let r = 0; r < 7; r++) {
      const radius = 0.48 + r * 0.045;
      const ribGeom = new THREE.TorusGeometry(radius, 0.032, 6, 24, Math.PI * 1.6);
      ribGeom.scale(1.4, 0.9, 1.0);
      const ribMesh = new THREE.Mesh(ribGeom, this.boneMaterial);
      ribMesh.position.set(0, -1.0 - r * 0.13, 0.15);
      ribMesh.rotation.x = Math.PI * 0.45 + r * 0.03;
      ribMesh.rotation.z = Math.PI * 0.2;
      this.ribCageGroup.add(ribMesh);
    }
  }

  public init(container: HTMLElement) {
    this.container = container;
    const width = container.clientWidth || 640;
    const height = container.clientHeight || 360;

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;

    container.appendChild(this.renderer.domElement);

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.setupInteractivity(this.renderer.domElement);
    this.startLoop();
  }

  public resize(width: number, height: number) {
    if (!this.renderer || !this.camera) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private setupInteractivity(canvas: HTMLCanvasElement) {
    canvas.addEventListener('mousedown', e => {
      this.isMouseDown = true;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;
    });

    window.addEventListener('mousemove', e => {
      if (!this.isMouseDown) return;
      const dx = e.clientX - this.mousePrevX;
      const dy = e.clientY - this.mousePrevY;
      this.mousePrevX = e.clientX;
      this.mousePrevY = e.clientY;

      this.orbitYaw -= dx * 0.008;
      this.orbitPitch = Math.max(-Math.PI * 0.35, Math.min(Math.PI * 0.35, this.orbitPitch + dy * 0.008));
      this.updateCameraOrbit();
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    canvas.addEventListener('wheel', e => {
      e.preventDefault();
      this.orbitDistance = Math.max(1.5, Math.min(10, this.orbitDistance + e.deltaY * 0.004));
      this.updateCameraOrbit();
    }, { passive: false });
  }

  public setCameraPreset(preset: CameraPreset) {
    this.currentCameraPreset = preset;
    switch (preset) {
      case 'FRONT':
        this.targetCameraPos.set(0, -0.1, 4.2);
        this.targetLookAt.set(0, -0.2, 0);
        this.orbitDistance = 4.2;
        this.orbitYaw = 0;
        this.orbitPitch = 0;
        break;
      case 'PROFILE':
        this.targetCameraPos.set(4.2, -0.1, 0);
        this.targetLookAt.set(0, -0.2, 0);
        this.orbitDistance = 4.2;
        this.orbitYaw = Math.PI * 0.5;
        this.orbitPitch = 0;
        break;
      case 'TOP':
        this.targetCameraPos.set(0, 4.4, 0.4);
        this.targetLookAt.set(0, 0, 0);
        this.orbitDistance = 4.4;
        this.orbitYaw = 0;
        this.orbitPitch = Math.PI * 0.45;
        break;
      case 'TMJ':
        // Zoom in close on right temporomandibular joint condyle
        this.targetCameraPos.set(1.8, 0.3, 1.4);
        this.targetLookAt.set(0.6, 0.16, 0);
        this.orbitDistance = 2.4;
        this.orbitYaw = 0.7;
        this.orbitPitch = 0.1;
        break;
      case 'WIDE':
        this.targetCameraPos.set(0, -0.6, 6.5);
        this.targetLookAt.set(0, -0.6, 0);
        this.orbitDistance = 6.5;
        this.orbitYaw = 0;
        this.orbitPitch = 0;
        break;
    }
  }

  private updateCameraOrbit() {
    const x = Math.sin(this.orbitYaw) * Math.cos(this.orbitPitch) * this.orbitDistance;
    const y = Math.sin(this.orbitPitch) * this.orbitDistance;
    const z = Math.cos(this.orbitYaw) * Math.cos(this.orbitPitch) * this.orbitDistance;
    this.targetCameraPos.set(x, y - 0.2, z);
  }

  public setXRayOpacity(opacity: number) {
    this.boneMaterial.opacity = opacity;
  }

  public setWireframe(wireframe: boolean) {
    this.boneMaterial.wireframe = wireframe;
  }

  // Animate TMJ & Biomechanical State in 3D
  public updatePhysics(tmj: TMJState) {
    // 1. Mandibular Rotation & Condylar Slide
    // Pivot condyle: rotation around local X axis
    this.mandibleGroup.rotation.x = tmj.jawAngle;

    // Condylar Slide: translational movement downward and forward
    // convert mm to Three.js units (1 unit ~ 100mm)
    const transY = -tmj.jawTranslationY * 0.01;
    const transZ = tmj.jawTranslationZ * 0.01;
    this.mandibleGroup.position.set(0, 0.16 + transY, -0.05 + transZ);

    // 2. Respiration: thoracic expansion and clavicle lift
    const breathFactor = Math.sin(tmj.respirationPhase);
    const ribExpansion = 1.0 + breathFactor * 0.035;
    this.ribCageGroup.scale.set(ribExpansion, 1.0 + breathFactor * 0.02, ribExpansion);

    if (this.leftClavicle && this.rightClavicle) {
      this.leftClavicle.rotation.z = 0.22 + breathFactor * 0.04;
      this.rightClavicle.rotation.z = -0.22 - breathFactor * 0.04;
    }

    // 3. Postural sway & tremor on the skull
    this.skullGroup.position.x = tmj.swayX * 0.004;
    this.skullGroup.position.y = tmj.swayY * 0.005;
    this.skullGroup.rotation.z = tmj.swayZ * 0.005;
    this.skullGroup.rotation.y = tmj.swayX * 0.003;

    // 4. Cardiac micro-pulse
    const pulse = tmj.heartBeatPulse * 0.008;
    this.boneMaterial.emissiveIntensity = 0.55 + pulse * 15;
  }

  private startLoop() {
    const loop = () => {
      this.animFrameId = requestAnimationFrame(loop);

      // Smooth camera interpolation
      this.camera.position.lerp(this.targetCameraPos, 0.08);
      this.camera.lookAt(this.targetLookAt);

      if (this.renderer) {
        this.renderer.render(this.scene, this.camera);
      }
    };
    loop();
  }

  public getDomElement(): HTMLCanvasElement | null {
    return this.renderer ? this.renderer.domElement : null;
  }

  public destroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer && this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
      this.renderer.dispose();
    }
  }
}
