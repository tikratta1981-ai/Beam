// src/App.tsx

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Eye, EyeOff, Maximize2, Minimize2 } from 'lucide-react';
import { TopHUD } from './components/hud/TopHUD';
import { LeftMenu } from './components/dock/LeftMenu';
import { RightMenu } from './components/dock/RightMenu';
import { BottomDock } from './components/dock/BottomDock';
import { FarmWorld } from './components/farm/FarmWorld';
import { AppModals } from './components/modals/AppModals';
import { Toast, ToastData } from './components/common/Toast';
import { AiChodChatModal } from './components/modals/system/AiChodChatModal';
import { AuthModal } from './components/modals/system/AuthModal';
import { PigFeedMixerModal } from './components/modals/animal/PigFeedMixerModal';
import { PigEntity } from './components/3d/models/animals/IsometricPig3D';
import { UserProfile } from './types/auth';
import {
  getCurrentUser,
  getAccountSaveKey,
  loadUserSaveData,
  logoutUser,
} from './utils/auth';
import {
  sanitizeFarmName,
  validateSnapshot,
  secureStorage,
  logSecurityEvent,
  monotonicClock,
} from './security';

import {
  CROPS,
  RECIPES,
  INITIAL_INVENTORY,
  INITIAL_QUESTS,
  INITIAL_FRIENDS,
  DAILY_REWARDS,
} from './data/initialData';
import {
  STORAGE_KEY,
  LEGACY_STORAGE_KEY,
  CROP_UNLOCK_LEVELS,
  ANIMAL_TEMPLATES,
  GameSnapshot,
} from './data/gameConstants';
import {
  Plot,
  AnimalPen,
  Factory,
  Quest,
  Order,
  Friend,
  DailyReward,
  CropType,
  FarmLog,
  InventoryItem,
} from './types/game';
import { MailMessage } from './components/modals/social/MailModal';
import { generateLevelAppropriateOrder } from './utils/generators/orderGenerator';
import { sound } from './utils/audio/index';
import { harvestSystem } from './components/farm/harvest/HarvestSystem';

// แม่แบบข้อมูลเริ่มต้นสำหรับคอกแพะนม 3D
const DEFAULT_GOAT_PEN: AnimalPen = (ANIMAL_TEMPLATES as any)?.goat || {
  id: 'pen_goat_init',
  type: 'goat',
  name: 'Goat Pen',
  thaiName: 'คอกแพะนม',
  icon: '🐐',
  levelRequired: 3,
  feedRequired: 2,
  feedCropId: 'wheat',
  durationSec: 35,
  produceItem: 'goat_milk',
  produceName: 'น้ำนมแพะสด',
  produceIcon: '🥛',
  produceQuantity: 2,
  fedAt: null,
  isReady: false,
};

// ฟังก์ชันเติมพิกัด Isometric Grid เริ่มต้นสำหรับแปลงที่ยังไม่มีตำแหน่ง x, y
const ensurePlotCoordinates = (plot: Plot, index: number): Plot => {
  const p = plot as any;
  const col = index % 5;
  const row = Math.floor(index / 5);
  return {
    ...plot,
    x: p.x ?? 510 + col * 114,
    y: p.y ?? 310 + row * 86,
    width: p.width ?? 120,
    height: p.height ?? 92,
    cropType: p.cropType || plot.cropId || null,
  } as Plot;
};

// ข้อมูลเริ่มต้นสำหรับหมู
const INITIAL_PIGS: PigEntity[] = [
  {
    id: 'pig_alpha_1',
    x: 640,
    y: 480,
    fedAt: null,
    durationSec: 30, // 30 วินาที
    isReady: false,
    produceName: 'เบคอนพรีเมียม',
    produceIcon: '🥓',
  },
];

export default function App() {
  // ----------------------------------------------------
  // 1. Robust Persistence Loader (Backward Compatible & Anti-Cheat Validated)
  // ----------------------------------------------------
  const loadInitialSnapshot = (): Partial<GameSnapshot & { pigs?: PigEntity[] }> => {
    try {
      const activeUser = getCurrentUser();
      const accountKey = getAccountSaveKey(activeUser?.id);
      const unifiedData = localStorage.getItem(accountKey) || localStorage.getItem(STORAGE_KEY);
      if (unifiedData) {
        const parsed = JSON.parse(unifiedData);
        if (parsed && !parsed.cipher) {
          const { sanitized, valid, reason } = validateSnapshot(parsed);
          if (!valid && reason) {
            console.warn('[SECURITY Anti-Cheat] Clamped snapshot:', reason);
          }
          return {
            ...sanitized,
            pigs: parsed.pigs || INITIAL_PIGS,
          };
        }
      }

      const legacyGet = <T,>(k: string, fallback: T): T => {
        const item = localStorage.getItem(`${LEGACY_STORAGE_KEY}_${k}`);
        return item ? JSON.parse(item) : fallback;
      };

      return {
        coins: legacyGet('coins', 500),
        gems: legacyGet('gems', 10),
        energy: legacyGet('energy', 30),
        maxEnergy: legacyGet('maxEnergy', 30),
        level: legacyGet('level', 1),
        xp: legacyGet('xp', 0),
        maxXp: legacyGet('maxXp', 100),
        farmName: legacyGet('farmName', 'My Cozy Farm'),
        plots: legacyGet('plots', []),
        animals: legacyGet('animals', []),
        factories: legacyGet('factories', {}),
        inventory: legacyGet('inventory', null as any),
        barnCapacity: Math.max(legacyGet('barnCapacity', 250), 250),
        quests: legacyGet('quests', INITIAL_QUESTS),
        orders: legacyGet('orders', []),
        friends: legacyGet('friends', INITIAL_FRIENDS),
        dailyRewards: legacyGet('dailyRewards', DAILY_REWARDS),
        festivalPoints: legacyGet('festivalPoints', 0),
        claimedTiers: legacyGet('claimedTiers', []),
        farmLogs: legacyGet('farmLogs', []),
        mails: legacyGet('mails', []),
        lastActiveTime: legacyGet('last_active_time', Date.now()),
        pigs: legacyGet('pigs', INITIAL_PIGS),
      };
    } catch {
      return {};
    }
  };

  const initialSave = useRef(loadInitialSnapshot()).current;

  // Window & UI State
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showLoadingScreen, setShowLoadingScreen] = useState<boolean>(true);
  const [isAiChodOpen, setIsAiChodOpen] = useState<boolean>(false);
  const [isZenMode, setIsZenMode] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => getCurrentUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Active Farm Zone
  const [currentFarmId, setCurrentFarmId] = useState<'farm1' | 'farm2'>(() => {
    try {
      return (localStorage.getItem('beam_farm_active_map_id') as 'farm1' | 'farm2') || 'farm1';
    } catch {
      return 'farm1';
    }
  });

  // Player Profile State
  const [coins, setCoins] = useState<number>(() => initialSave.coins ?? 500);
  const [gems, setGems] = useState<number>(() => initialSave.gems ?? 10);
  const [energy, setEnergy] = useState<number>(() => initialSave.energy ?? 30);
  const [maxEnergy, setMaxEnergy] = useState<number>(() => initialSave.maxEnergy ?? 30);
  const [level, setLevel] = useState<number>(() => initialSave.level ?? 1);
  const [xp, setXp] = useState<number>(() => initialSave.xp ?? 0);
  const [maxXp, setMaxXp] = useState<number>(() => initialSave.maxXp ?? 100);
  const [farmName, setFarmName] = useState<string>(() => initialSave.farmName ?? 'My Cozy Farm');

  const profileRef = useRef({
    coins,
    gems,
    energy,
    maxEnergy,
    level,
    xp,
    maxXp,
  });

  useEffect(() => {
    profileRef.current = { coins, gems, energy, maxEnergy, level, xp, maxXp };
  }, [coins, gems, energy, maxEnergy, level, xp, maxXp]);

  // Farm Elements State
  const [plots, setPlots] = useState<Plot[]>(() => {
    if (initialSave.plots && initialSave.plots.length > 0) {
      return initialSave.plots.map((p, idx) => ensurePlotCoordinates(p, idx));
    }
    return [
      { id: 0, cropId: null, plantedAt: null, isReady: false, watered: false, x: 510, y: 310, width: 120, height: 92 } as any,
      { id: 1, cropId: null, plantedAt: null, isReady: false, watered: false, x: 624, y: 310, width: 120, height: 92 } as any,
      { id: 2, cropId: null, plantedAt: null, isReady: false, watered: false, x: 738, y: 310, width: 120, height: 92 } as any,
      { id: 3, cropId: null, plantedAt: null, isReady: false, watered: false, x: 852, y: 310, width: 120, height: 92 } as any,
    ];
  });

  const [animals, setAnimals] = useState<AnimalPen[]>(() => {
    let list: AnimalPen[] = [];
    if (initialSave.animals && initialSave.animals.length > 0) {
      list = initialSave.animals;
      const hasGoat = list.some((a) => a.type === 'goat' || a.id?.includes('goat'));
      if (!hasGoat) {
        list = [...list, DEFAULT_GOAT_PEN];
      }
    } else {
      list = [
        { ...ANIMAL_TEMPLATES.chicken, id: 'pen_chicken_init' },
        { ...ANIMAL_TEMPLATES.cow, id: 'pen_cow_init' },
        DEFAULT_GOAT_PEN,
      ];
    }

    // Deduplicate by id so no duplicate keys (like pen_goat_init) can ever exist
    const seenIds = new Set<string>();
    const dedupedList: AnimalPen[] = [];
    for (const pen of list) {
      if (!pen) continue;
      const id = typeof pen.id === 'string' && pen.id.trim() ? pen.id.trim() : `pen_${pen.type}_${dedupedList.length}`;
      if (seenIds.has(id)) {
        continue;
      }
      seenIds.add(id);
      dedupedList.push({ ...pen, id });
    }
    return dedupedList;
  });

  // ระบบหมู 3 มิติ (Anatomical 3D Pigs)
  const [pigs, setPigs] = useState<PigEntity[]>(() => {
    return initialSave.pigs && initialSave.pigs.length > 0 ? initialSave.pigs : INITIAL_PIGS;
  });
  const [selectedPigForFeed, setSelectedPigForFeed] = useState<string | null>(null);

  const [factories, setFactories] = useState<Record<string, Factory>>(() => {
    if (initialSave.factories && Object.keys(initialSave.factories).length > 0) return initialSave.factories;
    return {
      bakery: { id: 'bakery', name: 'Bakery', thaiName: 'เตาอบขนมปัง', icon: '🍞', level: 1, currentProduction: null, queue: [], completedItems: [] },
      dairy: { id: 'dairy', name: 'Dairy', thaiName: 'โรงงานนมเนย', icon: '🥛', level: 1, currentProduction: null, queue: [], completedItems: [] },
      jam: { id: 'jam', name: 'Jam & Honey', thaiName: 'โรงงานน้ำผึ้งและแยม', icon: '🍯', level: 1, currentProduction: null, queue: [], completedItems: [] },
      windmill: { id: 'windmill', name: 'Windmill', thaiName: 'กังหันลมแป้ง', icon: '🌾', level: 1, currentProduction: null, queue: [], completedItems: [] },
    };
  });

  const [inventory, setInventory] = useState<Record<string, InventoryItem>>(() => {
    if (initialSave.inventory && Object.keys(initialSave.inventory).length > 0) {
      const inv = { ...initialSave.inventory };
      if (!inv.goat_milk) {
        inv.goat_milk = { id: 'goat_milk', name: 'Goat Milk', thaiName: 'น้ำนมแพะสด', category: 'animal', count: 0, icon: '🥛', sellPrice: 45 };
      }
      return inv;
    }
    return {
      ...INITIAL_INVENTORY,
      wheat: { id: 'wheat', name: 'Wheat', thaiName: 'ข้าวสาลี', category: 'crops', count: 10, icon: '🌾', sellPrice: 10 },
      corn: { id: 'corn', name: 'Corn', thaiName: 'ข้าวโพด', category: 'crops', count: 10, icon: '🌽', sellPrice: 20 },
      apple: { id: 'apple', name: 'Apple', thaiName: 'แอปเปิ้ลสด', category: 'special', count: 5, icon: '🍎', sellPrice: 35 },
      goat_milk: { id: 'goat_milk', name: 'Goat Milk', thaiName: 'น้ำนมแพะสด', category: 'animal', count: 0, icon: '🥛', sellPrice: 45 },
    };
  });

  const [barnCapacity, setBarnCapacity] = useState<number>(() => {
    const saved = initialSave.barnCapacity;
    return typeof saved === 'number' && saved >= 200 ? saved : 250;
  });
  const [quests, setQuests] = useState<Quest[]>(() => initialSave.quests ?? INITIAL_QUESTS);
  const [friends, setFriends] = useState<Friend[]>(() => initialSave.friends ?? INITIAL_FRIENDS);
  const [dailyRewards, setDailyRewards] = useState<DailyReward[]>(() => initialSave.dailyRewards ?? DAILY_REWARDS);
  const [festivalPoints, setFestivalPoints] = useState<number>(() => initialSave.festivalPoints ?? 0);
  const [claimedTiers, setClaimedTiers] = useState<number[]>(() => initialSave.claimedTiers ?? []);

  const [farmLogs, setFarmLogs] = useState<FarmLog[]>(() =>
    initialSave.farmLogs && initialSave.farmLogs.length > 0
      ? initialSave.farmLogs
      : [{ id: '1', message: 'ยินดีต้อนรับสู่ฟาร์มของคุณ! มีเมล็ดพืช เล้าไก่ และฝูงแพะนมอารมณ์ดีพร้อมดูแล 🌱🐔🐐', time: '08:00', type: 'info' }]
  );

  const [mails, setMails] = useState<MailMessage[]>(() =>
    initialSave.mails && initialSave.mails.length > 0
      ? initialSave.mails
      : [
          {
            id: 'm1',
            sender: 'ผู้ช่วยนายกเทศมนตรี',
            avatar: '🎩',
            subject: 'ยินดีต้อนรับสู่เมืองชนบทสุขใจ!',
            content: 'ยินดีด้วยกับการเริ่มต้นทำฟาร์ม! นี่คือทุนสนับสนุนก้อนแรกสำหรับซื้อเมล็ดพันธุ์',
            reward: { coins: 300, gems: 5, energy: 15 },
            read: false,
            claimed: false,
            date: 'วันนี้',
          },
        ]
  );

  const nextEnergyTimestampRef = useRef<number>(initialSave.nextEnergyTimestamp ?? (Date.now() + 180000));
  const nextGiftTimestampRef = useRef<number>(initialSave.nextGiftTimestamp ?? (Date.now() + 1800000));
  const [energyTimerDisplay, setEnergyTimerDisplay] = useState<string>('03:00');
  const [giftCountdownDisplay, setGiftCountdownDisplay] = useState<string>('30:00');
  const [isGiftReady, setIsGiftReady] = useState<boolean>(false);

  const fruitNextReadyAtRef = useRef<{ apple: number; orange: number }>({ apple: 0, orange: 0 });
  const [fruitReady, setFruitReady] = useState<{ apple: boolean; orange: boolean }>({ apple: true, orange: true });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(false);

  const [luckyFisherBuff, setLuckyFisherBuff] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('farm_lucky_buff') || 0);
    } catch {
      return 0;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('farm_lucky_buff', String(luckyFisherBuff));
    } catch {}
  }, [luckyFisherBuff]);

  // Modals & Navigation
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedPlotForPlanting, setSelectedPlotForPlanting] = useState<number | null>(null);
  const [selectedFactoryId, setSelectedFactoryId] = useState<string>('bakery');
  const [visitingFriend, setVisitingFriend] = useState<Friend | null>(null);
  const [shopInitialTab, setShopInitialTab] = useState<string>('seeds');
  const [levelUpData, setLevelUpData] = useState<{ show: boolean; level: number }>({ show: false, level: 1 });

  // Floating Toast
  const [toast, setToast] = useState<ToastData | null>(null);
  const showToast = useCallback((message: string, type: 'info' | 'error' | 'success' = 'info') => {
    setToast({ message, type });
  }, []);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 2800);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const addLog = useCallback((message: string, type: FarmLog['type'] = 'info') => {
    const newLog: FarmLog = {
      id: `${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      message,
      time: new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' }),
      type,
    };
    setFarmLogs((prev) => [...prev.slice(-19), newLog]);
  }, []);

  const [orders, setOrders] = useState<Order[]>(() => {
    if (initialSave.orders && initialSave.orders.length > 0) return initialSave.orders;
    return [
      generateLevelAppropriateOrder(1, 'ord_1'),
      generateLevelAppropriateOrder(1, 'ord_2'),
      generateLevelAppropriateOrder(1, 'ord_3'),
    ];
  });

  const toggleFullScreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {
        showToast('เบราว์เซอร์ไม่อนุญาตให้เปิดโหมดเต็มจออัตโนมัติ', 'error');
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => setIsFullscreen(false));
      }
    }
  }, [showToast]);

  useEffect(() => {
    const handleFullscreenChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const handleSwitchFarm = useCallback((farmId: 'farm1' | 'farm2') => {
    setCurrentFarmId(farmId);
    try {
      localStorage.setItem('beam_farm_active_map_id', farmId);
      window.dispatchEvent(new CustomEvent('farmMapChanged', { detail: farmId }));
    } catch {}
    sound.playClick();
    if (farmId === 'farm2') {
      showToast('ยินดีต้อนรับสู่อาณาเขตฟาร์มเกาะมรกต (Farm 2)! 🏝️', 'success');
      addLog('เดินทางสู่อาณาเขตฟาร์มเกาะมรกตเรียบร้อยแล้ว', 'upgrade');
    } else {
      showToast('กลับสู่ฟาร์มหลักริมสายน้ำ (Farm 1)! 🏡', 'success');
      addLog('เดินทางกลับสู่ฟาร์มหลักริมสายน้ำเรียบร้อยแล้ว', 'info');
    }
  }, [addLog, showToast]);

  // ----------------------------------------------------
  // 2. Offline Progress Loop
  // ----------------------------------------------------
  useEffect(() => {
    const lastActive = initialSave.lastActiveTime ?? Date.now();
    const now = Date.now();

    if (now < lastActive || monotonicClock.isTampered()) return;

    const maxOfflineSeconds = 43200; // 12 ชม.
    const offlineSeconds = Math.max(0, Math.min(maxOfflineSeconds, Math.floor((now - lastActive) / 1000)));

    if (offlineSeconds > 5) {
      const currentEnergy = profileRef.current.energy;
      const currentMaxEnergy = profileRef.current.maxEnergy;

      if (currentEnergy < currentMaxEnergy) {
        const energyGained = Math.floor(offlineSeconds / 180);
        if (energyGained > 0) {
          const updatedEnergy = Math.min(currentMaxEnergy, currentEnergy + energyGained);
          setEnergy(updatedEnergy);
          profileRef.current.energy = updatedEnergy;
          nextEnergyTimestampRef.current = Date.now() + 180000;
        }
      }

      setPlots((prev) =>
        prev.map((plot) => {
          const cropKey = plot.cropId || (plot as any).cropType;
          if (!cropKey || !plot.plantedAt || plot.isReady) return plot;
          const crop = CROPS[cropKey];
          return crop && (now - plot.plantedAt) / 1000 >= crop.growTimeSec ? { ...plot, isReady: true } : plot;
        })
      );

      setAnimals((prev) =>
        prev.map((pen) => {
          if (!pen.fedAt || pen.isReady) return pen;
          return (now - pen.fedAt) / 1000 >= pen.durationSec ? { ...pen, isReady: true } : pen;
        })
      );

      setPigs((prev) =>
        prev.map((pig) => {
          if (!pig.fedAt || pig.isReady) return pig;
          return (now - pig.fedAt) / 1000 >= pig.durationSec ? { ...pig, isReady: true } : pig;
        })
      );
    }
  }, []);

  // ----------------------------------------------------
  // 3. Main Game Loop (1s Tick)
  // ----------------------------------------------------
  useEffect(() => {
    const interval = window.setInterval(() => {
      const now = Date.now();

      // Plots Status
      setPlots((prevPlots) => {
        let hasMatured = false;
        for (let i = 0; i < prevPlots.length; i++) {
          const plot = prevPlots[i];
          const cropKey = plot.cropId || (plot as any).cropType;
          if (cropKey && plot.plantedAt && !plot.isReady) {
            const crop = CROPS[cropKey];
            if (crop && (now - plot.plantedAt) / 1000 >= crop.growTimeSec) {
              hasMatured = true;
              break;
            }
          }
        }
        if (!hasMatured) return prevPlots;

        return prevPlots.map((plot) => {
          const cropKey = plot.cropId || (plot as any).cropType;
          if (!cropKey || !plot.plantedAt || plot.isReady) return plot;
          const crop = CROPS[cropKey];
          return crop && (now - plot.plantedAt) / 1000 >= crop.growTimeSec ? { ...plot, isReady: true } : plot;
        });
      });

      // Animals Status (ไก่, วัว, แพะ, แกะ)
      setAnimals((prevAnimals) => {
        let hasProduced = false;
        for (let i = 0; i < prevAnimals.length; i++) {
          const pen = prevAnimals[i];
          if (pen.fedAt && !pen.isReady && (now - pen.fedAt) / 1000 >= pen.durationSec) {
            hasProduced = true;
            break;
          }
        }
        if (!hasProduced) return prevAnimals;

        return prevAnimals.map((pen) => {
          if (!pen.fedAt || pen.isReady) return pen;
          return (now - pen.fedAt) / 1000 >= pen.durationSec ? { ...pen, isReady: true } : pen;
        });
      });

      // หมูย่อยอาหารเสร็จสมบูรณ์
      setPigs((prevPigs) => {
        let hasProduced = false;
        for (let i = 0; i < prevPigs.length; i++) {
          const p = prevPigs[i];
          if (p.fedAt && !p.isReady && (now - p.fedAt) / 1000 >= p.durationSec) {
            hasProduced = true;
            break;
          }
        }
        if (!hasProduced) return prevPigs;

        return prevPigs.map((p) => {
          if (!p.fedAt || p.isReady) return p;
          return (now - p.fedAt) / 1000 >= p.durationSec ? { ...p, isReady: true } : p;
        });
      });

      // Factory Production
      setFactories((prevFactories) => {
        let changed = false;
        const updated = { ...prevFactories };

        Object.keys(updated).forEach((facId) => {
          const fac = updated[facId];
          if (fac.currentProduction) {
            const elapsed = (now - fac.currentProduction.startedAt) / 1000;
            if (elapsed >= fac.currentProduction.durationSec) {
              changed = true;
              updated[facId] = {
                ...fac,
                completedItems: [...(fac.completedItems || []), fac.currentProduction.recipeId],
                currentProduction: null,
              };
            }
          }
        });

        return changed ? updated : prevFactories;
      });

      // Fruit Trees
      setFruitReady((prev) => {
        const appleReady = now >= fruitNextReadyAtRef.current.apple;
        const orangeReady = now >= fruitNextReadyAtRef.current.orange;
        if (prev.apple === appleReady && prev.orange === orangeReady) return prev;
        return { apple: appleReady, orange: orangeReady };
      });

      // Energy Tick
      if (profileRef.current.energy < profileRef.current.maxEnergy) {
        if (now >= nextEnergyTimestampRef.current) {
          const gained = Math.max(1, Math.floor((now - nextEnergyTimestampRef.current) / 180000) + 1);
          setEnergy((e) => {
            const nextE = Math.min(profileRef.current.maxEnergy, e + gained);
            profileRef.current.energy = nextE;
            return nextE;
          });
          nextEnergyTimestampRef.current = now + 180000;
        }

        const remainingMs = Math.max(0, nextEnergyTimestampRef.current - now);
        const sec = Math.ceil(remainingMs / 1000);
        const m = Math.floor(sec / 60);
        const s = sec % 60;
        setEnergyTimerDisplay(`${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`);
      } else {
        nextEnergyTimestampRef.current = now + 180000;
        setEnergyTimerDisplay('เต็ม');
      }

      // Gift Countdown
      const remainingGiftSec = Math.max(0, Math.ceil((nextGiftTimestampRef.current - now) / 1000));
      setIsGiftReady(remainingGiftSec === 0);

      const gh = Math.floor(remainingGiftSec / 3600);
      const gm = Math.floor((remainingGiftSec % 3600) / 60);
      const gs = remainingGiftSec % 60;
      setGiftCountdownDisplay(
        `${gh.toString().padStart(2, '0')}:${gm.toString().padStart(2, '0')}:${gs.toString().padStart(2, '0')}`
      );
    }, 1000);

    return () => window.clearInterval(interval);
  }, []);

  // ----------------------------------------------------
  // 4. XP & Level Up Logic
  // ----------------------------------------------------
  const addXp = useCallback((amount: number) => {
    if (amount <= 0) return;

    const current = profileRef.current;
    let currentLvl = current.level;
    let currentMaxXp = current.maxXp;
    let currentXp = current.xp + amount;
    let currentCoins = current.coins;
    let currentGems = current.gems;
    let currentMaxEnergy = current.maxEnergy;
    let currentEnergy = current.energy;
    let leveledUp = false;

    while (currentXp >= currentMaxXp) {
      currentXp -= currentMaxXp;
      currentLvl += 1;
      currentMaxXp = Math.round(currentMaxXp * 1.35);
      currentCoins += currentLvl * 200;
      currentGems += 5;
      currentMaxEnergy = 30 + (currentLvl - 1) * 2;
      currentEnergy = currentMaxEnergy;
      leveledUp = true;
    }

    profileRef.current = {
      ...current,
      level: currentLvl,
      xp: currentXp,
      maxXp: currentMaxXp,
      coins: currentCoins,
      gems: currentGems,
      energy: currentEnergy,
      maxEnergy: currentMaxEnergy,
    };

    setXp(currentXp);

    if (leveledUp) {
      setLevel(currentLvl);
      setMaxXp(currentMaxXp);
      setMaxEnergy(currentMaxEnergy);
      setCoins(currentCoins);
      setGems(currentGems);
      setEnergy(currentEnergy);
      setLevelUpData({ show: true, level: currentLvl });
      addLog(`ฟาร์มเลเวลอัปเป็นเลเวล ${currentLvl} แล้ว! 🏆 (พลังงานเต็มพิกัด)`, 'upgrade');
    }
  }, [addLog]);

  // ----------------------------------------------------
  // 5. Optimized Snapshot Save System (Ref-Based)
  // ----------------------------------------------------
  const saveStateRef = useRef({
    farmName,
    plots,
    animals,
    pigs,
    factories,
    inventory,
    barnCapacity,
    quests,
    orders,
    friends,
    dailyRewards,
    festivalPoints,
    claimedTiers,
    farmLogs,
    mails,
    currentUser,
  });

  useEffect(() => {
    saveStateRef.current = {
      farmName,
      plots,
      animals,
      pigs,
      factories,
      inventory,
      barnCapacity,
      quests,
      orders,
      friends,
      dailyRewards,
      festivalPoints,
      claimedTiers,
      farmLogs,
      mails,
      currentUser,
    };
  }, [
    farmName,
    plots,
    animals,
    pigs,
    factories,
    inventory,
    barnCapacity,
    quests,
    orders,
    friends,
    dailyRewards,
    festivalPoints,
    claimedTiers,
    farmLogs,
    mails,
    currentUser,
  ]);

  const executeSaveSnapshot = useCallback(() => {
    try {
      const state = saveStateRef.current;
      const snapshot: GameSnapshot & { pigs: PigEntity[] } = {
        coins: profileRef.current.coins,
        gems: profileRef.current.gems,
        energy: profileRef.current.energy,
        maxEnergy: profileRef.current.maxEnergy,
        level: profileRef.current.level,
        xp: profileRef.current.xp,
        maxXp: profileRef.current.maxXp,
        farmName: state.farmName,
        plots: state.plots,
        animals: state.animals,
        pigs: state.pigs,
        factories: state.factories,
        inventory: state.inventory,
        barnCapacity: state.barnCapacity,
        quests: state.quests,
        orders: state.orders,
        friends: state.friends,
        dailyRewards: state.dailyRewards,
        festivalPoints: state.festivalPoints,
        claimedTiers: state.claimedTiers,
        farmLogs: state.farmLogs,
        mails: state.mails,
        nextEnergyTimestamp: nextEnergyTimestampRef.current,
        nextGiftTimestamp: nextGiftTimestampRef.current,
        lastActiveTime: Date.now(),
      };
      const accountKey = getAccountSaveKey(state.currentUser?.id);
      const snapshotJson = JSON.stringify(snapshot);
      localStorage.setItem(accountKey, snapshotJson);
      localStorage.setItem(STORAGE_KEY, snapshotJson);
      secureStorage.set(accountKey, snapshot).catch(() => {});
    } catch (e) {
      console.error('Failed to save snapshot:', e);
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      if (harvestSystem.isBusy()) return;
      executeSaveSnapshot();
    }, 4000);
    harvestSystem.setOnIdle(executeSaveSnapshot);
    const handleBeforeUnload = () => executeSaveSnapshot();
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') executeSaveSnapshot();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      clearInterval(timer);
      harvestSystem.setOnIdle(null);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [executeSaveSnapshot]);

  // ----------------------------------------------------
  // 6. Farm & Resource Handlers
  // ----------------------------------------------------
  const handleOpenPlot = useCallback((plotId: number) => {
    setSelectedPlotForPlanting(plotId);
    setActiveModal('seedPicker');
  }, []);

  const handlePlantCrop = useCallback((crop: CropType) => {
    if (selectedPlotForPlanting === null) return;

    const requiredLevel = CROP_UNLOCK_LEVELS[crop.id] || 1;
    if (level < requiredLevel) {
      showToast(`พืชนี้จะปลดล็อกเมื่อถึงเลเวล ${requiredLevel}!`, 'error');
      return;
    }

    if (energy < 1) {
      showToast('พลังงานไม่เพียงพอ! รอการฟื้นฟู ⚡', 'error');
      return;
    }

    const seedItem = inventory[crop.id];
    if (!seedItem || seedItem.count < 1) {
      showToast(`คุณไม่มีเมล็ด ${crop.thaiName} ในคลัง! กรุณาซื้อที่ร้านค้าก่อน 🌱`, 'error');
      return;
    }

    sound.playPlant();
    setEnergy((e) => Math.max(0, e - 1));

    setInventory((prev) => {
      const current = prev[crop.id];
      return {
        ...prev,
        [crop.id]: { ...current, count: Math.max(0, current.count - 1) },
      };
    });

    setPlots((prev) =>
      prev.map((p) =>
        p.id === selectedPlotForPlanting
          ? ({
              ...p,
              cropId: crop.id,
              cropType: crop.id,
              plantedAt: Date.now(),
              isReady: false,
              watered: true,
            } as any)
          : p
      )
    );

    const remainingSeeds = seedItem.count - 1;
    addLog(`ปลูก ${crop.thaiName} สำเร็จ (ใช้เมล็ด -1 🌱, -1⚡)`, 'info');
    showToast(
      remainingSeeds > 0
        ? `ปลูก ${crop.thaiName} สำเร็จ! เหลือเมล็ด ${remainingSeeds} ชิ้น`
        : `ปลูก ${crop.thaiName} สำเร็จ! เมล็ดพันธุ์หมดแล้ว`,
      'success'
    );
    setActiveModal(null);
    setSelectedPlotForPlanting(null);
  }, [selectedPlotForPlanting, level, energy, inventory, showToast, addLog]);

  const handleHarvestPlot = useCallback((plotId: number) => {
    const targetPlot = plots.find((p) => p.id === plotId);
    if (!targetPlot) return;

    const cropKey = targetPlot.cropId || (targetPlot as any).cropType;
    if (!cropKey || !targetPlot.isReady) return;

    const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
    if (currentInventoryCount + 10 > barnCapacity) {
      showToast('โรงนาเต็มแล้ว! กรุณาขายผลผลิตหรืออัปเกรดความจุก่อนเก็บ 10 ต้น', 'error');
      return;
    }

    const crop = CROPS[cropKey];
    if (!crop) return;

    sound.playHarvest();

    setInventory((prev) => {
      const current = prev[crop.id] || {
        id: crop.id,
        name: crop.name,
        thaiName: crop.thaiName,
        category: 'crops',
        count: 0,
        icon: crop.icon,
        sellPrice: crop.sellPrice,
      };
      return {
        ...prev,
        [crop.id]: { ...current, count: current.count + 10 },
      };
    });

    const totalEarnings = crop.sellPrice * 5;
    const totalXp = crop.xpReward * 5;

    setCoins((c) => c + totalEarnings);
    addXp(totalXp);
    setFestivalPoints((fp) => fp + 5);

    setPlots((prev) =>
      prev.map((p) =>
        p.id === plotId
          ? ({
              ...p,
              cropId: null,
              cropType: null,
              plantedAt: null,
              isReady: false,
              watered: false,
            } as any)
          : p
      )
    );

    setQuests((prev) =>
      prev.map((q) => (q.type === 'harvest' ? { ...q, current: Math.min(q.target, q.current + 10) } : q))
    );

    addLog(`เก็บเกี่ยว ${crop.thaiName} (10 ต้น) สำเร็จ! ได้รับผลผลิต x10 (+${totalEarnings}🪙 / +${totalXp}XP)`, 'harvest');
    showToast(`เก็บเกี่ยว ${crop.thaiName} สำเร็จ! ได้รับผลผลิต x10 ชิ้น 🧺`, 'success');
  }, [plots, inventory, barnCapacity, showToast, addXp, addLog]);

  const handleSpeedUpPlot = useCallback((plotId: number) => {
    if (gems < 1) {
      showToast('เพชรไม่เพียงพอ!', 'error');
      return;
    }
    sound.playSuccessChime();
    setGems((g) => g - 1);
    setPlots((prev) => prev.map((p) => (p.id === plotId ? { ...p, isReady: true } : p)));
    addLog('ใช้เพชร 1💎 เร่งการเจริญเติบโตเสร็จทันที!', 'info');
    showToast('เร่งการเติบโตเสร็จทันที! ✨', 'success');
  }, [gems, showToast, addLog]);

  const handleSellItem = useCallback((itemId: string, count: number) => {
    if (count <= 0) return;
    const item = inventory[itemId];
    if (!item || item.count < count) {
      showToast('จำนวนสินค้าในคลังไม่เพียงพอที่จะขาย!', 'error');
      return;
    }

    const earnings = count * item.sellPrice;
    setCoins((c) => c + earnings);

    setInventory((prev) => ({
      ...prev,
      [itemId]: { ...item, count: item.count - count },
    }));

    sound.playCoin();
    addLog(`ขาย ${item.thaiName} จำนวน ${count} ชิ้น ได้รับเงิน +${earnings.toLocaleString()}🪙`, 'coin');
    showToast(`ขาย ${item.thaiName} สำเร็จ! ได้รับ +${earnings.toLocaleString()}🪙`, 'success');
  }, [inventory, showToast, addLog]);

  const currentUpgradeCost = 300 + Math.max(0, Math.floor((barnCapacity - 250) / 15)) * 120;

  const handleUpgradeCapacity = useCallback(() => {
    if (coins < currentUpgradeCost) {
      showToast(`เหรียญทองไม่พอ! ต้องการ ${currentUpgradeCost.toLocaleString()} เหรียญ`, 'error');
      return;
    }

    setCoins((c) => c - currentUpgradeCost);
    setBarnCapacity((cap) => cap + 15);
    addLog(`อัปเกรดความจุคลังเป็น ${barnCapacity + 15} ช่องสำเร็จ! (-${currentUpgradeCost}🪙)`, 'upgrade');
    showToast(`อัปเกรดความจุคลังเป็น ${barnCapacity + 15} ช่องแล้ว! 🏠`, 'success');
  }, [coins, currentUpgradeCost, barnCapacity, showToast, addLog]);

  const handleAddPlot = useCallback(() => {
    const plotCost = Math.min(600, 150 + plots.length * 30);
    if (coins < plotCost) {
      showToast(`เหรียญทองไม่เพียงพอ! ต้องการ ${plotCost.toLocaleString()} เหรียญ`, 'error');
      return;
    }

    const newId = Date.now();
    const newX = 510 + (plots.length % 5) * 114;
    const newY = 310 + Math.floor(plots.length / 5) * 86;

    setCoins((c) => c - plotCost);
    setPlots((prev) => [
      ...prev,
      {
        id: newId,
        cropId: null,
        cropType: null,
        plantedAt: null,
        isReady: false,
        watered: false,
        x: newX,
        y: newY,
        width: 120,
        height: 92,
      } as any,
    ]);
    addLog(`ขยายแปลงเกษตรเพิ่มสำเร็จ! (-${plotCost}🪙)`, 'upgrade');
    showToast('ขยายแปลงเกษตรเพิ่มสำเร็จ! 🌱', 'success');
  }, [plots.length, coins, showToast, addLog]);

  const handleMovePlot = useCallback((plotId: number, x: number, y: number) => {
    setPlots((prev) => prev.map((p) => (p.id === plotId ? ({ ...p, x, y } as any) : p)));
  }, []);

  const handleDeletePlot = useCallback((plotId: number) => {
    setPlots((prev) => prev.filter((p) => p.id !== plotId));
    addLog('ลบแปลงเกษตรออกจากฟาร์มเรียบร้อย 🗑️', 'info');
    showToast('ลบแปลงเกษตรสำเร็จ!', 'info');
  }, [addLog, showToast]);

  const handleBuildAnimalPen = useCallback((animalType: 'chicken' | 'sheep' | 'cow' | 'goat') => {
    const levelReq = animalType === 'chicken' ? 2 : animalType === 'goat' ? 3 : animalType === 'sheep' ? 4 : 6;
    const cost = animalType === 'chicken' ? 400 : animalType === 'goat' ? 600 : animalType === 'sheep' ? 800 : 1500;

    if (level < levelReq) {
      showToast(`ต้องมีเลเวล ${levelReq} ขึ้นไปจึงจะสามารถสร้างได้!`, 'error');
      return;
    }
    if (coins < cost) {
      showToast(`เหรียญทองไม่เพียงพอ! ต้องการ ${cost.toLocaleString()} เหรียญ`, 'error');
      return;
    }

    const template = (ANIMAL_TEMPLATES as any)[animalType] || (animalType === 'goat' ? DEFAULT_GOAT_PEN : ANIMAL_TEMPLATES.chicken);
    const newPen: AnimalPen = { ...template, id: `pen_${animalType}_${Date.now()}` };

    setCoins((c) => c - cost);
    setAnimals((prev) => [...prev, newPen]);
    addXp(40);
    addLog(`สร้าง ${template.thaiName} สำเร็จ! (-${cost}🪙, +40XP)`, 'upgrade');
    showToast(`สร้าง ${template.thaiName} เรียบร้อยแล้ว! 🏡`, 'success');
  }, [level, coins, showToast, addXp, addLog]);

  const handleFeedAnimal = useCallback((penId: string) => {
    const pen = animals.find((a) => a.id === penId);
    if (!pen) return;
    if (energy < 1) {
      showToast('พลังงานไม่เพียงพอ! ⚡', 'error');
      return;
    }

    const feedItem = inventory[pen.feedCropId];
    if (!feedItem || feedItem.count < pen.feedRequired) {
      const cropName = CROPS[pen.feedCropId]?.thaiName || pen.feedCropId;
      showToast(`ต้องการ ${pen.feedRequired} ${cropName} เพื่อให้อาหาร!`, 'error');
      return;
    }

    setEnergy((e) => Math.max(0, e - 1));
    setInventory((prev) => ({
      ...prev,
      [pen.feedCropId]: { ...feedItem, count: feedItem.count - pen.feedRequired },
    }));

    setAnimals((prev) =>
      prev.map((p) => (p.id === penId ? { ...p, fedAt: Date.now(), isReady: false } : p))
    );

    addLog(`ให้อาหาร${pen.thaiName}เรียบร้อยแล้ว (-1⚡)`, 'info');
    showToast(`ให้อาหาร ${pen.thaiName} เรียบร้อย 🥣`, 'success');
  }, [animals, energy, inventory, showToast, addLog]);

  const handleCollectAnimal = useCallback((penId: string) => {
    const pen = animals.find((a) => a.id === penId);
    if (!pen || !pen.isReady) return;

    const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
    if (currentInventoryCount + pen.produceQuantity > barnCapacity) {
      showToast('โรงนาเต็มแล้ว! กรุณาเพิ่มความจุหรือขายผลผลิตก่อน', 'error');
      return;
    }

    try {
      if (pen.type === 'goat') {
        sound.playAnimal('cow');
      } else {
        sound.playAnimal(pen.type === 'sheep' ? 'cow' : pen.type);
      }
    } catch {
      sound.playHarvest();
    }

    setInventory((prev) => {
      const current = prev[pen.produceItem] || {
        id: pen.produceItem,
        name: pen.produceName,
        thaiName: pen.produceName,
        category: 'animal',
        count: 0,
        icon: pen.produceIcon,
        sellPrice: pen.type === 'goat' ? 45 : 50,
      };
      return {
        ...prev,
        [pen.produceItem]: { ...current, count: current.count + pen.produceQuantity },
      };
    });

    addXp(30);
    setCoins((c) => c + 80);

    setAnimals((prev) =>
      prev.map((p) => (p.id === penId ? { ...p, fedAt: null, isReady: false } : p))
    );

    setQuests((prev) =>
      prev.map((q) => (q.type === 'feed' ? { ...q, current: Math.min(q.target, q.current + 1) } : q))
    );

    addLog(`เก็บผลผลิต${pen.produceName}จาก${pen.thaiName}สำเร็จ! (+80🪙, +30XP)`, 'harvest');
    showToast(`เก็บ ${pen.produceName} เรียบร้อย! 🧺`, 'success');
  }, [animals, inventory, barnCapacity, showToast, addXp, addLog]);

  // ----------------------------------------------------
  // ระบบหมูชีวภาพ: การให้อาหาร เก็บผลผลิต และเคลื่อนย้าย
  // ----------------------------------------------------
  const handleOpenPigFeedMixer = useCallback((pigId: string) => {
    setSelectedPigForFeed(pigId);
    setActiveModal('pigMixer');
  }, []);

  const handleFeedPigMixer = useCallback((recipeType: 'mash' | 'truffle_mix') => {
    if (!selectedPigForFeed) return;

    const wheatCount = inventory['wheat']?.count || 0;
    const cornCount = inventory['corn']?.count || 0;
    const appleCount = inventory['apple']?.count || 0;

    let produceName = 'เบคอนพรีเมียม';
    let produceIcon = '🥓';

    if (recipeType === 'mash') {
      if (cornCount < 2 || wheatCount < 2) {
        showToast('วัตถุดิบไม่เพียงพอสำหรับผสมรำข้าวโพดหวาน!', 'error');
        return;
      }
      setInventory((prev) => ({
        ...prev,
        corn: { ...prev.corn, count: prev.corn.count - 2 },
        wheat: { ...prev.wheat, count: prev.wheat.count - 2 },
      }));
      produceName = 'เบคอนเกรดพรีเมียม';
      produceIcon = '🥓';
    } else {
      if (wheatCount < 3 || appleCount < 1) {
        showToast('วัตถุดิบไม่เพียงพอสำหรับผสมสลัดแอปเปิ้ลหมักทรัฟเฟิล!', 'error');
        return;
      }
      setInventory((prev) => ({
        ...prev,
        wheat: { ...prev.wheat, count: prev.wheat.count - 3 },
        apple: { ...prev.apple, count: prev.apple.count - 1 },
      }));
      produceName = 'เห็ดทรัฟเฟิลดำทองคำ';
      produceIcon = '🍄';
    }

    setPigs((prev) =>
      prev.map((p) =>
        p.id === selectedPigForFeed
          ? {
              ...p,
              fedAt: Date.now(),
              isReady: false,
              produceName,
              produceIcon,
            }
          : p
      )
    );

    sound.playLevelUp();
    addLog(`ผสมอาหารสูตร${recipeType === 'mash' ? 'รำข้าวโพดบด' : 'สลัดแอปเปิ้ลทรัฟเฟิล'}และป้อนหมูแล้ว 🥣`, 'info');
    showToast(`ป้อนอาหารให้หมูเรียบร้อย! หมูอารมณ์ดีมาก 🐷✨`, 'success');
    setActiveModal(null);
    setSelectedPigForFeed(null);
  }, [selectedPigForFeed, inventory, showToast, addLog]);

  const handleCollectPig = useCallback((pigId: string) => {
    const pig = pigs.find((p) => p.id === pigId);
    if (!pig || !pig.isReady) return;

    const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
    if (currentInventoryCount + 1 > barnCapacity) {
      showToast('โรงนาเต็มแล้ว! กรุณาเพิ่มความจุหรือขายสินค้าก่อนเก็บ', 'error');
      return;
    }

    const isTruffle = pig.produceName.includes('ทรัฟเฟิล');
    const rewardCoins = isTruffle ? 350 : 120;
    const rewardXp = isTruffle ? 120 : 45;
    const prodKey = isTruffle ? 'truffle_black' : 'bacon_premium';

    sound.playHarvest();

    setInventory((prev) => {
      const cur = prev[prodKey] || {
        id: prodKey,
        name: pig.produceName,
        thaiName: pig.produceName,
        category: 'special',
        count: 0,
        icon: pig.produceIcon,
        sellPrice: rewardCoins,
      };
      return {
        ...prev,
        [prodKey]: { ...cur, count: cur.count + 1 },
      };
    });

    setCoins((c) => c + rewardCoins);
    addXp(rewardXp);

    setPigs((prev) =>
      prev.map((p) =>
        p.id === pigId
          ? {
              ...p,
              fedAt: null,
              isReady: false,
            }
          : p
      )
    );

    addLog(`เก็บ ${pig.produceName} ${pig.produceIcon} สำเร็จ! (+${rewardCoins}🪙, +${rewardXp}XP)`, 'harvest');
    showToast(`เก็บ ${pig.produceName} เรียบร้อยแล้ว! 🧺✨`, 'success');
  }, [pigs, inventory, barnCapacity, showToast, addXp, addLog]);

  const handleMovePig = useCallback((pigId: string, newX: number, newY: number) => {
    setPigs((prev) => prev.map((p) => (p.id === pigId ? { ...p, x: newX, y: newY } : p)));
  }, []);

  const handleStartProduction = useCallback((factoryId: string, recipeId: string) => {
    const recipe = RECIPES[recipeId];
    if (!recipe) return;

    const hasAll = recipe.ingredients.every(
      (ing) => (inventory[ing.itemId]?.count ?? 0) >= ing.count
    );

    if (!hasAll) {
      showToast('วัตถุดิบในการผลิตไม่เพียงพอ!', 'error');
      return;
    }

    setInventory((prev) => {
      const updated = { ...prev };
      recipe.ingredients.forEach((ing) => {
        const it = updated[ing.itemId];
        if (it) updated[ing.itemId] = { ...it, count: it.count - ing.count };
      });
      return updated;
    });

    setFactories((prev) => ({
      ...prev,
      [factoryId]: {
        ...prev[factoryId],
        currentProduction: {
          recipeId,
          startedAt: Date.now(),
          durationSec: recipe.durationSec,
        },
      },
    }));

    addLog(`เริ่มผลิต${recipe.thaiName}ใน${factories[factoryId]?.thaiName}`, 'info');
    showToast(`เริ่มผลิต ${recipe.thaiName} แล้ว! 🍞`, 'success');
  }, [inventory, factories, showToast, addLog]);

  const handleSpeedUpProduction = useCallback((factoryId: string) => {
    if (gems < 2) {
      showToast('เพชรไม่เพียงพอ!', 'error');
      return;
    }
    const fac = factories[factoryId];
    if (!fac || !fac.currentProduction) return;

    sound.playSuccessChime();
    setGems((g) => g - 2);

    const finished = fac.currentProduction.recipeId;
    setFactories((prev) => ({
      ...prev,
      [factoryId]: {
        ...fac,
        currentProduction: null,
        completedItems: [...(fac.completedItems || []), finished],
      },
    }));

    addLog(`ใช้ 2💎 เร่งการผลิตใน${fac.thaiName}เสร็จสิ้นทันที!`, 'info');
    showToast('เร่งการผลิตเสร็จสมบูรณ์ทันที! ✨', 'success');
  }, [gems, factories, showToast, addLog]);

  const handleCollectProduct = useCallback((factoryId: string) => {
    const fac = factories[factoryId];
    if (!fac || !fac.completedItems || fac.completedItems.length === 0) return;

    const recipeId = fac.completedItems[0];
    const recipe = RECIPES[recipeId];
    if (!recipe) return;

    const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
    if (currentInventoryCount + recipe.outputCount > barnCapacity) {
      showToast('โรงนาเต็มแล้ว! กรุณาเพิ่มความจุหรือขายสินค้าก่อนเก็บ', 'error');
      return;
    }

    sound.playHarvest();

    setInventory((prev) => {
      const current = prev[recipe.id] || {
        id: recipe.id,
        name: recipe.name,
        thaiName: recipe.thaiName,
        category: 'factory',
        count: 0,
        icon: recipe.icon,
        sellPrice: recipe.sellPrice,
      };
      return {
        ...prev,
        [recipe.id]: { ...current, count: current.count + recipe.outputCount },
      };
    });

    addXp(recipe.xpReward);
    setQuests((prev) =>
      prev.map((q) =>
        q.type === 'produce' && (!q.targetType || q.targetType === recipe.id)
          ? { ...q, current: Math.min(q.target, q.current + 1) }
          : q
      )
    );

    setFactories((prev) => {
      const currentFac = prev[factoryId];
      if (!currentFac) return prev;
      const comp = [...(currentFac.completedItems || [])];
      comp.shift();

      return {
        ...prev,
        [factoryId]: { ...currentFac, completedItems: comp },
      };
    });

    addLog(`เก็บผลผลิต${recipe.thaiName}เข้าสู่คลังสำเร็จ!`, 'harvest');
    showToast(`เก็บ ${recipe.thaiName} สำเร็จ! 📦`, 'success');
  }, [inventory, barnCapacity, factories, showToast, addXp, addLog]);

  const handleFulfillOrder = useCallback((orderId: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const hasEnough = order.items.every(
      (it) => (inventory[it.itemId]?.count ?? 0) >= it.count
    );

    if (!hasEnough) {
      showToast('สินค้าในคลังไม่เพียงพอสำหรับการส่งออร์เดอร์!', 'error');
      return;
    }

    setInventory((prev) => {
      const updated = { ...prev };
      order.items.forEach((it) => {
        const item = updated[it.itemId];
        if (item) updated[it.itemId] = { ...item, count: item.count - it.count };
      });
      return updated;
    });

    setCoins((c) => c + order.rewardCoins);
    addXp(order.rewardXp);
    sound.playTruckHorn();

    setQuests((prev) =>
      prev.map((q) => (q.type === 'order' ? { ...q, current: Math.min(q.target, q.current + 1) } : q))
    );

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? generateLevelAppropriateOrder(level, orderId) : o))
    );

    addLog(`จัดส่งสินค้าให้ ${order.customerName} สำเร็จ! (+${order.rewardCoins}🪙)`, 'order');
    showToast(`จัดส่งสินค้าให้ ${order.customerName} เรียบร้อย! 🚚`, 'success');
  }, [orders, inventory, level, showToast, addXp, addLog]);

  const handleRefreshOrder = useCallback((orderId: string) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? generateLevelAppropriateOrder(level, orderId) : o))
    );
    showToast('รีเฟรชออร์เดอร์ใหม่เรียบร้อยแล้ว 🔄', 'info');
  }, [level, showToast]);

  const handlePickFruit = useCallback((type: 'apple' | 'orange') => {
    if (energy < 1) {
      showToast('พลังงานไม่เพียงพอสำหรับการเก็บผลไม้! ⚡', 'error');
      return;
    }

    const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
    if (currentInventoryCount + 2 > barnCapacity) {
      showToast('โรงนาเต็มแล้ว! กรุณาเพิ่มความจุหรือขายสินค้าก่อนเก็บ', 'error');
      return;
    }

    sound.playHarvest();
    const itemId = type === 'apple' ? 'apple' : 'orange';
    const itemName = type === 'apple' ? 'แอปเปิ้ลสด' : 'ส้มสายน้ำผึ้ง';
    const icon = type === 'apple' ? '🍎' : '🍊';

    setEnergy((e) => Math.max(0, e - 1));
    setInventory((prev) => {
      const cur = prev[itemId] || {
        id: itemId,
        name: itemName,
        thaiName: itemName,
        category: 'special',
        count: 0,
        icon,
        sellPrice: 35,
      };
      return {
        ...prev,
        [itemId]: { ...cur, count: cur.count + 2 },
      };
    });

    addXp(15);
    setCoins((c) => c + 30);
    fruitNextReadyAtRef.current[type] = Date.now() + 25000;
    setFruitReady((prev) => ({ ...prev, [type]: false }));

    addLog(`เก็บเกี่ยว${itemName} x2 สำเร็จ! (-1⚡, +15XP)`, 'harvest');
  }, [energy, inventory, barnCapacity, showToast, addXp, addLog]);

  const handleFeedCatFish = useCallback(() => {
    const fishKeys = ['fish_carp', 'fish_bass', 'fish_trout', 'fish_golden_catfish'];
    const availableFishKey = fishKeys.find((k) => (inventory[k]?.count || 0) > 0);

    if (!availableFishKey) {
      showToast('ไม่มีปลาสดในโรงนาเลย แวะไปตกปลาที่สระน้ำมรกตก่อนนะ 🐟', 'error');
      return;
    }

    const fishItem = inventory[availableFishKey];
    setInventory((prev) => ({
      ...prev,
      [availableFishKey]: {
        ...prev[availableFishKey],
        count: Math.max(0, prev[availableFishKey].count - 1),
      },
    }));

    setCoins((c) => c + 200);
    setGems((g) => g + 2);
    addXp(50);
    setLuckyFisherBuff((prev) => prev + 5);

    sound.playLevelUp();
    showToast(`🐱 เหมียววว! น้องแมวส้มกิน ${fishItem.thaiName} อย่างเอร็ดอร่อย (+200🪙, +2💎, +🍀 บัฟนำโชค 5 ครั้ง)!`, 'success');
    addLog(`ให้อาหาร ${fishItem.thaiName} แก่น้องแมวส้มริมบ่อปลา ได้รับพรนำโชค 🍀🐱`, 'info');
  }, [inventory, showToast, addXp, addLog]);

  const handleConsumeItems = useCallback((items: { itemId: string; count: number }[]) => {
    for (const it of items) {
      if ((inventory[it.itemId]?.count || 0) < it.count) return false;
    }
    setInventory((prev) => {
      const next = { ...prev };
      for (const it of items) {
        if (next[it.itemId]) {
          next[it.itemId] = { ...next[it.itemId], count: Math.max(0, next[it.itemId].count - it.count) };
        }
      }
      return next;
    });
    return true;
  }, [inventory]);

  const handleClaimQuest = useCallback((questId: string) => {
    const quest = quests.find((q) => q.id === questId);
    if (!quest || quest.claimed) return;

    setCoins((c) => c + quest.rewardCoins);
    addXp(quest.rewardXp);
    if (quest.rewardGems > 0) setGems((g) => g + quest.rewardGems);

    setQuests((prev) => prev.map((q) => (q.id === questId ? { ...q, claimed: true } : q)));

    addLog(`รับรางวัลภารกิจ: ${quest.thaiTitle} สำเร็จ!`, 'coin');
    showToast(`รับรางวัล ${quest.thaiTitle} เรียบร้อยแล้ว! ✨`, 'success');
  }, [quests, addXp, addLog, showToast]);

  const handleClaimDaily = useCallback((day: number) => {
    const target = dailyRewards.find((d) => d.day === day);
    if (!target || target.claimed) return;

    setCoins((c) => c + target.coins);
    setGems((g) => g + target.gems);

    setDailyRewards((prev) => prev.map((d) => (d.day === day ? { ...d, claimed: true } : d)));
    addLog(`เช็คอินวันที่ ${day} รับ +${target.coins}🪙 และ +${target.gems}💎 สำเร็จ!`, 'coin');
  }, [dailyRewards, addLog]);

  const handleSendGift = useCallback((friendId: string) => {
    setFriends((prev) => prev.map((f) => (f.id === friendId ? { ...f, giftSentToday: true } : f)));
    addXp(15);
    setCoins((c) => c + 50);
    addLog('ส่งกล่องของขวัญให้เพื่อนบ้านเรียบร้อยแล้ว (+15XP / +50🪙)', 'info');
  }, [addXp, addLog]);

  const handleHelpFriend = useCallback((friendId: string) => {
    setFriends((prev) => prev.map((f) => (f.id === friendId ? { ...f, needsHelp: false } : f)));
    addXp(25);
    setCoins((c) => c + 75);
    addLog('ช่วยเหลืองานในไร่ของเพื่อนบ้านสำเร็จ! ได้รับ +25XP และ +75🪙', 'coin');
  }, [addXp, addLog]);

  const handleResetGame = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(LEGACY_STORAGE_KEY);
    secureStorage.remove(STORAGE_KEY).catch(() => {});
    logSecurityEvent('reset_farm', 'ผู้เล่นทำการรีเซ็ตข้อมูลเกมเริ่มต้นใหม่ทั้งหมด');
    window.location.reload();
  }, []);

  const handleApplySnapshot = useCallback((rawSnapshot: any) => {
    if (!rawSnapshot || typeof rawSnapshot !== 'object') return;

    const { sanitized, valid, reason } = validateSnapshot(rawSnapshot);
    if (!valid && reason) {
      showToast(`ตรวจพบข้อมูลต้องปรับแก้: ${reason}`, 'info');
    }
    const snapshot = sanitized;

    if (typeof snapshot.coins === 'number') setCoins(snapshot.coins);
    if (typeof snapshot.gems === 'number') setGems(snapshot.gems);
    if (typeof snapshot.energy === 'number') setEnergy(snapshot.energy);
    if (typeof snapshot.maxEnergy === 'number') setMaxEnergy(snapshot.maxEnergy);
    if (typeof snapshot.level === 'number') setLevel(snapshot.level);
    if (typeof snapshot.xp === 'number') setXp(snapshot.xp);
    if (typeof snapshot.maxXp === 'number') setMaxXp(snapshot.maxXp);
    if (snapshot.farmName) setFarmName(sanitizeFarmName(snapshot.farmName));
    if (Array.isArray(snapshot.plots)) {
      setPlots(snapshot.plots.map((p, idx) => ensurePlotCoordinates(p, idx)));
    }
    if (Array.isArray(snapshot.animals)) {
      const seen = new Set<string>();
      const deduped = snapshot.animals.filter((a) => {
        if (!a || !a.id || seen.has(a.id)) return false;
        seen.add(a.id);
        return true;
      });
      setAnimals(deduped);
    }
    if (Array.isArray((rawSnapshot as any).pigs)) setPigs((rawSnapshot as any).pigs);
    if (snapshot.factories) setFactories(snapshot.factories);
    if (snapshot.inventory) setInventory(snapshot.inventory);
    if (typeof snapshot.barnCapacity === 'number') setBarnCapacity(snapshot.barnCapacity);
    if (Array.isArray(snapshot.quests)) setQuests(snapshot.quests);
    if (Array.isArray(snapshot.orders)) setOrders(snapshot.orders);
    if (Array.isArray(snapshot.friends)) setFriends(snapshot.friends);
    if (Array.isArray(snapshot.dailyRewards)) setDailyRewards(snapshot.dailyRewards);
    if (typeof snapshot.festivalPoints === 'number') setFestivalPoints(snapshot.festivalPoints);
    if (Array.isArray(snapshot.claimedTiers)) setClaimedTiers(snapshot.claimedTiers);
    if (Array.isArray(snapshot.farmLogs)) setFarmLogs(snapshot.farmLogs);
    if (Array.isArray(snapshot.mails)) setMails(snapshot.mails);

    try {
      const accountKey = getAccountSaveKey(currentUser?.id);
      const snapshotJson = JSON.stringify({ ...snapshot, pigs: (rawSnapshot as any).pigs || pigs });
      localStorage.setItem(accountKey, snapshotJson);
      localStorage.setItem(STORAGE_KEY, snapshotJson);
      secureStorage.set(accountKey, snapshot).catch(() => {});
    } catch {}

    addLog('โหลดข้อมูลและซิงก์ความคืบหน้าของฟาร์มสำเร็จ! ☁️✨', 'upgrade');
    showToast('ซิงก์ข้อมูลและโหลดเซฟสำเร็จเรียบร้อย! 🎉', 'success');
  }, [currentUser, pigs, addLog, showToast]);

  useEffect(() => {
    if (!showLoadingScreen) {
      const prompted = localStorage.getItem('beam_farm_auth_prompted_v1');
      if (!prompted && (!currentUser || currentUser.provider === 'guest')) {
        const timer = setTimeout(() => {
          setIsAuthModalOpen(true);
          localStorage.setItem('beam_farm_auth_prompted_v1', 'true');
        }, 800);
        return () => clearTimeout(timer);
      }
    }
  }, [showLoadingScreen, currentUser]);

  const handleLoginSuccess = useCallback((user: UserProfile) => {
    setCurrentUser(user);
    if (user.provider !== 'guest') {
      showToast(`ยินดีต้อนรับ ${user.displayName}! เข้าสู่ระบบสำเร็จ 🌾☁️`, 'success');
      const userSave = loadUserSaveData(user.id);
      if (userSave && Object.keys(userSave).length > 5) {
        handleApplySnapshot(userSave);
        addLog(`โหลดข้อมูลฟาร์มเดิมของบัญชี ${user.displayName} เรียบร้อยแล้ว`, 'info');
      } else {
        executeSaveSnapshot();
        addLog(`ผูกฟาร์มปัจจุบันเข้ากับบัญชี ${user.displayName} เรียบร้อยแล้ว`, 'upgrade');
      }
    } else {
      showToast('เข้าสู่โหมดผู้มาเยือน (Guest) เรียบร้อย', 'info');
    }
  }, [showToast, handleApplySnapshot, addLog, executeSaveSnapshot]);

  const handleLogout = useCallback(() => {
    logoutUser();
    setCurrentUser(null);
    showToast('ออกจากระบบเรียบร้อยแล้ว', 'info');
  }, [showToast]);

  const hudHeaderRef = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const el = hudHeaderRef.current;
    if (!el) return;
    const update = () => {
      document.documentElement.style.setProperty('--hud-h', `${Math.round(el.getBoundingClientRect().bottom)}px`);
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    window.addEventListener('resize', update);
    window.addEventListener('orientationchange', update);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', update);
      window.removeEventListener('orientationchange', update);
    };
  }, []);

  const unreadMails = mails.filter((m) => !m.claimed && m.reward).length;
  const uncompletedQuests = quests.filter((q) => q.current >= q.target && !q.claimed).length;

  return (
    <div className="relative w-full h-[100dvh] overflow-hidden select-none bg-stone-900 font-['Kanit',sans-serif]">
      {/* 1. Farm Canvas Layer พร้อมเรนเดอร์หมู 3 มิติ และแพะนม 3 มิติ */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden">
        <FarmWorld
          plots={plots}
          animals={animals}
          factories={factories}
          onPlotClick={handleOpenPlot}
          onHarvestPlot={handleHarvestPlot}
          onSpeedUpPlot={handleSpeedUpPlot}
          onMovePlot={handleMovePlot}
          onDeletePlot={handleDeletePlot}
          onAddPlot={handleAddPlot}
          onAnimalClick={(animalId) => {
            if (animalId) {
              const targetPen = animals.find((a) => a.id === animalId);
              if (targetPen && !targetPen.fedAt && !targetPen.isReady) {
                const feedItem = inventory[targetPen.feedCropId];
                if (feedItem && feedItem.count >= targetPen.feedRequired && energy >= 1) {
                  handleFeedAnimal(animalId);
                  return;
                }
              }
            }
            setActiveModal('animals');
          }}
          onCollectAnimal={handleCollectAnimal}
          onFactoryClick={(id) => {
            setSelectedFactoryId(id);
            setActiveModal('production');
          }}
          onCollectFactory={(id) => {
            handleCollectProduct(id);
          }}
          onOpenBarn={() => setActiveModal('inventory')}
          onOpenTruckOrders={() => setActiveModal('market')}
          onPickFruit={handlePickFruit}
          onFish={() => setActiveModal('fishing')}
          fruitReady={fruitReady}
          inventory={inventory}
          onFeedCatFish={handleFeedCatFish}
          currentFarmId={currentFarmId}
          // ส่วนขยายหมู 3D:
          pigs={pigs}
          onFeedPigClick={handleOpenPigFeedMixer}
          onCollectPigClick={handleCollectPig}
          onMovePig={handleMovePig}
        />
      </div>

      {/* 2. Floating Zen Mode Restore Button */}
      {isZenMode && (
        <button
          onClick={() => {
            sound.playClick();
            setIsZenMode(false);
          }}
          className="hud-zen-restore fixed top-3 right-3 z-50 flex items-center gap-1.5 px-3 py-1.5 bg-amber-950/90 text-amber-200 border-2 border-amber-400 rounded-full shadow-2xl backdrop-blur-md active:scale-95 transition-all text-xs font-bold cursor-pointer"
        >
          <Eye className="w-4 h-4 text-amber-300" />
          <span>เปิดเมนู</span>
        </button>
      )}

      {/* 3. HUD & Menus Overlay */}
      <div
        className={`hud-overlay absolute inset-0 w-full h-full pointer-events-none z-10 flex flex-col justify-between transition-opacity duration-300 ${
          isZenMode ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
      >
        {/* Top Header */}
        <header ref={hudHeaderRef} className="hud-header pointer-events-auto w-full flex items-center justify-between">
          <div className="flex-1">
            <TopHUD
              coins={coins}
              gems={gems}
              energy={energy}
              maxEnergy={maxEnergy}
              energyTimer={energyTimerDisplay}
              level={level}
              xp={xp}
              maxXp={maxXp}
              farmName={farmName}
              soundEnabled={soundEnabled}
              musicEnabled={musicEnabled}
              onToggleSound={() => {
                setSoundEnabled((s) => {
                  sound.soundEnabled = !s;
                  return !s;
                });
              }}
              onToggleMusic={() => {
                setMusicEnabled((m) => {
                  sound.toggleMusic(!m);
                  return !m;
                });
              }}
              onOpenSettings={() => setActiveModal('settings')}
              onOpenMail={() => setActiveModal('mail')}
              onOpenFriends={() => setActiveModal('friends')}
              onOpenShop={(tab) => {
                setShopInitialTab(tab || 'seeds');
                setActiveModal('shop');
              }}
              onOpenCloudSync={() => setActiveModal('cloud_sync')}
              onOpenAuth={() => setIsAuthModalOpen(true)}
              currentUser={currentUser}
              unreadMailCount={unreadMails}
            />
          </div>

          <div className="hud-tools flex items-center gap-1 sm:gap-2 mr-2 sm:mr-3">
            <button
              onClick={() => {
                sound.playClick();
                setIsZenMode(true);
              }}
              className="flex items-center justify-center p-1.5 sm:p-2 bg-stone-800/80 hover:bg-stone-700 text-amber-300 border border-amber-500/50 rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
              title="ซ่อน UI ชั่วคราว เพื่อชมฟาร์มแบบเต็มจอ"
            >
              <EyeOff className="w-4 h-4 text-amber-300" />
              <span className="hidden md:inline ml-1 text-xs font-bold">ซ่อน UI</span>
            </button>

            <button
              onClick={toggleFullScreen}
              className="flex items-center justify-center p-1.5 sm:p-2 bg-stone-800/80 hover:bg-stone-700 text-amber-300 border border-amber-500/50 rounded-xl shadow-lg transition-transform active:scale-95 cursor-pointer"
              title={isFullscreen ? 'ออกจากโหมดเต็มจอ' : 'เล่นแบบเต็มหน้าจอ (Fullscreen)'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              <span className="hidden sm:inline ml-1 text-xs font-bold">{isFullscreen ? 'ย่อจอ' : 'เต็มจอ'}</span>
            </button>
          </div>
        </header>

        {/* Side Actions */}
        <div className="flex-1 relative w-full pointer-events-none">
          <LeftMenu
            questCount={uncompletedQuests}
            onOpenQuests={() => setActiveModal('quests')}
            onOpenEvents={() => setActiveModal('events')}
            onOpenDaily={() => setActiveModal('daily')}
          />

          <RightMenu
            giftCountdown={giftCountdownDisplay}
            isGiftReady={isGiftReady}
            onOpenShop={() => {
              setShopInitialTab('seeds');
              setActiveModal('shop');
            }}
            onOpenMarket={() => setActiveModal('market')}
            onOpenGift={() => setActiveModal('gift')}
            onOpenFestival={() => setActiveModal('events')}
          />
        </div>

        {/* Floating Nai Chod Button */}
        <div className="chod-fab pointer-events-auto pl-2 sm:pl-4 pb-1 self-start">
          <button
            onClick={() => {
              sound.playClick();
              setIsAiChodOpen(true);
            }}
            className="group flex items-center bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 hover:from-amber-600 hover:to-amber-800 text-white rounded-full sm:rounded-2xl shadow-2xl border-2 border-amber-300 active:scale-95 transition-all p-1 sm:px-3 sm:py-2 cursor-pointer"
            title="คุยกับนายชด AI ปราชญ์ชาวสวน (มีเสียงพูด)"
          >
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center text-xl sm:text-2xl shadow-inner group-hover:rotate-12 transition-transform flex-shrink-0">
              👨‍🌾
              <span className="sm:hidden absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border border-stone-900 animate-pulse" />
            </div>

            <div className="hidden sm:block text-left font-kanit leading-tight pl-2 pr-1">
              <div className="text-xs font-bold text-amber-200 flex items-center gap-1">
                นายชด AI
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <div className="text-[10px] text-amber-300/90 font-medium">มีเสียงพูด • ปรึกษาฟาร์ม</div>
            </div>
          </button>
        </div>

        {/* Bottom Dock */}
        <footer className="pointer-events-auto w-full pb-safe">
          <BottomDock
            logs={farmLogs}
            inventoryBadge={Object.values(inventory).filter((i) => i.count > 0).length}
            onOpenMap={() => setActiveModal('map')}
            onOpenInventory={() => setActiveModal('inventory')}
            onOpenBuild={() => setActiveModal('build')}
            onOpenAnimals={() => setActiveModal('animals')}
            onOpenProduction={() => {
              setSelectedFactoryId('bakery');
              setActiveModal('production');
            }}
            onOpenMarket={() => setActiveModal('market')}
            onOpenFriends={() => setActiveModal('friends')}
            onOpenLogoInfo={() => setActiveModal('logoInfo')}
          />
        </footer>
      </div>

      {/* 4. Modals Layer */}
      <AppModals
        activeModal={activeModal}
        onCloseModal={() => setActiveModal(null)}
        setActiveModal={setActiveModal}
        level={level}
        coins={coins}
        gems={gems}
        energy={energy}
        maxEnergy={maxEnergy}
        xp={xp}
        maxXp={maxXp}
        farmName={farmName}
        setFarmName={setFarmName}
        barnCapacity={barnCapacity}
        currentUpgradeCost={currentUpgradeCost}
        inventory={inventory}
        factories={factories}
        selectedFactoryId={selectedFactoryId}
        animals={animals}
        orders={orders}
        quests={quests}
        festivalPoints={festivalPoints}
        claimedTiers={claimedTiers}
        dailyRewards={dailyRewards}
        friends={friends}
        visitingFriend={visitingFriend}
        setVisitingFriend={setVisitingFriend}
        shopInitialTab={shopInitialTab}
        mails={mails}
        plots={plots}
        farmLogs={farmLogs}
        soundEnabled={soundEnabled}
        musicEnabled={musicEnabled}
        onToggleSound={() => {
          setSoundEnabled((s) => {
            sound.soundEnabled = !s;
            return !s;
          });
        }}
        onToggleMusic={() => {
          setMusicEnabled((m) => {
            sound.toggleMusic(!m);
            return !m;
          });
        }}
        onResetGame={handleResetGame}
        isGiftReady={isGiftReady}
        giftCountdownDisplay={giftCountdownDisplay}
        levelUpData={levelUpData}
        setLevelUpData={setLevelUpData}
        showLoadingScreen={showLoadingScreen}
        setShowLoadingScreen={setShowLoadingScreen}
        onFinishLoading={() => {
          setShowLoadingScreen(false);
          if (musicEnabled) {
            sound.startBGM();
          }
        }}
        onSelectCrop={handlePlantCrop}
        onSellItem={handleSellItem}
        onUpgradeCapacity={handleUpgradeCapacity}
        onStartProduction={handleStartProduction}
        onSpeedUpProduction={handleSpeedUpProduction}
        onCollectProduct={handleCollectProduct}
        onFeedAnimal={handleFeedAnimal}
        onCollectAnimal={handleCollectAnimal}
        onBuildAnimalPen={handleBuildAnimalPen}
        onFulfillOrder={handleFulfillOrder}
        onRefreshOrder={handleRefreshOrder}
        onClaimQuest={handleClaimQuest}
        onClaimMilestone={(tier) => {
          setClaimedTiers((prev) => [...prev, tier]);
          setCoins((c) => c + tier * 500);
          setGems((g) => g + tier * 5);
          addLog(`รับรางวัลขั้นที่ ${tier} ของเทศกาลเก็บเกี่ยวแล้ว!`, 'coin');
        }}
        onClaimDaily={handleClaimDaily}
        onSendGift={handleSendGift}
        onHelpFriend={handleHelpFriend}
        onAddFriend={(code) => {
          const newF: Friend = {
            id: `f_${Date.now()}`,
            name: `เพื่อนใหม่ (${code})`,
            avatar: '🧑‍🌾',
            level: 1,
            farmName: 'Cozy Valley',
            giftSentToday: false,
            needsHelp: true,
            helpType: 'ช่วยรดน้ำแปลงผัก',
            isOnline: true,
          };
          setFriends((prev) => [...prev, newF]);
        }}
        onBuySeeds={(cropId, count, cost) => {
          const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
          if (currentInventoryCount + count > barnCapacity) {
            showToast('โรงนาเต็มแล้ว! กรุณาเพิ่มความจุหรือขายสินค้าก่อนซื้อเพิ่ม', 'error');
            return;
          }

          const reqLvl = CROP_UNLOCK_LEVELS[cropId] || 1;
          if (level < reqLvl) {
            showToast(`พืชนี้ปลดล็อกที่เลเวล ${reqLvl}!`, 'error');
            return;
          }
          if (coins < cost) {
            showToast('เหรียญทองไม่เพียงพอสำหรับการซื้อเมล็ดพันธุ์!', 'error');
            return;
          }
          setCoins((c) => c - cost);
          const crop = CROPS[cropId];
          setInventory((prev) => {
            const cur = prev[cropId] || {
              id: cropId,
              name: crop.name,
              thaiName: crop.thaiName,
              category: 'crops',
              count: 0,
              icon: crop.icon,
              sellPrice: crop.sellPrice,
            };
            return {
              ...prev,
              [cropId]: { ...cur, count: cur.count + count },
            };
          });
          addLog(`ซื้อเมล็ดพันธุ์ ${crop.thaiName} x${count} สำเร็จ!`, 'info');
        }}
        onBuyPlot={handleAddPlot}
        onRefillEnergy={() => {
          if (gems < 5) {
            showToast('เพชรไม่เพียงพอ!', 'error');
            return;
          }
          setGems((g) => g - 5);
          setEnergy(maxEnergy);
          addLog('เติมพลังงานเต็มพิกัดแล้ว! ⚡', 'info');
        }}
        onExchangeGemsForCoins={(costGems, gainCoins) => {
          if (gems < costGems) {
            showToast('เพชรไม่เพียงพอ!', 'error');
            return;
          }
          setGems((g) => g - costGems);
          setCoins((c) => c + gainCoins);
          addLog(`แลกเปลี่ยน ${costGems}💎 เป็น ${gainCoins.toLocaleString()}🪙 สำเร็จ!`, 'coin');
        }}
        onClaimMail={(mailId) => {
          const mail = mails.find((m) => m.id === mailId);
          if (!mail || !mail.reward || mail.claimed) return;
          const reward = mail.reward;

          if (reward.coins) setCoins((c) => c + (reward.coins ?? 0));
          if (reward.gems) setGems((g) => g + (reward.gems ?? 0));
          if (reward.energy) setEnergy((e) => Math.min(maxEnergy, e + (reward.energy ?? 0)));

          setMails((prev) =>
            prev.map((m) => (m.id === mailId ? { ...m, claimed: true, read: true } : m))
          );
          addLog('รับของขวัญจากกล่องจดหมายสำเร็จ! 💌', 'coin');
          showToast('รับของขวัญจากกล่องจดหมายเรียบร้อย!', 'success');
        }}
        onTravel={(locName) => {
          if (
            locName === 'fishing' ||
            locName.includes('fishing') ||
            locName.includes('ท่าน้ำ')
          ) {
            setActiveModal('fishing');
          } else {
            addLog(`เดินทางสู่ ${locName} เรียบร้อยแล้ว`, 'info');
            setActiveModal(null);
          }
        }}
        onBuildDecoration={(name, cost) => {
          if (coins < cost) {
            showToast('เหรียญทองไม่เพียงพอสำหรับการก่อสร้าง!', 'error');
            return;
          }
          setCoins((c) => c - cost);
          addLog(`สร้าง ${name} ในฟาร์มสำเร็จ! (-${cost}🪙)`, 'upgrade');
          showToast(`สร้าง ${name} สำเร็จ! 🔨`, 'success');
          setActiveModal(null);
        }}
        onApplySnapshot={handleApplySnapshot}
        onClaimGift={(rew) => {
          setCoins((c) => c + rew.coins);
          setGems((g) => g + rew.gems);
          setEnergy((e) => Math.min(maxEnergy, e + rew.energy));
          nextGiftTimestampRef.current = Date.now() + 1800000;
          setIsGiftReady(false);
          addLog(`เปิดกล่องของขวัญนำโชค ได้รับ +${rew.coins}🪙 และ +${rew.gems}💎!`, 'coin');
          showToast('รับของขวัญนำโชคเรียบร้อยแล้ว! 🎁', 'success');
        }}
        onUpdateFarmName={(name) => {
          const sanitized = sanitizeFarmName(name);
          setFarmName(sanitized);
          addLog(`เปลี่ยนชื่อฟาร์มเป็น "${sanitized}" เรียบร้อยแล้ว`, 'info');
        }}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        currentUser={currentUser}
        onConsumeEnergy={(cost) => {
          if (energy >= cost) {
            setEnergy((e) => Math.max(0, e - cost));
            return true;
          }
          return false;
        }}
        onAddRewards={(rCoins, rXp) => {
          setCoins((c) => c + rCoins);
          addXp(rXp);
        }}
        onAddFishToInventory={(fish, weight) => {
          const currentInventoryCount = Object.values(inventory).reduce((acc, it) => acc + it.count, 0);
          if (currentInventoryCount + 1 > barnCapacity) {
            showToast('โรงนาเต็มแล้ว! กรุณาเพิ่มความจุหรือขายสินค้าก่อนเก็บปลา', 'error');
            return;
          }

          setInventory((prev) => {
            const cur = prev[fish.id] || {
              id: fish.id,
              name: fish.name,
              thaiName: `${fish.thaiName} (${weight} กก.)`,
              category: 'special',
              count: 0,
              icon: fish.icon,
              sellPrice: fish.price,
            };
            return {
              ...prev,
              [fish.id]: { ...cur, count: cur.count + 1 },
            };
          });

          setQuests((prev) =>
            prev.map((q) => {
              if (q.type === 'fish') {
                if (q.id === 'q_fish_1') {
                  return { ...q, current: Math.min(q.target, q.current + 1) };
                }
                if (q.id === 'q_fish_2' && weight >= 3.0) {
                  return { ...q, current: Math.min(q.target, q.current + 1) };
                }
              }
              return q;
            })
          );

          addLog(`🎣 ตกได้ ${fish.thaiName} (${weight} กก.) จากสระมรกต! (+${fish.price}🪙 / +${fish.xp}XP)`, 'info');
          showToast(`🎣 ได้รับ ${fish.thaiName} (${weight} กก.) เข้าโรงนาแล้ว!`, 'success');
        }}
        onConsumeItems={handleConsumeItems}
        luckyFisherBuff={luckyFisherBuff}
        onConsumeLuckyBuff={() => setLuckyFisherBuff((prev) => Math.max(0, prev - 1))}
        currentFarmId={currentFarmId}
        onSwitchFarm={handleSwitchFarm}
      />

      {/* 5. 🥣 หน้าต่างเครื่องผสมอาหารหมูชีวภาพ & ทะเบียนประวัติ */}
      <PigFeedMixerModal
        isOpen={activeModal === 'pigMixer'}
        onClose={() => {
          setActiveModal(null);
          setSelectedPigForFeed(null);
        }}
        inventory={inventory}
        onFeedPig={handleFeedPigMixer}
        pig={pigs.find((p) => p.id === selectedPigForFeed)}
      />

      {/* 6. 👨‍🌾 หน้าต่าง AI แชตนายชด */}
      <AiChodChatModal
        isOpen={isAiChodOpen}
        onClose={() => setIsAiChodOpen(false)}
        farmContext={{
          coins,
          gems,
          level,
          energy,
          maxEnergy,
          barnCapacity,
          inventory,
          plots,
          animals,
          factories,
          orders,
        }}
      />

      {/* 7. 🔐 หน้าต่าง Authentication */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onLoginSuccess={handleLoginSuccess}
        onLogout={handleLogout}
      />

      {/* 8. Floating System Toast */}
      <Toast toast={toast} />
    </div>
  );
}